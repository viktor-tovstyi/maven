package com.nave.anteater.web;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.nave.anteater.ChoiceTaskRunner;
import com.nave.anteater.AELogRecord;
import com.nave.anteater.TestRunner;

public class WebLogger extends Logger {

	private List<WebLogRecord> logRecords = new ArrayList<WebLogRecord>();
	private TestRunner testRunner;
	private Object monitor = new Object();
	private WebInputItem input;
	private int maxRecordsInMemory = 50;
	private int startIndex = 0;
	private Logger logger;

	protected WebLogger(String name) {
		super(name);
		logger = Logger.getLogger(getName());
	}

	public void error(Object message) {
		addLogRecord(null, message, Level.ERROR, null);
	}

	public void error(Object message, Throwable t) {
		addLogRecord(null, message, Level.ERROR, t);
	}

	public void debug(Object message) {
		addLogRecord(null, message, Level.DEBUG, null);
	}

	public void debug(Object message, Throwable t) {
		addLogRecord(null, message, Level.DEBUG, t);
	}

	public void info(Object message) {
		addLogRecord(null, message, Level.INFO, null);
	}

	public void info(Object message, Throwable t) {
		addLogRecord(null, message, Level.INFO, t);
	}

	public void warn(Object message) {
		addLogRecord(null, message, Level.WARN, null);
	}

	public void warn(Object message, Throwable t) {
		addLogRecord(null, message, Level.WARN, t);
	}

	private void addLogRecord(String varName, Object message, Level level, Throwable t) {
		WebLogRecord element;

		if (message instanceof AELogRecord) {
			AELogRecord rec = (AELogRecord) message;
			element = new WebLogRecord(rec, level, varName);
		} else {
			String text = ObjectUtils.toString(message);
			element = new WebLogRecord(new AELogRecord(text, "txt", varName), level, varName);
		}

		if (t != null) {
			element.setTrace(ExceptionUtils.getStackTrace(t));
		}

		String text = ObjectUtils.toString(message);
		if (Level.DEBUG.toString().equals(level.toString())) {
			logger.debug(text, t);
		} else if (Level.INFO.toString().equals(level.toString())) {
			logger.info(text, t);
		} else if (Level.WARN.toString().equals(level.toString())) {
			logger.warn(text, t);
		} else if (Level.ERROR.toString().equals(level.toString())) {
			logger.error(text, t);
		}

		if (logRecords.size() == maxRecordsInMemory) {
			logRecords.remove(0);
			startIndex++;
		}
		logRecords.add(element);
	}

	public List<WebLogRecord> getLog(int id) {
		List<WebLogRecord> result = new ArrayList<WebLogRecord>();
		int startIndex = id - this.startIndex;
		if (startIndex < 0) {
			startIndex = 0;
		}
		for (int i = startIndex; i < logRecords.size(); i++) {
			WebLogRecord record = logRecords.get(i);
			record.setId(i + this.startIndex);
			result.add(record);
		}
		return result;
	}

	public void setTestRunner(TestRunner testRunner) {
		this.testRunner = testRunner;
	}

	public TestRunner getTestRunner() {
		return testRunner;
	}

	public String inputValue(String aDesc, String aName, String aValue) {
		input = new WebInputItem(aDesc, aName, aValue);
		synchronized (monitor) {
			try {
				monitor.wait();
			} catch (InterruptedException e) {
				//
			}
		}
		String value = input.getValue();
		input = null;
		return value;
	}

	public void applyInput(String[] value) {
		if (input instanceof WebChoiceItem) {
			if (input != null) {
				((WebChoiceItem) input).select(value);
			}
		} else if (input instanceof WebInputItem) {
			if (input != null) {
				if (ArrayUtils.isNotEmpty(value)) {
					input.setValue(value[0]);
				}
			}
		}
		synchronized (monitor) {
			monitor.notify();
		}
	}

	public WebInputItem getInput() {
		return input;
	}

	public void inputChoice(ChoiceTaskRunner tasksChoice) {
		input = new WebChoiceItem(tasksChoice);
		synchronized (monitor) {
			try {
				monitor.wait();
			} catch (InterruptedException e) {
				//
			}
		}
		tasksChoice.start();
		input = null;
	}

	public String inputSelectChoice(String aNameDialog, String[] aValues, String aDefaultValue) {
		input = new WebSelectItem(aNameDialog, aValues, aDefaultValue);
		synchronized (monitor) {
			try {
				monitor.wait();
			} catch (InterruptedException e) {
				//
			}
		}
		String value = input.getValue();
		input = null;
		return value;
	}

	public String inputChoiceValue(String desc, String name, Object[] aPossibleValues, String value) {
		input = new WebSelectItem(name, aPossibleValues, value);
		synchronized (monitor) {
			try {
				monitor.wait();
			} catch (InterruptedException e) {
				//
			}
		}
		value = input.getValue();
		if (WebSelectItem.CANCEL_X == value) {
			value = null;
		}
		input = null;
		return value;
	}

	public String inputFile(String name, File aDefaultFile, Logger log) {
		input = new FileUploadItem(name, aDefaultFile);
		synchronized (monitor) {
			try {
				monitor.wait();
			} catch (InterruptedException e) {
				//
			}
		}
		String value = input.getValue();
		if (WebSelectItem.CANCEL_X == value) {
			value = null;
		}
		input = null;
		return value;
	}
	
	public WebLogRecord getRecord(int id) {
		int index = id - startIndex;
		if (index < 0) {
			return new WebLogRecord(new AELogRecord("The record is no longer in a memory. Please see server log file .", "txt", null), Level.ERROR, null);
		}
		return logRecords.get(index);
	}

	public void reset() {
		synchronized (monitor) {
			monitor.notify();
		}
	}

	public int getStartIndex() {
		return startIndex;
	}

	synchronized public void moveToArchive() {
		this.startIndex = logRecords.size();
		logRecords.clear();
	}

}
