package com.nave.anteater.web;

import java.io.File;
import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.nave.anteater.AELogRecord;
import com.nave.anteater.AEWorkspace;
import com.nave.anteater.ChoiceTaskRunner;
import com.nave.anteater.ILogger;
import com.nave.anteater.MultiTaskRunDialog;
import com.nave.anteater.TestRunner;
import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.xml.easyparser.Node;

@Component("workspace")
public class WebWorkspace extends AEWorkspace implements InitializingBean {

	@Value(".")
	public File root;

	public static final String CONFIG_LOG_NAME = TaskProcessor.STARTUP;
	private Map<String, WebLogger> logs = new TreeMap<String, WebLogger>();

	public WebWorkspace() {
		super();
	}

	protected TestRunner createTestRunner(String name) {
		name = StringUtils.defaultString(name, TaskProcessor.STARTUP);
		TestRunner testRunner = new TestRunner(this);
		WebLogger log = logs.get(name);
		if (log == null) {
			log = new WebLogger(name);
			logs.put(name, log);
		}

		testRunner.setLog(log);
		log.setTestRunner(testRunner);
		TaskProcessor processor = new TaskProcessor(this, log, getStartDir());
		processor.setTestListener(testRunner);
		testRunner.setProcessor(processor);
		return testRunner;
	}

	public void afterPropertiesSet() {

		Thread thread = new Thread() {
			public void run() {
				try {
					WebLogger webLogger = getLog(CONFIG_LOG_NAME);
					webLogger.info("Configuration loading starting ...");
					loadConfiguration(true);
					webLogger.debug(new AELogRecord(getAllConfigNode().getXMLText(), "xml", null));
					webLogger.debug(new AELogRecord(getTasksMap(), "properties", null));
					webLogger.debug(new AELogRecord(getSystemVariables(), "properties", null));
					Node configNode = getConfigNode();
					if (configNode != null) {
						webLogger.info(new AELogRecord(configNode.getXMLText(), "xml", null));
					}

					runSetupNodes();

				} catch (Exception e) {
					WebLogger webLogger = getLog(CONFIG_LOG_NAME);
					webLogger.error("Configuration loading failed.", e);
				}
			}
		};
		thread.start();
	}

	public Map<String, WebLogger> getLogs() {
		return logs;
	}

	protected String selectConfiguration(String[] aPossibleValues) {
		WebLogger webLogger = getLog(CONFIG_LOG_NAME);
		String theDefaultConfiguration = getDefaultUserConfiguration(".defaultConfiguration", null);
		String inputChoiceValue = webLogger.inputChoiceValue("Select", "Configuration", aPossibleValues,
				theDefaultConfiguration);
		setDefaultUserConfiguration(".defaultConfiguration", inputChoiceValue);
		return inputChoiceValue;
	}

	public WebLogger getLog(String name) {
		WebLogger webLogger = logs.get(name);
		if (webLogger == null) {
			webLogger = new WebLogger(name);
			logs.put(name, webLogger);
		}
		return webLogger;
	}

	@Override
	public MultiTaskRunDialog tasksChoice(MultiTaskRunDialog mt, String[] list, boolean exceptionIgnoreFlag,
			Object setup, TaskProcessor taskProcessor, boolean visible) {
		ChoiceTaskRunner tasksChoice = (ChoiceTaskRunner) super.tasksChoice(mt, list, exceptionIgnoreFlag, setup,
				taskProcessor, visible);
		if (!defaultMode) {
			WebLogger weblog = (WebLogger) taskProcessor.getLogger();
			weblog.inputChoice(tasksChoice);
			if (setup == null) {
				setDefaultUserConfiguration("MultiTaskRunDialog:" + tasksChoice.getName(),
						StringUtils.join(tasksChoice.getSelectedTasks(), ';'));
			}
		}
		return tasksChoice;
	}

	@Override
	public String inputValue(String aDesc, String aName, String aValue, ILogger log, String type, boolean notifyMe) {
		// TODO: type should be used
		WebLogger weblog = (WebLogger) log;
		if (!defaultMode) {
			aValue = weblog.inputValue(aDesc, aName, aValue);
		}
		return aValue;
	}

	public String inputSelectChoice(String aNameDialog, String[] aValues, String aDefaultValue,
			TaskProcessor taskProcessor, boolean notifyMe) {
		WebLogger weblog = (WebLogger) taskProcessor.getLogger();
		aDefaultValue = super.inputSelectChoice(aNameDialog, aValues, aDefaultValue, taskProcessor, notifyMe);
		if (!defaultMode) {
			aDefaultValue = weblog.inputSelectChoice(aNameDialog, aValues, aDefaultValue);
		}
		return aDefaultValue;
	}

	public String choiceValue(String desc, String name, Object[] aPossibleValues, ILogger log, boolean notifyMe) {
		String value = super.choiceValue(desc, name, aPossibleValues, log, notifyMe);
		if (!defaultMode) {
			WebLogger weblog = (WebLogger) log;
			value = weblog.inputChoiceValue(desc, name, aPossibleValues, value);
		}
		return value;
	}

	@Override
	public File getStartDir() {
		String workingDir = System.getenv("AE_WORKING_DIR");
		File file;
		if (workingDir != null) {
			file = new File(workingDir);
		} else {
			file = new File(root, "ae");
		}
		file = new File(workingDir);
		return file;
	}

	@Override
	public void resetConfiguration() {
		Collection<WebLogger> logs = this.logs.values();
		for (WebLogger webLogger : logs) {
			TestRunner testRunner = webLogger.getTestRunner();
			if (testRunner != null) {
				testRunner.stopTest();
				webLogger.reset();
			}
		}
		super.resetConfiguration();
	}

	@Override
	public String inputFile(String name, File aDefaultFile, ILogger log, TaskProcessor tp) {
		String value = super.inputFile(name, aDefaultFile, log, tp);
		if (!defaultMode) {
			WebLogger weblog = (WebLogger) log;
			value = weblog.inputFile(name, aDefaultFile, log);
		}
		return value;
	}

	@Override
	public boolean confirmation(TaskProcessor unit, String description, String message, boolean notifyMe) throws Exception {
		// TODO: SHOULD BE IMPLEMENTED
		WebLogger webLogger = (WebLogger) unit.getLogger();
		Object[] aPossibleValues = new String[] { "Yes", "No" };
		String inputChoiceValue = webLogger.inputChoiceValue("Select", message, aPossibleValues, null);
		return "yes".equalsIgnoreCase(inputChoiceValue);
	}
}
