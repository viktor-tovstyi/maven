package com.nave.anteater.web;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class ConfigUploadController {

	@Autowired
	private WebWorkspace workspace;

	@RequestMapping(value = "/upload-configuration", method = RequestMethod.POST)
	public RedirectView handleFileUpload(@RequestParam("file") MultipartFile file) {
		if (!file.isEmpty()) {
			try {
				unZipIt(file.getInputStream());
				workspace.afterPropertiesSet();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return new RedirectView("dashboard");
	}

	public void unZipIt(InputStream zipStream) throws IOException {

		byte[] buffer = new byte[1024];

		File folder = workspace.getStartDir();
		if (!folder.exists()) {
			folder.delete();
			folder.mkdir();
		}

		ZipInputStream zis = new ZipInputStream(zipStream);
		ZipEntry ze = zis.getNextEntry();

		while (ze != null) {

			String fileName = ze.getName();
			File newFile = new File(folder, fileName);

			System.out.println("file unzip : " + newFile.getAbsoluteFile());
			if (ze.isDirectory()) {
				newFile.mkdir();

			} else {

				FileOutputStream fos = new FileOutputStream(newFile);

				int len;
				while ((len = zis.read(buffer)) > 0) {
					fos.write(buffer, 0, len);
				}

				fos.close();
			}
			ze = zis.getNextEntry();
		}

		zis.closeEntry();
		zis.close();

		System.out.println("Done");

	}
}
