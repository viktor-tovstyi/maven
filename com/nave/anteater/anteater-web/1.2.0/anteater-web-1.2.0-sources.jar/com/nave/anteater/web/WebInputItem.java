package com.nave.anteater.web;

public class WebInputItem {

	private String value;
	private String desc;
	private String name;

	public WebInputItem(String aDesc, String aName, String aValue) {
		this.desc = aDesc;
		this.name = aName;
		this.value = aValue;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDesc() {
		return desc;
	}

	public String getName() {
		return name;
	}

	
}
