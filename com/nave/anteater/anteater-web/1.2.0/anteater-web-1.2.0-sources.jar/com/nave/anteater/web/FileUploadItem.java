package com.nave.anteater.web;

import java.io.File;

public class FileUploadItem extends WebInputItem {

	public FileUploadItem(String name, File aDefaultFile) {
		super("File uploading.", name, aDefaultFile == null ? null : aDefaultFile.getAbsolutePath());
	}

}
