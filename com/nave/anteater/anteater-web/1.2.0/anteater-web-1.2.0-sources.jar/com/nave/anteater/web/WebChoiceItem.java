package com.nave.anteater.web;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;

import com.nave.anteater.ChoiceTaskRunner;

public class WebChoiceItem extends WebInputItem {

	private List<WebInputItem> choiceItems = new ArrayList<WebInputItem>();
	private ChoiceTaskRunner tasksChoice;

	public WebChoiceItem(ChoiceTaskRunner tasksChoice) {
		super(tasksChoice.getName(), null, null);
		this.tasksChoice = tasksChoice;

		String[] taskNames = tasksChoice.getTaskNames();
		List<String> selectedTasks = new ArrayList<>();
		final Iterator<String> tasks = tasksChoice.getSelectedTasks();
		while (tasks.hasNext()) {
			selectedTasks.add(tasks.next());
		}
		for (String taskName : taskNames) {
			boolean contains = selectedTasks.contains(taskName);
			WebInputItem e = new WebInputItem(null, taskName, contains ? "true" : "false");
			this.choiceItems.add(e);
		}

	}

	public Object[] getChoiceItems() {
		return ArrayUtils.clone(choiceItems.toArray());
	}

	public void select(String[] tasks) {
		tasksChoice.select(tasks, true);
	}
}
