package com.nave.anteater.web;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.AbstractView;
import org.springframework.web.servlet.view.RedirectView;

import com.nave.anteater.ConfigConstants;
import com.nave.anteater.TestRunner;
import com.nave.anteater.util.xml.easyparser.Node;

@Controller
public class AEApplicationController {

	@Autowired
	private WebWorkspace workspace;

	@RequestMapping("/dashboard")
	private ModelAndView dashboard(@RequestParam(required = false) String command) {
		ModelAndView modelAndView;
		if (!StringUtils.equals(command, "loadRecipePack") && workspace.getAllConfigNode() != null && workspace.getConfigNode() == null) {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
			}
		}
		Node configNode = workspace.getConfigNode();
		if (configNode == null || StringUtils.equals(command, "loadRecipePack")) {
			workspace.resetConfiguration();
			modelAndView = new ModelAndView("set-configuration");
			modelAndView.addObject(ConfigConstants.CONFIG_NAME_SYS_PRPERTY_NAME, workspace.getConfigurationName());
			WebLogger webLogger = workspace.getLogs().get(WebWorkspace.CONFIG_LOG_NAME);
			modelAndView.addObject("configLog", webLogger);

		} else if (StringUtils.equals(command, "changeConfig")) {
			workspace.resetConfiguration();
			workspace.afterPropertiesSet();
			WebLogger webLogger = workspace.getLogs().get(WebWorkspace.CONFIG_LOG_NAME);
			while (webLogger.getInput() == null) {
				try {
					Thread.sleep(200);
				} catch (InterruptedException e) {
				}
			}
			modelAndView = new ModelAndView("set-configuration");
			modelAndView.addObject("configLog", webLogger);
			modelAndView.addObject(ConfigConstants.CONFIG_NAME_SYS_PRPERTY_NAME, workspace.getConfigurationName());

		} else {
			modelAndView = new ModelAndView("dashboard");
			modelAndView.addObject(ConfigConstants.CONFIG_NAME_SYS_PRPERTY_NAME, workspace.getConfigurationName());
		}

		return modelAndView;
	}

	@RequestMapping("/input")
	public RedirectView input(@RequestParam String log, @RequestParam(required = false) String value[], @RequestParam(required = false) String redirectUrl,
			@RequestParam(required = false) String action) {
		WebLogger webLogger = workspace.getLogs().get(log);
		if ("Cancel".equals(action)) {
			value = null;
			if (webLogger.getInput() instanceof WebChoiceItem) {
				WebChoiceItem webChoiceItem = (WebChoiceItem) webLogger.getInput();
				Object[] choiceItems = webChoiceItem.getChoiceItems();
				for (int i = 0; i < choiceItems.length; i++) {
					WebInputItem webInputItem = (WebInputItem) choiceItems[i];
					webInputItem.setValue("false");
				}
			}
		}
		if ("Select All".equals(action)) {
			WebChoiceItem webChoiceItem = (WebChoiceItem) webLogger.getInput();
			Object[] choiceItems = webChoiceItem.getChoiceItems();
			for (int i = 0; i < choiceItems.length; i++) {
				WebInputItem webInputItem = (WebInputItem) choiceItems[i];
				webInputItem.setValue("true");
			}
			return new RedirectView(StringUtils.defaultIfEmpty(redirectUrl, "show?taskName=" + webLogger.getName()));
		}
		if (value == null) {
			value = new String[0];
		}
		webLogger.applyInput(value);
		return new RedirectView(StringUtils.defaultIfEmpty(redirectUrl, "show?taskName=" + webLogger.getName()));
	}

	@RequestMapping("/run")
	public RedirectView runTask(@RequestParam String taskName) {
		WebLogger webLogger = workspace.getLogs().get(taskName);
		if (webLogger != null) {
			webLogger.moveToArchive();
		}
		workspace.runTask(taskName, true);
		return new RedirectView("show?taskName=" + taskName);
	}

	@RequestMapping("/task")
	public AbstractView runTask(@RequestParam String taskName, @RequestParam String action) {
		WebLogger webLogger = workspace.getLogs().get(taskName);
		if ("stop".equals(action)) {
			if (!webLogger.getTestRunner().getTaskProcessor().isStoppedTest()) {
				webLogger.getTestRunner().stopTest();
			}
		}
		return new RedirectView("show?taskName=" + taskName);
	}

	@RequestMapping("/menu")
	public ModelAndView getMenu(@RequestParam(required = false) Boolean silent, @RequestParam(required = false) Boolean mode) {
		ModelAndView mv = new ModelAndView("menu");

		if (mode != null) {
			boolean defaultMode = silent != null && silent ? true : false;
			workspace.setConsoleDefaultInput(defaultMode);

			Collection<WebLogger> values = workspace.getLogs().values();
			for (WebLogger webLogger : values) {
				webLogger.reset();
			}
		}

//		mv.addObject("menuEnabled", !workspace.isMenuDisabled());
//		mv.addObject("menu", workspace.getCustomizedMenu());
		mv.addObject("tests", workspace.getPublicTestsList());
		mv.addObject("logs", workspace.getLogs());
		mv.addObject("silent", workspace.isConsoleDefaultInput(null));
		return mv;
	}

	@RequestMapping("/show")
	public ModelAndView showMessage(@RequestParam(required = false) String taskName) {

		ModelAndView mv = new ModelAndView();
		if (taskName != null) {
			showLog(taskName, mv, 0);
			mv.setViewName("show-log");

		} else {
			mv.setViewName("settings");
			Node configNode = workspace.getConfigNode();
			if (configNode != null) {
				mv.addObject("configs", workspace.getAllConfigNode().getXMLText());
				mv.addObject("config", configNode.getXMLText());
				mv.addObject("startDir", workspace.getStartDir());
				mv.addObject("systemVariables", workspace.getSystemVariables());
				mv.addObject("testDirs", workspace.getTestDirs());
				mv.addObject("workingDir", workspace.getWorkingDir());
			}
		}

		return mv;
	}

	@RequestMapping("/view")
	public ModelAndView viewRecord(@RequestParam String taskName, @RequestParam int id) throws IOException {
		WebLogger log = workspace.getLogs().get(taskName);
		WebLogRecord record = log.getRecord(id);
		ModelAndView mv = new ModelAndView();
		String viewName = "view/" + StringUtils.defaultString(record.getType(), "txt");
		mv.setViewName(viewName);
		mv.addObject("record", record);
		mv.addObject("taskName", taskName);
		mv.addObject("id", id);
		return mv;
	}

	@RequestMapping("/record")
	@ResponseBody
	public void showRecord(@RequestParam String taskName, @RequestParam int id, HttpServletResponse response) throws IOException {
		WebLogger log = workspace.getLogs().get(taskName);
		WebLogRecord record = log.getRecord(id);
		response.setHeader("Content-Disposition", "inline; filename=\"record." + record.getType() + "\"");

		if ("xml".equals(record.getType())) {
			response.setContentType("text/xml");
		} else if ("html".equals(record.getType())) {
			response.setContentType("text/html");
		} else if ("json".equals(record.getType())) {
			response.setContentType("application/json");
		} else if ("properties".equals(record.getType())) {
			response.setContentType("text/x-java-properties");
		} else if ("eml".equals(record.getType())) {
			response.setContentType("message/rfc822");
			Object text = record.getMessage();
			if (text instanceof byte[]) {
				IOUtils.write((byte[]) text, response.getWriter());
			} else {
				response.getWriter().append(ObjectUtils.toString(text));
			}
			return;
		} else {
			response.setContentType("text/plain");
		}
		response.getWriter().append(ObjectUtils.toString(record.getText()));
	}

	@RequestMapping("/task-log")
	public ModelAndView taskLog(@RequestParam String taskName, @RequestParam(required = false, defaultValue = "-1") int id) {
		ModelAndView mv = new ModelAndView();
		showLog(taskName, mv, id + 1);
		mv.setViewName("task-log");

		return mv;
	}

	private void showLog(String taskName, ModelAndView mv, int id) {
		WebLogger log = workspace.getLogs().get(taskName);

		if (log != null) {
			TestRunner testRunner = log.getTestRunner();
			if (testRunner != null && testRunner.getTaskProcessor() != null) {
				mv.addObject("status", testRunner.getTaskProcessor().isStoppedTest() ? "stopped" : "running");
			}
			mv.addObject("title", log.getName());
			mv.addObject("startId", log.getStartIndex());
			mv.addObject("log", log.getLog(id));
			mv.addObject("input", log.getInput());
		}
	}

}