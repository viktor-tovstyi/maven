package com.nave.anteater.web;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Level;

import com.nave.anteater.AELogRecord;

public class WebLogRecord extends AELogRecord {

	private Level level;
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH.mm.ss,SSS");
	private Date time;
	private String trace;
	private long logId;

	public WebLogRecord(AELogRecord rec, Level level, String varName) {
		super(rec.getMessage(), rec.getType(), varName);
		this.level = level;
		time = new Date();
	}

	public Level getLevel() {
		return level;
	}

	public String getTime() {
		return simpleDateFormat.format(time);
	}

	public void setTrace(String trace) {
		this.trace = trace;
	}

	public String getTrace() {
		return trace;
	}

	public long getId() {
		return logId;
	}

	public void setLevel(Level level) {
		this.level = level;
	}

	public void setId(int id) {
		logId = id;
	}

}
