package com.nave.anteater.web;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.view.RedirectView;

@Controller
public class FileUploadController {

	@Autowired
	private WebWorkspace workspace;

	@RequestMapping(value = "/upload-file", method = RequestMethod.POST)
	public RedirectView handleFileUpload(@RequestParam("file") MultipartFile file, @RequestParam String log) {
		WebLogger webLogger = workspace.getLogs().get(log);
		if (!file.isEmpty()) {
			try {
				byte[] bytes = file.getBytes();
				File createTempFile = File.createTempFile("anteater", "file");
				BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(createTempFile));
				stream.write(bytes);
				stream.close();

				WebInputItem input = webLogger.getInput();
				if (input instanceof FileUploadItem) {
					webLogger.applyInput(new String[]{createTempFile.getAbsolutePath()});
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return new RedirectView("show?taskName=" + webLogger.getName());
	}

}
