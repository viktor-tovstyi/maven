package com.nave.anteater.web;

public class LogReport {

}
