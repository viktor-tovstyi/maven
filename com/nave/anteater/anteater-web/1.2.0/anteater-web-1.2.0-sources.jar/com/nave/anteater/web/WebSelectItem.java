package com.nave.anteater.web;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;

public class WebSelectItem extends WebInputItem {

	public static final String CANCEL_X = "Cancel";
	private List<WebInputItem> values = new ArrayList<WebInputItem>();

	public WebSelectItem(String name, Object[] aValues, String defaultValue) {
		super(null, name, defaultValue);
		for (Object value : aValues) {
			boolean contains = StringUtils.equals(ObjectUtils.toString(value), defaultValue);
			WebInputItem e = new WebInputItem(null, ObjectUtils.toString(value), contains ? "true" : "false");
			this.values.add(e);
		}
	}

	public Object[] getValues() {
		return ArrayUtils.clone(values.toArray());
	}

}
