package com.nave.ae.processor;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;

public class WebDriverManager {

	private static Map<String, WebDriver> driverMap = new HashMap<>();

	static {
		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				Collection<WebDriver> values = driverMap.values();
				for (WebDriver webDriver : values) {
					try {
						webDriver.close();
					} catch (Exception e) {
						// do nothing
					}
					try {
						webDriver.quit();
					} catch (Exception e) {
						// do nothing
					}
				}
			}
		});
	}

	public static WebDriver getDriver(String driverName) {
		return driverMap.get(driverName);
	}

	public static WebDriver setDriver(String driverName, WebDriver webDriver) {
		return driverMap.put(driverName, webDriver);
	}

}
