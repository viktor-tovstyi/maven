package com.nave.anteater;

import java.util.HashMap;
import java.util.Map;

import javax.swing.table.AbstractTableModel;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;

import com.nave.anteater.util.xml.easyparser.Node;

public class InputTableModel extends AbstractTableModel {

	private static final String PWD_MASK = "************";

	private static final long serialVersionUID = 2907837684253858613L;

	private Node[] theResultVariablesNodes = null;
	private Map<String, Object> variables;
	private Map<String, String> types;

	public InputTableModel(TemplateProcessor unit, String title, Node[] theResultVariablesNodes) {

		this.theResultVariablesNodes = theResultVariablesNodes;
		this.variables = new HashMap<>();
		this.types = new HashMap<>();

		for (Node node : theResultVariablesNodes) {
			String name = node.getAttribute("name");
			String value = null;
			String valueAttribute = node.getAttribute("value");
			String type = node.getAttribute("type");
			types.put(name, type);

			if (valueAttribute != null) {
				value = unit.replaceProperties(valueAttribute);
			} else {
				value = unit.getVariableString(name);
			}

			if (value == null) {
				String defaultValue = node.getAttribute("default");
				String savedVarName = ".inputValue." + title + "." + StringUtils.upperCase(name);
				value = AEWorkspace.getInstance().getDefaultUserConfiguration(savedVarName, defaultValue);
			}

			value = StringUtils.trimToNull(value);
			if (value != null) {
				this.variables.put(name, value);
			}
		}
	}

	public int getColumnCount() {
		return 2;
	}

	public int getRowCount() {
		return theResultVariablesNodes.length;
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
		String name = theResultVariablesNodes[rowIndex].getAttribute("name");

		Object value = variables.get(name);
		String type = types.get(name);
		if ("password".equals(type)) {
			if (value != null && columnIndex == 1) {
				value = PWD_MASK;
			}
		}

		return columnIndex == 0 ? name : value;
	}

	@Override
	public String getColumnName(int column) {
		return column == 0 ? "Property name" : "Value";
	}

	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return columnIndex == 1;
	}

	@Override
	public void setValueAt(Object value, int rowIndex, int columnIndex) {
		String name = theResultVariablesNodes[rowIndex].getAttribute("name");
		String type = types.get(name);
		if (!("password".equals(type)
				&& (PWD_MASK.equals(value) || StringUtils.isBlank(ObjectUtils.toString(value))))) {
			variables.put(name, value);
		}
	}

}
