package com.nave.anteater.view.panel;

import java.awt.BorderLayout;
import java.util.Properties;

import javax.swing.JPanel;

import com.nave.anteater.ILogger;
import com.nave.anteater.view.LogPresenter;

public class PresentationPanel extends JPanel {

	private static final long serialVersionUID = 6840549038631221985L;
	private String name;
	protected ILogger log;
	private Properties params;

	public PresentationPanel(Properties params, LogPresenter logger) {
		this(params.getProperty("frameId"), logger);
	}

	public PresentationPanel(String name, ILogger logger) {
		super(new BorderLayout());
		this.name = name;
		this.log = logger;
	}

	protected PresentationPanel(Properties params) {
		super(new BorderLayout());
		this.params = params;
	}

	public String getName() {
		return name;
	}

	public void out(Object data, Properties properties) {
		if (log != null) {
			log.info(data);
		}
	}

	public Properties getParams() {
		return params;
	}

}
