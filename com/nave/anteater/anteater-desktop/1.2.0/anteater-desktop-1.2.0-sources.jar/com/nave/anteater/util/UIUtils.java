package com.nave.anteater.util;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.undo.UndoManager;

import org.apache.commons.lang.StringUtils;

import com.nave.anteater.AEWorkspace;

public class UIUtils {

	static public void applyPreferedView(Window dialog, String name, int height, int width) {
		int screenDevicesCount = GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices().length;

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

		int x = (screenSize.width - dialog.getWidth()) / 2;
		int y = (screenSize.height - dialog.getHeight()) / 2;

		x = Integer.valueOf(AEWorkspace.getInstance()
				.getDefaultUserConfiguration(name + ":@Dialog_X:" + screenDevicesCount, Integer.toString(x)));
		y = Integer.valueOf(AEWorkspace.getInstance()
				.getDefaultUserConfiguration(name + ":@Dialog_Y:" + screenDevicesCount, Integer.toString(y)));

		if (screenDevicesCount == 1) {
			if (x < 0) {
				x = 0;
			}

			if (y < 0) {
				y = 0;
			}
		}

		dialog.setLocation(x, y);

		width = Integer.valueOf(AEWorkspace.getInstance()
				.getDefaultUserConfiguration(name + ":@Dialog_Width:" + screenDevicesCount, Integer.toString(width)));
		height = Integer.valueOf(AEWorkspace.getInstance()
				.getDefaultUserConfiguration(name + ":@Dialog_Height:" + screenDevicesCount, Integer.toString(height)));

		if ((height + y) > screenSize.height) {
			height = screenSize.height - y - 20;
		}

		Dimension size = new Dimension(width, height);
		dialog.setSize(size);
	}

	public static void saveDialogPreferedView(Window dialog, String name) {
		Point location = dialog.getLocation();
		int screenDevicesCount = GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices().length;

		String propertyName = name + ":@Dialog_X:" + screenDevicesCount;
		AEWorkspace.getInstance().setDefaultUserConfiguration(propertyName, Integer.toString(location.x));
		propertyName = name + ":@Dialog_Y:" + screenDevicesCount;
		AEWorkspace.getInstance().setDefaultUserConfiguration(propertyName, Integer.toString(location.y));
		Dimension size = dialog.getSize();
		propertyName = name + ":@Dialog_Width:" + screenDevicesCount;
		AEWorkspace.getInstance().setDefaultUserConfiguration(propertyName, Integer.toString(size.width));
		propertyName = name + ":@Dialog_Height:" + screenDevicesCount;
		AEWorkspace.getInstance().setDefaultUserConfiguration(propertyName, Integer.toString(size.height));
	}

	public static void applyLookAndFeel(Object className, Component component) {
		String lookAndFeelClassName = null;
		if (className instanceof String) {
			lookAndFeelClassName = (String) className;
		} else if (className instanceof List) {
			lookAndFeelClassName = (String) ((List) className).get(0);
		}

		if (StringUtils.isBlank(lookAndFeelClassName)) {
			lookAndFeelClassName = UIManager.getCrossPlatformLookAndFeelClassName();
		}
		try {
			UIManager.setLookAndFeel(lookAndFeelClassName);
			
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException
				| UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void applyPreferedView(JDialog dialog, String name) {
		int screenDevicesCount = GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices().length;
		String defaultX = AEWorkspace.getInstance()
				.getDefaultUserConfiguration(name + ":@Dialog_X:" + screenDevicesCount, null);
		if (defaultX != null) {
			applyPreferedView(dialog, name, 400, 600);
		}
	}

	public static void addJPopupMenuTo(JEditorPane txtField) {
		JPopupMenu popup = new JPopupMenu();
		UndoManager undoManager = new UndoManager();
		txtField.getDocument().addUndoableEditListener(undoManager);

		Action undoAction = new AbstractAction("Undo") {
			@Override
			public void actionPerformed(ActionEvent ae) {
				if (undoManager.canUndo()) {
					undoManager.undo();
				} else {
					JOptionPane.showMessageDialog(null, "Undoable: " + undoManager.canUndo(), "Undo Status",
							JOptionPane.INFORMATION_MESSAGE);
				}
			}
		};

		Action copyAction = new AbstractAction("Copy") {
			@Override
			public void actionPerformed(ActionEvent ae) {
				txtField.copy();
			}
		};

		Action cutAction = new AbstractAction("Cut") {
			@Override
			public void actionPerformed(ActionEvent ae) {
				txtField.cut();
			}
		};

		Action pasteAction = new AbstractAction("Paste") {
			@Override
			public void actionPerformed(ActionEvent ae) {
				txtField.paste();
			}
		};

		Action selectAllAction = new AbstractAction("Select All") {
			@Override
			public void actionPerformed(ActionEvent ae) {
				txtField.selectAll();
			}
		};

		popup.add(undoAction);
		popup.addSeparator();
		popup.add(cutAction);
		popup.add(copyAction);
		popup.add(pasteAction);
		popup.addSeparator();
		popup.add(selectAllAction);

		txtField.setComponentPopupMenu(popup);
	}

}
