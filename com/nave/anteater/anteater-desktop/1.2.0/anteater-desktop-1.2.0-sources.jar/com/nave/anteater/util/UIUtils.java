package com.nave.anteater.util;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.Window;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import org.apache.commons.lang.StringUtils;

import com.nave.anteater.AEWorkspace;

public class UIUtils {

	static public void applyPreferedView(Window dialog, String name, int height, int width) {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

		int x = (screenSize.width - dialog.getWidth()) / 2;
		int y = (screenSize.height - dialog.getHeight()) / 2;

		x = Integer.valueOf(AEWorkspace.getInstance().getDefaultUserConfiguration(name + ":X", Integer.toString(x)));
		y = Integer.valueOf(AEWorkspace.getInstance().getDefaultUserConfiguration(name + ":Y", Integer.toString(y)));

		GraphicsEnvironment localGraphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();

		if (localGraphicsEnvironment.getScreenDevices().length == 1) {
			if (x < 0) {
				x = 0;
			}

			if (y < 0) {
				y = 0;
			}
		}

		dialog.setLocation(x, y);

		width = Integer.valueOf(
				AEWorkspace.getInstance().getDefaultUserConfiguration(name + ":Width", Integer.toString(width)));
		height = Integer.valueOf(
				AEWorkspace.getInstance().getDefaultUserConfiguration(name + ":Height", Integer.toString(height)));

		if ((height + y) > screenSize.height) {
			height = screenSize.height - y - 20;
		}

		Dimension size = new Dimension(width, height);
		dialog.setSize(size);
	}

	public static void saveDialogPreferedView(Window dialog, String name) {
		Point location = dialog.getLocation();
		AEWorkspace.getInstance().setDefaultUserConfiguration(name + ":X", Integer.toString(location.x));
		AEWorkspace.getInstance().setDefaultUserConfiguration(name + ":Y", Integer.toString(location.y));
		Dimension size = dialog.getSize();
		AEWorkspace.getInstance().setDefaultUserConfiguration(name + ":Width", Integer.toString(size.width));
		AEWorkspace.getInstance().setDefaultUserConfiguration(name + ":Height", Integer.toString(size.height));
	}

	public static void applyLookAndFeel(Object className, Component... frame) {

		String lookAndFeelClassName = null;
		if (className instanceof String) {
			lookAndFeelClassName = (String) className;
		} else if (className instanceof List) {
			lookAndFeelClassName = (String) ((List) className).get(0);
		}

		if (StringUtils.isBlank(lookAndFeelClassName)) {
			lookAndFeelClassName = UIManager.getCrossPlatformLookAndFeelClassName();
		}
		try {
			UIManager.setLookAndFeel(lookAndFeelClassName);
			for (Component jFrame : frame) {
				Component root = SwingUtilities.getRoot(jFrame);
				if (root != null) {
					SwingUtilities.updateComponentTreeUI(root);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void applyPreferedView(JDialog dialog, String name) {
		String defaultX = AEWorkspace.getInstance().getDefaultUserConfiguration(name + ":X", null);
		if (defaultX != null) {
			applyPreferedView(dialog, name, 400, 600);
		}
	}

}
