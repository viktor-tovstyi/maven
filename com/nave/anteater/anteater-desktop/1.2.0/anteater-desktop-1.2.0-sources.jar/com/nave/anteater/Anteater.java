package com.nave.anteater;

import org.apache.commons.lang.ArrayUtils;

/**
 * Viktor_Tovstyi Date: Sep 7, 2006 Time: 10:24:58 AM
 */
public class Anteater {

	public static void main(final String... args) throws Exception {

		if (args.length > 0 && "/console".equalsIgnoreCase(args[0])) {
			String[] c_args = (String[]) ArrayUtils.subarray(args, 1, args.length);
			TestRunner.main(c_args);

		} else {
			AEFrame theMainFrame = new AEFrame();
			AEWorkspace workspace = theMainFrame.getWorkspace();
			CommandServer.createCommandServer(workspace, args);
			try {
				theMainFrame.pack();
				theMainFrame.setVisible(true);
				theMainFrame.start();
				for (String taskFileName : args) {
					theMainFrame.runTask(taskFileName);
				}
			} catch (TaskCancelingException e) {
				System.exit(0);
			} catch (ConfigurationException e) {
				e.printStackTrace();
				System.exit(0);
			}
		}
	}

}
