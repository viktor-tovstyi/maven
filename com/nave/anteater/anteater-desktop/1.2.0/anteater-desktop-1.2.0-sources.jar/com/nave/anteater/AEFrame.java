package com.nave.anteater;

import java.awt.AWTEvent;
import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.event.AWTEventListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowStateListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.AEUtils;
import com.nave.anteater.util.UIUtils;
import com.nave.anteater.util.xml.easyparser.EasyParser;
import com.nave.anteater.util.xml.easyparser.Node;
import com.nave.anteater.view.ConfigurationEditor;
import com.nave.anteater.view.JDialogPopupMenu;
import com.nave.anteater.view.ListLogPresenter.LogRecord;

public class AEFrame extends JFrame {

	private static final String MENU_TITLE = "Menu";

	public static final String TASK_PROTOCOL = "recipe:";

	public static final String TAKE_IT_EASY = "Take it Easy";

	private static final String MENU_TAG_NAME = "Menu";

	private static final int USER_ACTION_NOTIFY_TIMEOUT = 3000;

	private static final String RESTART_ALL_RUNNING_TASKS = "Restart all running tasks";

	private static final double ICON_SIZE = 80.0;

	public AEWorkspace getWorkspace() {
		return workspace;
	}

	private static final long serialVersionUID = 1L;

	private static final int COMPACT_THRESHOLD = 450;

	private static final String LOGO_ERROR_JPG = "logo-error.png";

	private static final String LOGO_FATAL_JPG = "logo-fatal.png";

	private static final String ICON16_JPG = "icon16.jpg";

	static final String LOGO_JPG = "logo.png";

	static final String TAKE_IT_EASY_JPG = "take-it-easy.png";

	private static final String LOGO_CHAINED = "logo-chained.png";

	static final String APP_TITLE = "Anteater";

	private static final String CONF_REFRESH_COMMAND = "Refresh recipes";

	private EnvPropertiesTable varTable;

	private TaskEditor failedEditor = null;

	private SoundManager soundManager;

	private boolean menuDisabled;

	private List<CustomizedMenu> configurableMenu;

	public class UIChoiceTaskRunner extends MultiTaskRunDialogImpl implements MultiTaskRunDialog {

		private static final long serialVersionUID = 1L;

		public UIChoiceTaskRunner(String name, TaskProcessor taskProcessor, boolean useHistory) {
			super(AEFrame.this, name, taskProcessor, useHistory);
		}

	}

	private AEWorkspace workspace;

	private JTabbedPane tabbedPanel;

	private JTabbedPane fCustomizedMenu;

	private JProgressBar progress;

	private JButton theJButton;

	private JCheckBox fConsoleDefaultInputBox;

	private JButton mainButton;

	private JDialogPopupMenu leftMenu;
	private JPanel panel;

	private ILogger log = new Logger("AEFrame");

	private boolean compactStyle;

	private CheckpointsDialog checkpointsDialog;

	private RecipesPanel recipesPanel;

	private Long lastUserActionTime = System.currentTimeMillis();

	private boolean win_maximized;

	private JFrame menuDilog;

	private JComponent preferedMenu;

	private JFrame configurationDialod;

	public AEFrame() {
		super(APP_TITLE);
		setMinimumSize(new Dimension(240, 198));

		workspace = new DesktopWorkspace(this) {
			@Override
			public void refreshTaskPath() throws IOException {
				super.refreshTaskPath();
				recipesPanel.refreshTaskPathTable();
			}
		};

		tabbedPanel = new JTabbedPane();

		progress = new JProgressBar();
		theJButton = new JButton(CONF_REFRESH_COMMAND);
		fConsoleDefaultInputBox = new JCheckBox("<html>" + TAKE_IT_EASY.replace("E", "<u>E</u>") + "</html>");
		fConsoleDefaultInputBox
				.setSelected(Boolean.valueOf(System.getProperty(ConfigConstants.TAKE_IT_EASY_MODE, "false")));

		mainButton = new JButton(getIcon(getLogo()));
		mainButton.setBorder(BorderFactory.createEmptyBorder());

		leftMenu = new JDialogPopupMenu(mainButton);
		panel = new JPanel(new BorderLayout());

		recipesPanel = new RecipesPanel(workspace) {

			private static final long serialVersionUID = 1L;

			public TaskEditor editTask(String name) {
				return AEFrame.this.editTask(name);
			}

		};

		soundManager = new SoundManager(this);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JOptionPane.setRootFrame(this);

		createFrame();

		addComponentListener(new ComponentAdapter() {

			public void componentResized(ComponentEvent e) {
				checkLayoutStyle();
			}
		});

		addWindowStateListener(new WindowStateListener() {
			public void windowStateChanged(WindowEvent e) {
				checkLayoutStyle();
				int state = e.getNewState();
				win_maximized = state == Frame.MAXIMIZED_BOTH;
			}
		});

		JMenuItem menuItem = new JMenuItem(RESTART_ALL_RUNNING_TASKS);
		menuItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				for (int i = 0; i < tabbedPanel.getTabCount(); i++) {
					Component comp = tabbedPanel.getComponentAt(i);
					if (comp instanceof TaskPanel) {
						TaskPanel taskPanel = (TaskPanel) comp;
						TaskEditor taskEditor = taskPanel.getTaskEditor();
						if (taskEditor.isRunning()) {
							taskEditor.stopTest();
							taskEditor.runTask();
						}
					}
				}
			}
		});
		leftMenu.add(menuItem);

		checkpointsDialog = new CheckpointsDialog(AEFrame.this);

		Toolkit.getDefaultToolkit().addAWTEventListener(new AWTEventListener() {
			@Override
			public void eventDispatched(AWTEvent event) {
				if (event instanceof MouseEvent) {
					lastUserActionTime = System.currentTimeMillis();
					SoundManager.stop();
				}
				if (event instanceof KeyEvent) {
					lastUserActionTime = System.currentTimeMillis();
					SoundManager.stop();
				}
			}
		}, AWTEvent.MOUSE_EVENT_MASK | AWTEvent.MOUSE_MOTION_EVENT_MASK | AWTEvent.KEY_EVENT_MASK);

		getRootPane().registerKeyboardAction(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				fConsoleDefaultInputBox.setSelected(!fConsoleDefaultInputBox.isSelected());
				mainButton.setIcon(getIcon(getLogo()));
			}
		}, KeyStroke.getKeyStroke(KeyEvent.VK_E, KeyEvent.CTRL_MASK), JComponent.WHEN_IN_FOCUSED_WINDOW);

		varTable = new EnvPropertiesTable(this);

		fCustomizedMenu = new JTabbedPane();
		menuDilog = createDialod(fCustomizedMenu, MENU_TITLE);
		menuDilog.setIconImage(getIcon(ICON16_JPG).getImage());
	}

	private JFrame createDialod(Component comp, String title) {
		JFrame menuDilog = new JFrame(title);
		menuDilog.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				UIUtils.saveDialogPreferedView(menuDilog, title);
			}
			
			@Override
			public void windowDeactivated(WindowEvent e) {
				UIUtils.saveDialogPreferedView(menuDilog, title);
			}
		});

		menuDilog.getContentPane().add(comp);
		menuDilog.pack();

		return menuDilog;
	}

	public boolean isCompactStyle() {
		double width = getSize().getWidth();
		return width < COMPACT_THRESHOLD;
	}

	private void checkLayoutStyle() {
		boolean newStyle = isCompactStyle();
		setAlwaysOnTop(newStyle);

		varTable.refresh();
		if (newStyle != compactStyle) {
			try {
				setStyle(newStyle);
				compactStyle = newStyle;
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}

		if (newStyle) {
			Component comp = tabbedPanel.getSelectedComponent();
			if (comp instanceof TaskPanel) {
				TaskPanel taskPanel = (TaskPanel) comp;
				TaskEditor taskEditor = taskPanel.getTaskEditor();
				taskEditor.setSplitPanel();
			}
		}

		Dimension minimumSize = getMinimumSize();
		if (getSize().equals(minimumSize)) {
			Component comp = tabbedPanel.getSelectedComponent();
			if (comp instanceof TaskPanel) {
				TaskPanel taskPanel = (TaskPanel) comp;
				TaskEditor taskEditor = taskPanel.getTaskEditor();
				mainButton.setToolTipText(taskEditor.getPanelName());
			}
		} else {
			mainButton.setToolTipText(null);
		}

	}

	private void createFrame() {

		setIconImage(getIcon(ICON16_JPG).getImage());
		addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent arg0) {
				int screenDevicesCount = GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices().length;
				if (!win_maximized) {
					AEWorkspace.getInstance().setDefaultUserConfiguration(".win_position_x:" + screenDevicesCount,
							String.valueOf(getLocation().getX()));
					AEWorkspace.getInstance().setDefaultUserConfiguration(".win_position_y:" + screenDevicesCount,
							String.valueOf(getLocation().getY()));
					AEWorkspace.getInstance().setDefaultUserConfiguration(".win_position_w:" + screenDevicesCount,
							String.valueOf(getSize().width));
					AEWorkspace.getInstance().setDefaultUserConfiguration(".win_position_h:" + screenDevicesCount,
							String.valueOf(getSize().height));
				}
				AEWorkspace.getInstance().setDefaultUserConfiguration(".win_maximized", win_maximized ? "1" : "0");

				super.windowClosing(arg0);
			}

		});

		mainButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				boolean minimizeRun = false;

				if (getSize().equals(getMinimumSize())) {
					Component comp = tabbedPanel.getSelectedComponent();
					if (comp instanceof TaskPanel) {
						TaskPanel taskPanel = (TaskPanel) comp;
						TaskEditor taskEditor = taskPanel.getTaskEditor();
						if (!taskEditor.isRunning()) {
							taskEditor.runTask();
							minimizeRun = true;
						}
					}

				}

				if (!minimizeRun) {
					if (!isMenuDisabled()) {
						if (failedEditor != null) {
							try {
								setSelectedComponent(failedEditor.getMainPanel());
							} catch (Exception e) {
								// DO NOTHING
							}
							failedEditor = null;
							mainButton.setIcon(getIcon(getLogo()));
						} else {
							showDialogTestSelect();
						}
					} else {
						if (failedEditor != null) {
							setSelectedComponent(failedEditor.getMainPanel());
							failedEditor = null;
							mainButton.setIcon(getIcon(getLogo()));
						}
					}
				}
			}

			private void run(String name) {
				try {
					for (int i = 0; i < tabbedPanel.getTabCount(); i++) {
						Component comp = tabbedPanel.getComponentAt(i);
						if (comp instanceof TaskPanel) {
							TaskPanel taskPanel = (TaskPanel) comp;
							TaskEditor taskEditor = taskPanel.getTaskEditor();
							String title = taskEditor.getTaskNode().getAttribute("name");
							if (StringUtils.equals(title, name) && !taskEditor.isRunning()) {
								taskEditor.runTask();
								return;
							}
						}
					}

					runTask(name);
				} catch (ConfigurationException e) {
					e.printStackTrace();
				}
			}

		});

		mainButton.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == 3) {
					leftMenu.show(mainButton, 0, 0);
				}
			}
		});

	}

	public static ImageIcon getIcon(String name) {
		name = "/images/ui/" + name;
		URL resource = AEFrame.class.getResource(name);
		if (resource == null) {
			throw new IllegalArgumentException("Resource is not found: " + name);
		}
		ImageIcon imageIcon = new ImageIcon(resource);
		return imageIcon;
	}

	private void setStyle(boolean compackStyle) {
		fConsoleDefaultInputBox.setOpaque(false);
		fConsoleDefaultInputBox.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				mainButton.setIcon(getIcon(getLogo()));
			}
		});

		getContentPane().removeAll();

		panel.removeAll();
		progress.setStringPainted(true);
		panel.add(mainButton, BorderLayout.NORTH);
		JPanel comp = new JPanel(new BorderLayout());
		comp.add(fConsoleDefaultInputBox, BorderLayout.WEST);
		JButton checkpointList = new JButton(Character.toString((char) 9016));
		checkpointList.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				checkpointsDialog.showDialog();
			}
		});
		checkpointList.setToolTipText("Required dialogs");
		checkpointList.setFont(new Font(checkpointList.getFont().getName(), Font.PLAIN, 16));
		checkpointList.setBorder(new EmptyBorder(0, 0, 0, 0));
		checkpointList.setBorderPainted(false);
		comp.add(checkpointList, BorderLayout.EAST);
		panel.add(comp, BorderLayout.CENTER);
		panel.add(progress, BorderLayout.SOUTH);

		if (compackStyle) {
			getContentPane().add(panel, BorderLayout.NORTH);
			getContentPane().add(tabbedPanel, BorderLayout.CENTER);

		} else {

			JPanel leftPanel = new JPanel(new BorderLayout());
			leftPanel.setBorder(BorderFactory.createBevelBorder(0));

			leftPanel.add(panel, BorderLayout.NORTH);
			leftPanel.add(createConfirPanel(), BorderLayout.CENTER);
			JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, tabbedPanel);
			splitPane.setDividerLocation(230);

			getContentPane().add(splitPane);

		}
		setAlwaysOnTop(compackStyle);
	}

	public void start() throws Exception {

		setControlEnabled(false);
		String configName = loadConfiguration();
		if (configName != null) {
			boolean menuDisabled = isMenuDisabled();
			setControlEnabled(!menuDisabled);

			if (menuDisabled) {
				mainButton.setIcon(getIcon(LOGO_CHAINED));
			}
		}
	}

	public void setSelectedComponent(Component comp) {
		tabbedPanel.setSelectedComponent(comp);
	}

	protected TaskEditor editTask(String name) {
		TaskEditor taskEditor = null;
		taskEditor = new TaskEditor(this);
		if (name != null) {
			taskEditor.setActiveTest(name);
		}
		String logName = StringUtils.defaultString(name, TaskProcessor.STARTUP);
		taskEditor.edit(logName);
		addTaskPanel(taskEditor, logName);
		return taskEditor;
	}

	private void addTaskPanel(TaskEditor taskEditor, String name) {
		taskEditor.showPanel(tabbedPanel, name);
		leftMenu.add(new TaskMenuItem(name, taskEditor));
	}

	protected void setControlEnabled(boolean aEnabled) {
		mainButton.setIcon(getIcon(getLogo()));
		mainButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
	}

	public String taskFileNameConflict(String aKey, String aCurrentFile, String aNewFile) throws Exception {
		StringBuffer theStringBuffer = new StringBuffer();

		theStringBuffer.append("<html><body>");
		theStringBuffer.append("Duplication file for task with name: '" + aKey + "'<br>");
		theStringBuffer.append("Registration file: '" + aCurrentFile + "'<br>");
		theStringBuffer.append("Conflict file: '" + aNewFile + "'<br>");
		theStringBuffer.append("<br>");
		theStringBuffer.append("Please select priority folder:<br>");
		theStringBuffer.append("</body></html>");

		String theFirstFile = new File(aNewFile).getParent();
		String theSecondFile = new File(aCurrentFile).getParent();

		Object[] possibleValues = { theFirstFile, theSecondFile };

		StringBuffer theMessageBuffer = new StringBuffer();
		theMessageBuffer.append("Duplication file for task with name: '" + aKey + "' ");

		String thePriorityFolder = null;
		List<String> priorityFolders = getWorkspace().getPriorityFolders();
		if (priorityFolders.contains(theFirstFile)) {
			thePriorityFolder = theFirstFile;
			theMessageBuffer.append("presetting selection file: " + aNewFile);
		} else if (priorityFolders.contains(theSecondFile)) {
			thePriorityFolder = theSecondFile;
			theMessageBuffer.append("presetting selection file: " + aCurrentFile);
		} else {
			thePriorityFolder = (String) JOptionPane.showInputDialog(this, theStringBuffer.toString(),
					"Conflict of variants recipes", JOptionPane.INFORMATION_MESSAGE, null, possibleValues,
					possibleValues[0]);
			theMessageBuffer.append("manual selection priority folder: " + thePriorityFolder);
		}

		priorityFolders.add(thePriorityFolder);

		if (thePriorityFolder == null) {
			StringBuffer fBuffer = new StringBuffer();
			fBuffer.append("Duplication file for task with name: '" + aKey + "': ");
			fBuffer.append("Registration file: '" + aCurrentFile + "', ");
			fBuffer.append("Conflict file: '" + aNewFile + "'");
			throw new Exception(fBuffer.toString());
		}

		if (theSecondFile != null && theSecondFile.equals(thePriorityFolder))
			aNewFile = aCurrentFile;

		log.warn(theMessageBuffer.toString());
		return aNewFile;
	}

	public void refreshTaskPath() throws IOException {
		getWorkspace().refreshTaskPath();
		recipesPanel.refreshTaskPathTable();
	}

	public String inputValue(String description, String aName, String aValue, String type, boolean notifyMe) {
		description = StringUtils.defaultString(description, aName);

		if (aValue == null) {
			aValue = AEWorkspace.getInstance().getDefaultUserConfiguration(".inputValue." + aName, aValue);
			description = description + " (last value)";
		}

		pushOnTop();
		if (notifyMe) {
			soundManager.play();
		}

		type = (String) ObjectUtils.defaultIfNull(type, StringUtils.EMPTY);

		switch (type) {
		case "password":
			aValue = inputPassword(aName, aValue);
			break;
		case "text":
			aValue = simpleInput(aName, aValue, null, description, true);
			break;
		case "map":
			aValue = inputMap(aName, aValue);
			break;

		default:
			aValue = simpleInput(aName, aValue, null, description, false);
		}

		if (notifyMe) {
			SoundManager.stop();
		}

		if (!"text".equals(type)) {
			AEWorkspace.getInstance().setDefaultUserConfiguration(".inputValue." + aName, aValue);
		}
		return aValue;
	}

	@SuppressWarnings("unchecked")
	private String simpleInput(String name, Object values, Object defaultValue, String description, boolean bigText) {
		String result = null;

		JPanel panel = new JPanel(new BorderLayout());
		JLabel label = new JLabel(name);
		panel.add(label, BorderLayout.NORTH);

		if (description != null) {
			if (!StringUtils.startsWith(description, "<html>")) {
				description = "<html><body>" + description.replace("\n", "<br/>") + "</body></html>";
			}
			panel.add(new JLabel(description), BorderLayout.NORTH);
		}

		JComponent inputField;
		if (values instanceof String || values == null) {
			JComponent jTextField;
			if (bigText) {
				jTextField = new JEditorPane();
				jTextField.setDropTarget(new DropTarget() {
					public synchronized void drop(DropTargetDropEvent evt) {
						try {
							evt.acceptDrop(DnDConstants.ACTION_COPY);
							List<File> droppedFiles = (List<File>) evt.getTransferable()
									.getTransferData(DataFlavor.javaFileListFlavor);
							for (File file : droppedFiles) {
								String text = IOUtils.toString(new FileInputStream(file));
								JEditorPane jEditorPane = (JEditorPane) jTextField;
								jEditorPane.setText(jEditorPane.getText() + text);
							}
						} catch (Exception ex) {
							ex.printStackTrace();
						}
					}
				});

				UIUtils.addJPopupMenuTo((JEditorPane) jTextField);
			} else {
				jTextField = new JTextField(20);
			}

			inputField = jTextField;
			String text = (String) values;

			if (inputField instanceof JTextField) {
				((JTextField) inputField).setText(text);
				panel.add(inputField, BorderLayout.CENTER);
			}
			if (inputField instanceof JEditorPane) {
				((JEditorPane) inputField).setText(text);
				panel.add(new JScrollPane(inputField), BorderLayout.CENTER);
			}

		} else {
			inputField = new JComboBox<Object>((Object[]) values);
			((JComboBox<String>) inputField).setSelectedItem(defaultValue);
			panel.add(inputField, BorderLayout.CENTER);
		}

		CheckPointBox vip = new CheckPointBox(name, InputDialogType.VAR);
		panel.add(vip, BorderLayout.SOUTH);

		String[] options = new String[] { "OK", "Cancel" };
		Frame rootFrame = JOptionPane.getRootFrame();

		int option = OptionPane.showOptionDialog(rootFrame, panel, name, JOptionPane.NO_OPTION,
				JOptionPane.QUESTION_MESSAGE);

		vip.saveCheckpointFlag();

		switch (option) {
		case JOptionPane.OK_OPTION:
			if (values instanceof String || values == null) {

				if (inputField instanceof JTextField) {
					result = ((JTextField) inputField).getText();
				}
				if (inputField instanceof JEditorPane) {
					result = ((JEditorPane) inputField).getText();
				}

			} else {
				result = (String) ((JComboBox<?>) inputField).getSelectedItem();
			}
			break;
		case JOptionPane.CANCEL_OPTION:
		case JOptionPane.NO_OPTION:
			result = null;
			break;
		case JOptionPane.CLOSED_OPTION:
			throw new TaskCancelingException();
		}

		return result;
	}

	private String inputMap(String description, String aValue) {
		final Map<String, String> map = AEUtils.convertStringToMap(aValue);

		Set<Entry<String, String>> entrySet = map.entrySet();
		Object[][] data = new Object[map.size()][];
		int i = 0;
		for (Entry<String, String> entry : entrySet) {
			Object[] row = new Object[2];
			row[0] = entry.getKey();
			row[1] = entry.getValue();
			data[i++] = row;
		}

		Object[] columnNames = { "Name", "Value" };
		final JTable table = new JTable(data, columnNames) {
			private static final long serialVersionUID = 1L;

			@Override
			public Dimension getPreferredScrollableViewportSize() {
				Dimension d = getPreferredSize();
				int n = getRowHeight();
				return new Dimension(d.width, (n * map.size()));
			}
		};
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		table.setCellSelectionEnabled(true);

		JPanel jPanel = new JPanel();
		jPanel.setLayout(new BorderLayout());
		JScrollPane sp = new JScrollPane(table);
		jPanel.add(sp, BorderLayout.CENTER);

		CheckPointBox vip = new CheckPointBox(description, InputDialogType.MAP);
		jPanel.add(vip, BorderLayout.SOUTH);

		jPanel.add(new JLabel(description), BorderLayout.NORTH);
		Frame rootFrame = JOptionPane.getRootFrame();

		int option = OptionPane.showOptionDialog(rootFrame, jPanel, "Input the map property", JOptionPane.OK_OPTION,
				JOptionPane.QUESTION_MESSAGE);
		vip.saveCheckpointFlag();

		String result = null;
		if (option == -1) {
			throw new TaskCancelingException();
		}
		if (option == 0) // pressing OK button
		{
			Map<String, String> resultMap = new HashMap<>(map);
			for (int j = 0; j < map.size(); j++) {
				resultMap.put((String) data[j][0], (String) data[j][1]);
			}
			result = resultMap.toString();
		}

		return result;
	}

	private String inputPassword(String description, String aValue) {
		String result = null;

		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		JLabel label = new JLabel(description);
		JPasswordField pass = new JPasswordField(20);
		pass.setText(aValue);
		panel.add(label);
		panel.add(pass);

		CheckPointBox vip = new CheckPointBox(description, InputDialogType.PWD);
		panel.add(vip);

		Frame rootFrame = JOptionPane.getRootFrame();

		int option = OptionPane.showOptionDialog(rootFrame, panel, "Input a password", JOptionPane.NO_OPTION,
				JOptionPane.QUESTION_MESSAGE);
		vip.saveCheckpointFlag();

		switch (option) {
		case JOptionPane.OK_OPTION:
			char[] password = pass.getPassword();
			result = new String(password);
			break;
		case JOptionPane.CANCEL_OPTION:
		case JOptionPane.NO_OPTION:
			result = null;
			break;
		case JOptionPane.CLOSED_OPTION:
			throw new TaskCancelingException();
		}

		return result;
	}

	public void showDialogTestSelect() {

		int selectedTab = fCustomizedMenu.getSelectedIndex();
		if (preferedMenu != null) {
			fCustomizedMenu.remove(preferedMenu);
		}

		Object[] testArray = recipesPanel.getMenuTasks().toArray();
		if (testArray.length > 0) {
			CustomizedMenu menu = new CustomizedMenu();
			for (Object recipeName : testArray) {
				Node itemNode = new Node("item");
				itemNode.setAttribute("task", (String) recipeName);
				menu.addItem(itemNode);
			}
			preferedMenu = createMenuTab(menu);
			fCustomizedMenu.addTab("Selected", preferedMenu);
			fCustomizedMenu.setSelectedIndex(selectedTab);
		}

		UIUtils.applyPreferedView(menuDilog, MENU_TITLE, 400, 600);
		menuDilog.setVisible(true);
	}

	protected void createToolBar() {
		fCustomizedMenu.setTabPlacement(JTabbedPane.TOP);
		for (CustomizedMenu cmenu : configurableMenu) {
			JScrollPane createMenuTab = createMenuTab(cmenu);
			String title = cmenu.getTitle();
			fCustomizedMenu.addTab(title, createMenuTab);
		}
	}

	private JScrollPane createMenuTab(CustomizedMenu menu) {
		StringBuilder content = new StringBuilder("<html><body>");

		for (CustomizedMenu.Item item : menu) {
			content.append(item.getDescription());

			String name = item.getName();
			if (name != null) {
				String filePath = getWorkspace().getTasksMap().getProperty(name);
				try {
					Node object = new EasyParser().getObject(new File(filePath));

					Node[] descriptions;
					descriptions = object.getNodes("About/description");
					content.append(
							"<div style=\"display: inline-block;width: 100%;background-color:#d0d0d0;\"><a href=\""
									+ TASK_PROTOCOL + item.getName() + "\">" + name + "</a></div>");
					for (Node description : descriptions) {
						content.append(description.getInnerXMLText());
					}
					content.append("<hr/>");
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}

		content.append("</body><html>");

		JEditorPane menuBox = new JEditorPane();
		menuBox.setEditorKit(JEditorPane.createEditorKitForContentType("text/html"));
		menuBox.setEditable(false);
		menuBox.setText(content.toString());
		menuBox.addHyperlinkListener(new HyperlinkListener() {
			public void hyperlinkUpdate(HyperlinkEvent e) {
				if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
					String description = e.getDescription();
					if (StringUtils.startsWith(description, TASK_PROTOCOL)) {
						String taskName = StringUtils.substringAfter(description, TASK_PROTOCOL);
						runTask(taskName);
						menuDilog.setVisible(false);
					} else {
						if (Desktop.isDesktopSupported()) {
							try {
								URL url = e.getURL();
								Desktop.getDesktop().browse(url.toURI());
							} catch (IOException | URISyntaxException e1) {
								log.error("Can't open URL: " + e.getURL(), e1);
							}
						}
					}
				}
			}
		});

		JScrollPane component = new JScrollPane(menuBox);
		return component;
	}

	BufferedImage createResizedCopy(Image originalImage, int scaledWidth, int scaledHeight, boolean preserveAlpha) {
		int imageType = preserveAlpha ? BufferedImage.TYPE_INT_RGB : BufferedImage.TYPE_INT_ARGB;
		BufferedImage scaledBI = new BufferedImage(scaledWidth, scaledHeight, imageType);
		Graphics2D g = scaledBI.createGraphics();
		if (preserveAlpha) {
			g.setComposite(AlphaComposite.Src);
		}
		g.drawImage(originalImage, 0, 0, scaledWidth, scaledHeight, null);
		g.dispose();
		return scaledBI;
	}

	public void message(String string) {
		JOptionPane.showMessageDialog(this, string);
	}

	public class JTaskButton extends JButton implements ActionListener {

		private static final long serialVersionUID = 1L;

		protected Node fTaskNode;

		protected boolean fMultiThread;

		public JTaskButton(Node aTaskNode) {
			// setBorder(BorderFactory.createEtchedBorder());
			fTaskNode = aTaskNode;
			String theTask = fTaskNode.getAttribute("task");
			recipesPanel.setMenuTask(theTask);
			addActionListener(this);
			fMultiThread = "enabled".equals(aTaskNode.getAttribute("multi"));
			setFont(new Font("Dialog", Font.BOLD, 14));
		}

		public boolean isMultiThread() {
			return fMultiThread;
		}

		public void actionPerformed(ActionEvent e) {

			try {
				TaskEditor taskEditor = new TaskEditor(AEFrame.this);
				String theTask = fTaskNode.getAttribute("task");
				if (theTask != null) {
					String name = fTaskNode.getAttribute("name");
					if (name == null)
						name = theTask;
					addTaskPanel(taskEditor, name);
					taskEditor.start(theTask);
				}

			} catch (Throwable e1) {
				e1.printStackTrace();
			}
		}
	}

	public String getTestPath(String name) {

		String property = getWorkspace().getTestsDescList().getProperty(name);
		return property == null ? name : property;
	}

	private JTabbedPane createConfirPanel() {

		JScrollPane theScrollPane = new JScrollPane(varTable);

		JPanel theButtonsPanel = new JPanel();
		JButton theButton = new JButton(AEFrame.getIcon("save.png"));
		theButton.setToolTipText("Save custom configuration");
		theButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				SwingUtilities.invokeLater(new Runnable() {
					@Override
					public void run() {
						saveEnvProperties();
					}
				});
			}
		});
		theButtonsPanel.add(theButton);

		theButton = new JButton(AEFrame.getIcon("default.png"));
		theButton.setToolTipText("Reset custom configuration");
		theButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SwingUtilities.invokeLater(new Runnable() {
					@Override
					synchronized public void run() {
						String customConfPropFileName = getWorkspace()
								.getCustomConfPropFileName(getWorkspace().getConfigurationName());
						File theConfFile = new File(customConfPropFileName);
						boolean result = theConfFile.delete();
						if (result) {
							JOptionPane.showMessageDialog(JOptionPane.getRootFrame(),
									"The user configuration has been deleted.\nPlease restart the application.");
						}
					}
				});
			}
		});
		theButtonsPanel.add(theButton);

		theButton = new JButton(AEFrame.getIcon("sandbox.png"));
		theButton.setToolTipText("Open user folder");
		theButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String absolutePath = AEWorkspace.getInstance().getHomeWorkingDir().getAbsolutePath();
				try {
					Desktop.getDesktop().open(new File(absolutePath));
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
		theButtonsPanel.add(theButton);

		JPanel panel = new JPanel(new BorderLayout(4, 4));

		theButton = new JButton(AEFrame.getIcon("hierarchy.png"));
		theButton.setToolTipText("Configuration");
		theButton.setEnabled(true);
		theButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				configurationDialod.setVisible(true);
			}
		});

		panel.add(theButton, BorderLayout.EAST);

		JPanel theSysvarButtonsPanel = new JPanel(new BorderLayout(4, 4));
		theSysvarButtonsPanel.add(theScrollPane, BorderLayout.CENTER);
		theSysvarButtonsPanel.add(panel, BorderLayout.NORTH);
		theSysvarButtonsPanel.add(theButtonsPanel, BorderLayout.SOUTH);

		JPanel recPanel = new JPanel();
		recPanel.setLayout(new BorderLayout());
		recPanel.add(recipesPanel, BorderLayout.CENTER);

		JPanel comp = new JPanel();

		JButton theCreate = new JButton(AEFrame.getIcon("create.png"));
		theCreate.setToolTipText("Create a new recipe");
		theCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TaskEditor taskEditor;
				try {
					taskEditor = new TaskEditor(AEFrame.this);

					String taskName = JOptionPane.showInputDialog(JOptionPane.getRootFrame(), "Task name");
					if (taskName != null) {
						addTaskPanel(taskEditor, taskName);
						taskEditor.create(taskName);
					}

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		});
		comp.add(theCreate);

		JButton theRefresh = new JButton(AEFrame.getIcon("refresh.png"));
		theRefresh.setToolTipText("Refresh recipe list");
		theRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					workspace.refreshTaskPath();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
		comp.add(theRefresh);

		recPanel.add(comp, BorderLayout.SOUTH);

		JTabbedPane tablePane = new JTabbedPane();
		tablePane.add("Recipes", recPanel);
		tablePane.add("Environment", theSysvarButtonsPanel);

		theJButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				refreshTaskMap();
			}
		});

		return tablePane;
	}

	public Long getLastUserActionTime() {
		return lastUserActionTime;
	}

	public String loadConfiguration() throws Exception {
		return loadConfiguration(null);
	}

	protected String loadConfiguration(String confName) throws Exception {
		String currentConfName = getWorkspace().getConfigurationName();
		String loadConfiguration = getWorkspace().loadConfiguration(confName, true);
		if (loadConfiguration != null) {
			ConfigurationEditor configurationEditor = new ConfigurationEditor(this);
			configurationEditor.refreshActiveConfig();
			configurationDialod = createDialod(configurationEditor, "Configuration");
			configurationDialod.setIconImage(AEFrame.getIcon("hierarchy.png").getImage());

			Node configNode = workspace.getConfigNode();
			String menuName = configNode.getAttribute("menu");
			Node[] theToolBarNodes = configNode.getNodes(MENU_TAG_NAME);
			if (StringUtils.isNotBlank(menuName)) {
				if (menuName != null) {
					Node findNode = configNode.findNode(MENU_TAG_NAME, "name", menuName);
					if (findNode != null) {
						theToolBarNodes = new Node[] { findNode };
					}
				}
			}

			if (theToolBarNodes != null && theToolBarNodes.length > 0) {
				createToolBar(theToolBarNodes);
				if (configurableMenu.size() == 0) {
					menuDisabled = true;
				} else {
					menuDisabled = false;
				}
			} else {
				menuDisabled = false;
			}

			setTitle(loadConfiguration + " - " + APP_TITLE);

			if (!StringUtils.equals(currentConfName, loadConfiguration)) {
				tabbedPanel.removeAll();
			}

			varTable.refresh();
			recipesPanel.refreshTaskPathTable();

			pack();
			boolean newStyle = isCompactStyle();
			setStyle(newStyle);
			setVisible(true);

			getWorkspace().runSetupNodes(); // TODO: potentially bug
		}

		return loadConfiguration;
	}

	protected void createToolBar(Node[] aToolBarNodes) {
		List<CustomizedMenu> menuList = new ArrayList<>();

		for (int k = 0; k < aToolBarNodes.length; k++) {
			CustomizedMenu menu = new CustomizedMenu();

			Node theNode = aToolBarNodes[k];
			String name = theNode.getAttribute("name");
			if (name != null) {
				menu.setTitle(name);
			}
			String colorStr = theNode.getAttribute("color");
			if (colorStr != null) {
				Color color;
				try {
					color = (Color) Color.class.getDeclaredField(colorStr.toLowerCase()).get(null);
					menu.setColor(color);
				} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException
						| SecurityException e) {
					e.printStackTrace();
				}
			}

			for (Node node : theNode) {
				if ("item".equals(node.getTag())) {
					menu.addItem(node);
				}
			}

			menuList.add(menu);
		}

		configurableMenu = menuList;
		createToolBar();
	}

	public void removeTab(TaskEditor editor) {
		tabbedPanel.remove(editor.getMainPanel());
		for (int i = 0; i < leftMenu.getComponentCount(); i++) {
			Component component = leftMenu.getComponent(i);
			if (component instanceof TaskMenuItem) {
				TaskMenuItem taskMenuItem = (TaskMenuItem) component;
				if (taskMenuItem.getTaskEditor() == editor) {
					leftMenu.remove(taskMenuItem);
				}
			}
		}
	}

	public void runTask(String name) {
		if (name != null) {
			TaskEditor taskEditor = null;
			try {
				taskEditor = new TaskEditor(this);
				addTaskPanel(taskEditor, name);
				taskEditor.start(name);
			} catch (ConfigurationException e) {
				refreshRecipeMap(taskEditor);
			}
		}
	}

	public void refreshRecipeMap(TaskEditor taskEditor) {
		removeTab(taskEditor);
		int showConfirmDialog = JOptionPane.showConfirmDialog(this, "Recipe file is not found. Refresh recipe map?");
		if (showConfirmDialog == JOptionPane.OK_OPTION) {
			refreshTaskMap();
		}
	}

	public void setTestPath(String name, String path) {
		recipesPanel.refreshTaskPathTable();
		tabbedPanel.setTitleAt(tabbedPanel.getSelectedIndex(), name);
	}

	@Override
	public void pack() {
		// super.pack();
		int screenDevicesCount = GraphicsEnvironment.getLocalGraphicsEnvironment().getScreenDevices().length;

		int theX = (int) Float.parseFloat(
				AEWorkspace.getInstance().getDefaultUserConfiguration(".win_position_x:" + screenDevicesCount, "0"));
		int theY = (int) Float.parseFloat(
				AEWorkspace.getInstance().getDefaultUserConfiguration(".win_position_y:" + screenDevicesCount, "0"));
		int theW = Integer.parseInt(
				AEWorkspace.getInstance().getDefaultUserConfiguration(".win_position_w:" + screenDevicesCount, "680"));
		int theH = Integer.parseInt(
				AEWorkspace.getInstance().getDefaultUserConfiguration(".win_position_h:" + screenDevicesCount, "500"));

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		GraphicsEnvironment localGraphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();

		String win_maximized = AEWorkspace.getInstance().getDefaultUserConfiguration(".win_maximized", "0");
		if ("1".equals(win_maximized)) {
			setExtendedState(getExtendedState() | MAXIMIZED_BOTH);
		}
		if (localGraphicsEnvironment.getScreenDevices().length > 1
				|| (theX < screenSize.getWidth() - 20 && theY < screenSize.getHeight() - 20)) {
			Dimension size = new Dimension(theW, theH);
			setSize(size);
			setLocation(theX, theY);

			if (!isCompactStyle()) {
				setAlwaysOnTop(false);
				setAlwaysOnTop(true);
			}
		}
	}

	void refreshTaskMap() {
		Thread thread = new Thread(new Runnable() {

			public void run() {
				theJButton.setEnabled(false);
				try {
					setControlEnabled(false);
					refreshTaskPath();
					setControlEnabled(true);

				} catch (IOException e1) {
					JOptionPane.showMessageDialog(AEFrame.this,
							"<html>Incorrect TESTDIR value.<br/><br/><i>" + e1.getMessage() + "</i></html>");
					e1.printStackTrace();
				}
				theJButton.setEnabled(true);
			}

		});
		thread.start();
	}

	public void checkFailure(TaskEditor editor) {
		mainButton.setIcon(getIcon(LOGO_ERROR_JPG));
		if (editor != null) {
			failedEditor = editor;
		}
	}

	public void criticalError(TaskEditor editor) {
		mainButton.setIcon(getIcon(LOGO_FATAL_JPG));
		if (editor != null) {
			failedEditor = editor;
		}
	}

	public void setConsoleDefaultInput(boolean defaultMode) {
		fConsoleDefaultInputBox.setSelected(defaultMode);
		mainButton.setIcon(getIcon(getLogo()));
	}

	public UIChoiceTaskRunner getChoiceTaskRunner(MultiTaskRunDialog name, TaskProcessor taskProcessor, Object setup) {
		return new UIChoiceTaskRunner(name.getName(), taskProcessor, setup == null);
	}

	public void startTaskNotify(TaskEditor editor) {
		if (failedEditor == editor)
			mainButton.setIcon(getIcon(getLogo()));
	}

	protected void createAboutPanel() {
		JToolBar theToolBar = new JToolBar();
		theToolBar.setFloatable(false);
		getContentPane().add(theToolBar, BorderLayout.SOUTH);
	}

	public void progressValue(int i, int length, boolean success) {
		progress.setMinimum(0);
		if (length > 0) {
			progress.setValue(i);
			progress.setMaximum(length);
			progress.setForeground(success ? Color.green.darker() : Color.red.darker());
		} else {
			progress.setValue(0);
			progress.setMaximum(100);
			progress.setForeground(Color.lightGray);
		}
	}

	public String inputSelectChoice(String name, String[] aValues, String defaultValue, TaskProcessor taskProcessor,
			boolean notifyMe) {
		if (defaultValue == null && aValues.length > 0) {
			defaultValue = AEWorkspace.getInstance().getDefaultUserConfiguration(".choice." + name, aValues[0]);
		}

		if (workspace.isConsoleDefaultInput(name) == false) {
			pushOnTop();
			if (notifyMe) {
				soundManager.play();
			}

			defaultValue = simpleInput(name, aValues, defaultValue, null, false);
			SoundManager.stop();
			AEWorkspace.getInstance().setDefaultUserConfiguration(".choice." + name, defaultValue);
		}

		return defaultValue;
	}

	public void pushOnTop() {
		if (!isAlwaysOnTop()) {
			setAlwaysOnTop(true);
			setAlwaysOnTop(false);
		}
	}

	public boolean isConsoleDefaultInput() {
		return fConsoleDefaultInputBox.isSelected();
	}

	public void resetConfiguration() {
		tabbedPanel.removeAll();

	}

	public void resetUserAction() {
		lastUserActionTime = null;
	}

	public void fireBuzzAction() {
		fireBuzzAction(null);
	}

	public void fireBuzzAction(Runnable runnable) {
		if (isUserInactive()) {
			buzzAction(runnable);
		} else {
			if (runnable != null) {
				runnable.run();
			}
		}
	}

	private void buzzAction(Runnable runnable) {

		soundManager.play();

		boolean alwaysOnTop = isAlwaysOnTop();
		if (alwaysOnTop == false) {
			setAlwaysOnTop(true);
		}

		if (getState() == Frame.ICONIFIED) {
			setState(Frame.NORMAL);
		}

		Thread buzzThread = new Thread(new Runnable() {
			private Color color = Color.MAGENTA;
			private int borderSize = 10;
			private int period = 200;

			@Override
			public void run() {
				boolean bordered = true;
				while (!Thread.currentThread().isInterrupted()) {
					setBorder(bordered);
					bordered = !bordered;
					try {
						Thread.sleep(period);
					} catch (InterruptedException e) {
						break;
					}
				}
			}

			private void setBorder(boolean bordered) {
				JPanel glassPane = (JPanel) getContentPane();
				if (bordered) {
					glassPane.setBorder(
							BorderFactory.createMatteBorder(borderSize, borderSize, borderSize, borderSize, color));
				} else {
					glassPane.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.LIGHT_GRAY));
				}
				glassPane.repaint();
			}
		});
		buzzThread.start();

		if (runnable == null) {
			JOptionPane.showMessageDialog(getContentPane(), "Process finished!", "Notification",
					JOptionPane.INFORMATION_MESSAGE);
		} else {
			runnable.run();
		}

		SoundManager.stop();

		((JPanel) getContentPane()).setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.LIGHT_GRAY));
		buzzThread.interrupt();
		setAlwaysOnTop(alwaysOnTop);
	}

	public String choiceValue(String name, Object[] values, String title, ILogger log, boolean notifyMe) {
		String defaultValue = null;
		if (values != null && values.length > 0) {
			defaultValue = (String) values[0];
		}
		String result = AEWorkspace.getInstance().getDefaultUserConfiguration(".choiceValue." + name, defaultValue);

		if (workspace.isConsoleDefaultInput(name) == false) {
			pushOnTop();
			if (notifyMe) {
				soundManager.play();
			}
			result = simpleInput(name, values, result, null, false);
			AEWorkspace.getInstance().setDefaultUserConfiguration(".choiceValue." + name, result);
			SoundManager.stop();
		}

		return result;
	}

	public void saveEnvProperties() {
		String customConfPropFileName = getWorkspace().getCustomConfPropFileName(getWorkspace().getConfigurationName());

		File theConfDir = getWorkspace().getHomeConfigurationsDir();
		if (theConfDir.exists() && theConfDir.isDirectory()) {
			theConfDir.mkdirs();
		}

		Properties theConfProp = new Properties();

		Set<Entry<String, Object>> entrySet = getWorkspace().getSystemVariables().entrySet();
		for (Entry<String, Object> entry : entrySet) {
			Object value = entry.getValue();
			if (value instanceof String) {
				theConfProp.setProperty(entry.getKey(), (String) value);
			} else if (value instanceof List) {
				theConfProp.setProperty(entry.getKey(), (String) ((List<?>) value).get(0));
			}
		}

		try {
			FileOutputStream theFile = new FileOutputStream(customConfPropFileName);
			theConfProp.store(theFile, null);
			theFile.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		try {
			refreshTaskPath();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean isMenuDisabled() {
		return menuDisabled;
	}

	private String getLogo() {
		return fConsoleDefaultInputBox.isSelected() ? TAKE_IT_EASY_JPG : LOGO_JPG;
	}

	public boolean isUserInactive() {
		Long lastUserActionTime = getLastUserActionTime();
		return lastUserActionTime == null
				|| (lastUserActionTime + USER_ACTION_NOTIFY_TIMEOUT) < System.currentTimeMillis();
	}

	public SoundManager getSoundManager() {
		return soundManager;
	}

	public void setSoundManager(SoundManager soundManager) {
		this.soundManager = soundManager;
	}

	public void out(LogRecord text, TaskProcessor taskProcessor) {
	}
}
