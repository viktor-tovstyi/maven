package com.nave.anteater;

import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import javax.swing.AbstractAction;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ListSelectionModel;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.UIUtils;
import com.nave.anteater.util.xml.easyparser.Node;
import com.nave.anteater.view.TextLogPresenter;
import com.nave.anteater.view.ListLogPresenter.LogRecord;

class JAttachButton extends JLabel implements MouseListener {

	private static final long serialVersionUID = 1L;

	private String fFileName;

	private String fDesc;

	private String width;

	private String height;

	private WorkPlace workplace;

	private String taskName;

	public JAttachButton(WorkPlace workplace, Node aFileNode, String taskName) {

		this.workplace = workplace;
		this.taskName = taskName;

		TaskProcessor processor = workplace.getTaskProcessor();
		String name = aFileNode.getAttribute("name");
		name = processor.replaceProperties(name);

		File file = workplace.getManager().getFile(SystemUtils.getUserDir(), name);
		if (file != null && file.exists()) {
			fFileName = file.getAbsolutePath();
		} else {
			fFileName = name;
		}

		setToolTipText(name);

		fDesc = aFileNode.getAttribute("description");
		width = aFileNode.getAttribute("width");
		height = aFileNode.getAttribute("height");
		addMouseListener(this);
		setCursor(new Cursor(Cursor.HAND_CURSOR));
		setIcon(AEFrame.getIcon("doc.png"));
		if (fDesc != null) {
			setToolTipText(fDesc);
		}
	}

	public void mouseClicked(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1) {
			try {
				String theType = null;

				if (StringUtils.startsWithIgnoreCase(fFileName, "http")) {
					Desktop.getDesktop().browse(new URI(fFileName));
				} else if (fFileName.toUpperCase().endsWith(".HTM") || fFileName.toUpperCase().endsWith(".HTML")) {
					theType = "text/html";
				} else if (fFileName.toUpperCase().endsWith(".TXT")) {
					theType = "text/plain";
				} else if (fFileName.toUpperCase().endsWith(".RTF")) {
					theType = "text/rtf";
				} else {
					Desktop.getDesktop().open(new File(fFileName));
				}

				if (theType != null) {
					JDialog theAttachFrame = new JDialog(workplace.getAeFrame(), fDesc, false);
					theAttachFrame
							.setTitle(StringUtils.defaultIfEmpty(fDesc, "About: \"" + taskName + "\" - " + fFileName));

					theAttachFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
					String theText = IOUtils.toString(new FileInputStream(
							workplace.getManager().getFile(workplace.getTaskProcessor().getBaseDir(), fFileName)));
					JEditorPane editorPane = new JEditorPane();

					editorPane.setEditorKit(JEditorPane.createEditorKitForContentType(theType));
					editorPane.setText(theText);
					editorPane.addHyperlinkListener(new HyperlinkListener() {
						public void hyperlinkUpdate(HyperlinkEvent e) {
							if (e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
								String description = e.getDescription();
								if (StringUtils.startsWith(description, AEFrame.TASK_PROTOCOL)) {
									String taskName = StringUtils.substringAfter(description, AEFrame.TASK_PROTOCOL);
									workplace.getManager().runTask(taskName, true);
								} else {
									if (Desktop.isDesktopSupported()) {
										try {
											URL url = e.getURL();
											Desktop.getDesktop().browse(url.toURI());
										} catch (IOException | URISyntaxException e1) {
											workplace.getLogger().error("Can't open URL: " + e.getURL(), e1);
										}
									}
								}
							}
						}
					});

					editorPane.setEditable(false);
					JScrollPane theScroll = new JScrollPane(editorPane);
					theAttachFrame.setContentPane(theScroll);
					theAttachFrame.pack();

					Dimension size = theAttachFrame.getSize();
					if (size.getWidth() > 700)
						size.width = 700;
					if (size.getHeight() > 500)
						size.height = 500;

					try {
						if (width != null)
							size.width = Integer.parseInt(width);
						if (height != null)
							size.height = Integer.parseInt(height);
					} catch (Exception e1) {
						//
					}

					UIUtils.applyPreferedView(theAttachFrame, "attach_frame" + fFileName, size.height, size.width);

					theAttachFrame.addWindowListener(new WindowAdapter() {
						@Override
						public void windowClosing(WindowEvent e) {
							UIUtils.saveDialogPreferedView(theAttachFrame, "attach_frame" + fFileName);
							super.windowClosing(e);
						}
					});

					theAttachFrame.setVisible(true);
				}

			} catch (Exception e1) {
				if (workplace.getManager().isConsoleDefaultInput(null) == false)
					JOptionPane.showMessageDialog(JOptionPane.getRootFrame(), e1.getMessage(),
							"Attach opening is failed", JOptionPane.ERROR_MESSAGE);
				workplace.getLogger().error("Throubles with coping attach.", e1);
			}
		}

		if (e.getButton() == MouseEvent.BUTTON3) {
			final JPopupMenu popup = new JPopupMenu();
			JMenuItem jMenuItem = new JMenuItem("Copy Path");
			jMenuItem.addActionListener(new AbstractAction() {

				@Override
				public void actionPerformed(ActionEvent var1) {
					StringSelection stringSelection = new StringSelection(fFileName);
					Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
					clipboard.setContents(stringSelection, null);
				}

			});
			popup.add(jMenuItem);
			popup.show(e.getComponent(), e.getX(), e.getY());
		}

	}

	public void mouseEntered(MouseEvent e) {

	}

	public void mouseExited(MouseEvent e) {

	}

	public void mousePressed(MouseEvent e) {

	}

	public void mouseReleased(MouseEvent e) {

	}

}
