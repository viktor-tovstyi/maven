package com.nave.anteater;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import org.apache.commons.lang.StringUtils;

public class RecipesPanel extends JPanel {

	private static final long serialVersionUID = -7864956226414737090L;

	private static final String MENU_PREFERENCE_PROP_NAME = "MenuPreferences";

	private Vector<Vector<Object>> fPathVaribles = new Vector<Vector<Object>>();

	private AEWorkspace workspace;

	private Set<String> menuTasks = new TreeSet<>();

	private JTable table = new JTable();

	private JTextField filter = new JTextField();

	public RecipesPanel(AEWorkspace workspace) {
		super(new BorderLayout());

		this.workspace = workspace;

		Vector<String> columns = new Vector<String>();

		columns.add("Menu");
		columns.add("Name");
		columns.add("Path");

		DefaultTableModel defaultTableModel = new DefaultTableModel(fPathVaribles, columns) {

			private static final long serialVersionUID = 1L;

			@Override
			public boolean isCellEditable(int row, int column) {
				return column == 0;
			}

			@Override
			public Class<?> getColumnClass(int coll) {
				if (coll == 0)
					return Boolean.class;
				return String.class;
			}

			@Override
			public void setValueAt(Object value, int row, int coll) {
				if (coll == 0) {
					Vector<Object> vector = fPathVaribles.get(row);
					vector.set(0, value);
					String task = (String) vector.get(1);
					if ((boolean) value) {
						menuTasks.add(task);
					} else {
						menuTasks.remove(task);
					}
					saveMenuList();
				}
			}
		};

		table.setModel(defaultTableModel);
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		table.setCellSelectionEnabled(true);
		table.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent arg0) {
				try {
					if (arg0.getClickCount() == 2) {
						String name = (String) table.getModel().getValueAt(table.getSelectedRow(), 1);
						TaskEditor editTask = editTask(name);
						if (editTask != null) {
							editTask.setRunButtonAction(true);
						}
					}
				} catch (Exception e) {
					JOptionPane.showMessageDialog(JOptionPane.getRootFrame(),
							"Incorrect code!\nError: " + e.getMessage());
				}
			}

		});

		TableColumn column = table.getColumnModel().getColumn(0);
		column.setPreferredWidth(28);
		column.setMaxWidth(40);
		column.setCellEditor(new DefaultCellEditor(new JCheckBox()));

		column = table.getColumnModel().getColumn(1);
		column.setPreferredWidth(400);
		
		column = table.getColumnModel().getColumn(2);
		column.setPreferredWidth(28);
		
		table.getTableHeader().setReorderingAllowed(false);

		filter.setBorder(BorderFactory.createEtchedBorder());
		filter.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				refreshTaskPathTable();
				if (e.getKeyCode() == KeyEvent.VK_ENTER) {
					int rowCount = table.getRowCount();
					if (rowCount == 1) {
						String taskName = (String) table.getModel().getValueAt(0, 1);
						TaskEditor editTask = editTask(taskName);
						if (editTask != null) {
							editTask.setRunButtonAction(true);
						}
					}
				}
			}
		});

		JPanel filterPanel = new JPanel(new BorderLayout());
		filterPanel.add(filter, BorderLayout.CENTER);
		JButton cleanFilterBtn = new JButton("X");
		cleanFilterBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				filter.setText("");
				refreshTaskPathTable();
			}
		});
		filter.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode() == KeyEvent.VK_ESCAPE) {
					filter.setText("");
				}
			}
		});
		cleanFilterBtn.setFont(new Font(cleanFilterBtn.getFont().getName(), Font.PLAIN, 14));
		cleanFilterBtn.setBorder(new EmptyBorder(0, 0, 0, 0));
		cleanFilterBtn.setBorderPainted(false);
		filterPanel.add(cleanFilterBtn, BorderLayout.EAST);
		add(filterPanel, BorderLayout.NORTH);

		add(new JScrollPane(table), BorderLayout.CENTER);
	}

	public TaskEditor editTask(String name) {
		return null;
	}

	public void refreshTaskPathTable() {
		String filerText = filter.getText();

		fPathVaribles.removeAllElements();
		String menuPrefStr = AEWorkspace.getInstance().getDefaultUserConfiguration(MENU_PREFERENCE_PROP_NAME, null);
		String[] prefMenu = StringUtils.split(menuPrefStr, ";");
		if (prefMenu != null) {
			Set tehKeySet = workspace.getTestsDescList().keySet();
			for (String menu : prefMenu) {
				if (tehKeySet.contains(menu)) {
					menuTasks.add(menu);
				}
			}
		}

		Set tehKeySet = workspace.getTestsDescList().keySet();
		Object[] theKeys = tehKeySet.toArray();
		Arrays.sort(theKeys);

		for (int theCurId = 0; theCurId < theKeys.length; theCurId++) {

			String key = (String) theKeys[theCurId];
			Object theValue = workspace.getTestsDescList().get(key);

			boolean menu = menuTasks.contains(key);
			if (StringUtils.isBlank(filerText) || StringUtils.containsIgnoreCase(key, filerText)
					|| (StringUtils.containsIgnoreCase("menu", filerText) && menu)) {
				Vector theCurrentRow = new Vector();
				theCurrentRow.add(menu);
				theCurrentRow.add(key);
				theCurrentRow.add(theValue);

				fPathVaribles.add(theCurrentRow);
			}
		}

		File theConfFile;
		try {
			theConfFile = workspace.getTaskListCashFile();
			FileOutputStream fileOutputStream = new FileOutputStream(theConfFile);
			String theTestDir = (String) workspace.getSystemVariables().get("TESTDIR");
			workspace.getTestsDescList().store(fileOutputStream, theTestDir);
			fileOutputStream.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		((AbstractTableModel) table.getModel()).fireTableDataChanged();
	}

	private void saveMenuList() {
		AEWorkspace.getInstance().setDefaultUserConfiguration(MENU_PREFERENCE_PROP_NAME,
				StringUtils.join(menuTasks, ";"));
	}

	public void refresh() {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				invalidate();
				repaint();
			}
		});
	}

	public void setMenuTask(String task) {
		menuTasks.add(task);
	}

	public Set<String> getMenuTasks() {
		return menuTasks;
	}

	public JTable getTable() {
		return table;
	}

}
