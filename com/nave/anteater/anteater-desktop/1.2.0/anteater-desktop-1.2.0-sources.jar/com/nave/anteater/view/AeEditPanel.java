package com.nave.anteater.view;

import java.awt.Component;
import java.awt.Point;

import com.nave.anteater.AEManager;
import com.nave.anteater.Editor;
import com.nave.anteater.processor.TaskProcessor;

public interface AeEditPanel {

	void save();

	void format();

	void runTask();

	Point getMagicCaretPosition();

	Component getComponent();

	String getText();

	int getCaretPosition();

	TaskProcessor getTaskProcessor();

	AEManager getManager();

	void replaceRange(String text, int i, int caretPosition2);

	JDialogPopupMenu contextHelp(JDialogPopupMenu menu);

	Editor getEditor();
	
	void reload();

}
