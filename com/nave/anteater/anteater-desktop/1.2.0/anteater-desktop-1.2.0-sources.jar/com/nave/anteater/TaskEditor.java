package com.nave.anteater;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ContainerEvent;
import java.awt.event.ContainerListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Observable;
import java.util.Observer;
import java.util.Properties;
import java.util.Set;
import java.util.Vector;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSlider;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.JTree.DynamicUtilTreeNode;
import javax.swing.KeyStroke;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.log4j.Logger;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.xml.easyparser.EasyParser;
import com.nave.anteater.util.xml.easyparser.EasyUtils;
import com.nave.anteater.util.xml.easyparser.Node;
import com.nave.anteater.util.xml.easyparser.Node.TreeVector;
import com.nave.anteater.view.AeEditPanel;
import com.nave.anteater.view.CodeHelper;
import com.nave.anteater.view.DatabaseCommandPanel;
import com.nave.anteater.view.JDialogPopupMenu;
import com.nave.anteater.view.ListLoggPanel;
import com.nave.anteater.view.LoggPanel;
import com.nave.anteater.view.VariableViewPanel;
import com.nave.anteater.view.panel.PresentationPanel;

/**
 * @author victort
 * @version 1.0, 29-Jul-2005
 */
public class TaskEditor extends WorkPlace implements AEPanel, KeyListener, Observer, AeEditPanel, ContainerListener {

	private static final Color ACTIVE_COLOR = Color.GREEN.darker();

	private static final Font font = new Font("Monospaced", Font.PLAIN, 12);

	private static final String SQL_REQUEST_PANEL = "Database";

	private static final String TASK_EDITOR = "Editor";

	private static final String TASK_TREE = "Processing";

	protected static final String VARIABLES_LIST = "Variables";

	private JTree taskTree;

	private String fTaskFile;

	private Vector<?> fTreeVector;

	private Editor fTaskText = new Editor();
	private JScrollPane theJScrollPane = new JScrollPane();

	private JTabbedPane fOutputTabbedPane;

	private Map<String, Object> fPresentationPanels = new HashMap<String, Object>();

	private TaskPanel thePanel;

	private JMenuItem fRunMenuItem = new JMenuItem("Run");

	private JMenuItem fContinueMenuItem = new JMenuItem("Continue");

	private JMenuItem fCompileMenuItem = new JMenuItem("Compile");

	private JMenuItem fStopMenuItem = new JMenuItem("Stop");

	private JMenuItem fPauseMenuItem = new JMenuItem("Pause");

	private JTabbedPane createEditorPanel;

	private DatabaseCommandPanel fRequestPanel;

	private JButton fRunButton = new JButton("Run");

	private JButton fCloseButton = new JButton(AEFrame.getIcon("close.png"));

	private JCheckBox fNotifyMe = new JCheckBox();

	private JMenuItem saveMenuItem;

	private JSplitPane fOutputSplitPanel;

	private JSlider speed = new JSlider(0, 100, 100);

	private AEFrame frame;

	private VariableViewPanel variables;

	protected boolean consoleDefaultInput;

	private boolean changed;

	private boolean openIn;

	private JTabbedPane tabbedPanel;

	public TaskEditor(AEFrame aFrame, Node aConfigNode, Map<String, Object> aSystemVariables) {
		super(aFrame, aConfigNode, aSystemVariables);
		this.frame = aFrame;

		this.thePanel = new TaskPanel(this);
		variables = new VariableViewPanel(this);

		fOutputTabbedPane = new JTabbedPane();
		fOutputTabbedPane.setPreferredSize(new Dimension(200, 800));
		fOutputTabbedPane.addKeyListener(this);

		createEditorPanel = createEditorPanel();

		fOutputSplitPanel = new JSplitPane(JSplitPane.VERTICAL_SPLIT, createEditorPanel, fOutputTabbedPane);

		setSplitPanel();

		thePanel.add(fOutputSplitPanel, BorderLayout.CENTER);
		JMenuBar menuBar = new JMenuBar();

		createFileMenu(menuBar);
		createProcessMenu(menuBar);

		Node taskNode = getTaskNode();
		if (taskNode != null && taskNode.findNode("About", null, null) != null) {
			showAbout();
		}

		JPanel panel = new JPanel(new BorderLayout(4, 4));
		panel.setBorder(BorderFactory.createEtchedBorder());
		JPanel panel2 = new JPanel(new BorderLayout(4, 4));
		panel2.add(menuBar, BorderLayout.WEST);
		panel2.add(fRunButton, BorderLayout.CENTER);
		fNotifyMe.setIcon(AEFrame.getIcon("shout-off.png"));
		fNotifyMe.setSelectedIcon(AEFrame.getIcon("shout.png"));
		panel2.add(fNotifyMe, BorderLayout.EAST);

		fNotifyMe.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				if (getTaskName() != null) {
					String aName = getTaskName() + ".notifyMe";
					String value = Boolean.toString(fNotifyMe.isSelected());
					AEWorkspace.getInstance().setDefaultUserConfiguration(aName, value);
				}
			}
		});

		speed.setPreferredSize(new Dimension(30, 18));
		speed.setToolTipText("Action speed");
		speed.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				speed.setToolTipText("Delay: " + getTraceDelay() + "ms.");
			}
		});
		panel.add(panel2, BorderLayout.WEST);
		panel.add(fCloseButton, BorderLayout.EAST);

		fCloseButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				stopTest();
				closeTab();
			}

		});

		thePanel.add(panel, BorderLayout.NORTH);

		JPanel aboutPanel = new JPanel(new BorderLayout());
		aboutPanel.add(aboutToolBox, BorderLayout.WEST);
		aboutPanel.add(fTitleTest, BorderLayout.CENTER);

		panel.add(aboutPanel, BorderLayout.CENTER);
	}

	public void setSplitPanel() {
		fOutputSplitPanel.setOneTouchExpandable(true);
		fOutputSplitPanel.setDividerLocation(0.0);
		fOutputSplitPanel.setLastDividerLocation(0);
	}

	private String getTaskName() {
		String name = null;
		if (getTaskNode() != null) {
			name = getTaskNode().getAttribute("name");
		}
		return name;
	}

	public TaskEditor(AEFrame aeFrame) {
		this(aeFrame, aeFrame.getWorkspace().getConfigNode(), aeFrame.getWorkspace().getSystemVariables());
		setRunButtonAction(false);
	}

	private void createFileMenu(JMenuBar menuBar) {
		JMenu menu = new JMenu("File");

		JMenuItem menuItem;
		menuItem = new JMenuItem("Save");
		try {
			menuItem.setAccelerator(
					KeyStroke.getKeyStroke('S', Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
		} catch (Exception e) {
		}

		this.saveMenuItem = menuItem;
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				changed = false;
				save();
			}
		});
		menu.add(menuItem);

		menuItem = new JMenuItem("Reload");
		final JMenuItem reloadmenuItem = menuItem;
		try {
			menuItem.setAccelerator(
					KeyStroke.getKeyStroke('R', Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
		} catch (Exception e) {
		}
		this.saveMenuItem = menuItem;
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				reload();
			}
		});
		menu.add(menuItem);

		menuItem = new JMenuItem("Open In");
		try {
			menuItem.setAccelerator(
					KeyStroke.getKeyStroke('O', Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
		} catch (Exception e) {
		}
		this.saveMenuItem = menuItem;
		menuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {

				File file = new File(fTaskFile);
				if (file.exists()) {
					try {
						Desktop.getDesktop().open(file);
						openIn = true;
						reloadmenuItem.setEnabled(false);

					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		});
		menu.add(menuItem);

		menu.add(new JSeparator());
		menuItem = new JMenuItem("Close");
		try {
			menuItem.setAccelerator(
					KeyStroke.getKeyStroke('X', Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
		} catch (Exception e) {
		}
		menuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				closeTab();
			}

		});
		menu.add(menuItem);
		menuBar.add(menu);
	}

	public void reload() {
		openTaskFile(fTaskFile);
	}

	public void save() {
		format();
		saveTask();
	}

	public void format() {
		try {
			compileTask();
			refreshTaskTree();
			Node taskNode = getTaskNode();
			if (taskNode != null && taskNode.findNode("About", null, null) != null) {
				showAbout();
			}
		} catch (Exception e) {
			getLog().error("Save action failed.", e);
		}
	}

	private void createProcessMenu(JMenuBar menuBar) {
		JMenu menu = new JMenu("Process");

		menu.add(fCompileMenuItem);
		fCompileMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {

					compileTask();
				} catch (Exception e) {
					getLog().error("Compilation failed.", e);
				}
			}
		});

		menu.add(fRunMenuItem);

		try {
			fRunMenuItem.setAccelerator(
					KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
		} catch (Exception e) {
		}

		fRunMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				runTask();
			}
		});
		menu.add(speed);

		fRunButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boolean isCurrentRunAction = "Run".equals(arg0.getActionCommand());

				if (isCurrentRunAction)
					runTask();
				else {
					stopTest();
					if (getTaskProcessor().isStoppedTest()) {
						setRunButtonAction(true);
					}
				}
			}
		});

		menu.add(fPauseMenuItem);

		try {
			fPauseMenuItem.setAccelerator(
					KeyStroke.getKeyStroke('P', Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
		} catch (Exception e) {
		}

		fPauseMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				getTaskProcessor().pause();
			}
		});

		menu.add(fContinueMenuItem);

		try {
			fContinueMenuItem.setAccelerator(
					KeyStroke.getKeyStroke('P', Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
		} catch (Exception e) {
		}

		fContinueMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				getTaskProcessor().resume();
			}
		});

		try {
			fStopMenuItem.setAccelerator(
					KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, Toolkit.getDefaultToolkit().getMenuShortcutKeyMaskEx()));
		} catch (Exception e) {
		}

		fStopMenuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				stopTask();
			}

		});
		menu.add(fStopMenuItem);
		menuBar.add(menu);
	}

	public void setProgress(String message, long aMaxTags, long aCurrTags, boolean aErrorState) {
		manager.progressValue((int) (((double) aCurrTags / aMaxTags) * 100), 100, true);
		fTitleTest.setText(message);
	}

	public void stopTask() {
		for (Object key : fPresentationPanels.keySet()) {
			Object panel = fPresentationPanels.get(key);
			if (panel instanceof LoggPanel) {
				LoggPanel presentationPanel = (LoggPanel) panel;
				presentationPanel.setEnabled(false);
			}
		}

		super.stopTest();
	}

	private JTabbedPane createEditorPanel() {
		JTabbedPane editorPanel = new JTabbedPane();
		editorPanel.setTabPlacement(JTabbedPane.BOTTOM);

		theJScrollPane.getViewport().add(fTaskText);
		fTaskText.addKeyListener(new CodeHelper(this, getLog()));
		fTaskText.setEditable(true);
		fTaskText.addKeyListener(new KeyAdapter() {

			@Override
			public void keyTyped(KeyEvent e) {
				changed = true;
			}
		});

		fTaskText.setFont(font);
		fTaskText.setTabSize(4);

		JScrollPane theScroll = new JScrollPane();
		theScroll.getViewport().removeAll();
		taskTree = new JTree();
		taskTree.setRootVisible(false);

		taskTree.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if (e.getClickCount() == 2) {
					DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) taskTree
							.getLastSelectedPathComponent();
					TreeVector userObject = (TreeVector) selectedNode.getUserObject();
					Node node = userObject.getNode();

					String tagName = node.getTag();
					if ("Task".equals(tagName)) {
						String name = node.getAttribute("name");
						TaskEditor editTask = getAeFrame().editTask(name);
						editTask.setRunButtonAction(true);
					}
				}
			}
		});

		theScroll.getViewport().add(taskTree);

		editorPanel.addTab(TASK_TREE, theScroll);
		editorPanel.addTab(TASK_EDITOR, theJScrollPane);
		editorPanel.addTab(VARIABLES_LIST, variables);

		editorPanel.addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				Component selectedComponent = editorPanel.getSelectedComponent();
				if (selectedComponent instanceof VariableViewPanel) {
					VariableViewPanel panel = (VariableViewPanel) selectedComponent;
					panel.refreshData();
				}
			}
		});

		theJScrollPane.setSize(0, 0);
		theScroll.setSize(0, 0);
		variables.setSize(0, 0);

		return editorPanel;
	}

	public void compileTask() throws Exception {
		try {
			Node object = new EasyParser().getObject(fTaskText.getText());
			setTaskNode(object);

		} catch (Exception e1) {
			JOptionPane.showMessageDialog(JOptionPane.getRootFrame(), "Incorrect code!\nError: " + e1.getMessage());
			throw e1;
		}
	}

	public void showPanel(JTabbedPane panel, String name) {
		if (name == null) {
			name = getPanelName();
		}
		tabbedPanel = panel;
		panel.addContainerListener(this);
		panel.addTab(name, thePanel);
		panel.setSelectedComponent(thePanel);
	}

	public JPanel getMainPanel() {
		return thePanel;
	}

	public void endTask(boolean aErrorState) {
		super.endTask(aErrorState);
		fRunMenuItem.setEnabled(true);
		setRunButtonAction(true);
	}

	private void openTaskFile(String filePath) {
		fTaskFile = filePath;
		if (new File(fTaskFile).exists()) {
			if (!openIn) {
				setEditable(true);
			}
		}

		try {
			Node taskNode = getTaskNode();
			if (taskNode != null) {
				Node[] nodes = taskNode.getNodes("Note");
				if (nodes != null && nodes.length > 0) {
					String text = nodes[0].getNode(0).getText();
					createSqlNotePanel();
					fRequestPanel.setText(text.trim());
				}
			}
		} catch (Exception e) {
			throw new ConfigurationException("Invalide recipe file.", e);
		}
		try {
			Node load = new EasyParser().load(filePath);
			setTaskNode(load);
			refreshTaskTree();
		} catch (Exception e1) {
			throw new ConfigurationException("Invalide recipe file.", e1);
		}
	}

	private void setEditable(boolean editable) {
		saveMenuItem.setEnabled(editable);
		fTaskText.setEditable(editable);
	}

	protected void refreshTaskTree() {
		if (getTaskNode() != null) {

			int caretPosition = fTaskText.getCaretPosition();
			fTaskText.setOriginalText(getTaskNode().getXMLText());
			fTaskText.setCaretPosition(caretPosition);

			fTreeVector = getTaskNode().getVector(true);

			DefaultMutableTreeNode root = new DefaultMutableTreeNode("root");
			DynamicUtilTreeNode.createChildren(root, fTreeVector);
			DefaultTreeModel model = new DefaultTreeModel(root, false);
			taskTree.setModel(model);

			taskTree.setEditable(false);
			taskTree.setEnabled(true);

			taskTree.setFont(font);
			taskTree.setForeground(ACTIVE_COLOR);
			for (int i = 0; i < taskTree.getRowCount(); i++) {
				taskTree.expandRow(i);
			}
		}
	}

	public void changeVariable(String aAttribut, Object aValue) {
	}

	public void update(Observable o, Object arg) {
	}

	private abstract class ComponentActionListener implements ActionListener {
		protected Component component;

		public ComponentActionListener(Component component) {
			this.component = component;
		}
	}

	static class JBorderedPanel extends JPanel {
		private static final long serialVersionUID = 1L;

		public JBorderedPanel(Component aNorth, Component aWest, Component aCenter, Component aEast, Component aSouth) {
			setLayout(new BorderLayout());
			if (aNorth != null) {
				add(aNorth, BorderLayout.NORTH);
			}
			if (aWest != null) {
				add(aWest, BorderLayout.WEST);
			}
			if (aCenter != null) {
				add(aCenter, BorderLayout.CENTER);
			}
			if (aEast != null) {
				add(aEast, BorderLayout.EAST);
			}
			if (aSouth != null) {
				add(aSouth, BorderLayout.SOUTH);
			}
		}
	}

	public void startCommand(int aNumberCommand) {
		setRunButtonAction(false);
		try {
			if (taskTree != null) {
				taskTree.setSelectionRow(aNumberCommand);
				long delay = getTraceDelay();
				if (delay > 0) {
					Thread.sleep(delay);
				}
			}
		} catch (Exception e) {
		}
	}

	private long getTraceDelay() {
		int delay = (int) ((Math.pow(1.5, (double) (100 - speed.getValue()) / 4)) - 1);
		return delay;
	}

	public void aboutTest(String theTaskName, Node aCurrentAction) {
		try {
			setAbout(theTaskName, aCurrentAction);
			aboutToolBox.setVisible(true);
		} catch (Exception e) {
			getLog().error("Error", e);
		}
	}

	protected void createAboutPanel() {
	}

	public void runCommandFrame(Properties params) throws Throwable {
		String theFrameId = params.getProperty("frameId");
		String title = params.getProperty("title");

		String reuse = params.getProperty("reuse");
		if ("true".equals(reuse)) {
			PresentationPanel thePPanel = (PresentationPanel) fPresentationPanels.get(theFrameId);
			if (thePPanel != null) {
				return;
			}
		}

		createFrame(theFrameId, params, title);
	}

	private PresentationPanel createFrame(String theFrameId, Properties linkedMap, String title) throws Exception {

		if (title == null) {
			title = theFrameId;
		}

		Class ppClass = Class.forName("com.nave.anteater.view.panel." + linkedMap.getProperty("type", "TextPanel"));
		Constructor constructor = ppClass.getConstructor(Properties.class);
		PresentationPanel thePPanel = (PresentationPanel) constructor.newInstance(linkedMap);
		fPresentationPanels.put(theFrameId, thePPanel);

		JPanel panel = new JPanel(new BorderLayout());
		JToolBar tools = new JToolBar();
		JButton comp = new JButton(AEFrame.getIcon("close.png"));
		comp.addActionListener(new ComponentActionListener(thePPanel) {
			@Override
			public void actionPerformed(ActionEvent e) {
				Object frameId = ((PresentationPanel) component).getFrameId();
				removeActivePresentationPanel();
				fPresentationPanels.remove(frameId);
			}
		});
		tools.add(comp);
		panel.add(tools, BorderLayout.NORTH);
		panel.add(thePPanel, BorderLayout.CENTER);

		fOutputTabbedPane.add(title, panel);
		fOutputTabbedPane.setSelectedComponent(panel);
		return thePPanel;
	}

	public void outToFrame(TaskProcessor processor, Properties properties, Object value) throws Exception {
		String frameId = processor.replaceProperties((String) properties.get("frameId"));
		if (frameId != null) {
			PresentationPanel thePPanel = (PresentationPanel) fPresentationPanels.get(frameId);
			if (thePPanel == null) {
				thePPanel = createFrame(frameId, properties, null);
			}
			thePPanel.out(value, properties);
		}
	}

	public void keyTyped(KeyEvent e) {

	}

	public void keyPressed(KeyEvent e) {

	}

	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_F4 && e.isControlDown()) {
			removeActivePresentationPanel();
		}
	}

	public void removeActivePresentationPanel() {
		int selectedIndex = fOutputTabbedPane.getSelectedIndex();

		Component theComp = fOutputTabbedPane.getComponent(selectedIndex);
		if (theComp instanceof PresentationPanel) {
			PresentationPanel thePPanel = (PresentationPanel) theComp;
			fPresentationPanels.remove(thePPanel.getFrameId());
		}

		fOutputTabbedPane.remove(selectedIndex);
		fLoggers.remove(findLogger(theComp));
	}

	/* ---------------------------------------- */

	public void windowActivated(WindowEvent e) {

	}

	public void windowClosed(WindowEvent e) {

	}

	int fNumberLog = 1;

	private ArrayList<LoggPanel> fLoggers = new ArrayList<LoggPanel>();

	public Logger createLog(String aLogName, boolean mainLog) {

		LoggPanel loggPanel = findLogger(aLogName);

		if (loggPanel == null) {
			if (aLogName == null || aLogName.length() == 0)
				aLogName = "Log #" + String.valueOf(fNumberLog++);
			loggPanel = new ListLoggPanel(this, aLogName, mainLog);

		}

		// fOutputTabbedPane.setSelectedComponent(loggPanel.getPanel());
		setLog(loggPanel);
		return loggPanel;
	}

	private LoggPanel findLogger(String aLogName) {
		if (aLogName == null) {
			return fLoggers.get(0);
		}

		int tabCount = fLoggers.size();
		for (int i = 0; i < tabCount; i++) {
			LoggPanel logger = (LoggPanel) fLoggers.get(i);
			if (logger.getName().equals(aLogName)) {
				return logger;
			}
		}

		return null;
	}

	private LoggPanel findLogger(Component aLogName) {
		int tabCount = fLoggers.size();
		for (int i = 0; i < tabCount; i++) {
			LoggPanel logger = (LoggPanel) fLoggers.get(i);
			if (logger.getPanel() == aLogName) {
				return logger;
			}
		}
		return null;
	}

	public void errorInformation(TaskProcessor processor, Throwable e, Node aTask) throws CommandException {
		TracePanel panel = new TracePanel(processor, e, aTask);

		fOutputTabbedPane.add("Trace", panel);
		fOutputTabbedPane.setSelectedComponent(panel);

		int showConfirmDialog = JOptionPane.OK_OPTION;

		if (frame.getWorkspace().isConsoleDefaultInput(null) == false)
			showConfirmDialog = JOptionPane.showConfirmDialog(JOptionPane.getRootFrame(),
					"There was an error. Do you want to continue this task?",
					"Catch exeption for paused mode. Press 'OK' for continue.", JOptionPane.OK_CANCEL_OPTION);

		if (showConfirmDialog != JOptionPane.OK_OPTION)
			throw new CommandException("Pause is canceled.", processor);
	}

	class TracePanel extends JPanel {

		private static final long serialVersionUID = 1L;

		JSplitPane thePanel;

		public TracePanel(TaskProcessor processor, Throwable e, Node aTask) {
			super(new BorderLayout());

			PanelTree jTree = new PanelTree(processor.getCallTaskTrace());
			String message = e.getMessage();
			if (message == null)
				message = "Message is null.";
			JTextArea theJTextArea = new JTextArea(message);
			theJTextArea.setEditable(false);
			theJTextArea.setOpaque(false);

			JScrollPane jScrollPane = new JScrollPane(theJTextArea);
			JSplitPane theStackPanel = new JSplitPane(JSplitPane.VERTICAL_SPLIT, jScrollPane, jTree);
			theStackPanel.setDividerLocation(0.0);

			JTree theTask = new JTree(aTask.getVector(true));
			thePanel = new JSplitPane(JSplitPane.VERTICAL_SPLIT, theStackPanel, theTask);
			thePanel.setDividerLocation(0.0);
			thePanel.setOneTouchExpandable(true);

			add(thePanel, BorderLayout.CENTER);
			JPanel panel2 = new JPanel(new BorderLayout());
			JButton button = new JButton(AEFrame.getIcon("close.png"));
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					fOutputTabbedPane.remove(TracePanel.this);
				}
			});
			panel2.add(button, BorderLayout.EAST);
			add(panel2, BorderLayout.NORTH);
		}

		public Component getSelectedComponent() {
			return thePanel;
		}
	}

	class VarTableModel extends AbstractTableModel {
		private static final long serialVersionUID = 1L;
		private String[][] fRows;

		public VarTableModel() throws Exception {
			Set<String> enumeration = getSystemVariables().keySet();
			fRows = new String[getSystemVariables().size()][2];
			int i = 0;
			for (String theName : enumeration) {
				String theValue = (String) getSystemVariables().get(theName);
				fRows[i][0] = theName;
				fRows[i][1] = theValue;
				i++;
			}
		}

		public int getColumnCount() {
			return 2;
		}

		public int getRowCount() {
			return getSystemVariables().size();
		}

		public Class<String> getColumnClass(int columnIndex) {
			return String.class;
		}

		public Object getValueAt(int row, int col) {
			return fRows[row][col];
		}

		public boolean isCellEditable(int rowIndex, int columnIndex) {
			return columnIndex > 0;
		}

		public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
			if (columnIndex == 1) {
				getSystemVariables().put(fRows[rowIndex][0], aValue);
				fRows[rowIndex][1] = (String) aValue;
			}
		}

		public String getColumnName(int column) {
			if (column == 0) {
				return "Name";
			} else {
				return "Value";
			}
		}
	}

	public void outputPaneAdd(LoggPanel aLogPanel) {
		fLoggers.add(aLogPanel);
		fOutputTabbedPane.add(aLogPanel.getName(), aLogPanel.getPanel());
		fPresentationPanels.put(aLogPanel.getName(), aLogPanel);
	}

	public void complete() {

	}

	protected void setActiveTest(String theActiveTest) {
		String property = getManager().getTestPath(theActiveTest);
		setActiveTestFile(property);
	}

	private void setActiveTestFile(String fileName) {
		if (fileName == null)
			throw new RuntimeException("Task file is not found. Recipe: " + fileName);

		openTaskFile(fileName);
		fTestsFile = fileName;

		boolean editable = new File(fTaskFile).exists();
		saveMenuItem.setEnabled(editable);
		fTaskText.setEditable(editable);

		refreshTaskTree();
		openTaskFile(getTestFile());
		Node taskNode = getTaskNode();
		boolean c = taskNode != null && taskNode.findNode("About", null, null) != null;
		if (c) {
			showAbout();
		}
	}

	public void runTaskNode() {

		Thread thread = new Thread() {
			public void run() {
				TaskProcessor processor = createProcessor();
				try {
					Map<String, Object> hashtable = processor.fStartVariables;
					File parentFile = SystemUtils.getUserDir();
					if (fTaskFile != null) {
						parentFile = new File(fTaskFile).getParentFile();
					}
					Node taskNode = getTaskNode();
					taskNode.getVector(true);
					processor.processTesting(taskNode, hashtable, parentFile);
					processor.getListener().endTask(false);
					endTask(false);
					setRunButtonAction(true);
					if (fNotifyMe.isSelected()) {
						getAeFrame().fireBuzzAction();
					}

				} catch (Throwable e1) {
					e1.printStackTrace();
				}
			}

		};

		thread.start();
	}

	private TaskProcessor createProcessor() {
		String attribute = getTaskNode().getAttribute("name");
		if (attribute == null || attribute.length() == 0)
			attribute = getTaskNode().getAttribute("description");

		Logger createLog = createLog(attribute, true);
		setProcessor(null);
		TaskProcessor processor = new TaskProcessor(fConfigNode, getSystemVariables(), this, getManager().getStartDir(),
				createLog, getTaskProcessor());
		setProcessor(processor);
		return processor;
	}

	public void start(String theActiveTest) {
		if (StringUtils.isNotBlank(theActiveTest)) {
			// log = new ListLoggPanel(this, theActiveTest);
			setActiveTest(theActiveTest);
			runTaskNode();
		}
		fRunMenuItem.setEnabled(false);
	}

	public void setRunButtonAction(boolean runAction) {
		if (runAction) {
			try {
				fRunButton.setText("Run");
				fRunButton.setToolTipText("Run");
				fRunButton.setForeground(Color.BLACK);
				fRunButton.setBackground(Color.WHITE);
				fContinueMenuItem.setEnabled(false);
				fRunMenuItem.setEnabled(true);
				fStopMenuItem.setEnabled(false);
				fPauseMenuItem.setEnabled(false);
				if (tabbedPanel != null) {
					int componentZOrder = tabbedPanel.getComponentZOrder(thePanel);
					tabbedPanel.setIconAt(componentZOrder, null);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else {
			try {
				fRunButton.setText("Stop");
				fRunButton.setToolTipText("Stop");
				fRunButton.setForeground(Color.WHITE);
				fRunButton.setBackground(ACTIVE_COLOR);
				fContinueMenuItem.setEnabled(false);
				fRunMenuItem.setEnabled(false);
				fStopMenuItem.setEnabled(true);
				fPauseMenuItem.setEnabled(true);
				if (tabbedPanel != null) {
					int componentZOrder = tabbedPanel.getComponentZOrder(thePanel);
					tabbedPanel.setIconAt(componentZOrder, AEFrame.getIcon("running.png"));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void edit(String theActiveTest) {
		setLog(new ListLoggPanel(this, theActiveTest));
		fRunMenuItem.setEnabled(true);
		theJScrollPane.setVisible(true);
	}

	public void create(String name) {
		try {
			setLog(new ListLoggPanel(this, name));

			fRunMenuItem.setEnabled(true);
			Node node = new EasyParser()
					.getObject("<Recipe name=\"" + name + "\">\n<!-- your recipe code -->\n</Recipe>");

			setTaskNode(node);
			refreshTaskTree();

			runTest(new Node[] { node });
			fContinueMenuItem.setEnabled(false);

		} catch (Throwable e) {
			getLog().error("Creation failed.", e);
		}
	}

	public String getPanelName() {
		TaskProcessor processor = getTaskProcessor();
		return processor.getTestName();
	}

	public void setInPropgress(boolean b) {
		// fProgress.setVisible(b);
		// fProgress.setIndeterminate(b);
	}

	public void saveTask() {
		if (fTaskFile != null && fTaskFile.startsWith("jar:"))
			return;
		try {

			if (fTaskFile == null) {
				FileDialog theFileDialog = new FileDialog(JOptionPane.getRootFrame(), "Save recipe file",
						FileDialog.SAVE);
				File[] testDirs = getManager().getTestDirs();
				if (testDirs.length > 0) {
					String absolutePath = testDirs[0].getAbsolutePath();
					theFileDialog.setDirectory(absolutePath);
				}
				if (getTaskNode() != null)
					theFileDialog.setFile(getTaskNode().getAttribute("name") + ".recipe");
				theFileDialog.setVisible(true);
				if (theFileDialog.getFile() == null)
					return;
				fTaskFile = new File(theFileDialog.getDirectory() + theFileDialog.getFile()).getAbsolutePath();
			}

			if (getTaskNode() != null) {
				File file = new File(fTaskFile);
				String name = FilenameUtils.getBaseName(file.getName());
				String oldName = getTaskNode().getAttribute("name");
				if (!StringUtils.equals(name, oldName)) {
					File newfile = new File(file.getParent(), oldName + ".recipe");
					if (file.renameTo(newfile)) {
						file = newfile;
						fTaskFile = file.getAbsolutePath();
					}
				}

				Node theNode = (Node) getTaskNode().clone();
				String newName = theNode.getAttribute("name");

				getManager().getRemoveTestPath(oldName);
				getManager().setTestPath(newName, fTaskFile);

				EasyUtils.removeTagId(theNode);

				byte[] bytes = getTaskNode().getXMLText().getBytes("UTF-8");

				try (FileOutputStream theFileOutputStream = new FileOutputStream(fTaskFile)) {
					theFileOutputStream.write("<?xml version='1.0' encoding='UTF-8'?>\n".getBytes("UTF-8"));
					theFileOutputStream.write(bytes);
					theFileOutputStream.close();
				}
			}

		} catch (Exception e1) {
			getLog().error("Saving failed.", e1);
		}
	}

	private void createSqlNotePanel() throws Exception {
		if (fRequestPanel == null) {
			if (getTaskProcessor() == null) {
				createProcessor();
			}

			fRequestPanel = new DatabaseCommandPanel(TaskEditor.this);

			createEditorPanel.addTab(SQL_REQUEST_PANEL, fRequestPanel);
			fRequestPanel.setDividerLocation(100);
		}
	}

	public void runTask() {
		try {
			if (openIn) {
				reload();
			}

			if (!changed) {
				openTaskFile(fTaskFile);
			}
			getManager().startTaskNotify(this);
			compileTask();
			runTaskNode();

		} catch (Exception e) {
			getLog().error("Running failed.", e);
		}
	}

	public void criticalError(final CommandException aThrowable, final TaskProcessor processor) {
		frame.criticalError(TaskEditor.this);
		endTask(true);
		if (fNotifyMe.isSelected()) {
			getFrame().fireBuzzAction(new Runnable() {
				@Override
				public void run() {
					TaskEditor.super.criticalError(aThrowable, processor);
				}
			});
		} else {
			super.criticalError(aThrowable, processor);
		}
	}

	public void checkFailure(final CommandException e, final TaskProcessor processor) {
		frame.checkFailure(TaskEditor.this);
		endTask(false);

		if (fNotifyMe.isSelected()) {
			getFrame().fireBuzzAction(new Runnable() {
				@Override
				public void run() {
					TaskEditor.super.checkFailure(e, processor);
				}
			});
		} else {
			super.checkFailure(e, processor);
		}
	}

	public void closeTab() {
		frame.removeTab(TaskEditor.this);
	}

	public void showAbout() {
		Node taskNode = getTaskNode();
		aboutTest(taskNode.getAttribute("name"), taskNode.findNode("About", null, null));
	}

	public void showEditorPane() {
		theJScrollPane.setVisible(true);
	}

	public void showTaskTreePane() {
		CardLayout cl = (CardLayout) (createEditorPanel.getLayout());
		cl.show(createEditorPanel, TASK_TREE);
	}

	public int getCaretPosition() {
		return fTaskText.getCaretPosition();
	}

	public Component getComponent() {
		return fTaskText;
	}

	public Point getMagicCaretPosition() {
		return fTaskText.getCaret().getMagicCaretPosition();
	}

	public String getText() {
		return fTaskText.getText();
	}

	public void replaceRange(String text, int i, int caretPosition2) {
		fTaskText.replaceRange(text, i, caretPosition2);
	}

	public JDialogPopupMenu contextHelp(KeyEvent e, JDialogPopupMenu menu) {
		final String selectedText = fTaskText.getSelectedText();

		if (StringUtils.isNotBlank(selectedText)) {

			try {
				new EasyParser().getObject("<Task>" + selectedText + "</Task>");

				JMenuItem popupMenu = new JMenuItem("Run selected text");
				popupMenu.addActionListener(new AbstractAction() {
					private static final long serialVersionUID = 1L;

					public void actionPerformed(ActionEvent e) {
						Thread thread = new Thread() {
							@Override
							public void run() {
								try {
									TaskProcessor processor = getTaskProcessor();
									if (processor == null)
										processor = createProcessor();

									processor = new TaskProcessor(processor);
									processor.setMaxTestListener(TaskEditor.this);
									processor.taskNode(new EasyParser().getObject("<Task>" + selectedText + "</Task>"));
									endTask(false);
								} catch (Throwable e1) {
									getLog().error("Selected text running failed.", e1);
									endTask(true);
								}
							}
						};
						thread.start();
					}
				});

				popupMenu.setFont(CodeHelper.POPUP_MENU_FONT);

				menu.add(popupMenu);
			} catch (ParseException e2) {
			}
		}
		return menu;
	}

	public void runTest(Node testNode[]) throws Exception {
		Node object = testNode[0];
		object.getVector(true);
		setTaskNode(object);
		refreshTaskTree();
		runTaskNode();
	}

	public AEFrame getFrame() {
		return frame;
	}

	public void componentAdded(ContainerEvent e) {

	}

	public void componentRemoved(ContainerEvent e) {

	}

	public void pause() {
		fRunMenuItem.setEnabled(false);
		fContinueMenuItem.setEnabled(true);
		fPauseMenuItem.setEnabled(false);

		fTitleTest.setText(" Suspended execution ...");
		fTitleTest.setForeground(Color.YELLOW.darker());
	}

	public void resume() {
		fRunMenuItem.setEnabled(false);
		fContinueMenuItem.setEnabled(false);
		fPauseMenuItem.setEnabled(true);

		fTitleTest.setText("");
		fTitleTest.setForeground(Color.GRAY.darker());
	}

	public boolean isRunning() {
		return fRunButton.getBackground() == ACTIVE_COLOR;
	}

	public Editor getEditor() {
		return fTaskText;
	}

	public void select() {
		getFrame().setSelectedComponent(getMainPanel());
	}

	@Override
	public void setTaskNode(Node taskNode) {
		super.setTaskNode(taskNode);
		String aName = getTaskName() + ".notifyMe";
		boolean notify = Boolean.parseBoolean(AEWorkspace.getInstance().getDefaultUserConfiguration(aName, "false"));
		fNotifyMe.setSelected(notify);
	}

}
