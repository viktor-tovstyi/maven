package com.nave.anteater;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.Vector;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSlider;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.JTree.DynamicUtilTreeNode;
import javax.swing.KeyStroke;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.log4j.Logger;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.xml.easyparser.EasyParser;
import com.nave.anteater.util.xml.easyparser.EasyUtils;
import com.nave.anteater.util.xml.easyparser.Node;
import com.nave.anteater.util.xml.easyparser.Node.TreeVector;
import com.nave.anteater.view.AeEditPanel;
import com.nave.anteater.view.CodeHelper;
import com.nave.anteater.view.JDialogPopupMenu;
import com.nave.anteater.view.ListLogPresenter;
import com.nave.anteater.view.LogPresenter;
import com.nave.anteater.view.VariableViewPanel;
import com.nave.anteater.view.panel.PresentationPanel;

/**
 * @author victort
 * @version 1.0, 29-Jul-2005
 */
public class TaskEditor extends WorkPlace implements AEPanel, AeEditPanel {

	private static final Color ACTIVE_COLOR = Color.GREEN.darker();

	private static final Font font = new Font("Monospaced", Font.PLAIN, 12);

	private static final String TASK_EDITOR = "Editor";
	private static final String TASK_TREE = "Processing";
	protected static final String VARIABLES = "Variables";

	private AEFrame frame;

	private JTree taskTree;

	private String fTaskFile;

	private Vector<?> fTreeVector;

	private Editor fTaskText = new Editor();

	private JTabbedPane fOutputTabbedPane;

	private Map<String, Object> fPresentationPanels = new HashMap<String, Object>();

	private TaskPanel thePanel;

	private JMenuItem fRunMenuItem = new JMenuItem("Run");

	private JMenuItem fContinueMenuItem = new JMenuItem("Continue");

	private JMenuItem fStopMenuItem = new JMenuItem("Stop");

	private JMenuItem fPauseMenuItem = new JMenuItem("Pause");

	private JButton fRunButton = new JButton("Run");

	private JCheckBox fNotifyMe = new JCheckBox();

	private JMenuItem saveMenuItem;

	private JSplitPane fOutputSplitPanel;

	private JSlider speed = new JSlider(0, 100, 100);

	private JTabbedPane createEditorPanel;

	private VariableViewPanel variables;

	protected boolean consoleDefaultInput;

	private boolean changed;

	private boolean openIn;

	private JLabel lblTitle = new JLabel();

	private JTabbedPane tabbedPanel;

	public TaskEditor(AEFrame aFrame, Node aConfigNode, Map<String, Object> aSystemVariables) {
		super(aFrame, aConfigNode, aSystemVariables);
		this.frame = aFrame;

		this.thePanel = new TaskPanel(this);
		variables = new VariableViewPanel(this);

		fOutputTabbedPane = new JTabbedPane();
		fOutputTabbedPane.setPreferredSize(new Dimension(200, 800));
		fOutputTabbedPane.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_F4 && e.isControlDown()) {
					removeActivePresentationPanel();
				}
			}
		});

		fOutputTabbedPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JTabbedPane fOutputTabbedPane = (JTabbedPane) e.getSource();
				if (e.getButton() == MouseEvent.BUTTON2) {
					if (fOutputTabbedPane.findComponentAt(e.getX(), e.getY()) == fOutputTabbedPane
							&& fOutputTabbedPane.indexAtLocation(e.getX(), e.getY()) != -1) {

						Component selectedComponent = fOutputTabbedPane.getSelectedComponent();
						Object frameId = ((PresentationPanel) selectedComponent).getName();
						removeActivePresentationPanel();
						fPresentationPanels.remove(frameId);
					}
				}
				if (e.getButton() == MouseEvent.BUTTON3) {
					if (fOutputTabbedPane.findComponentAt(e.getX(), e.getY()) == fOutputTabbedPane
							&& fOutputTabbedPane.indexAtLocation(e.getX(), e.getY()) != -1) {

						LogPresenter selectedComponent = (LogPresenter) fOutputTabbedPane.getSelectedComponent();

						if (!selectedComponent.isEmpty()) {
							if (fLoggers.contains(selectedComponent)) {
								String frameId = selectedComponent.getName();
								LogPresenter findLogger = findLogger(frameId);
								LogPresenter bakPresenter = findLogger.copyAndClean();
								fOutputTabbedPane.addTab(frameId, AEFrame.getIcon("copied.png"), bakPresenter);
							}
						}
					}
				}
			}
		});
		createEditorPanel = createEditorPanel();

		fOutputSplitPanel = new JSplitPane(JSplitPane.VERTICAL_SPLIT, createEditorPanel, fOutputTabbedPane);

		setSplitPanel();

		thePanel.add(fOutputSplitPanel, BorderLayout.CENTER);
		JMenuBar menuBar = new JMenuBar();

		createFileMenu(menuBar);
		createProcessMenu(menuBar);

		Node taskNode = getTaskNode();
		if (taskNode != null && taskNode.findNode("About", null, null) != null) {
			showAbout();
		}

		JPanel panel = new JPanel(new BorderLayout(4, 4));
		panel.setBorder(BorderFactory.createEtchedBorder());
		JPanel panel2 = new JPanel(new BorderLayout(4, 4));
		panel2.add(menuBar, BorderLayout.WEST);
		panel2.add(fRunButton, BorderLayout.CENTER);
		fNotifyMe.setIcon(AEFrame.getIcon("shout-off.png"));
		fNotifyMe.setSelectedIcon(AEFrame.getIcon("shout.png"));
		panel2.add(fNotifyMe, BorderLayout.EAST);

		fNotifyMe.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

				if (getTaskName() != null) {
					String aName = getTaskName() + ".notifyMe";
					String value = Boolean.toString(fNotifyMe.isSelected());
					AEWorkspace.getInstance().setDefaultUserConfiguration(aName, value);
					AEWorkspace.getInstance().setDefaultUserConfiguration("notifyMe", value);
				}
			}
		});

		speed.setPreferredSize(new Dimension(30, 18));
		speed.setToolTipText("Action speed");
		speed.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				speed.setToolTipText("Delay: " + getTraceDelay() + "ms.");
			}
		});
		panel.add(panel2, BorderLayout.WEST);

		JButton сloseButton = new JButton(AEFrame.getIcon("close.png"));
		panel.add(сloseButton, BorderLayout.EAST);

		сloseButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {

				stopTest();
				closeTab();
			}

		});

		thePanel.add(panel, BorderLayout.NORTH);

		JPanel aboutPanel = new JPanel(new BorderLayout());
		aboutPanel.add(aboutButtonPanel, BorderLayout.WEST);
		aboutPanel.add(fTitleTest, BorderLayout.CENTER);

		panel.add(aboutPanel, BorderLayout.CENTER);
	}

	public void setSplitPanel() {
		fOutputSplitPanel.setOneTouchExpandable(true);
		fOutputSplitPanel.setDividerLocation(0.0);
		fOutputSplitPanel.setLastDividerLocation(0);
	}

	private String getTaskName() {
		String name = null;
		if (getTaskNode() != null) {
			name = getTaskNode().getAttribute("name");
		}
		return name;
	}

	public TaskEditor(AEFrame aeFrame) {
		this(aeFrame, aeFrame.getWorkspace().getConfigNode(), aeFrame.getWorkspace().getSystemVariables());
		setRunButtonAction(false);
	}

	private void createFileMenu(JMenuBar menuBar) {
		JMenu menu = new JMenu("File");

		JMenuItem menuItem;
		menuItem = new JMenuItem("Save");
		try {
			menuItem.setAccelerator(KeyStroke.getKeyStroke('S', Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		} catch (Exception e) {
		}

		this.saveMenuItem = menuItem;
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				changed = false;
				save();
			}
		});
		menu.add(menuItem);

		menuItem = new JMenuItem("Reload");
		final JMenuItem reloadmenuItem = menuItem;
		try {
			menuItem.setAccelerator(KeyStroke.getKeyStroke('R', Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		} catch (Exception e) {
		}
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				reload();
			}
		});
		menu.add(menuItem);

		menuItem = new JMenuItem("Open In");
		try {
			menuItem.setAccelerator(KeyStroke.getKeyStroke('O', Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		} catch (Exception e) {
		}
		menuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {

				File file = new File(fTaskFile);
				if (file.exists()) {
					try {
						Desktop.getDesktop().open(file);
						openIn = true;
						reloadmenuItem.setText("Reload [Before Run]");

					} catch (IOException e) {
						getLogger().error(e.getMessage(), e);
					}
				}
			}
		});
		menu.add(menuItem);

		menu.add(new JSeparator());
		menuItem = new JMenuItem("Close");
		try {
			menuItem.setAccelerator(KeyStroke.getKeyStroke('X', Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		} catch (Exception e) {
		}
		menuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				closeTab();
			}

		});
		menu.add(menuItem);
		menuBar.add(menu);
	}

	public void reload() {
		openTaskFile(fTaskFile);
	}

	public void save() {
		format();
		saveTask();
	}

	public void format() {
		try {
			compileTask();
			refreshTaskTree();
			Node taskNode = getTaskNode();
			if (taskNode != null && taskNode.findNode("About", null, null) != null) {
				showAbout();
			}
		} catch (Exception e) {
			getLogger().error("Save action failed.", e);
		}
	}

	private void createProcessMenu(JMenuBar menuBar) {
		JMenu menu = new JMenu("Process");

		JMenuItem сompileMenuItem = new JMenuItem("Compile");
		menu.add(сompileMenuItem);
		сompileMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {

					compileTask();
				} catch (Exception e) {
					getLogger().error("Compilation failed.", e);
				}
			}
		});

		menu.add(fRunMenuItem);

		try {
			fRunMenuItem.setAccelerator(
					KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		} catch (Exception e) {
		}

		fRunMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				runTask();
			}
		});
		menu.add(speed);

		fRunButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				boolean isCurrentRunAction = "Run".equals(arg0.getActionCommand());

				if (isCurrentRunAction)
					runTask();
				else {
					stopTest();
					if (getTaskProcessor().isStoppedTest()) {
						setRunButtonAction(true);
					}
				}
			}
		});

		menu.add(fPauseMenuItem);

		try {
			fPauseMenuItem
					.setAccelerator(KeyStroke.getKeyStroke('P', Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		} catch (Exception e) {
		}

		fPauseMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				getTaskProcessor().pause();
			}
		});

		menu.add(fContinueMenuItem);

		try {
			fContinueMenuItem
					.setAccelerator(KeyStroke.getKeyStroke('P', Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		} catch (Exception e) {
		}

		fContinueMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				getTaskProcessor().resume();
			}
		});

		try {
			fStopMenuItem.setAccelerator(
					KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
		} catch (Exception e) {
		}

		fStopMenuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				stopTask();
			}

		});
		menu.add(fStopMenuItem);
		menuBar.add(menu);
	}

	public void setProgress(String message, long aMaxTags, long aCurrTags, boolean aErrorState) {
		manager.progressValue((int) (((double) aCurrTags / aMaxTags) * 100), 100, true);
		fTitleTest.setText(message);
	}

	public void stopTask() {
		super.stopTest();
	}

	private JTabbedPane createEditorPanel() {
		JTabbedPane editorPanel = new JTabbedPane();
		editorPanel.setTabPlacement(JTabbedPane.BOTTOM);

		TextLineNumber tln = new TextLineNumber(fTaskText);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setRowHeaderView(tln);
		scrollPane.getViewport().add(fTaskText);
		fTaskText.addKeyListener(new CodeHelper(this, getLogger()));
		fTaskText.setEditable(true);
		fTaskText.addKeyListener(new KeyAdapter() {

			@Override
			public void keyTyped(KeyEvent e) {
				changed = true;
			}
		});

		fTaskText.setFont(font);
		fTaskText.setTabSize(4);

		JScrollPane theScroll = new JScrollPane();
		theScroll.getViewport().removeAll();
		taskTree = new JTree();
		taskTree.setRootVisible(false);

		taskTree.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				if (e.getClickCount() == 2) {
					DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) taskTree
							.getLastSelectedPathComponent();
					TreeVector userObject = (TreeVector) selectedNode.getUserObject();
					Node node = userObject.getNode();

					String tagName = node.getTag();
					if ("Task".equals(tagName)) {
						String name = node.getAttribute("name");
						TaskEditor editTask = getAeFrame().editTask(name);
						editTask.setRunButtonAction(true);
					}
				}
			}
		});

		theScroll.getViewport().add(taskTree);

		editorPanel.addTab(TASK_TREE, theScroll);
		editorPanel.addTab(TASK_EDITOR, scrollPane);
		editorPanel.addTab(VARIABLES, variables);

		editorPanel.addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				Component selectedComponent = editorPanel.getSelectedComponent();
				if (selectedComponent instanceof VariableViewPanel) {
					VariableViewPanel panel = (VariableViewPanel) selectedComponent;
					panel.refreshData();
				}
			}
		});

		return editorPanel;
	}

	public void compileTask() throws Exception {
		try {
			Node object = new EasyParser().getObject(fTaskText.getText());
			setTaskNode(object);

		} catch (Exception e1) {
			JOptionPane.showMessageDialog(JOptionPane.getRootFrame(), "Incorrect code!\nError: " + e1.getMessage());
			throw e1;
		}
	}

	public void showPanel(JTabbedPane panel, String name) {
		if (name == null) {
			name = getPanelName();
		}
		tabbedPanel = panel;
		String tabNameId = Integer.toString(thePanel.hashCode());
		panel.addTab(tabNameId, thePanel);
		panel.setSelectedComponent(thePanel);

		JPanel pnlTab = new JPanel(new BorderLayout());
		pnlTab.setOpaque(false);
		pnlTab.setBorder(BorderFactory.createEmptyBorder(4, 0, 0, 0));

		lblTitle.setText(StringUtils.abbreviate(name, 12));
		lblTitle.setToolTipText(name);
		lblTitle.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent var1) {
				int index = tabbedPanel.indexOfTab(tabNameId);
				int button = var1.getButton();
				if (button == MouseEvent.BUTTON2) {
					tabbedPanel.removeTabAt(index);
				} else {
					tabbedPanel.setSelectedIndex(index);
				}
			}
		});

		pnlTab.add(lblTitle, BorderLayout.CENTER);

		int index = tabbedPanel.indexOfTab(tabNameId);
		tabbedPanel.setTabComponentAt(index, pnlTab);
	}

	public JPanel getMainPanel() {
		return thePanel;
	}

	public void endTask(boolean aErrorState) {
		super.endTask(aErrorState);
		fRunMenuItem.setEnabled(true);
		setRunButtonAction(true);
	}

	private void openTaskFile(String filePath) {
		fTaskFile = filePath;
		if (new File(fTaskFile).exists()) {
			if (!openIn) {
				setEditable(true);
			}
		}

		try {
			Node load = new EasyParser().load(filePath);
			setTaskNode(load);
			refreshTaskTree();
		} catch (Exception e1) {
			throw new ConfigurationException("Invalide recipe file.", e1);
		}
	}

	private void setEditable(boolean editable) {
		saveMenuItem.setEnabled(editable);
		fTaskText.setEditable(editable);
	}

	protected void refreshTaskTree() {
		if (getTaskNode() != null) {

			int caretPosition = fTaskText.getCaretPosition();
			fTaskText.setOriginalText(getTaskNode().getXMLText().trim());
			fTaskText.setCaretPosition(caretPosition);

			fTreeVector = getTaskNode().getVector(true);

			DefaultMutableTreeNode root = new DefaultMutableTreeNode("root");
			DynamicUtilTreeNode.createChildren(root, fTreeVector);
			DefaultTreeModel model = new DefaultTreeModel(root, false);
			taskTree.setModel(model);

			taskTree.setEditable(false);
			taskTree.setEnabled(true);

			taskTree.setFont(font);
			taskTree.setForeground(ACTIVE_COLOR);
			for (int i = 0; i < taskTree.getRowCount(); i++) {
				taskTree.expandRow(i);
			}
		}
	}

	public void changeVariable(String aAttribut, Object aValue) {
	}

	static class JBorderedPanel extends JPanel {
		private static final long serialVersionUID = 1L;

		public JBorderedPanel(Component aNorth, Component aWest, Component aCenter, Component aEast, Component aSouth) {
			setLayout(new BorderLayout());
			if (aNorth != null) {
				add(aNorth, BorderLayout.NORTH);
			}
			if (aWest != null) {
				add(aWest, BorderLayout.WEST);
			}
			if (aCenter != null) {
				add(aCenter, BorderLayout.CENTER);
			}
			if (aEast != null) {
				add(aEast, BorderLayout.EAST);
			}
			if (aSouth != null) {
				add(aSouth, BorderLayout.SOUTH);
			}
		}
	}

	public void startCommand(int aNumberCommand) {
		setRunButtonAction(false);
		try {
			if (taskTree != null) {
				taskTree.setSelectionRow(aNumberCommand);
				long delay = getTraceDelay();
				if (delay > 0) {
					Thread.sleep(delay);
				}
			}
		} catch (Exception e) {
		}
	}

	private long getTraceDelay() {
		int delay = (int) ((Math.pow(1.5, (double) (100 - speed.getValue()) / 4)) - 1);
		return delay;
	}

	public void aboutTest(String theTaskName, Node aCurrentAction) {
		try {
			setAbout(theTaskName, aCurrentAction);
			aboutButtonPanel.setVisible(true);
		} catch (Exception e) {
			getLogger().error("Error", e);
		}
	}

	protected void createAboutPanel() {
	}

	public void runCommandFrame(Properties params) throws Throwable {
		String theFrameId = params.getProperty("frameId");
		String title = params.getProperty("title");

		String reuse = params.getProperty("reuse");
		if ("true".equals(reuse)) {
			PresentationPanel thePPanel = (PresentationPanel) fPresentationPanels.get(theFrameId);
			if (thePPanel != null) {
				return;
			}
		}

		createFrame(theFrameId, params, title);
	}

	private PresentationPanel createFrame(String theFrameId, Properties linkedMap, String title) throws Exception {

		if (title == null) {
			title = theFrameId;
		}

		String className = linkedMap.getProperty("type", "TextPanel");

		if (className.indexOf('.') < 0) {
			className = "com.nave.anteater.view.panel." + className;
		}

		Class ppClass = Class.forName(className);
		Constructor constructor = ppClass.getConstructor(Properties.class);
		PresentationPanel pPanel = (PresentationPanel) constructor.newInstance(linkedMap);

		fPresentationPanels.put(theFrameId, pPanel);
		fOutputTabbedPane.add(title, pPanel);

		fOutputTabbedPane.setSelectedComponent(pPanel);
		return pPanel;
	}

	public void outToFrame(TaskProcessor processor, Properties properties, Object value) throws Exception {
		String frameId = processor.replaceProperties((String) properties.get("frameId"));
		if (frameId != null) {
			PresentationPanel thePPanel = (PresentationPanel) fPresentationPanels.get(frameId);
			if (thePPanel == null) {
				thePPanel = createFrame(frameId, properties, null);
			}
			thePPanel.out(value, properties);
		}
	}

	public void removeActivePresentationPanel() {
		int selectedIndex = fOutputTabbedPane.getSelectedIndex();

		Component theComp = fOutputTabbedPane.getComponent(selectedIndex);
		if (theComp instanceof PresentationPanel) {
			PresentationPanel thePPanel = (PresentationPanel) theComp;
			fPresentationPanels.remove(thePPanel.getName());
		}

		fOutputTabbedPane.remove(selectedIndex);
		fLoggers.remove(findLogger(theComp));
	}

	int fNumberLog = 1;

	private ArrayList<LogPresenter> fLoggers = new ArrayList<LogPresenter>();

	public ILogger createLog(String aLogName, boolean mainLog) {

		LogPresenter loggPanel = findLogger(aLogName);

		if (loggPanel == null) {
			if (aLogName == null || aLogName.length() == 0)
				aLogName = "Log #" + String.valueOf(fNumberLog++);
			loggPanel = new ListLogPresenter(this, aLogName, mainLog);
			outputPaneAdd(loggPanel);
		}

		setLog(loggPanel);
		return loggPanel;
	}

	private LogPresenter findLogger(String aLogName) {
		if (aLogName == null) {
			return fLoggers.get(0);
		}

		int tabCount = fLoggers.size();
		for (int i = 0; i < tabCount; i++) {
			LogPresenter logger = (LogPresenter) fLoggers.get(i);
			if (logger.getName().equals(aLogName)) {
				return logger;
			}
		}

		return null;
	}

	private LogPresenter findLogger(Component comp) {
		int tabCount = fLoggers.size();
		for (int i = 0; i < tabCount; i++) {
			LogPresenter logger = (LogPresenter) fLoggers.get(i);
			if (logger == comp) {
				return logger;
			}
		}
		return null;
	}

	public void errorInformation(TaskProcessor processor, Throwable e, Node aTask) throws CommandException {
		TracePanel panel = new TracePanel(processor, e, aTask);

		fOutputTabbedPane.add("Trace", panel);
		fOutputTabbedPane.setSelectedComponent(panel);

		int showConfirmDialog = JOptionPane.OK_OPTION;

		if (frame.getWorkspace().isConsoleDefaultInput(null) == false)
			showConfirmDialog = JOptionPane.showConfirmDialog(JOptionPane.getRootFrame(),
					"There was an error. Do you want to continue this task?",
					"Catch exeption for paused mode. Press 'OK' for continue.", JOptionPane.OK_CANCEL_OPTION);

		if (showConfirmDialog != JOptionPane.OK_OPTION)
			throw new CommandException("Pause is canceled.", processor);
	}

	class TracePanel extends JPanel {

		private static final long serialVersionUID = 1L;

		JSplitPane thePanel;

		public TracePanel(TaskProcessor processor, Throwable e, Node aTask) {
			super(new BorderLayout());

			PanelTree jTree = new PanelTree(processor.getCallTaskTrace());
			String message = e.getMessage();
			if (message == null)
				message = "Message is null.";
			JTextArea theJTextArea = new JTextArea(message);
			theJTextArea.setEditable(false);
			theJTextArea.setOpaque(false);

			JScrollPane jScrollPane = new JScrollPane(theJTextArea);
			JSplitPane theStackPanel = new JSplitPane(JSplitPane.VERTICAL_SPLIT, jScrollPane, jTree);
			theStackPanel.setDividerLocation(0.0);

			JTree theTask = new JTree(aTask.getVector(true));
			thePanel = new JSplitPane(JSplitPane.VERTICAL_SPLIT, theStackPanel, theTask);
			thePanel.setDividerLocation(0.0);
			thePanel.setOneTouchExpandable(true);

			add(thePanel, BorderLayout.CENTER);
			JPanel panel2 = new JPanel(new BorderLayout());
			JButton button = new JButton(AEFrame.getIcon("close.png"));
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					fOutputTabbedPane.remove(TracePanel.this);
				}
			});
			panel2.add(button, BorderLayout.EAST);
			add(panel2, BorderLayout.NORTH);
		}

		public Component getSelectedComponent() {
			return thePanel;
		}
	}

	class VarTableModel extends AbstractTableModel {
		private static final long serialVersionUID = 1L;
		private String[][] fRows;

		public VarTableModel() throws Exception {
			Set<String> enumeration = getSystemVariables().keySet();
			fRows = new String[getSystemVariables().size()][2];
			int i = 0;
			for (String theName : enumeration) {
				String theValue = (String) getSystemVariables().get(theName);
				fRows[i][0] = theName;
				fRows[i][1] = theValue;
				i++;
			}
		}

		public int getColumnCount() {
			return 2;
		}

		public int getRowCount() {
			return getSystemVariables().size();
		}

		public Class<String> getColumnClass(int columnIndex) {
			return String.class;
		}

		public Object getValueAt(int row, int col) {
			return fRows[row][col];
		}

		public boolean isCellEditable(int rowIndex, int columnIndex) {
			return columnIndex > 0;
		}

		public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
			if (columnIndex == 1) {
				getSystemVariables().put(fRows[rowIndex][0], aValue);
				fRows[rowIndex][1] = (String) aValue;
			}
		}

		public String getColumnName(int column) {
			if (column == 0) {
				return "Name";
			} else {
				return "Value";
			}
		}
	}

	public void outputPaneAdd(LogPresenter logPanel) {
		fLoggers.add(logPanel);
		LogPresenter panel = logPanel;
		fOutputTabbedPane.add(logPanel.getName(), panel);
		fPresentationPanels.put(logPanel.getName(), logPanel);
		fOutputTabbedPane.setSelectedComponent(panel);
	}

	public void complete() {

	}

	protected void setActiveTest(String theActiveTest) {
		String property = getManager().getTestPath(theActiveTest);
		setActiveTestFile(property);
	}

	private void setActiveTestFile(String fileName) {
		if (fileName == null)
			throw new RuntimeException("Task file is not found. Recipe: " + fileName);

		openTaskFile(fileName);
		fTestsFile = fileName;

		boolean editable = new File(fTaskFile).exists();
		saveMenuItem.setEnabled(editable);
		fTaskText.setEditable(editable);

		refreshTaskTree();
		openTaskFile(getTestFile());
		Node taskNode = getTaskNode();
		boolean c = taskNode != null && taskNode.findNode("About", null, null) != null;
		if (c) {
			showAbout();
		}
	}

	public void runTaskNode() {

		Thread thread = new Thread() {
			public void run() {
				TaskProcessor processor = createProcessor();
				try {
					Map<String, Object> hashtable = processor.fStartVariables;
					File parentFile = SystemUtils.getUserDir();
					if (fTaskFile != null) {
						parentFile = new File(fTaskFile).getParentFile();
					}
					Node taskNode = getTaskNode();
					taskNode.getVector(true);
					processor.processTesting(taskNode, hashtable, parentFile);
					processor.getListener().endTask(false);
					endTask(false);
					setRunButtonAction(true);
					if (fNotifyMe.isSelected()) {
						getAeFrame().fireBuzzAction();
					}

				} catch (Throwable e1) {
					e1.printStackTrace();
				}
			}

		};

		thread.start();
	}

	private TaskProcessor createProcessor() {
		String attribute = getTaskNode().getAttribute("name");
		if (attribute == null || attribute.length() == 0)
			attribute = getTaskNode().getAttribute("description");

		ILogger createLog = createLog(attribute, true);
		setProcessor(null);
		TaskProcessor processor = new TaskProcessor(fConfigNode, getSystemVariables(), this, getManager().getStartDir(),
				createLog, getTaskProcessor());
		setProcessor(processor);
		return processor;
	}

	public void start(String name) {
		if (StringUtils.isNotBlank(name)) {
			setActiveTest(name);
			runTaskNode();
		}
		fRunMenuItem.setEnabled(false);
	}

	public void setRunButtonAction(boolean runAction) {
		if (runAction) {
			try {
				fRunButton.setText("Run");
				fRunButton.setToolTipText("Run");
				fRunButton.setForeground(Color.BLACK);
				fRunButton.setBackground(Color.WHITE);
				fContinueMenuItem.setEnabled(false);
				fRunMenuItem.setEnabled(true);
				fStopMenuItem.setEnabled(false);
				fPauseMenuItem.setEnabled(false);
				lblTitle.setForeground(Color.BLACK);
			} catch (Exception e) {
				e.printStackTrace();
			}

		} else {
			try {
				fRunButton.setText("Stop");
				fRunButton.setToolTipText("Stop");
				fRunButton.setForeground(Color.WHITE);
				fRunButton.setBackground(ACTIVE_COLOR);
				fContinueMenuItem.setEnabled(false);
				fRunMenuItem.setEnabled(false);
				fStopMenuItem.setEnabled(true);
				fPauseMenuItem.setEnabled(true);
				lblTitle.setForeground(ACTIVE_COLOR);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void edit(String name) {
		ListLogPresenter log = new ListLogPresenter(this, name);
		setLog(log);
		outputPaneAdd(log);
		fRunMenuItem.setEnabled(true);
	}

	public void create(String name) {
		try {
			ListLogPresenter log = new ListLogPresenter(this, name);
			setLog(log);

			fRunMenuItem.setEnabled(true);
			Node node = new EasyParser()
					.getObject("<Recipe name=\"" + name + "\">\n<!-- your recipe code -->\n</Recipe>");

			setTaskNode(node);
			refreshTaskTree();

			runTest(new Node[] { node });
			fContinueMenuItem.setEnabled(false);

		} catch (Throwable e) {
			getLogger().error("Creation failed.", e);
		}
	}

	public String getPanelName() {
		TaskProcessor processor = getTaskProcessor();
		return processor.getTestName();
	}

	public void saveTask() {
		if (fTaskFile != null && fTaskFile.startsWith("jar:"))
			return;
		try {

			if (fTaskFile == null) {
				FileDialog theFileDialog = new FileDialog(JOptionPane.getRootFrame(), "Save recipe file",
						FileDialog.SAVE);
				File[] testDirs = getManager().getTestDirs();
				if (testDirs.length > 0) {
					String absolutePath = testDirs[0].getAbsolutePath();
					theFileDialog.setDirectory(absolutePath);
				}
				if (getTaskNode() != null)
					theFileDialog.setFile(getTaskNode().getAttribute("name") + ".recipe");
				theFileDialog.setVisible(true);
				if (theFileDialog.getFile() == null)
					return;
				fTaskFile = new File(theFileDialog.getDirectory() + theFileDialog.getFile()).getAbsolutePath();
			}

			if (getTaskNode() != null) {
				File file = new File(fTaskFile);
				String name = FilenameUtils.getBaseName(file.getName());
				String oldName = getTaskNode().getAttribute("name");
				if (!StringUtils.equals(name, oldName)) {
					File newfile = new File(file.getParent(), oldName + ".recipe");
					if (file.renameTo(newfile)) {
						file = newfile;
						fTaskFile = file.getAbsolutePath();
					}
				}

				Node theNode = (Node) getTaskNode().clone();
				String newName = theNode.getAttribute("name");

				getManager().getRemoveTestPath(oldName);
				getManager().setTestPath(newName, fTaskFile);

				EasyUtils.removeTagId(theNode);

				byte[] bytes = getTaskNode().getXMLText().getBytes("UTF-8");

				try (FileOutputStream theFileOutputStream = new FileOutputStream(fTaskFile)) {
					theFileOutputStream.write("<?xml version='1.0' encoding='UTF-8'?>\n".getBytes("UTF-8"));
					theFileOutputStream.write(bytes);
					theFileOutputStream.close();
				}
			}

		} catch (Exception e1) {
			getLogger().error("Saving failed.", e1);
		}
	}

	public void runTask() {
		try {
			if (openIn) {
				reload();
			}

			if (!changed) {
				openTaskFile(fTaskFile);
			}
			getManager().startTaskNotify(this);
			compileTask();
			runTaskNode();

		} catch (Exception e) {
			getLogger().error("Running failed.", e);
		}
	}

	public void criticalError(final CommandException aThrowable, final TaskProcessor processor) {
		frame.criticalError(TaskEditor.this);
		endTask(true);
		if (isNotifyMe()) {
			getFrame().fireBuzzAction(new Runnable() {
				@Override
				public void run() {
					TaskEditor.super.criticalError(aThrowable, processor);
				}
			});
		} else {
			super.criticalError(aThrowable, processor);
		}
	}

	public void checkFailure(final CommandException e, final TaskProcessor processor) {
		frame.checkFailure(TaskEditor.this);
		endTask(false);

		if (isNotifyMe()) {
			getFrame().fireBuzzAction(new Runnable() {
				@Override
				public void run() {
					TaskEditor.super.checkFailure(e, processor);
				}
			});
		} else {
			super.checkFailure(e, processor);
		}
	}

	public void closeTab() {
		frame.removeTab(TaskEditor.this);
	}

	public void showAbout() {
		Node taskNode = getTaskNode();
		aboutTest(taskNode.getAttribute("name"), taskNode.findNode("About", null, null));
	}

	public void showTaskTreePane() {
		CardLayout cl = (CardLayout) (createEditorPanel.getLayout());
		cl.show(createEditorPanel, TASK_TREE);
	}

	public int getCaretPosition() {
		return fTaskText.getCaretPosition();
	}

	public Component getComponent() {
		return fTaskText;
	}

	public Point getMagicCaretPosition() {
		return fTaskText.getCaret().getMagicCaretPosition();
	}

	public String getText() {
		return fTaskText.getText();
	}

	public void replaceRange(String text, int i, int caretPosition2) {
		fTaskText.replaceRange(text, i, caretPosition2);
	}

	public JDialogPopupMenu contextHelp(KeyEvent e, JDialogPopupMenu menu) {
		final String selectedText = fTaskText.getSelectedText();

		if (StringUtils.isNotBlank(selectedText)) {

			try {
				new EasyParser().getObject("<Task>" + selectedText + "</Task>");

				JMenuItem popupMenu = new JMenuItem("Run selected text");
				popupMenu.addActionListener(new AbstractAction() {
					private static final long serialVersionUID = 1L;

					public void actionPerformed(ActionEvent e) {
						Thread thread = new Thread() {
							@Override
							public void run() {
								try {
									TaskProcessor processor = getTaskProcessor();
									if (processor == null)
										processor = createProcessor();

									processor = new TaskProcessor(processor);
									processor.setTestListener(TaskEditor.this);
									processor.taskNode(new EasyParser().getObject("<Task>" + selectedText + "</Task>"));
									endTask(false);
								} catch (Throwable e1) {
									getLogger().error("Selected text running failed.", e1);
									endTask(true);
								}
							}
						};
						thread.start();
					}
				});

				popupMenu.setFont(CodeHelper.POPUP_MENU_FONT);

				menu.add(popupMenu);
			} catch (ParseException e2) {
			}
		}
		return menu;
	}

	public void runTest(Node testNode[]) throws Exception {
		Node object = testNode[0];
		object.getVector(true);
		setTaskNode(object);
		refreshTaskTree();
		runTaskNode();
	}

	public AEFrame getFrame() {
		return frame;
	}

	public void pause() {
		fRunMenuItem.setEnabled(false);
		fContinueMenuItem.setEnabled(true);
		fPauseMenuItem.setEnabled(false);

		fTitleTest.setText(" Suspended execution ...");
		fTitleTest.setForeground(Color.YELLOW.darker());
		lblTitle.setForeground(Color.YELLOW.darker());
	}

	public void resume() {
		fRunMenuItem.setEnabled(false);
		fContinueMenuItem.setEnabled(false);
		fPauseMenuItem.setEnabled(true);

		fTitleTest.setText("");
		fTitleTest.setForeground(Color.GRAY.darker());
		lblTitle.setForeground(ACTIVE_COLOR);
	}

	public boolean isRunning() {
		return fRunButton.getBackground() == ACTIVE_COLOR;
	}

	public Editor getEditor() {
		return fTaskText;
	}

	public void select() {
		getFrame().setSelectedComponent(getMainPanel());
	}

	@Override
	public void setTaskNode(Node taskNode) {
		super.setTaskNode(taskNode);
		String aName = getTaskName() + ".notifyMe";
		String defaultNotify = AEWorkspace.getInstance().getDefaultUserConfiguration("notifyMe", "false");
		boolean notify = Boolean
				.parseBoolean(AEWorkspace.getInstance().getDefaultUserConfiguration(aName, defaultNotify));
		fNotifyMe.setSelected(notify);
	}

	public boolean isNotifyMe() {
		return fNotifyMe.isSelected();
	}
}
