package com.nave.anteater;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.JTree;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.log4j.Logger;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.xml.easyparser.Node;

public class WorkPlace extends TestRunner {

	protected JPasswordField fPasswordField = null;

	protected JToolBar aboutToolBox = new JToolBar();

	protected String fTestsFile;

	FileDialog theAttacFileDialog;

	private final Font ABOUT_FONT = new Font("SansSerif", Font.PLAIN, 12);

	protected JLabel fTitleTest = new JLabel();

	protected JTextField theConfigName = new JTextField();

	private AEFrame aeFrame = null;

	private Component aboutPanel;

	JDialog theToolBar = new JDialog(JOptionPane.getRootFrame(), "About", false);

	public WorkPlace(AEFrame aMainFrame, Node aConfigNode, Map<String, Object> aSystemVariables) {
		super(aMainFrame.getWorkspace(), aConfigNode, aSystemVariables);
		aConfigNode.getVector(true);
		aeFrame = aMainFrame;
		theConfigName.setEditable(false);

		theConfigName.setFont(new Font("Dialog", Font.PLAIN, 9));
		theConfigName.setBackground(Color.lightGray);

		theAttacFileDialog = new FileDialog(JOptionPane.getRootFrame(), "Storing attach in file", FileDialog.SAVE);
		theAttacFileDialog.setDirectory(System.getProperty("user.home"));

		JPanel thePanelLogo = new JPanel(new BorderLayout());

		thePanelLogo.add(theConfigName, BorderLayout.SOUTH);

		JPanel theComp = new JPanel(new BorderLayout());
		JPanel theCompTitle = new JPanel(new BorderLayout());
		theComp.add(theCompTitle, BorderLayout.NORTH);
	}

	protected void setActiveTest(String theActiveTest) {
		if (theActiveTest != null) {
			fTestsFile = getManager().getTestPath(theActiveTest);
			// setDefaultUserConfiguration(".defaultTest", fActiveTest);
		}

		runTest(fTestsFile, createLog(theActiveTest, true));
	}

	public void startTask(String aNameTask) {
		setTestName(aNameTask);
		fTitleTest.setForeground(Color.BLACK);
		fTitleTest.setText(aNameTask);
	}

	public void setTestName(String aNameTask) {
		fTitleTest.setText(aNameTask);
	}

	public void endTask(boolean aErrorState) {

		fTitleTest.setForeground(Color.BLACK);
		if (!aErrorState) {
			fTitleTest.setText(" Recipe done.");
		} else {
			fTitleTest.setText(" Recipe failed.");
		}
		fTitleTest.setForeground(aErrorState ? Color.RED.darker() : Color.GREEN.darker());

		manager.progressValue(0, 0, !aErrorState);

	}

	public void runTest(String aTestFile, Logger aLog) {
		if (aTestFile == null) {
			return;
		}
		fTestsFile = aTestFile;

		TaskThread theThread = new TaskThread(this, aTestFile);
		theThread.start();
	}

	public String getTestFile() {
		return fTestsFile;
	}

	public void setTestsFile(String aTestsFile) {
		fTestsFile = aTestsFile;
	}

	public String inputFile(File aDefaultFile, TaskProcessor taskProcessor) {
		String theResult = null;

		String defaultUserConfiguration = AEWorkspace.getInstance().getDefaultUserConfiguration(".inputFile",
				aDefaultFile == null ? null : aDefaultFile.getAbsolutePath());
		if (defaultUserConfiguration != null)
			aDefaultFile = new File(defaultUserConfiguration);

		theResult = defaultUserConfiguration;
		if (defaultUserConfiguration == null || getManager().isConsoleDefaultInput("inputFile") == false) {
			FileDialog theFileDialog = new FileDialog(JOptionPane.getRootFrame(), "Loading file in property ",
					FileDialog.LOAD);

			if (aDefaultFile != null) {
				if (aDefaultFile.getPath() != null && "null".equals(aDefaultFile.getPath()) == false)
					theFileDialog.setDirectory(aDefaultFile.getPath());
				if (aDefaultFile.getName() != null && "null".equals(aDefaultFile.getName()) == false)
					theFileDialog.setFile(aDefaultFile.getName());
			}

			theFileDialog.setVisible(true);

			theResult = theFileDialog.getDirectory() + theFileDialog.getFile();
			AEWorkspace.getInstance().setDefaultUserConfiguration(".inputFile", theResult);
		}

		return theResult;
	}

	public String inputSelectChoice(String aNameDialog, String[] aValues, String aDefaultValue,
			TaskProcessor taskProcessor) {
		aDefaultValue = null; // getDefaultUserConfiguration(".choice." +
								// aNameDialog, aDefaultValue);

		if (getManager().isConsoleDefaultInput(null) == false) {
			Frame rootFrame = JOptionPane.getRootFrame();
			rootFrame.setAutoRequestFocus(true);
			aDefaultValue = (String) JOptionPane.showInputDialog(rootFrame, aNameDialog, "Input",
					JOptionPane.QUESTION_MESSAGE, null, aValues, aDefaultValue);
			rootFrame.setAutoRequestFocus(false);
			// setDefaultUserConfiguration(".choice." + aNameDialog,
			// aDefaultValue);
		}

		return aDefaultValue;
	}

	public void aboutTest(String theTaskName, Node aCurrentAction) {
		if (theTaskName == null)
			return;
		setAbout(theTaskName, aCurrentAction);
	}

	protected void setAbout(String theTaskName, Node aCurrentAction) {

		JPanel theJPanel = new JPanel();
		aboutPanel = theJPanel;

		theJPanel.setLayout(new BorderLayout());
		theJPanel.setBorder(BorderFactory.createBevelBorder(10));

		StringBuffer theBuffer = new StringBuffer();

		Node[] theAuthorNodes = aCurrentAction.getNodes("author");

		theBuffer.append("<html><body>");
		Node[] descriptions = aCurrentAction.getNodes("description");
		for (Node description : descriptions) {
			theBuffer.append(description.getInnerXMLText());
		}
		if (!ArrayUtils.isEmpty(descriptions) && ArrayUtils.isNotEmpty(theAuthorNodes)) {
			theBuffer.append("<hr/>");
		}

		Node[] theRequirementsNodes = aCurrentAction.getNodes("version");
		if (theRequirementsNodes != null && theRequirementsNodes.length > 0) {
			String version = theRequirementsNodes[0].getAttribute("task");
			theBuffer.append("Version: " + version + "<br>");
		}

		for (int i = 0; i < theAuthorNodes.length; i++) {
			if (theAuthorNodes[i].getAttribute("name") != null)
				theBuffer.append(
						"Authore: <font color=\"red\">" + theAuthorNodes[i].getAttribute("name") + "</font><br>");
			if (theAuthorNodes[i].getAttribute("mail") != null)
				theBuffer.append("Mail: <a href='" + theAuthorNodes[i].getAttribute("mail") + "'>"
						+ theAuthorNodes[i].getAttribute("mail") + "</a><br>");
			if (theAuthorNodes[i].getAttribute("messager") != null)
				theBuffer.append("Messager: " + theAuthorNodes[i].getAttribute("messager") + "<br>");
			if (theAuthorNodes[i].getAttribute("phone") != null)
				theBuffer.append("Phone: " + theAuthorNodes[i].getAttribute("phone") + "<br>");
			if (theAuthorNodes.length > 1)
				theBuffer.append("<hr>");
		}

		if (theRequirementsNodes != null && theRequirementsNodes.length > 0) {
			theBuffer.append("Requirements:<ul>");
			Node[] theProductsNode = theRequirementsNodes[0].getNodes("product");
			for (int i = 0; i < theProductsNode.length; i++) {
				theBuffer.append("<li>" + theProductsNode[i].getAttribute("name") + ": "
						+ theProductsNode[i].getAttribute("value") + "</li>");
			}
			theBuffer.append("</ul>");
		}
		theBuffer.append("</body></html>");

		JEditorPane jLabel = new JEditorPane();
		jLabel.setContentType("text/html");
		jLabel.setText(theBuffer.toString());

		jLabel.setEditable(false);
		jLabel.setFont(ABOUT_FONT);

		theJPanel.add(new JScrollPane(jLabel), BorderLayout.CENTER);
		aboutToolBox.removeAll();

		if (ArrayUtils.isNotEmpty(descriptions) || ArrayUtils.isNotEmpty(theRequirementsNodes)
				|| ArrayUtils.isNotEmpty(theAuthorNodes)) {
			JButton aboutButton = new JButton(AEFrame.getIcon("about.png"));
			aboutButton.addActionListener((x) -> showAboutPanel());
			aboutToolBox.add(aboutButton);
		}

		Node[] theDocNodes = aCurrentAction.getNodes("attach/file");

		if (theDocNodes != null && theDocNodes.length > 0) {
			for (int i = 0; i < theDocNodes.length; i++) {
				JLabel theButton = new JAttachButton(this, theDocNodes[i], theTaskName);
				aboutToolBox.add(theButton);
			}

		}

	}

	private void showAboutPanel() {
		theToolBar.setLocation(150, 150);
		theToolBar.getContentPane().add(aboutPanel);
		theToolBar.pack();
		theToolBar.setVisible(true);
	}

	public void errorInformation(TaskProcessor processor, Throwable e, Node aTaskNode) throws CommandException {
		PanelTree jTree = new PanelTree(processor.getCallTaskTrace());
		String message = e.getMessage();
		if (message == null)
			message = "Message is null.";
		JFrame theFrame = new JFrame("Error information panel");
		JSplitPane thePanel = new JSplitPane(JSplitPane.VERTICAL_SPLIT, new JScrollPane(new JTextArea(message)), jTree);
		theFrame.getContentPane().add(thePanel);
		theFrame.pack();
		theFrame.setVisible(true);

		int showConfirmDialog = JOptionPane.OK_OPTION;

		if (getManager().isConsoleDefaultInput(null) == false)
			showConfirmDialog = JOptionPane.showConfirmDialog(JOptionPane.getRootFrame(),
					"There was a error. To continue this task?",
					"Catch exeption for paused mode. Press 'OK' for continue.", JOptionPane.OK_CANCEL_OPTION);

		if (showConfirmDialog != JOptionPane.OK_OPTION)
			throw new CommandException("Pause is canceled.", processor);
	}

	public void criticalError(CommandException aThrowable, TaskProcessor processor) {
		super.criticalError(aThrowable, processor);

		boolean b = aThrowable.getMessage() == null || aThrowable.getMessage().trim().length() == 0;
		String theMessage = "Error message: " + aThrowable.getMessage();
		if (b)
			theMessage = "Message is absent. Please see stack trace.";

		JOptionPane.showMessageDialog(JOptionPane.getRootFrame(), theMessage, "Critical exception",
				JOptionPane.ERROR_MESSAGE);
	}

	public void checkFailure(CommandException e, TaskProcessor processor) {
		super.checkFailure(e, processor);

		String message = e.getMessage();
		if (message.length() > 1000) {
			message = "Check Failure. See log messages.";
		}

		String formatMessage = formatMessage(message);

		JOptionPane.showMessageDialog(JOptionPane.getRootFrame(), formatMessage, "Exception of check",
				JOptionPane.ERROR_MESSAGE);

	}

	private String formatMessage(String message) {
		if (message == null)
			return "<NULL>";

		StringBuffer theBuffer = new StringBuffer();
		int theCursor = 0, theNewCursor = 0;
		int theNumberLine = 0;

		do {
			theNewCursor = message.indexOf(' ', theCursor + theNewCursor + 1);

			if (theNewCursor - theCursor > 20 || theNewCursor < 0) {
				if (theNewCursor < 0)
					theNewCursor = message.length() - 1;

				String substring = message.substring(theCursor, theNewCursor);

				String trim = substring.trim();
				if (trim.length() > 0) {
					theBuffer.append(trim);
					theBuffer.append("\n");
				}
				theCursor = theNewCursor;
				theNewCursor = 0;

				theNumberLine++;
				if (theNumberLine > 10) {
					theBuffer.append("...");
					break;
				}
			}

		} while (theCursor < message.length() - 1);

		return theBuffer.toString();
	}

	public void exceptionIgnored(Throwable e) {
		super.exceptionIgnored(e);
	}

	public void outToFrame(TaskProcessor processor, Properties aProperties, Object aTheValue) throws Exception {

	}

	public void runCommandFrame(Properties params) throws Throwable {
	}

	class PanelTree extends JPanel implements ActionListener {
		private static final long serialVersionUID = 1L;

		JTree jTree = null;

		boolean fExpandRow = true;

		JButton theButton = new JButton("Collapse");

		public PanelTree(Vector<Vector<String>> theVector) {
			super(new BorderLayout());
			jTree = new JTree(theVector);

			jTree.setEditable(true);

			for (int i = 0; i < jTree.getRowCount(); i++) {
				jTree.expandRow(i);
			}

			JScrollPane theScroll = new JScrollPane(jTree);

			JToolBar theToolBar = new JToolBar();
			theButton.addActionListener(this);
			theToolBar.add(theButton);

			add(theToolBar, BorderLayout.NORTH);
			add(theScroll, BorderLayout.CENTER);
		}

		public void actionPerformed(ActionEvent e) {
			fExpandRow = !fExpandRow;
			if (fExpandRow) {
				theButton.setText("Collapse");
				for (int i = 0; i < jTree.getRowCount(); i++) {
					jTree.expandRow(i);
				}
			} else {
				theButton.setText("Expand");
				for (int i = jTree.getRowCount(); i >= 0; i--) {
					jTree.collapseRow(i);
				}
			}
		}
	}

	public void dbPropertiesCheck(Properties aProperties) {
		super.dbPropertiesCheck(aProperties);

		if (aProperties.getProperty("url") == null) {
			String theValue = (String) JOptionPane.showInputDialog(aeFrame,
					"This is a required property. The URL indicating the database\n"
							+ "from which the Data Source will obtain connections, \n"
							+ "such as 'jdbc:oracle:thin:@localhost:1521:sample' for\n"
							+ "thin driver and 'jdbc:oracle:oci8:@sample' for thick driver.\n");

			aProperties.setProperty("url", theValue);
		}

		if (aProperties.getProperty("username") == null) {
			String theValue = (String) JOptionPane.showInputDialog(aeFrame,
					"Specifies the database authentication data user ID.");

			aProperties.setProperty("username", theValue);
		}

		if (aProperties.getProperty("password") == null) {
			JPanel thePanel = new JPanel(new BorderLayout());
			JTextArea theJTextArea = new JTextArea("Specifies the password to use for\n" + "the Databse connection.");
			theJTextArea.setEditable(false);
			theJTextArea.setOpaque(false);
			thePanel.add(theJTextArea, BorderLayout.NORTH);

			fPasswordField = new JPasswordField();
			thePanel.add(fPasswordField, BorderLayout.CENTER);

			JOptionPane.showMessageDialog(aeFrame, thePanel);

			String thePassword = new String(fPasswordField.getPassword());
			fPasswordField = null;

			aProperties.setProperty("password", thePassword);
		}
	}

	public TaskProcessor getTaskProcessor() {
		TaskProcessor processor = super.getTaskProcessor();
		if (processor == null) {
			String testFile = getTestFile();
			if (testFile == null) {
				testFile = getManager().getStartDir().getAbsolutePath();
			}
			processor = new TaskProcessor(getManager(), getLog(), new File(testFile).getParentFile());
			processor.setMaxTestListener(this);
		}
		return processor;
	}

	public AEFrame getAeFrame() {
		return aeFrame;
	}

}
