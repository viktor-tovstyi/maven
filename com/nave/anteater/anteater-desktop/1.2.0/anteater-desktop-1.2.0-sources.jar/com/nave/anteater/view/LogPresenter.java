package com.nave.anteater.view;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.nave.anteater.ILogger;
import com.nave.anteater.Logger;
import com.nave.anteater.util.xml.easyparser.Node;
import com.nave.anteater.view.panel.PresentationPanel;
import com.nave.logfilter.LogFilter;

abstract public class LogPresenter extends PresentationPanel implements ILogger {

	private static final long serialVersionUID = 1L;

	private List<LogFilter> logFilters = new ArrayList<>();
	private boolean empty = true;

	protected LogPresenter(String name, Node node) {
		super(name, new Logger(name));

		if (node != null) {
			Node[] filters = node.getNodes("Logger/filter");
			for (Node filterNode : filters) {
				try {
					String className = filterNode.getAttribute("class");
					Class<?> filterClass = Class.forName(className);
					Constructor<?> constructor = filterClass.getConstructor(Map.class);
					LogFilter filter = (LogFilter) constructor.newInstance(filterNode.getAttributes());

					logFilters.add(filter);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		;
	}

	@Override
	public void info(Object message) {
		message = filter(message);
		log.info(message);
		empty = false;
	}

	public String filter(Object message) {
		for (LogFilter logFilter : logFilters) {
			message = logFilter.filter(message.toString());
		}
		return (String) message;
	}

	@Override
	public void debug(Object message) {
		message = filter(message);
		log.debug(message);
		empty = false;
	}

	@Override
	public void debug(Object message, Throwable t) {
		message = filter(message);
		log.debug(message, t);
		empty = false;
	}

	@Override
	public void error(Object message) {
		message = filter(message);
		log.error(message);
		empty = false;
	}

	@Override
	public void error(Object message, Throwable t) {
		message = filter(message);
		log.error(message, t);
		empty = false;
	}

	public boolean isFilterEnabled() {
		return logFilters.size() > 0;
	}

	public boolean isEmpty() {
		return empty;
	}

	public abstract LogPresenter copyAndClean();

}