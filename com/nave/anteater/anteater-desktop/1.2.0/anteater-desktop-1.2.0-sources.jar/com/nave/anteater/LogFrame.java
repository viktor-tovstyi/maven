package com.nave.anteater;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.AbstractButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;

import org.apache.commons.lang.StringUtils;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.UIUtils;
import com.nave.anteater.view.ListLoggPanel.LogRecord;
import com.nave.anteater.view.TextLoggPanel;

public class LogFrame extends JFrame implements WindowListener {

	private static final long serialVersionUID = 1L;
	private static final String LOG_MSG_ICON = "log-message.png";
	private TextLoggPanel logPanel;
	private JCheckBox onTop = new JCheckBox();
	
	private String NOT_ALWAYS_ON_TOP_ICON = "off-always-on-top.png";
	private String ALWAYS_ON_TOP_TOP = "on-always-on-top.png";

	public LogFrame(TextLoggPanel logPanel) {
		super("Log message");
		this.logPanel = logPanel;
		setIconImage(AEFrame.getIcon(LOG_MSG_ICON).getImage());

		getContentPane().add(logPanel.getPanel());

		logPanel.getLogTextArea().addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ESCAPE)
					setVisible(false);
			}
		});
		
		onTop.setIcon(AEFrame.getIcon(NOT_ALWAYS_ON_TOP_ICON));
		onTop.setSelectedIcon(AEFrame.getIcon(ALWAYS_ON_TOP_TOP));
		onTop.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setAlwaysOnTop(onTop.isSelected());
			}
		});

		onTop.setEnabled(true);
		logPanel.addButton((AbstractButton)onTop);

		pack();
		UIUtils.applyPreferedView(this, "log_win", 400, 600);

		addWindowListener(this);
	}

	public void showText(LogRecord text, TaskProcessor taskEditor, boolean autoformat) {
		setVisible(true);
		try {
			setTitle(StringUtils.abbreviate(text.getText(), 64));
		} catch (Exception e) {
			// TODO: handle exception
		}
		logPanel.clear();
		out(text, taskEditor);
		if (autoformat) {
			logPanel.format();
		}
	}

	public void out(LogRecord text, TaskProcessor taskEditor) {
		logPanel.info(text, taskEditor);
	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosing(WindowEvent e) {
		UIUtils.saveDialogPreferedView(this, "log_win");

	}

	@Override
	public void windowClosed(WindowEvent e) {

	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowActivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setVisible(boolean b) {
		super.setVisible(b);
		logPanel.getLogTextArea().requestFocus();
	}
}
