package com.nave.anteater.view.panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.Properties;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.CategoryItemRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.ui.TextAnchor;

public class BarChart extends PresentationPanel {
	private static final long serialVersionUID = 1L;

	private DefaultCategoryDataset dataset;
	private JFreeChart chart = null;

	public BarChart(Properties params) throws Exception {
		super(params);
		String title = params.getProperty("title");
		String xAxisLabel = params.getProperty("xAxisLabel");
		String yAxisLabel = params.getProperty("yAxisLabel");

		dataset = new DefaultCategoryDataset();
		chart = ChartFactory.createBarChart(title, xAxisLabel, yAxisLabel, dataset, PlotOrientation.VERTICAL, true,
				true, false);
		chart.setBackgroundPaint(Color.white);
        CategoryPlot plot = chart.getCategoryPlot();
        plot.setDomainGridlinesVisible(true);
        
        CategoryItemRenderer renderer = ((CategoryPlot)chart.getPlot()).getRenderer();
        renderer.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
        renderer.setBaseItemLabelsVisible(true);
        ItemLabelPosition position = new ItemLabelPosition(ItemLabelAnchor.OUTSIDE12, 
                TextAnchor.TOP_CENTER);
        renderer.setBasePositiveItemLabelPosition(position);
        
        
        final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
		add(new ChartPanel(chart, false), BorderLayout.CENTER);
	}

	synchronized public void out(Object data, Properties properties) {
		if (data instanceof String) {
			double value = Double.parseDouble((String) data);
			Comparable row = properties.getProperty("row");
			Comparable column = properties.getProperty("column");

			CategoryPlot plot = chart.getCategoryPlot();
			final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
			if (value != Math.ceil(value) && rangeAxis.getStandardTickUnits() == NumberAxis.createIntegerTickUnits()) {
		        rangeAxis.setStandardTickUnits(NumberAxis.createStandardTickUnits());
			}
				
			dataset.addValue((int) value, row, column);
		}
	}
}