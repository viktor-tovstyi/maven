package com.nave.anteater.view;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.CellRendererPane;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JTextArea;
import javax.swing.JToolTip;
import javax.swing.MenuElement;
import javax.swing.MenuSelectionManager;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicToolTipUI;

public class JDialogPopupMenu extends JPopupMenu {

	private JTextArea editor;

	public JDialogPopupMenu(Component component) {
		super();
		if (component instanceof JTextArea)
			this.editor = (JTextArea) component;
		setAutoscrolls(true);
	}

	/**
	 * Field holding the value of serialVersionUID
	 */
	private static final long serialVersionUID = 829852467458669791L;

	public JMenuItem add(JMenuItem menuItem) {
		return super.add(menuItem);
	}

	public void show(Component component, int x, int y) {
		super.show(component, x, y);
	}

	public void add(AbstractAction action) {
		super.add(action);
	}

	public void add(JMenuItem item, int i) {
		super.add(item, i);
	}

	public void addSeparator() {
		super.addSeparator();
	}

	public static class JMultiLineToolTip extends JToolTip {
		private static final String uiClassID = "ToolTipUI";

		String tipText;
		JComponent component;

		public JMultiLineToolTip() {
			updateUI();
		}

		public void updateUI() {
			setUI(MultiLineToolTipUI.createUI(this));
		}

		public void setColumns(int columns) {
			this.columns = columns;
			this.fixedwidth = 0;
		}

		public int getColumns() {
			return columns;
		}

		public void setFixedWidth(int width) {
			this.fixedwidth = width;
			this.columns = 0;
		}

		public int getFixedWidth() {
			return fixedwidth;
		}

		protected int columns = 0;
		protected int fixedwidth = 0;
	}

	static class MultiLineToolTipUI extends BasicToolTipUI {
		static MultiLineToolTipUI sharedInstance = new MultiLineToolTipUI();
		Font smallFont;
		static JToolTip tip;
		protected CellRendererPane rendererPane;

		private static JLabel textArea;

		public static ComponentUI createUI(JComponent c) {
			return sharedInstance;
		}

		public MultiLineToolTipUI() {
			super();
		}

		public void installUI(JComponent c) {
			super.installUI(c);
			tip = (JToolTip) c;
			rendererPane = new CellRendererPane();
			c.add(rendererPane);
		}

		public void uninstallUI(JComponent c) {
			super.uninstallUI(c);

			c.remove(rendererPane);
			rendererPane = null;
		}

		public void paint(Graphics g, JComponent c) {
			Dimension size = c.getSize();
			textArea.setBackground(c.getBackground());
			rendererPane.paintComponent(g, textArea, c, 1, 1, size.width - 1, size.height - 1, true);
		}

		public Dimension getPreferredSize(JComponent c) {
			String tipText = ((JToolTip) c).getTipText();
			if (tipText == null)
				return new Dimension(0, 0);
			textArea = new JLabel(tipText);
			rendererPane.removeAll();
			rendererPane.add(textArea);
//      textArea.setWrapStyleWord(true);
			int width = ((JMultiLineToolTip) c).getFixedWidth();
			int columns = ((JMultiLineToolTip) c).getColumns();

			if (columns > 0) {
//        textArea.setColumns(columns);
				textArea.setSize(0, 0);
//      textArea.setLineWrap(true);
				textArea.setSize(textArea.getPreferredSize());
			} else if (width > 0) {
//      textArea.setLineWrap(true);
				Dimension d = textArea.getPreferredSize();
				d.width = width;
				d.height++;
				textArea.setSize(d);
			}
//      else
//        textArea.setLineWrap(false);

			Dimension dim = textArea.getPreferredSize();

			dim.height += 1;
			dim.width += 1;
			return dim;
		}

		public Dimension getMinimumSize(JComponent c) {
			return getPreferredSize(c);
		}

		public Dimension getMaximumSize(JComponent c) {
			return getPreferredSize(c);
		}
	}

	@Override
	public void processKeyEvent(KeyEvent e, MenuElement[] path, MenuSelectionManager manager) {
		char keyChar = e.getKeyChar();
		if (Character.isLetter(keyChar)) {
			setVisible(false);
			if (editor != null)
				editor.insert(new String(new char[] { keyChar }), editor.getCaretPosition());
		} else
			super.processKeyEvent(e, path, manager);
	}

}
