package com.nave.anteater;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Comparator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.Vector;

import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableColumn;

import org.apache.commons.lang.StringUtils;

import com.nave.anteater.util.UIUtils;

class CheckpointsDialog extends AbstractTableModel {

	private static final long serialVersionUID = -7042738069522850806L;
	private static final String CP_DIALOG_PREF_PROP_NAME = "CheckpointDialog";

	private static CheckpointsDialog instance;
	private JDialog dialog;

	public JDialog getDialog() {
		return dialog;
	}

	private Vector<CheckpointsRec> checkpoints = new Vector<>();
	private JTable table;

	public CheckpointsDialog(final AEFrame frame) {
		dialog = new JDialog(frame, "Required dialogs", false);
		dialog.setPreferredSize(new Dimension(300, 400));
		frame.pushOnTop();
		dialog.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				UIUtils.saveDialogPreferedView(dialog, CP_DIALOG_PREF_PROP_NAME);
			}
		});
		dialog.setPreferredSize(new Dimension(300, 400));

		table = new JTable(this);
		TableColumn column = table.getColumnModel().getColumn(0);
		column.setMaxWidth(40);
		column.setHeaderValue("Active");
		column.setCellEditor(new DefaultCellEditor(new JCheckBox()));

		TableColumn column1 = table.getColumnModel().getColumn(1);
		column1.setHeaderValue("Dialog Box");

		dialog.getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);
		instance = this;
		dialog.pack();

	}

	public void showDialog() {

		int size = refresh();

		int height = size * 19 + 80;
		UIUtils.applyPreferedView(dialog, CP_DIALOG_PREF_PROP_NAME, height, 300);
		dialog.setVisible(true);
	}

	public int getColumnCount() {
		return 2;
	}

	public int getRowCount() {
		return checkpoints.size();
	}

	public Object getValueAt(int row, int coll) {
		CheckpointsRec checkpointsRec = checkpoints.get(row);
		if (coll == 0) {
			return checkpointsRec.state;
		}
		String name = checkpointsRec.name;
		InputDialogType type = checkpointsRec.type;
		switch (type) {
		case TASKS:
			name = "<html><body><strong>" + name + "</strong></body></html>";
			break;

		default:
			break;
		}
		return name;
	}

	@Override
	public Class<?> getColumnClass(int coll) {
		if (coll == 0)
			return Boolean.class;
		return String.class;
	}

	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return columnIndex == 0;
	}

	@Override
	public void setValueAt(Object arg0, int row, int coll) {
		CheckpointsRec checkpointsRec = checkpoints.get(row);
		String name = checkpointsRec.name;
		if (coll == 0) {
			checkpointsRec.state = (Boolean) arg0;
			CheckPointBox.setCheckPointFlag(checkpointsRec.type, name, checkpointsRec.state);
		}
	}

	public static CheckpointsDialog getInstance() {
		return instance;
	}

	public int refresh() {
		Properties userPreferences = AEWorkspace.getUserPreferences();
		Set<Entry<Object, Object>> entrySet = userPreferences.entrySet();

		int size = checkpoints.size();

		for (Entry<Object, Object> entry : entrySet) {
			String recStr = (String) entry.getKey();
			String prefix = AEWorkspace.getInstance().getConfigurationName() + "@" + CheckPointBox.CHECKPOINT_PREFIX;
			if (recStr.startsWith(prefix)) {
				String name = StringUtils.substringAfterLast(recStr, ".");
				if (StringUtils.isNotEmpty(name)) {
					CheckpointsRec rec = getRec(name);
					String type = StringUtils.substringBetween(recStr, prefix + ".", ".");
					rec.type = InputDialogType.valueOf(type);
					rec.state = Boolean.valueOf((String) entry.getValue());
					if (!checkpoints.contains(rec)) {
						checkpoints.add(rec);
					}
				}
			}
		}

		if (size == 0) {
			checkpoints.sort(new Comparator<CheckpointsRec>() {
				@Override
				public int compare(CheckpointsRec o1, CheckpointsRec o2) {
					return o1.name.compareTo(o2.name);
				}
			});
		}

		table.invalidate();
		table.repaint();
		return checkpoints.size();
	}

	private CheckpointsRec getRec(String name) {
		for (CheckpointsRec checkpointsRec : checkpoints) {
			if (StringUtils.equals(checkpointsRec.name, name)) {
				return checkpointsRec;
			}
		}
		return new CheckpointsRec(name);
	}

	public void updated(InputDialogType type, String name) {
		for (CheckpointsRec checkpointsRec : checkpoints) {
			if (StringUtils.equals(checkpointsRec.name, name)) {
				checkpoints.remove(checkpointsRec);
				checkpoints.insertElementAt(checkpointsRec, 0);
				break;
			}
		}
		refresh();
	}

}