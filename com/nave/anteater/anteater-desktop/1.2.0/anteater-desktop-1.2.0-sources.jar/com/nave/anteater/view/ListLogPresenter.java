package com.nave.anteater.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.UIDefaults;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;

import com.nave.anteater.AEFrame;
import com.nave.anteater.AELogRecord;
import com.nave.anteater.AEWorkspace;
import com.nave.anteater.LogFrame;
import com.nave.anteater.TaskEditor;
import com.nave.anteater.util.TextPrompt;

public class ListLogPresenter extends LogPresenter implements ActionListener {

	private static final long serialVersionUID = 1L;

	private static final Font LOG_FONT = new Font("Monospaced", Font.PLAIN, 11);

	private LogList logList;

	private JComboBox<String> levelBox = new JComboBox<String>(new String[] { "Debug", "Info", "Warning", "Error" });
	private JCheckBox autoformatBtn = new JCheckBox("Auto format");
	private JTextField find = new JTextField(8);

	private JTable fLogTextArea = new JTable(new AbstractTableModel() {
		private static final long serialVersionUID = 1L;

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH.mm.ss,SSS");

		public int getColumnCount() {
			return 3;
		}

		public int getRowCount() {
			return logList.getSize();
		}

		public Object getValueAt(int rowIndex, int columnIndex) {

			String text = logList.get(rowIndex).toString();

			switch (columnIndex) {
			case 0:
				return simpleDateFormat.format(logList.get(rowIndex).time);
			case 1:
				if (logList.get(rowIndex).getSource() != null) {
					if (text != null) {
						return logList.get(rowIndex).getSource() + " = " + text;
					} else {
						return logList.get(rowIndex).getSource() + " is not defined.";
					}
				} else {
					return text;
				}
			case 2:
				return text == null ? 0 : text.length();
			}
			return null;
		}
	}) {

		private static final long serialVersionUID = 1L;

		@Override
		public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
			Component c = super.prepareRenderer(renderer, row, column);

			UIDefaults defaults = javax.swing.UIManager.getDefaults();
			Color background = defaults.getColor("List.background");
			Color foreground = defaults.getColor("List.foreground");

			LogRecord logRecord = logList.get(row);
			int level = logRecord.getLogLevel();

			switch (column) {
			case 0:
				long time = logRecord.getTime();
				double a = time / 500.0;
				double b = (Math.sin(a) + 1) / 2.0;
				background = new Color((float) b, (float) b, (float) b);
				break;

			case 1:
				String text = find.getText();
				if (StringUtils.isNotBlank(text)) {
					String message = ObjectUtils.toString(logRecord.getMessage());
					if (logRecord.getSource() != null) {
						message = logRecord.getSource() + " = " + message;
					}
					int indexOf = StringUtils.indexOfIgnoreCase(message, text);
					background = indexOf < 0 ? Color.white : Color.yellow;
				}
				break;

			case 2:
				text = logRecord.toString();
				if (text != null) {
					a = (double) (text.length()) / 100;
					if (a < 1) {
						a = 1;
					}
					b = Math.log(a) * 8;
					b = (100 - b) / 100;
					if (b < 0.4) {
						b = 0.4;
					}
					background = new Color((float) b, (float) b, (float) b);
				} else {
					background = Color.YELLOW;
				}
				break;
			}

			switch (level) {
			case 0:
				foreground = tuneColorByBackground(Color.RED);
				break;
			case 1:
				foreground = tuneColorByBackground(Color.BLUE);
				break;
			case 2:
				foreground = tuneColorByBackground(Color.GREEN);
				break;
			case 3:
				break;
			default:

			}

			ListSelectionModel selectionModel = fLogTextArea.getSelectionModel();
			if (selectionModel.isSelectedIndex(row)) {
				c.setBackground(foreground);
				c.setForeground(background);

			} else {
				c.setBackground(background);
				c.setForeground(foreground);
			}

			return c;
		}

		private Color tuneColorByBackground(Color fgc) {
			UIDefaults defaults = javax.swing.UIManager.getDefaults();
			Color background = defaults.getColor("List.background");

			int alpha = (int) (0.2126 * background.getRed() + 0.7152 * background.getGreen()
					+ 0.0722 * background.getBlue());

			if (alpha < 60) {
				int colorLevel = 140;
				fgc = new Color(fgc.getRed() == 0 ? colorLevel : fgc.getRed(),
						fgc.getGreen() == 0 ? colorLevel : fgc.getGreen(),
						fgc.getBlue() == 0 ? colorLevel : fgc.getBlue());
			}

			if (alpha > 200) {
				fgc = fgc.darker().darker();
			}
			return fgc;
		}

	};

	private JCheckBox fLogToEnd = new JCheckBox("Auto scrolling");
	private JCheckBox fDeleteOldRec = new JCheckBox("Limit 50 records");

	private JScrollPane fLogScrollPanel = new JScrollPane();

	private TaskEditor fTaskEditor;

	private JLabel messageBar = new JLabel();

	private boolean mainLog;

	public ListLogPresenter(TaskEditor aTaskEditor, String aName) {
		this(aTaskEditor, aName, false);
	}

	public ListLogPresenter(TaskEditor aTaskEditor, String aName, boolean mainLog) {
		super(aName, aTaskEditor.getConfigNode());
		this.mainLog = mainLog;
		fTaskEditor = aTaskEditor;
		createPanel();
	}

	private void copyToClipboard() {
		ListSelectionModel selectionModel = fLogTextArea.getSelectionModel();
		int minSelectionIndex = selectionModel.getMinSelectionIndex();
		int maxSelectionIndex = selectionModel.getMaxSelectionIndex();

		StringBuilder msgBuilder = new StringBuilder();
		for (int i = minSelectionIndex; i <= maxSelectionIndex; i++) {

			boolean selectedIndex = selectionModel.isSelectedIndex(i);

			if (selectedIndex) {
				if (i != minSelectionIndex) {
					msgBuilder.append("\n---------------------\n");
				}

				LogRecord text = logList.get(i);
				TextLogPresenter logPanel = new TextLogPresenter(fTaskEditor, getName());
				logPanel.info(text, fTaskEditor.getTaskProcessor());
				boolean selected = autoformatBtn.isSelected();
				if (selected) {
					logPanel.format();
				}

				String msg = ((JTextArea) logPanel.getLogTextArea()).getText();
				msgBuilder.append(msg);
			}
		}

		StringSelection stringSelection = new StringSelection(msgBuilder.toString());
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		clipboard.setContents(stringSelection, null);
	}

	public void actionPerformed(ActionEvent e) {
		if (e != null && e.getSource() == fLogToEnd) {
			AEWorkspace.getInstance().setDefaultUserConfiguration(".Edit.LogToEnd",
					fLogToEnd.isSelected() ? "true" : "false");
			return;
		}
		if (e != null && e.getSource() == fDeleteOldRec) {
			AEWorkspace.getInstance().setDefaultUserConfiguration(".Edit.DeleteOldRec",
					fDeleteOldRec.isSelected() ? "true" : "false");
			return;
		}
	}

	public void info(Object o) {
		appendText(2, o);
		super.info(o);
	}

	public void debug(Object o) {
		if (o instanceof Throwable) {
			StringWriter theStringWriter = new StringWriter();
			((Throwable) o).printStackTrace(new PrintWriter(theStringWriter));
			appendText(3, theStringWriter.toString());
		} else {
			appendText(3, o);
			super.debug(o);
		}
	}

	public void debug(Object o, Throwable aThrowable) {
		appendText(3, o);

		StringWriter theStringWriter = new StringWriter();
		aThrowable.printStackTrace(new PrintWriter(theStringWriter));
		appendText(3, theStringWriter.toString());

		super.error(o, aThrowable);
	}

	public void error(Object o) {
		appendText(0, o);
		super.error(o);
	}

	public void error(Object o, Throwable aThrowable) {
		StringWriter theStringWriter = new StringWriter();
		aThrowable.printStackTrace(new PrintWriter(theStringWriter));
		appendText(0, ObjectUtils.toString(o) + "\n" + theStringWriter.toString());
		super.error(o, aThrowable);
	}

	public void warn(Object o) {
		appendText(1, o);
		super.error(o);
	}

	void appendText(int logLevel, Object o) {
		logList.add(new LogRecord(logLevel, o), fDeleteOldRec.isSelected());

		int level = 3 - levelBox.getSelectedIndex();
		if (logLevel <= level) {
			fLogTextArea.revalidate();
			fLogScrollPanel.repaint();
		}
		
		if (fLogToEnd.isSelected()) {
			JScrollBar verticalScrollBar = fLogScrollPanel.getVerticalScrollBar();
			verticalScrollBar.setValue(verticalScrollBar.getMaximum());
		}
	}

	public void warn(Object o, Throwable aThrowable) {
		appendText(1, o);
		StringWriter theStringWriter = new StringWriter();
		aThrowable.printStackTrace(new PrintWriter(theStringWriter));
		appendText(1, theStringWriter.toString());
		super.error(o, aThrowable);
	}

	public void createPanel() {
		String defaultUserConfiguration = AEWorkspace.getInstance().getDefaultUserConfiguration(".defaultLogLevel",
				"2");
		int defLevel = Integer.parseInt(defaultUserConfiguration);
		logList = new LogList(defLevel);

		logList.setLevel(defLevel);
		levelBox.setSelectedIndex(3 - defLevel);
		levelBox.setFont(LOG_FONT);

		fLogTextArea.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		fLogTextArea.setCellSelectionEnabled(true);

		fLogTextArea.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.isControlDown() && e.isShiftDown() && e.getKeyCode() == KeyEvent.VK_C) {
					copyToClipboard();
				}
			}

		});

		fLogTextArea.addMouseListener(new MouseAdapter() {

			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == 1) {

					if (e.getClickCount() == 2) {
						LogRecord logRecord = selectAndGetRecord(e);
						if (!e.isControlDown()) {
							openLogRecord(logRecord);

						} else {
							openIn(logRecord);
						}
					}

				} else if (e.getButton() == 3) {
					LogRecord logRecord = selectAndGetRecord(e);

					final JPopupMenu popup = new JPopupMenu();
					JMenuItem jMenuItem = new JMenuItem("Open");
					jMenuItem.addActionListener(new AbstractAction() {

						@Override
						public void actionPerformed(ActionEvent var1) {
							openLogRecord(logRecord);
						}

					});
					popup.add(jMenuItem);
					jMenuItem = new JMenuItem("Open In");
					jMenuItem.addActionListener(new AbstractAction() {

						@Override
						public void actionPerformed(ActionEvent var1) {
							openIn(logRecord);
						}

					});
					popup.add(jMenuItem);
					jMenuItem = new JMenuItem("Copy");
					jMenuItem.addActionListener(new AbstractAction() {

						@Override
						public void actionPerformed(ActionEvent var1) {
							copyToClipboard();
						}

					});
					popup.add(jMenuItem);
					jMenuItem = new JMenuItem("Save");
					jMenuItem.addActionListener(new AbstractAction() {

						@Override
						public void actionPerformed(ActionEvent var1) {
							ListSelectionModel selectionModel = fLogTextArea.getSelectionModel();
							int minSelectionIndex = selectionModel.getMinSelectionIndex();
							int maxSelectionIndex = selectionModel.getMaxSelectionIndex();

							for (int i = minSelectionIndex; i <= maxSelectionIndex; i++) {

								boolean selectedIndex = selectionModel.isSelectedIndex(i);

								if (selectedIndex) {
									LogRecord logRecord = logList.get(i);
									TextLogPresenter logPanel = new TextLogPresenter(fTaskEditor,
											logRecord.getSource());

									logPanel.info(logRecord, fTaskEditor.getTaskProcessor());
									boolean selected = autoformatBtn.isSelected();
									if (selected) {
										logPanel.format();
									}
									logPanel.saveToFile();
								}
							}
						}
					});
					popup.add(jMenuItem);
					popup.show(e.getComponent(), e.getX(), e.getY());
				}
			}

			private LogRecord selectAndGetRecord(MouseEvent e) {
				int r = fLogTextArea.rowAtPoint(e.getPoint());
				if (r >= 0 && r < fLogTextArea.getRowCount()) {
					fLogTextArea.setRowSelectionInterval(r, r);
				} else {
					fLogTextArea.clearSelection();
				}
				ListSelectionModel selectionModel = fLogTextArea.getSelectionModel();
				int anchorSelectionIndex = selectionModel.getAnchorSelectionIndex();
				LogRecord logRecord = logList.get(anchorSelectionIndex);
				return logRecord;
			}

			private void openLogRecord(LogRecord logRecord) {
				String source = logRecord.getSource();
				source = StringUtils.defaultString(source);
				TextLogPresenter logPanel = new TextLogPresenter(fTaskEditor, source);
				LogFrame logFrame = new LogFrame(logPanel);
				logFrame.showText(logRecord, fTaskEditor.getTaskProcessor(), autoformatBtn.isSelected());
			}

			private void openIn(LogRecord text) {
				try {
					fTaskEditor.getFrame().out(text, fTaskEditor.getTaskProcessor());
					TextLogPresenter.openFile(text, text.getType());
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
		});

		TableColumnModel columnModel = fLogTextArea.getColumnModel();
		columnModel.getColumn(0).setMinWidth(0);
		columnModel.getColumn(0).setPreferredWidth(8);
		columnModel.getColumn(0).setMaxWidth(90);
		columnModel.getColumn(0).setHeaderValue("Time");
		columnModel.getColumn(1).setHeaderValue("Message");
		columnModel.getColumn(2).setHeaderValue("Size, B");
		columnModel.getColumn(2).setMinWidth(0);
		columnModel.getColumn(2).setMaxWidth(150);
		columnModel.getColumn(2).setPreferredWidth(8);

		fLogScrollPanel.getVerticalScrollBar().setDoubleBuffered(true);

		add(fLogScrollPanel, BorderLayout.CENTER);

		JPanel theFindPanel = new JPanel();

		theFindPanel.add(find);
		new TextPrompt("Search", find);

		find.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
					find.setText("");
				}
				fLogTextArea.repaint();
			}
		});
		JLabel comp = new JLabel("Level:");
		comp.setFont(LOG_FONT);
		theFindPanel.add(comp);
		levelBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ListSelectionModel selectionModel = fLogTextArea.getSelectionModel();
				selectionModel.clearSelection();
				int logLevel = 3 - levelBox.getSelectedIndex();
				AEWorkspace.getInstance().setDefaultUserConfiguration(".defaultLogLevel", Integer.toString(logLevel));
				logList.setLevel(logLevel);
				fLogTextArea.revalidate();
				fLogScrollPanel.revalidate();
			}
		});
		theFindPanel.add(levelBox);

		JButton theClearButton = new JButton(AEFrame.getIcon("clean.png"));
		theClearButton.setFont(LOG_FONT);
		theClearButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ListSelectionModel selectionModel = fLogTextArea.getSelectionModel();
				selectionModel.clearSelection();
				logList.clear();
				fLogTextArea.revalidate();
				fLogScrollPanel.revalidate();
			}

		});

		theFindPanel.add(theClearButton);

		if (!mainLog) {
			JButton theCloseButton = new JButton(AEFrame.getIcon("close.png"));
			theCloseButton.setFont(LOG_FONT);
			theCloseButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					fTaskEditor.removeActivePresentationPanel();
				}
			});

			theFindPanel.add(theCloseButton);
		}

		JPanel theLogControlPanel = new JPanel(new BorderLayout());
		theLogControlPanel.add(theFindPanel, BorderLayout.EAST);
		JPanel theLogLevelPanel = new JPanel();

		theLogControlPanel.add(theLogLevelPanel, BorderLayout.WEST);

		add(theLogControlPanel, BorderLayout.NORTH);

		JPanel panel = new JPanel(new BorderLayout());
		JPanel panel4 = new JPanel();

		panel4.add(fLogToEnd);
		panel4.add(fDeleteOldRec);

		autoformatBtn.setSelected(
				"true".equals(AEWorkspace.getInstance().getDefaultUserConfiguration(".Edit.AutoFormat", "false")));
		autoformatBtn.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				AEWorkspace.getInstance().setDefaultUserConfiguration(".Edit.AutoFormat",
						autoformatBtn.isSelected() ? "true" : "false");
			}
		});

		panel4.add(autoformatBtn);

		panel4.add(this.messageBar);
		panel.add(panel4, BorderLayout.WEST);
		add(panel, BorderLayout.SOUTH);
		fLogToEnd.setSelected(
				"true".equals(AEWorkspace.getInstance().getDefaultUserConfiguration(".Edit.LogToEnd", "true")));
		fLogToEnd.addActionListener(this);

		fDeleteOldRec.setSelected(
				"true".equals(AEWorkspace.getInstance().getDefaultUserConfiguration(".Edit.DeleteOldRec", "true")));
		fDeleteOldRec.addActionListener(this);

		fLogTextArea.setFont(LOG_FONT);
		fLogScrollPanel.getViewport().add(fLogTextArea);
	}

	public ListLogPresenter copyAndClean() {
		ListLogPresenter listLogPresenter = new ListLogPresenter(fTaskEditor, getName());
		listLogPresenter.setLogList(logList);
		String defaultUserConfiguration = AEWorkspace.getInstance().getDefaultUserConfiguration(".defaultLogLevel",
				"2");
		int defLevel = Integer.parseInt(defaultUserConfiguration);
		logList = new LogList(defLevel);
		fLogTextArea.revalidate();
		fLogScrollPanel.repaint();

		return listLogPresenter;
	}

	private void setLogList(LogList logList) {
		this.logList = logList;
		fLogToEnd.setVisible(false);
		fDeleteOldRec.setVisible(false);
	}

	public static class LogRecord {

		private Object message;

		private int logLevel;

		private Date time;

		private String type;

		private String source;

		public LogRecord(int logLevel, Object o) {
			if (o instanceof Map) {
				Map map = (Map) o;
				message = new HashMap();
				((Map) message).putAll(map);

			} else if (o instanceof AELogRecord) {
				type = ((AELogRecord) o).getType();
				message = ((AELogRecord) o).getMessage();

				if (message instanceof Map) {
					Map map = (Map) message;
					message = new HashMap();
					((Map) message).putAll(map);
				}

				source = ((AELogRecord) o).getVarName();
			} else {
				message = o;
			}
			this.logLevel = logLevel;
			this.time = new Date();
		}

		public Object getMessage() {
			return message;
		}

		public long getTime() {
			return time.getTime();
		}

		public Object getResume() {
			return message;
		}

		public int getLogLevel() {
			return logLevel;
		}

		public String getType() {
			return type;
		}

		@Override
		public String toString() {
			if (message instanceof byte[]) {
				return new String((byte[]) message);
			}
			return ObjectUtils.toString(message, null);
		}

		public String getSource() {
			return source;
		}

		public void setSource(String source) {
			this.source = source;
		}

		public String getText() {
			return ObjectUtils.toString(message);
		}

	}

}
