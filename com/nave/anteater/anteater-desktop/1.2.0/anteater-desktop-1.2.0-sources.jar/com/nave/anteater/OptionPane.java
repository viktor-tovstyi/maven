package com.nave.anteater;

import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Frame;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.nave.anteater.util.UIUtils;

public class OptionPane {

	public static int showOptionDialog(Component parentComponent, Object message, String title, int optionType,
			int messageType, Object[] options, Object initialValue) {
		int result = 0;

		JOptionPane pane = new JOptionPane(message, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
		pane.setOptions(options);
		pane.setMessageType(messageType);
		pane.setOptionType(optionType);
		pane.setInitialValue(initialValue);
		JDialog dialog = pane.createDialog(parentComponent, "Input value");
		dialog.setModal(false);

		dialog.setVisible(true);
		dialog.requestFocus();
		UIUtils.applyPreferedView(dialog, title);

		if (message instanceof JPanel) {
			JPanel panel = (JPanel) message;
			try {
			Component component = panel.getComponent(2);
			if(component instanceof CheckPointBox) {
				component = panel.getComponent(1);
			}
			if (component instanceof JTextField) {
				JTextField field = (JTextField) component;
				EventQueue.invokeLater(new Runnable() {
					@Override
					public void run() {
						field.grabFocus();
						field.requestFocus();
						field.selectAll();
					}
				});
				dialog.pack();
			} else if (component instanceof JComboBox) {
				JComboBox field = (JComboBox) component;
				EventQueue.invokeLater(new Runnable() {
					@Override
					public void run() {
						field.grabFocus();
						field.requestFocus();
					}
				});
				dialog.pack();
			} else {
				dialog.setResizable(true);
			}
			}catch (ArrayIndexOutOfBoundsException e) {
				// TODO: handle exception
			}
		}

		Object value = null;
		do {
			value = pane.getValue();
			try {
				Thread.sleep(20);
			} catch (Exception e) {
				// TODO: handle exception
			}
		} while (value == "uninitializedValue");

		UIUtils.saveDialogPreferedView(dialog, title);
		dialog.dispose();

		if (value == null) {
			result = -1;
		}

		if ("Cancel".equals(value)) {
			result = JOptionPane.CANCEL_OPTION;
		}
		if ("OK".equals(value)) {
			result = JOptionPane.OK_OPTION;
		}

		if (value instanceof Integer) {
			result = (int) value;
		}

		SoundManager.stop();
		return result;
	}

	public static int showConfirmDialog(Frame frame, JComponent panel, String title, int warningMessage) {
		return showOptionDialog(frame, panel, title, JOptionPane.OK_OPTION, JOptionPane.QUESTION_MESSAGE, null, null);
	}

}
