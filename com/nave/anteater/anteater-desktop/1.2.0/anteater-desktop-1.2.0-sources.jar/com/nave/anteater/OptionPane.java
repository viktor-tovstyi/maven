package com.nave.anteater;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Frame;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import com.nave.anteater.util.UIUtils;

public class OptionPane {

	public static int showOptionDialog(Component parentComponent, Object message, String title, int optionType,
			int messageType) {
		return showOptionDialog(parentComponent, message, title, optionType, messageType, false);
	}

	public static int showOptionDialog(Component parentComponent, Object message, String title, int optionType,
			int messageType, boolean modal) {
		int result = 0;

		JOptionPane pane = new JOptionPane(message, JOptionPane.QUESTION_MESSAGE, JOptionPane.CANCEL_OPTION, null, new String[] {"OK", "Skip"});
		pane.setMessageType(messageType);
		JDialog dialog = pane.createDialog(parentComponent, title);
		dialog.setModal(modal);

		if (!parentComponent.isVisible()) {
			dialog.setAlwaysOnTop(true);
		}

		UIUtils.applyPreferedView(dialog, title);
		dialog.setVisible(true);
		dialog.requestFocus();

		if (message instanceof JPanel) {
			JPanel panel = (JPanel) message;
			try {
				Component component = panel.getComponent(2);
				if (component instanceof CheckPointBox) {
					component = panel.getComponent(1);
				}
				if (component instanceof JTextField) {
					JTextField field = (JTextField) component;
					EventQueue.invokeLater(new Runnable() {
						@Override
						public void run() {
							field.grabFocus();
							field.requestFocus();
							field.selectAll();
						}
					});
					dialog.pack();
				} else if (component instanceof JComboBox) {
					JComboBox field = (JComboBox) component;
					SwingUtilities.invokeLater(new Runnable() {
						@Override
						public void run() {
							field.grabFocus();
							field.requestFocus();
						}
					});
					dialog.pack();
				} else {
					dialog.setResizable(true);
				}
			} catch (ArrayIndexOutOfBoundsException e) {
				// TODO: handle exception
			}
		}

		Object value = null;
		do {
			value = pane.getValue();
			try {
				Thread.sleep(100);
			} catch (Exception e) {
				// TODO: handle exception
			}
		} while (value == "uninitializedValue");

		UIUtils.saveDialogPreferedView(dialog, title);
		dialog.dispose();

		if (value == null) {
			result = -1;
		}

		if ("Skip".equals(value)) {
			result = JOptionPane.CANCEL_OPTION;
		}
		if ("OK".equals(value)) {
			result = JOptionPane.OK_OPTION;
		}

		if (value instanceof Integer) {
			result = (int) value;
		}

		SoundManager.stop();
		return result;
	}

	public static int showConfirmDialog(Frame frame, JComponent panel, String title, int warningMessage) {
		return showOptionDialog(frame, panel, title, JOptionPane.OK_OPTION, JOptionPane.QUESTION_MESSAGE);
	}

	public static String showInputDialog(Component rootPane, String message, String title, int informationMessage,
			Object object, Object[] list, String newValueTitle) {
		JPanel panel = new JPanel(new BorderLayout());
		JLabel label = new JLabel(message);
		panel.add(label, BorderLayout.NORTH);
		JComponent inputField = new JComboBox((Object[]) list);
		((JComboBox<String>) inputField).setSelectedItem(newValueTitle);
		panel.add(inputField, BorderLayout.CENTER);

		CheckPointBox vip = new CheckPointBox(title, InputDialogType.VAR);
		panel.add(vip, BorderLayout.SOUTH);
		int showOptionDialog = showOptionDialog(rootPane, panel, title, 0, 3, true);
		String result = showOptionDialog == -1 ? null : (String) ((JComboBox<String>) inputField).getSelectedItem();
		return result;
	}

}
