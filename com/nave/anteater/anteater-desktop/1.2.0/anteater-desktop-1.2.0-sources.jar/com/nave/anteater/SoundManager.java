package com.nave.anteater;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import org.apache.log4j.Logger;

public class SoundManager {

	private Logger log = Logger.getLogger(AEFrame.class);

	private static Clip clip;
	
	private AEFrame aeFrame;

	public SoundManager(AEFrame aeFrame) {
		this.aeFrame = aeFrame;
	}

	synchronized public void play() {
		if (clip == null) {
			if (aeFrame.isUserInactive()) {
				AudioInputStream audioInputStream;
				try {
					audioInputStream = AudioSystem
							.getAudioInputStream(AEFrame.class.getResource("/sounds/anteater.mp3"));
					clip = AudioSystem.getClip();
					clip.open(audioInputStream);
					clip.start();
				} catch (Exception e1) {
					log.debug("Notification sounds error: " + e1.getMessage());
				}
			}
		}
	}

	public static void stop() {
		if (clip != null) {
			clip.stop();
		}
		clip = null;
	}
}
