package com.nave.anteater;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class SoundManager {

	private ILogger log = new Logger("SoundManager");

	private static Clip clip;
	private static Thread thread = null;

	private AEFrame aeFrame;
	private long[] delaysBeforePlay = { 2000, 30000, 30000, 30000, 30000, 5000, 10000 };

	public SoundManager(AEFrame aeFrame) {
		this.aeFrame = aeFrame;
	}

	synchronized public void play() {
		if (thread == null) {
			if (aeFrame.isUserInactive()) {
				thread = new Thread(() -> {
					AudioInputStream audioInputStream;
					try {
						int i = 1;
						for (long delay : delaysBeforePlay) {
							if (thread == null) {
								break;
							}
							Thread.sleep(delay);
							if (thread == null) {
								break;
							}
							audioInputStream = AudioSystem
									.getAudioInputStream(AEFrame.class.getResource("/sounds/anteater-" + i + ".wav"));
							clip = AudioSystem.getClip();
							clip.open(audioInputStream);
							clip.start();
							i++;
						}
					} catch (Exception e1) {
						log.debug("Notification sounds error: " + e1.getMessage());
					}
				});

				thread.start();
			}
		}
	}

	public static void stop() {
		thread = null;
		if (clip != null) {
			clip.stop();
		}
		clip = null;
	}
}
