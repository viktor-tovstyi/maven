package com.nave.anteater.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.apache.commons.lang.StringUtils;

import com.nave.anteater.AEFrame;
import com.nave.anteater.util.xml.easyparser.Node;

public class ConfigurationPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private AEFrame aeFrame;

	public ConfigurationPanel(AEFrame aeFrame) {
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		this.aeFrame = aeFrame;
	}

	public void setConfigNode(Node allConfigNode) throws Exception {

		removeAll();

		Vector<String> names = new Vector<String>();
		names.add(StringUtils.EMPTY);
		for (int i = 0; i < allConfigNode.size(); i++) {
			Node node = allConfigNode.getNode(i);
			String attribute = node.getAttribute("name");
			if ("Configuration".equals(node.getTag()) && attribute != null)
				names.add(attribute);
		}

		for (int i = 0; i < allConfigNode.size(); i++) {
			JTextArea textArea = new JTextArea();
			textArea.setBorder(BorderFactory.createRaisedBevelBorder());
			textArea.setTabSize(2);

			Node node = allConfigNode.getNode(i);
			String name = node.getAttribute("name");

			if ("Comment".equals(node.getTag())) {
				continue;

			} else {
				JPanel panel = new JPanel(new BorderLayout());

				StringBuffer text = new StringBuffer();
				for (int j = 0; j < node.size(); j++) {
					text.append(node.getNode(j).getXMLText());
				}
				textArea.setText(text.toString());

				JPanel panel2 = new JPanel();
				JCheckBox checkBox = new JCheckBox(" Configuration name:");
				Node configNode = aeFrame.getWorkspace().getConfigNode();
				boolean equals = StringUtils.equals(name, configNode.getAttribute("name"));
				checkBox.setSelected(equals);
				checkBox.setEnabled(false);
				panel2.add(checkBox);

				JTextField textField = new JTextField(name);
				textField.setOpaque(false);
				textField.setEditable(false);
				textField.setBorder(BorderFactory.createEmptyBorder());
				JPanel panel3 = new JPanel(new BorderLayout(4, 4));
				panel3.add(panel2, BorderLayout.WEST);
				panel3.add(textField);

				panel2 = new JPanel();
				panel2.add(new JLabel("Base configuration:"));
				JComboBox<String> textField2 = new JComboBox<>(names);

				String base = node.getAttribute("base");
				textField2.setSelectedItem(StringUtils.defaultString(base, StringUtils.EMPTY));
				panel2.add(textField2);
				textField2.setEnabled(false);

				panel3.add(panel2, BorderLayout.EAST);

				panel.add(panel3, BorderLayout.NORTH);
				panel.add(textArea);
				add(panel);
			}
		}
	}

}
