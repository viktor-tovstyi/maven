package com.nave.anteater.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.BevelBorder;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.sling.commons.json.JSONObject;

import com.nave.anteater.AEFrame;
import com.nave.anteater.TaskEditor;
import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.AEUtils;
import com.nave.anteater.util.xml.easyparser.EasyParser;
import com.nave.anteater.util.xml.easyparser.Node;
import com.nave.anteater.view.ListLoggPanel.LogRecord;

public class TextLoggPanel extends LoggPanel implements ActionListener {

	private JTextArea fLogTextArea;

	private JPanel toolBar = new JPanel(new BorderLayout());
	private JTextField statusLineLable = new JTextField("");
	private JButton emailMaskButton = new JButton(AEFrame.getIcon("email-mask.png"));

	List<String> supportedTypes = new ArrayList<>();
	{
		supportedTypes.add("txt");
		supportedTypes.add("html");
		supportedTypes.add("xml");
		supportedTypes.add("json");
		supportedTypes.add("~json");
		supportedTypes.add("url");
		supportedTypes.add("path");
		supportedTypes.add("uri");
	}

	private JPanel theLogPanel = new JPanel(new BorderLayout());

	private JTextField fFindText = new JTextField(12);

	private JCheckBox fLogToEnd = new JCheckBox("auto scrolling.");

	private JScrollPane fLogScrollPanel;

	JButton theFormatButton = new JButton(AEFrame.getIcon("format.png"));

	private TaskEditor fTaskEditor;

	private JPanel fPanel;

	private TaskProcessor processor;

	private FileDialog theFileDialog;

	private JComboBox<String> propertiesNames = new JComboBox<String>();

	private JComboBox<String> typeBox = new JComboBox<String>(
			supportedTypes.toArray(new String[supportedTypes.size()]));

	private Object originData;

	public TextLoggPanel() {
		this(null, "");
	}

	public TextLoggPanel(TaskEditor aTaskEditor, String aName) {
		super(aName);

		fTaskEditor = aTaskEditor;

		fLogTextArea = new JTextArea();
		fLogTextArea.setFont(new Font("Consolar", Font.PLAIN, 12));

		fLogTextArea.setDoubleBuffered(true);
		fLogTextArea.setEditable(true);
		fLogTextArea.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				printStatusLine();
			}
		});

		fLogTextArea.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				printStatusLine();
			}
		});

		fLogScrollPanel = new JScrollPane(fLogTextArea);
		theLogPanel.add(fLogScrollPanel, BorderLayout.CENTER);

		theFormatButton.setToolTipText("Pretty print");

		JPanel bar = new JPanel();
		if (fTaskEditor != null) {
			JButton theClearButton = new JButton(AEFrame.getIcon("clean.png"));
			theClearButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					setText("");
					printStatusLine();
				}
			});
			bar.add(theClearButton);
		} else {
			theFormatButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					SwingUtilities.invokeLater(() -> {
						format();
					});
				}
			});

			bar.add(propertiesNames);
			bar.add(typeBox);
			bar.add(theFormatButton);

			JButton button = new JButton(AEFrame.getIcon("placeholder.png"));
			button.setToolTipText("Placeholder parsing");

			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String text = fLogTextArea.getText();
					try {
						int caretPosition = fLogTextArea.getCaretPosition();
						String replaceProperties = processor.replaceProperties(text);
						replaceProperties = replaceProperties.replaceAll("<br/>", "\n");
						// replaceProperties =
						// EasyParser.replaseReferense(replaceProperties);
						setText(replaceProperties);
						printStatusLine();
						fLogTextArea.setCaretPosition(0);
						if (caretPosition < replaceProperties.length())
							fLogTextArea.setCaretPosition(caretPosition);
					} catch (Exception e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(getPanel()),
								"$...{} replacer failed.");
					}
				}
			});

			propertiesNames.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					print();
				}
			});

			bar.add(button);

			button = new JButton(AEFrame.getIcon("open.png"));
			button.setToolTipText("Open in defaulf editor");

			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						String selectedItem = (String) typeBox.getSelectedItem();
						String text = fLogTextArea.getText();
						openFile(text, selectedItem);
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(getPanel()),
								"File opening failed.");
					}
				}

			});
			bar.add(button);

			button = new JButton(AEFrame.getIcon("save.png"));
			button.setToolTipText("Save to file");

			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						String text = fLogTextArea.getText();
						if (theFileDialog == null)
							theFileDialog = new FileDialog(JOptionPane.getRootFrame(), "Save log record.",
									FileDialog.SAVE);
						theFileDialog.setFile(StringUtils.left(text.trim(), 12) + ".txt");
						theFileDialog.setVisible(true);
						File theFile = new File(theFileDialog.getDirectory() + theFileDialog.getFile());
						FileOutputStream theFileOutputStream = new FileOutputStream(theFile);
						theFileOutputStream.write(text.getBytes("UTF-8"));
						theFileOutputStream.close();
					} catch (Exception e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(getPanel()),
								"File is not saved.");
					}
				}
			});
			bar.add(button);

			emailMaskButton.setToolTipText("Email address masking");

			emailMaskButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String text = fLogTextArea.getText();
					String atSignSymbol = "@";
					String[] terminator = new String[] { " ", "\"", "'", "\t", "\n", "\r" };
					int notMaskLength = 5;

					if (StringUtils.indexOf(text, atSignSymbol) > 0) {
						String[] split = StringUtils.split(text, atSignSymbol);
						for (int i = 0; i < split.length; i++) {
							String line = split[i];
							int index = StringUtils.lastIndexOfAny(line, terminator);
							int maskLength = line.length() - index - notMaskLength;
							split[i] = StringUtils.substring(line, 0, index + notMaskLength)
									+ StringUtils.repeat("*", maskLength);
							if (i > 0) {
								line = split[i];
								index = StringUtils.indexOfAny(line, terminator) - notMaskLength;
								split[i] = StringUtils.repeat("*", index)
										+ StringUtils.substring(line, index, line.length());
							}
						}
						String maskedText = StringUtils.join(split, atSignSymbol);
						setText(maskedText);
						printStatusLine();
						fLogTextArea.setCaretPosition(0);
					}
				}
			});
			bar.add(emailMaskButton);
		}
		
		JButton button = new JButton(AEFrame.getIcon("unescape.png"));
		button.setToolTipText("XML Unescape");

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String text = fLogTextArea.getText();
				text  = StringEscapeUtils.unescapeXml(text).trim();
				text  = text.replace("\\n", "\n");
				text  = text.replace("\\\"", "\"");
				setText(text);
			}

		});
		bar.add(button);

		bar.add(new JLabel("Find:"));
		bar.add(fFindText);

		JButton theFindButton = new JButton("Find");
		theFindButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String text = fFindText.getText();
				try {
					findText(text);

				} catch (Exception e1) {
					JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(theLogPanel),
							"Replesing properties is failed.");
				}
			}
		});

		fFindText.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyChar() == KeyEvent.VK_ESCAPE) {
					fFindText.setText("");
					findText("");
				}
			}
		});

		theFindButton.setEnabled(true);
		bar.add(theFindButton);

		if (fTaskEditor != null) {
			JButton theCloseButton = new JButton(AEFrame.getIcon("close.png"));
			theCloseButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					fTaskEditor.removeActivePresentationPanel();
				}
			});

			bar.add(theCloseButton);
		}

		theLogPanel.add(toolBar, BorderLayout.NORTH);

		JPanel panel4 = new JPanel();
		if (fTaskEditor != null)
			panel4.add(fLogToEnd);

		statusLineLable.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		statusLineLable.setEditable(false);
		theLogPanel.add(statusLineLable, BorderLayout.SOUTH);

		if (fTaskEditor != null) {
			fLogToEnd.setSelected(false); // "true".equals(fTaskEditor.getDefaultUserConfiguration(".Edit.LogToEnd",
			// "false")));
			fLogToEnd.addActionListener(this);
		}

		fLogTextArea.setEditable(true);
		if (fTaskEditor != null)
			fLogTextArea.addKeyListener(fTaskEditor);

		fPanel = theLogPanel;

		if (fTaskEditor != null)
			fTaskEditor.outputPaneAdd(this);

		toolBar.add(bar, BorderLayout.CENTER);
	}

	protected void printStatusLine() {
		String text = fLogTextArea.getText();
		int count = countLines(text);

		int selectedCount = 0;
		String selectedText = fLogTextArea.getSelectedText();
		if (selectedText != null) {
			selectedCount = countLines(selectedText);
		}

		emailMaskButton.setEnabled(text.indexOf('@') >= 0);

		statusLineLable.setText("Lines: " + count + (selectedCount > 0 ? "; Selected lines: " + selectedCount : ""));
	}

	private int countLines(String text) {
		char someChar = '\n';
		int count = 0;

		if (text != null) {
			if (text.length() > 0) {
				count = 1;
			}

			for (int i = 0; i < text.length(); i++) {
				if (text.charAt(i) == someChar) {
					count++;
				}
			}
		}
		return count;
	}

	public void actionPerformed(ActionEvent e) {

		if (e != null && e.getSource() == fLogToEnd) {
			// fTaskEditor.setDefaultUserConfiguration(".Edit.LogToEnd",
			// fLogToEnd.isSelected() ? "true" : "false");
			return;
		}

	}

	public void info(Object o, TaskProcessor processor) {
		this.processor = processor;
		setType(o);
		if (fTaskEditor == null)
			appendText(o);
	}

	public void format() {
		Thread thread = new Thread(() -> {
			String text = fLogTextArea.getText();
			String type = StringUtils.upperCase(getType());

			switch (type) {
			case "XML":
				try {

					int indexOf2 = text.indexOf("?>");
					if (indexOf2 < 0)
						indexOf2 = 0;
					int indexOf = text.indexOf('<', indexOf2);
					int lastIndexOf = text.lastIndexOf(">") + 1;

					Node object = new EasyParser().getObject(text.substring(indexOf, lastIndexOf));
					setText(text.substring(0, indexOf) + (indexOf > 0 ? "\n" : "") + object.getXMLText()
							+ text.substring(lastIndexOf));
					printStatusLine();
					fLogTextArea.setCaretPosition(0);
				} catch (Exception e1) {
					setText(text);
					printStatusLine();
					fLogTextArea.setCaretPosition(0);
					JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(getPanel()),
							"XML formating failed.");
				}
				break;
			case "JSON":
				try {
					String jsonBody = StringUtils.trim(text);
					setText(new JSONObject(jsonBody).toString(4));
					printStatusLine();
					fLogTextArea.setCaretPosition(0);

				} catch (Exception e1) {
					setText(text);
					printStatusLine();
					fLogTextArea.setCaretPosition(0);
					JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(getPanel()),
							"JSON formating failed.");
				}
				break;
			case "~JSON":
				try {
					setText(AEUtils.format(text));
					printStatusLine();
					fLogTextArea.setCaretPosition(0);
				} catch (Exception e1) {
					setText(text);
					printStatusLine();
					fLogTextArea.setCaretPosition(0);
					JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(getPanel()),
							"JSON formating failed.");
				}
				break;
			case "URL":
				try {
					StringBuilder formatedText = new StringBuilder();
					String trim = text.replace(" ", "");
					trim = trim.replace("\n", "");
					URL url = new URL(trim);
					formatedText.append(url.getProtocol() + "://");
					formatedText.append(url.getHost());
					if (url.getPort() > 0)
						formatedText.append(":" + url.getPort());
					formatedText.append(url.getPath());

					List<NameValuePair> parse = URLEncodedUtils.parse(url.toURI(), "UTF-8");
					if (parse.size() > 0) {
						formatedText.append("\n");
						String delim = "?";
						for (NameValuePair nameValuePair : parse) {
							formatedText
									.append(delim + nameValuePair.getName() + "=" + nameValuePair.getValue() + "\n");
							delim = "&";
						}
					}
					setText(formatedText.toString());
					printStatusLine();
					fLogTextArea.setCaretPosition(0);
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(getPanel()),
							"URI transformation failed.\n" + e1.getMessage());
				}
				break;
			}
		});
		thread.start();
	}

	private void setText(String text) {
		fLogTextArea.setText(text.trim());
	}

	protected void setType(Object o) {
		String type = StringUtils.defaultIfBlank(((LogRecord) o).getType(), "txt");

		if (o instanceof LogRecord) {
			if (((LogRecord) o).getMessage() instanceof String) {

				if (StringUtils.startsWith((String) ((LogRecord) o).getMessage(), "<?xml")) {
					type = "xml";
				}

				type = StringUtils.defaultIfEmpty(type, supportedTypes.get(0));
				if (!supportedTypes.contains(type.toLowerCase())) {
					supportedTypes.add(type);
					this.typeBox.addItem(type);
				}
				this.typeBox.setSelectedItem(type);

			} else if (StringUtils.isNotBlank(type)) {
				if (StringUtils.startsWith(ObjectUtils.toString(o), "<?xml")) {
					type = "xml";
					this.typeBox.setSelectedItem(type);
				} else {
					this.typeBox.setSelectedItem(type);
					if (!StringUtils.equals(this.typeBox.getSelectedItem().toString(), type)) {
						this.typeBox.addItem(type);
					}
					this.typeBox.setSelectedItem(type);
				}
			}
		}
	}

	private void setPropertiesList(Set keySet) {
		for (Object object : keySet) {
			String key = (String) object;
			if (StringUtils.isNotBlank(key)) {
				propertiesNames.addItem(key);
			}
		}
		propertiesNames.setVisible(true);
	}

	private void cleanPropertiesList() {
		propertiesNames.removeAllItems();
		propertiesNames.setVisible(false);
	}

	public void debug(Object o) {
		setType(o);
		if (o instanceof Throwable) {
			StringWriter theStringWriter = new StringWriter();
			((Throwable) o).printStackTrace(new PrintWriter(theStringWriter));
			if (fTaskEditor == null)
				appendText(theStringWriter.toString());
		} else {
			if (fTaskEditor == null)
				appendText(o);
		}
	}

	public void debug(Object o, Throwable aThrowable) {
		setType(o);
		if (fTaskEditor == null) {
			appendText(o);

			StringWriter theStringWriter = new StringWriter();
			aThrowable.printStackTrace(new PrintWriter(theStringWriter));
			appendText(theStringWriter.toString());
		}

	}

	public void error(Object o) {
		setType(o);
		if (fTaskEditor == null)
			appendText(o);
	}

	public void error(Object o, Throwable aThrowable) {
		setType(o);
		if (fTaskEditor == null) {
			appendText(o);
			StringWriter theStringWriter = new StringWriter();
			aThrowable.printStackTrace(new PrintWriter(theStringWriter));
			appendText(theStringWriter.toString());
		}
	}

	public void warn(Object o) {
		setType(o);
		if (fTaskEditor == null)
			appendText(o);
	}

	synchronized private void appendText(Object o) {
		this.originData = o;
		cleanPropertiesList();

		LogRecord record = (LogRecord) o;
		String type = record.getType();

		Object message = record.getMessage();
		if (message instanceof Map && !"json".equals(type)) {
			Map propertiesData = (Map) ((LogRecord) o).getMessage();
			setPropertiesList(propertiesData.keySet());
		}

		print();
	}

	private void print() {
		setText("");
		if (originData instanceof LogRecord) {
			LogRecord rec = (LogRecord) originData;
			Object data = rec.getMessage();

			String type = getType();
			if (data instanceof Map && "map".equals(type)) {
				data = ((Map) data).get(propertiesNames.getSelectedItem());
			}

			String text;

			if (data instanceof byte[]) {
				try {
					text = new String((byte[]) data, "UTF-8");
				} catch (UnsupportedEncodingException e) {
					throw new IllegalArgumentException(e);
				}
			} else if (data != null && data.getClass().isArray()) {
				Object[] array = (Object[]) data;
				text = ArrayUtils.toString(array);

			} else if (data != null && data instanceof List) {
				text = StringUtils.join((List) data, "\n");

			} else if ("json".equals(type)) {
				if (data instanceof Map) {
					text = new JSONObject((Map) data).toString();
				} else {
					text = ObjectUtils.toString(data, "<null>");
				}
			} else {
				text = ObjectUtils.toString(data, "<null>");
			}

			fLogTextArea.setText(text);

		} else {

			fLogTextArea.setText(ObjectUtils.toString(originData));
		}
		int lastIndexOf = fLogTextArea.getText().lastIndexOf('\n');

		if (fTaskEditor != null && fLogToEnd.isSelected()) {
			if (lastIndexOf > 0)
				fLogTextArea.setCaretPosition(lastIndexOf + 1);
		}

		fLogTextArea.setCaretPosition(0);
		printStatusLine();
	}

	public String getType() {
		return (String) TextLoggPanel.this.typeBox.getSelectedItem();
	}

	public void warn(Object o, Throwable aThrowable) {
		setType(o);
		if (fTaskEditor == null)
			appendText(o);
		StringWriter theStringWriter = new StringWriter();
		aThrowable.printStackTrace(new PrintWriter(theStringWriter));
		appendText(theStringWriter.toString());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.maxbill.maxtest.LoggPaneli#getPanel()
	 */
	public JPanel getPanel() {
		return fPanel;
	}

	public void findText(String text) {
		int indexOf = StringUtils.indexOfIgnoreCase(fLogTextArea.getText(), text, fLogTextArea.getCaretPosition() + 1);
		if (indexOf > 0) {
			fLogTextArea.setCaretPosition(indexOf);
			fLogTextArea.setSelectionStart(indexOf);
			fLogTextArea.setSelectionEnd(indexOf + text.length());
			fLogTextArea.requestFocus(true);
		} else
			JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(theLogPanel),
					"Text: \"" + text + "\" is not found.");
	}

	public void setEnabled(boolean enabled) {
		if (enabled == false)
			fLogTextArea.setBackground(Color.lightGray);
		else
			fLogTextArea.setBackground(Color.white);
	}

	public void clear() {
		setText("");
		printStatusLine();
	}

	public JComponent getLogTextArea() {
		return fLogTextArea;
	}

	public static void openFile(Object originData, String type) throws IOException {

		switch (StringUtils.upperCase(type)) {
		case "URL":
			try {
				String string = ObjectUtils.toString(originData, "");
				URL url = new URL(string);
				URI uri = url.toURI();
				openWebpage(uri);
			} catch (URISyntaxException e) {
				new IOException(e);
			}
			break;

		case "URI":
			try {
				openWebpage(new URI(ObjectUtils.toString(originData, "")));
			} catch (URISyntaxException e) {
				new IOException(e);
			}
			break;

		case "PATH":
			Desktop.getDesktop().open(new File(ObjectUtils.toString(originData, "").trim()));
			break;

		default:
			if (StringUtils.startsWith(type, "~")) {
				type = StringUtils.substringAfter(type, "~");
			}
			File file = File.createTempFile("anteater", "." + StringUtils.defaultString(type, "txt"));
			byte[] data;
			if (originData instanceof LogRecord) {
				Object logdata = ((LogRecord) originData).getMessage();
				if (logdata instanceof byte[]) {
					data = (byte[]) logdata;
				} else {
					data = ((LogRecord) originData).toString().getBytes();
				}
			} else {
				data = ObjectUtils.toString(originData).getBytes();
			}

			FileOutputStream output = new FileOutputStream(file);
			IOUtils.write(data, output);
			output.flush();
			Desktop.getDesktop().open(file);
			output.close();
		}
	}

	public static void openWebpage(URI uri) {
		Desktop desktop = Desktop.isDesktopSupported() ? Desktop.getDesktop() : null;
		if (desktop != null && desktop.isSupported(Desktop.Action.BROWSE)) {
			try {
				desktop.browse(uri);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void addButton(AbstractButton onTop) {
		toolBar.add(onTop, BorderLayout.EAST);
	}
}