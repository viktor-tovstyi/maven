package com.nave.anteater;

import java.awt.Color;

import javax.swing.JCheckBox;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class CheckPointBox extends JCheckBox implements ChangeListener {

	public static final String CHECKPOINT_PREFIX = "CheckPoint";

	private static final long serialVersionUID = -3670107773808535274L;

	private static final String ALWAYS_SHOW_NOTIFICATIONS = "Important dialog";

	private String name;

	private InputDialogType type;

	private Color bgColor;

	public CheckPointBox(String propertyName, InputDialogType type) {
		super(ALWAYS_SHOW_NOTIFICATIONS);
		this.type = type;
		name = propertyName;
		setEnabled(true);
		addChangeListener(this);

		Boolean valueOf = getCheckPointFlag(type, name);
		if (valueOf != null) {
			setSelected(valueOf);
		}else {
			setSelected(true);
		}

		applyBackgroungColor();
	}

	public void saveCheckpointFlag() {
		boolean selected = isSelected();
		setCheckPointFlag(type, name, selected);
	}

	private void applyBackgroungColor() {
		if (this.bgColor == null) {
			bgColor = getBackground();
		}
		setBackground(isSelected() ? new Color(0xe4696a) : bgColor);
	}

	public static Boolean getCheckPointFlag(InputDialogType type, String name) {

		CheckpointsDialog instance = CheckpointsDialog.getInstance();
		if (instance != null) {
			instance.updated(type, name);
		}

		AEWorkspace aeWorkspace = AEWorkspace.getInstance();
		String propertyName = CHECKPOINT_PREFIX + "." + type + "." + name;
		String checkPoint = aeWorkspace.getDefaultUserConfiguration(propertyName, null);

		Boolean valueOf = checkPoint == null ? null : Boolean.valueOf(checkPoint);
		return valueOf;
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		saveCheckpointFlag();
		applyBackgroungColor();
	}

	public static void setCheckPointFlag(InputDialogType type, String name, boolean selected) {
		AEWorkspace instance = AEWorkspace.getInstance();
		String propertyName = CHECKPOINT_PREFIX + "." + type + "." + name;
		String value = Boolean.toString(selected);
		instance.setDefaultUserConfiguration(propertyName, value);

	}

}
