package com.nave.anteater;

import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.Icon;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.AbstractTableModel;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;

import com.nave.anteater.AEFrame.UIChoiceTaskRunner;
import com.nave.anteater.processor.MessageHandler;
import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.UIUtils;
import com.nave.anteater.util.xml.easyparser.Node;

public class DesktopWorkspace extends AEWorkspace {

	private static final String CONFIG = ".config";
	private AEFrame frame;

	public DesktopWorkspace(AEFrame frame) {
		this.frame = frame;
	}

	protected String selectConfiguration(String[] aPossibleValues) {
		String theValue;

		String theDefaultConfiguration = aPossibleValues[0];
		theDefaultConfiguration = AEWorkspace.getInstance().getDefaultUserConfiguration(".defaultConfiguration",
				theDefaultConfiguration);

		frame.setAlwaysOnTop(true);
		Icon fWelcomeLogo = AEFrame.getIcon(AEFrame.LOGO_JPG);
		theValue = (String) JOptionPane.showInputDialog(frame, "Environments:",
				"Giant anteater searches for a meal ...", JOptionPane.QUESTION_MESSAGE, fWelcomeLogo, aPossibleValues,
				theDefaultConfiguration);
		frame.setAlwaysOnTop(false);
		if (theValue == null)
			throw new IllegalArgumentException("Configuration is not selected.");

		AEWorkspace.getInstance().setDefaultUserConfiguration(".defaultConfiguration", theValue);

		return theValue;
	}

	@Override
	public MultiTaskRunDialog tasksChoice(MultiTaskRunDialog name, String[] list, boolean exceptionIgnoreFlag,
			Object setup, TaskProcessor taskProcessor, boolean visible) {
		UIChoiceTaskRunner choiceTaskRunner = frame.getChoiceTaskRunner(name, taskProcessor, setup);
		MultiTaskRunDialog tasksChoice = super.tasksChoice(choiceTaskRunner, list, exceptionIgnoreFlag, setup,
				taskProcessor, visible);
		return tasksChoice;
	}

	public void startTaskNotify(TestRunner task) {
		TaskEditor editor = (TaskEditor) task;
		super.startTaskNotify(editor);
		frame.startTaskNotify(editor);
	}

	@Override
	public void progressValue(int i, int length, boolean success) {
		frame.progressValue(i, length, success);
	}

	@Override
	public void progressText(String text) {
		super.progressText(text);
	}

	@Override
	public String inputValue(String aDesc, String aName, String aValue, ILogger log, String type, boolean notifyMe) {
		return frame.inputValue(aDesc, aName, aValue, type, notifyMe);
	}

	public void setConsoleDefaultInput(boolean defaultMode) {
		frame.setConsoleDefaultInput(defaultMode);
	}

	public boolean isConsoleDefaultInput(String varName) {
		boolean consoleDefaultInput = frame.isConsoleDefaultInput();
		if (varName != null && consoleDefaultInput) {
			Boolean checkPointFlag = false;
			InputDialogType[] values = InputDialogType.values();
			for (InputDialogType inputDialogType : values) {
				checkPointFlag = CheckPointBox.getCheckPointFlag(inputDialogType, varName);
				if (checkPointFlag != null) {
					break;
				}
			}
			consoleDefaultInput = checkPointFlag != null && !checkPointFlag;
		}
		return consoleDefaultInput;
	}

	protected TestRunner createTestRunner(String name) {
		TaskEditor editTask = frame.editTask(name);
		return editTask;
	}

	public String inputSelectChoice(String aNameDialog, String[] aValues, String aDefaultValue,
			TaskProcessor taskProcessor, boolean notifyMe) {
		return frame.inputSelectChoice(aNameDialog, aValues, aDefaultValue, taskProcessor, notifyMe);
	}

	public String inputFile(String name, File aDefaultFile, ILogger log, TaskProcessor taskProcessor) {
		String theResult = null;

		String defaultUserConfiguration = getDefaultUserConfiguration(".inputFile",
				aDefaultFile == null ? null : aDefaultFile.getAbsolutePath());
		if (defaultUserConfiguration != null)
			aDefaultFile = new File(defaultUserConfiguration);

		theResult = defaultUserConfiguration;

		if (defaultUserConfiguration == null || isConsoleDefaultInput(name) == false) {

			JFileChooser chooser = new JFileChooser();
			if (aDefaultFile != null) {
				if (aDefaultFile.getPath() != null && "null".equals(aDefaultFile.getPath()) == false) {
					if (aDefaultFile.isDirectory()) {
						chooser.setCurrentDirectory(aDefaultFile.getParentFile());

					} else {
						chooser.setCurrentDirectory(aDefaultFile.getParentFile());
						chooser.setSelectedFile(aDefaultFile);
					}
				}
			}

			chooser.setDialogTitle("Open file or directory");
			chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			//
			// disable the "All files" option.
			//
			chooser.setAcceptAllFileFilterUsed(false);
			//
			int showOpenDialog = chooser.showOpenDialog(JOptionPane.getRootFrame());
			if (showOpenDialog == JFileChooser.APPROVE_OPTION) {
				theResult = new File(chooser.getCurrentDirectory(), chooser.getSelectedFile().getName())
						.getAbsolutePath();
				setDefaultUserConfiguration(".inputFile", theResult);
			} else if (showOpenDialog == JFileChooser.CANCEL_OPTION) {
				theResult = null;
				setDefaultUserConfiguration(".inputFile", theResult);
			} else {
				taskProcessor.stop();
				theResult = null;
			}

		}

		CheckPointBox.setCheckPointFlag(InputDialogType.FILE, name, (boolean) ObjectUtils
				.defaultIfNull(CheckPointBox.getCheckPointFlag(InputDialogType.FILE, name), false));

		return theResult;
	}

	@Override
	public boolean confirmation(TaskProcessor unit, String description, String message, boolean notifyMe) throws Exception {

		String title = StringUtils.defaultIfEmpty("Confirmation", description);
		
		JOptionPane pane = new JOptionPane(message, JOptionPane.WARNING_MESSAGE, JOptionPane.YES_NO_OPTION);
		JDialog dialog = pane.createDialog(frame, title);
		dialog.setModal(false);

		if (notifyMe) {
			frame.getSoundManager().play();
		}

		dialog.setVisible(true);
		UIUtils.applyPreferedView(dialog, title);
		dialog.pack();

		Object value = null;
		do {
			value = pane.getValue();
			Thread.sleep(100);
		} while (value == "uninitializedValue");

		if (notifyMe) {
			SoundManager.stop();
		}

		UIUtils.saveDialogPreferedView(dialog, title);
		dialog.dispose();

		if (value == null) {
			value = -1;
		}

		int confirm = (int) value;
		if (confirm < 0) {
			unit.stop();
		}
		return confirm == JOptionPane.YES_OPTION;
	}

	@Override
	public MessageHandler message(TaskProcessor taskProcessor, String description, String message, boolean notifyMe) {

		String title = StringUtils.defaultIfEmpty("Message", description);
		
		JOptionPane pane = new JOptionPane(message, JOptionPane.INFORMATION_MESSAGE);
		JDialog dialog = pane.createDialog(frame, title);
		dialog.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosed(WindowEvent var1) {
				UIUtils.saveDialogPreferedView(dialog, title);
				SoundManager.stop();
			}
		});
		dialog.setModal(false);
		UIUtils.applyPreferedView(dialog, title);
		dialog.pack();

		if (notifyMe) {
			frame.getSoundManager().play();
		}

		dialog.setVisible(true);

		return new MessageHandler() {
			@Override
			public void close() {
				dialog.dispose();
			}
		};
	}

	public void inputDataTable(TemplateProcessor unit, Node aTableNode, boolean notifyMe) throws IOException {
		Node[] theVariablesNodes = aTableNode.getNodes("var");
		String theLine = null;

		String fileName = aTableNode.getAttribute("file");
		if (unit != null)
			fileName = unit.replaceProperties(aTableNode.getAttribute("file"));

		if (fileName != null) {
			File file = unit.getFile(fileName);
			if (file.exists()) {
				BufferedReader theFileReader = new BufferedReader(new FileReader(file));
				while ((theLine = theFileReader.readLine()) != null) {
					theLine = theLine.trim();
					if (theLine.length() == 0) {
						continue;
					}
					if (theLine.charAt(0) == '#') {
						continue;
					}
					int thePbrk = theLine.indexOf('=');

					String theName = theLine.substring(0, thePbrk);
					String theValue = theLine.substring(thePbrk + 1);

					Node theNode = new Node("var");
					theNode.setAttribute("name", theName);
					theNode.setAttribute("value", theValue);

					for (Node node : theVariablesNodes) {
						if (node.getAttribute("name").equalsIgnoreCase(theName)) {
							node.setAttribute("value", theValue);
						}
					}

				}
				theFileReader.close();
			}
		}

		String title = aTableNode.getAttribute("name");
		AbstractTableModel dataModel = new InputTableModel(unit, title, theVariablesNodes);

		JTable table = new JTable(dataModel);
		table.setRowHeight(20);
		JScrollPane scrollpane = new JScrollPane(table);
		CheckPointBox vip = new CheckPointBox(title, InputDialogType.MAP);

		if (isConsoleDefaultInput(title) == false || vip.isSelected()) {
			if (title == null)
				title = "";

			JPanel jPanel = new JPanel();
			jPanel.add(new JLabel(), BorderLayout.NORTH);
			jPanel.setLayout(new BorderLayout());
			jPanel.add(scrollpane, BorderLayout.CENTER);

			jPanel.add(vip, BorderLayout.SOUTH);

			if (notifyMe) {
				frame.getSoundManager().play();
			}

			int showConfirmDialog = OptionPane.showConfirmDialog(frame, jPanel, title, JOptionPane.WARNING_MESSAGE);

			if (notifyMe) {
				SoundManager.stop();
			}

			switch (showConfirmDialog) {
			case -1:
				unit.stop();
				break;
			case 2:
				unit.stop();
				break;
			}

		}

		FileWriter theFileReader = null;
		if (fileName != null) {
			File file = unit.getFile(fileName);
			file.getParentFile().mkdirs();
			theFileReader = new FileWriter(file);
		}

		for (int row = 0; row < dataModel.getRowCount(); row++) {

			String name = StringUtils.upperCase((String) dataModel.getValueAt(row, 0));
			Object valueAt = dataModel.getValueAt(row, -1);
			if (valueAt != null) {
				if (theFileReader != null) {
					theFileReader.write(name + "=" + valueAt + "\n");
				}
				String value = "";
				if (valueAt instanceof String) {
					value = (String) valueAt;
				} else if (valueAt instanceof String[]) {
					if (((String[]) valueAt).length > 0) {
						value = ((String[]) valueAt)[0];
					} else {
						value = "";
					}
				}
				AEWorkspace.getInstance().setDefaultUserConfiguration(".inputValue." + title + "." + name, value);
				unit.setVariableValue(name, value);
			}

		}
		if (theFileReader != null) {
			theFileReader.close();
		}

	}

	public String choiceValue(String s, String name, Object[] aPossibleValues, ILogger log, boolean notifyMe) {
		return frame.choiceValue(name, aPossibleValues, s, log, notifyMe);
	}

	protected String choicePriorityRecipeFolder(String text, String[] possibleValues) {
		String thePriorityFolder = (String) JOptionPane.showInputDialog(frame, text, "Conflict of the names",
				JOptionPane.INFORMATION_MESSAGE, null, possibleValues, possibleValues[0]);
		return thePriorityFolder;
	}

	protected File getConfigurationFile() {
		File configurationFile = super.getConfigurationFile();
		if (!configurationFile.exists()) {

			String config = AEWorkspace.getInstance().getDefaultUserConfiguration(CONFIG, null);
			if (config == null) {
				config = SystemUtils.getUserDir().getAbsolutePath();
			}

			JFileChooser chooser = new JFileChooser(config);
			chooser.setDialogTitle("Environments configuration.");
			chooser.addChoosableFileFilter(new FileFilter() {
				@Override
				public String getDescription() {
					return "Configuration";
				}

				@Override
				public boolean accept(File f) {
					return FilenameUtils.isExtension(f.getName(), "xml");
				}
			});
			chooser.setSelectedFile(new File(config));
			int returnVal = chooser.showOpenDialog(JOptionPane.getRootFrame());
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				File selectedFile = chooser.getSelectedFile();
				AEWorkspace.getInstance().setDefaultUserConfiguration(CONFIG, selectedFile.getAbsolutePath());
				return selectedFile;
			}
		}
		return configurationFile;
	}

	public void resetConfiguration() {
		super.resetConfiguration();
		frame.resetConfiguration();
	}
}
