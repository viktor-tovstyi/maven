package com.nave.anteater;

import java.awt.BorderLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;

import javax.swing.Icon;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.filechooser.FileFilter;
import javax.swing.table.AbstractTableModel;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.log4j.Logger;

import com.nave.anteater.AEFrame.UIChoiceTaskRunner;
import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.xml.easyparser.Node;

public class DesktopWorkspace extends AEWorkspace {

	private AEFrame frame;

	public DesktopWorkspace(AEFrame frame) {
		this.frame = frame;
	}

	protected String selectConfiguration(String[] aPossibleValues) {
		String theValue;

		String theDefaultConfiguration = aPossibleValues[0];
		theDefaultConfiguration = AEWorkspace.getInstance().getDefaultUserConfiguration(".defaultConfiguration",
				theDefaultConfiguration);

		Icon fWelcomeLogo = AEFrame.getIcon(AEFrame.LOGO_JPG);
		frame.setAlwaysOnTop(true);
		theValue = (String) JOptionPane.showInputDialog(frame, "Environments:",
				"Giant anteater searches for a meal ...", JOptionPane.QUESTION_MESSAGE, fWelcomeLogo, aPossibleValues,
				theDefaultConfiguration);
		frame.setAlwaysOnTop(false);
		if (theValue == null)
			throw new IllegalArgumentException("Configuration is not selected.");
		fWelcomeLogo = null;

		AEWorkspace.getInstance().setDefaultUserConfiguration(".defaultConfiguration", theValue);

		return theValue;
	}

	@Override
	public MultiTaskRunDialog tasksChoice(MultiTaskRunDialog name, String[] list, boolean exceptionIgnoreFlag,
			Object setup, TaskProcessor taskProcessor, boolean visible) {
		UIChoiceTaskRunner choiceTaskRunner = frame.getChoiceTaskRunner(name, taskProcessor, setup);
		MultiTaskRunDialog tasksChoice = super.tasksChoice(choiceTaskRunner, list, exceptionIgnoreFlag, setup,
				taskProcessor, visible);
		return tasksChoice;
	}

	public void startTaskNotify(TestRunner task) {
		TaskEditor editor = (TaskEditor) task;
		super.startTaskNotify(editor);
		frame.startTaskNotify(editor);
	}

	@Override
	public void progressValue(int i, int length, boolean success) {
		frame.progressValue(i, length, success);
	}

	@Override
	public void progressText(String text) {
		super.progressText(text);
	}

	@Override
	public String inputValue(String aDesc, String aName, String aValue, Logger log, String type) {
		return frame.inputValue(aDesc, aName, aValue, type);
	}

	public void setConsoleDefaultInput(boolean defaultMode) {
		frame.setConsoleDefaultInput(defaultMode);
	}

	public boolean isConsoleDefaultInput(String varName) {
		boolean consoleDefaultInput = frame.isConsoleDefaultInput();
		if (varName != null && consoleDefaultInput) {
			Boolean checkPointFlag = false;
			InputDialogType[] values = InputDialogType.values();
			for (InputDialogType inputDialogType : values) {
				checkPointFlag = CheckPointBox.getCheckPointFlag(inputDialogType, varName);
				if (checkPointFlag != null) {
					break;
				}
			}
			consoleDefaultInput = checkPointFlag != null && !checkPointFlag;
		}
		return consoleDefaultInput;
	}

	protected TestRunner createTestRunner(String name) {
		TaskEditor editTask = frame.editTask(name);
		return editTask;
	}

	public String inputSelectChoice(String aNameDialog, String[] aValues, String aDefaultValue,
			TaskProcessor taskProcessor) {
		return frame.inputSelectChoice(aNameDialog, aValues, aDefaultValue, taskProcessor);
	}

	public String inputFile(String name, File aDefaultFile, Logger log, TaskProcessor taskProcessor) {
		String theResult = null;

		String defaultUserConfiguration = getDefaultUserConfiguration(".inputFile",
				aDefaultFile == null ? null : aDefaultFile.getAbsolutePath());
		if (defaultUserConfiguration != null)
			aDefaultFile = new File(defaultUserConfiguration);

		theResult = defaultUserConfiguration;

		if (defaultUserConfiguration == null || isConsoleDefaultInput(name) == false) {

			JFileChooser chooser = new JFileChooser();
			if (aDefaultFile != null) {
				if (aDefaultFile.getPath() != null && "null".equals(aDefaultFile.getPath()) == false) {
					if (aDefaultFile.isDirectory()) {
						chooser.setCurrentDirectory(aDefaultFile.getParentFile());

					} else {
						chooser.setCurrentDirectory(aDefaultFile.getParentFile());
						chooser.setSelectedFile(aDefaultFile);
					}
				}
			}

			chooser.setDialogTitle("Open file or directory");
			chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			//
			// disable the "All files" option.
			//
			chooser.setAcceptAllFileFilterUsed(false);
			//
			int showOpenDialog = chooser.showOpenDialog(JOptionPane.getRootFrame());
			if (showOpenDialog == JFileChooser.APPROVE_OPTION) {
				theResult = new File(chooser.getCurrentDirectory(), chooser.getSelectedFile().getName())
						.getAbsolutePath();
				setDefaultUserConfiguration(".inputFile", theResult);
			} else if (showOpenDialog == JFileChooser.CANCEL_OPTION) {
				theResult = null;
				setDefaultUserConfiguration(".inputFile", theResult);
			} else {
				taskProcessor.stop();
				theResult = null;
			}

		}

		CheckPointBox.setCheckPointFlag(InputDialogType.FILE, name, (boolean) ObjectUtils
				.defaultIfNull(CheckPointBox.getCheckPointFlag(InputDialogType.FILE, name), false));

		return theResult;
	}

	@Override
	public boolean confirmation(TaskProcessor unit, String message) throws Exception {

		JOptionPane pane = new JOptionPane(message, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
		JDialog dialog = pane.createDialog(frame, "Confirmation");
		dialog.setModal(false);
		dialog.setVisible(true);

		Object value = null;
		do {
			value = pane.getValue();
			Thread.sleep(20);
		} while (value == "uninitializedValue");

		dialog.dispose();

		if (value == null) {
			value = -1;
		}

		int confirm = (int) value;
		if (confirm < 0) {
			unit.stop();
		}
		return confirm == JOptionPane.YES_OPTION;
	}

	public void inputDataTable(TemplateProcessor unit, Node aTableNode, Map<String, Object> aVariables,
			TaskProcessor taskProcessor) throws IOException {
		Node[] theVariablesNodes = aTableNode.getNodes("var");
		String theLine = null;

		String fileName = aTableNode.getAttribute("file");
		if (unit != null)
			fileName = unit.replaceProperties(aTableNode.getAttribute("file"));

		if (fileName != null) {
			File file = unit.getFile(fileName);
			if (file.exists()) {
				BufferedReader theFileReader = new BufferedReader(new FileReader(file));
				while ((theLine = theFileReader.readLine()) != null) {
					theLine = theLine.trim();
					if (theLine.length() == 0) {
						continue;
					}
					if (theLine.charAt(0) == '#') {
						continue;
					}
					int thePbrk = theLine.indexOf('=');

					String theName = theLine.substring(0, thePbrk);
					String theValue = theLine.substring(thePbrk + 1);

					Node theNode = new Node("var");
					theNode.setAttribute("name", theName);
					theNode.setAttribute("value", theValue);

					for (Node node : theVariablesNodes) {
						if (node.getAttribute("name").equalsIgnoreCase(theName)) {
							node.setAttribute("value", theValue);
						}
					}

				}
				theFileReader.close();
			}
		}

		String title = aTableNode.getAttribute("name");
		AbstractTableModel dataModel = new InputTableModel(unit, title, theVariablesNodes, aVariables);

		JTable table = new JTable(dataModel);
		table.setRowHeight(20);
		JScrollPane scrollpane = new JScrollPane(table);
		CheckPointBox vip = new CheckPointBox(title, frame, InputDialogType.MAP);

		if (isConsoleDefaultInput(null) == false || vip.isSelected()) {
			if (title == null)
				title = "";

			JPanel jPanel = new JPanel();
			jPanel.setLayout(new BorderLayout());
			jPanel.add(scrollpane, BorderLayout.CENTER);

			jPanel.add(vip, BorderLayout.SOUTH);

			int showConfirmDialog = OptionPane.showConfirmDialog(frame, jPanel, title, JOptionPane.WARNING_MESSAGE);
			switch (showConfirmDialog) {
			case -1:
				taskProcessor.stop();
				break;
			case 2:
				taskProcessor.stop();
				break;
			}

		}

		FileWriter theFileReader = null;
		if (fileName != null) {
			File file = unit.getFile(fileName);
			file.getParentFile().mkdirs();
			theFileReader = new FileWriter(file);
		}

		for (int row = 0; row < dataModel.getRowCount(); row++) {

			Object valueAt = dataModel.getValueAt(row, 1);
			if (valueAt != null) {
				Object name = dataModel.getValueAt(row, 0);
				if (theFileReader != null) {
					theFileReader.write(name + "=" + valueAt + "\n");
				}
				String value = "";
				if (valueAt instanceof String) {
					value = (String) valueAt;
				} else if (valueAt instanceof String[]) {
					if (((String[]) valueAt).length > 0) {
						value = ((String[]) valueAt)[0];
					} else {
						value = "";
					}
				}
				AEWorkspace.getInstance().setDefaultUserConfiguration(".inputValue." + title + "." + name, value);

				unit.setVariableValue((String) name, value);
			}

		}
		if (theFileReader != null) {
			theFileReader.close();
		}

	}

	public String choiceValue(String s, String name, Object[] aPossibleValues, Logger log) {
		return frame.choiceValue(name, aPossibleValues, s, log);
	}

	protected String choicePriorityRecipeFolder(String text, String[] possibleValues) {
		String thePriorityFolder = (String) JOptionPane.showInputDialog(frame, text, "Conflict of the names",
				JOptionPane.INFORMATION_MESSAGE, null, possibleValues, possibleValues[0]);
		return thePriorityFolder;
	}

	protected File getConfigurationFile() {
		File configurationFile = super.getConfigurationFile();
		if (!configurationFile.exists()) {

			String testconfig = AEWorkspace.getInstance().getDefaultUserConfiguration(".testconfig", null);
			if (testconfig == null) {
				testconfig = SystemUtils.getUserDir().getAbsolutePath();
			}

			JFileChooser chooser = new JFileChooser(testconfig);
			chooser.setDialogTitle("Environments configuration.");
			chooser.addChoosableFileFilter(new FileFilter() {
				@Override
				public String getDescription() {
					return "Configuration";
				}

				@Override
				public boolean accept(File f) {
					return FilenameUtils.isExtension(f.getName(), "xml");
				}
			});
			chooser.setSelectedFile(new File(testconfig));
			int returnVal = chooser.showOpenDialog(JOptionPane.getRootFrame());
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				File selectedFile = chooser.getSelectedFile();
				AEWorkspace.getInstance().setDefaultUserConfiguration(".testconfig", selectedFile.getAbsolutePath());
				return selectedFile;
			}
		}
		return configurationFile;
	}

	public void resetConfiguration() {
		super.resetConfiguration();
		frame.resetConfiguration();
	}
}
