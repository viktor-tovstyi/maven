package com.nave.anteater;

import java.awt.Component;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.Set;

import javax.swing.DefaultCellEditor;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.AbstractTableModel;

public class EnvPropertiesTable extends JTable {

	public class VarTableModel extends AbstractTableModel {

		private static final long serialVersionUID = 1L;
		private Object[][] fRows = new Object[0][0];

		public void refresh() {
			Set<String> tehKeySet = getWorkspace().getSystemVariables().keySet();
			fRows = new Object[tehKeySet.size()][2];
			int i = 0;

			String[] theKeys = tehKeySet.toArray(new String[tehKeySet.size()]);
			Arrays.sort(theKeys);

			for (String theName : theKeys) {
				Object theValue = getWorkspace().getSystemVariables().get(theName);
				fRows[i][0] = theName;
				fRows[i][1] = theValue;
				i++;
			}
		}

		public int getColumnCount() {
			return 2;
		}

		public int getRowCount() {
			return fRows.length;
		}

		public Object getValueAt(int row, int col) {
			Object string = null;
			try {
				string = fRows[row][col];
			} catch (RuntimeException e) {
				//
			}
			return string;
		}

		public boolean isCellEditable(int rowIndex, int columnIndex) {
			return columnIndex > 0;
		}

		@Override
		public Class<?> getColumnClass(int columnIndex) {
			int selectedRow = getSelectedRow();
			Object object = fRows[selectedRow < 0 ? 0 : selectedRow][columnIndex];
			Class<? extends Object> clazz = object.getClass();
			return clazz;
		}

		public void setValueAt(Object value, int rowIndex, int columnIndex) {
			if (columnIndex == 1) {
				String object = (String) fRows[rowIndex][0];
				String name = object.toUpperCase();

				getWorkspace().getSystemVariables().put(name, value);
				fRows[rowIndex][1] = value;
			}

			String theTestDir = (String) getWorkspace().getSystemVariables().get(AEWorkspace.TESTDIR_VAR_NAME);
			if (AEWorkspace.TESTDIR_VAR_NAME.equals(fRows[rowIndex][0]) && value.equals(theTestDir) == false) {
				getWorkspace().getTestsDescList().clear();
				try {
					frame.refreshTaskPath();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		public String getColumnName(int column) {
			if (column == 0) {
				return "Name";
			} else {
				return "Value";
			}
		}
	}

	private static final long serialVersionUID = 1L;
	private AEFrame frame;
	private VarTableModel dataModel;

	public EnvPropertiesTable(AEFrame aeFrame) {
		this.frame = aeFrame;
		setDefaultEditor(String.class, new DefaultCellEditor(new JTextField()));
		setDefaultEditor(Map.class, new ArrayCellEditor(frame));
		setDefaultEditor(ArrayList.class, new ArrayCellEditor(frame));
		setDefaultEditor(String[].class, new ArrayCellEditor(frame));
		getTableHeader().setReorderingAllowed(false);
		dataModel = new VarTableModel();
		setModel(dataModel);
	}

	public AEWorkspace getWorkspace() {
		return frame.getWorkspace();
	}

	public void refresh() {
		dataModel.refresh();
		invalidate();
	}
}
