package com.nave.anteater.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.UIDefaults;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumnModel;

import org.apache.commons.lang.ObjectUtils;
import org.apache.log4j.Logger;

import com.nave.anteater.AEFrame;
import com.nave.anteater.AELogRecord;
import com.nave.anteater.AEWorkspace;
import com.nave.anteater.TaskEditor;

public class ListLoggPanel extends LoggPanel implements ActionListener {

	private static final Font LOG_FONT = new Font("Monospaced", Font.PLAIN, 11);

	private LogList logList;

	private JComboBox<String> levelBox = new JComboBox<String>(new String[] { "Debug", "Info", "Warning", "Error" });

	private JTable fLogTextArea = new JTable(new AbstractTableModel() {
		private static final long serialVersionUID = 1L;

		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH.mm.ss,SSS");

		public int getColumnCount() {
			return 3;
		}

		public int getRowCount() {
			return logList.getSize();
		}

		public Object getValueAt(int rowIndex, int columnIndex) {

			String text = logList.get(rowIndex).toString();

			switch (columnIndex) {
			case 0:
				return simpleDateFormat.format(logList.get(rowIndex).time);
			case 1:
				if (logList.get(rowIndex).getSource() != null) {
					if (text != null) {
						return logList.get(rowIndex).getSource() + " = " + text;
					} else {
						return logList.get(rowIndex).getSource() + " is not defined.";
					}
				} else {
					return text;
				}
			case 2:
				return text == null ? 0 : text.length();
			}
			return null;
		}
	}) {

		private static final long serialVersionUID = 1L;

		@Override
		public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
			Component c = super.prepareRenderer(renderer, row, column);

			UIDefaults defaults = javax.swing.UIManager.getDefaults();
			Color background = defaults.getColor("List.background");
			Color foreground = defaults.getColor("List.foreground");

			c.setBackground(background);
			c.setForeground(foreground);

			LogRecord logRecord = logList.get(row);
			int level = logRecord.getLogLevel();

			switch (column) {
			case 0:
				long time = logRecord.getTime();
				double a = time / 500.0;
				double b = (Math.sin(a) + 1) / 2.0;
				Color bg = new Color((float) b, (float) b, (float) b);
				c.setBackground(bg);
				break;

			case 2:
				String text = logRecord.toString();
				if (text != null) {
					a = (double) (text.length()) / 100;
					if (a < 1) {
						a = 1;
					}
					b = Math.log(a) * 8;
					b = (100 - b) / 100;
					if (b < 0.4) {
						b = 0.4;
					}
					c.setBackground(new Color((float) b, (float) b, (float) b));
				} else {
					c.setBackground(Color.YELLOW);
				}
				break;
			}

			switch (level) {
			case 0:
				Color fgc = tuneColorByBackground(Color.RED);
				((JComponent) c).setForeground(fgc);
				break;
			case 1:
				fgc = tuneColorByBackground(Color.BLUE);
				((JComponent) c).setForeground(fgc);
				break;
			case 2:
				fgc = tuneColorByBackground(Color.GREEN);
				((JComponent) c).setForeground(fgc);
				break;
			case 3:
				break;
			default:

			}
			return c;
		}

		private Color tuneColorByBackground(Color fgc) {
			UIDefaults defaults = javax.swing.UIManager.getDefaults();
			Color background = defaults.getColor("List.background");

			int alpha = (int) (0.2126 * background.getRed() + 0.7152 * background.getGreen()
					+ 0.0722 * background.getBlue());

			if (alpha < 60) {
				int colorLevel = 140;
				fgc = new Color(fgc.getRed() == 0 ? colorLevel : fgc.getRed(),
						fgc.getGreen() == 0 ? colorLevel : fgc.getGreen(),
						fgc.getBlue() == 0 ? colorLevel : fgc.getBlue());
			}

			if (alpha > 200) {
				fgc = fgc.darker().darker();
			}
			return fgc;
		}

	};

	protected Logger log = Logger.getLogger(ListLoggPanel.class);

	private JPanel fPanel = new JPanel(new BorderLayout());

	private JCheckBox fLogToEnd = new JCheckBox("auto scrolling.");
	private JCheckBox fDeleteOldRec = new JCheckBox("show 50 last records.");

	private JScrollPane fLogScrollPanel = new JScrollPane();

	private TaskEditor fTaskEditor;

	private JLabel messageBar = new JLabel();

	private boolean mainLog;

	public ListLoggPanel(TaskEditor aTaskEditor, String aName) {
		this(aTaskEditor, aName, false);
	}

	public ListLoggPanel(TaskEditor aTaskEditor, String aName, boolean mainLog) {
		super(aName);
		this.mainLog = mainLog;
		log = Logger.getLogger(aName);

		String defaultUserConfiguration = AEWorkspace.getInstance().getDefaultUserConfiguration(".defaultLogLevel",
				"1");
		int defLevel = Integer.parseInt(defaultUserConfiguration);
		logList = new LogList(defLevel);

		logList.setLevel(defLevel);
		levelBox.setSelectedIndex(3 - defLevel);
		levelBox.setFont(LOG_FONT);

		fTaskEditor = aTaskEditor;

		fLogTextArea.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		fLogTextArea.setCellSelectionEnabled(true);
		fLogTextArea.setSelectionBackground(Color.YELLOW);
		ListSelectionModel selectionModel = fLogTextArea.getSelectionModel();
		selectionModel.addListSelectionListener(new ListSelectionListener() {

			public void valueChanged(ListSelectionEvent arg0) {
				if (fLogTextArea.getSelectedRows().length > 1) {
					int firstIndex = arg0.getFirstIndex();
					int lastIndex = arg0.getLastIndex();
					long time = logList.get(lastIndex).time.getTime() - logList.get(firstIndex).time.getTime();

					String string = "Selection time: ";
					if (time < 1000) {
						messageBar.setText(string + time + "ms.");
					} else if (time < 60000) {
						messageBar.setText(string + (time / 1000) + "s.");
					} else if (time < 360000) {
						messageBar.setText(string + (time / 60000) + "m.");
					} else {
						messageBar.setText(string + (time / 3600000) + "h.");
					}
				} else
					messageBar.setText("");
			}

		});

		fLogTextArea.addMouseListener(new MouseAdapter() {

			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 2) {
					ListSelectionModel selectionModel = fLogTextArea.getSelectionModel();
					int anchorSelectionIndex = selectionModel.getAnchorSelectionIndex();
					LogRecord text = logList.get(anchorSelectionIndex);
					if (!e.isControlDown()) {
						fTaskEditor.getFrame().showText(text, fTaskEditor.getTaskProcessor());
					} else {
						try {
							fTaskEditor.getFrame().out(text, fTaskEditor.getTaskProcessor());
							TextLoggPanel.openFile(text, text.getType());
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
				}
			}
		});

		TableColumnModel columnModel = fLogTextArea.getColumnModel();
		columnModel.getColumn(0).setMinWidth(0);
		columnModel.getColumn(0).setPreferredWidth(8);
		columnModel.getColumn(0).setMaxWidth(90);
		columnModel.getColumn(0).setHeaderValue("Time");
		columnModel.getColumn(1).setHeaderValue("Message");
		columnModel.getColumn(2).setHeaderValue("Size, B");
		columnModel.getColumn(2).setMinWidth(0);
		columnModel.getColumn(2).setMaxWidth(150);
		columnModel.getColumn(2).setPreferredWidth(8);

		fLogScrollPanel.getVerticalScrollBar().setDoubleBuffered(true);

		fPanel.add(fLogScrollPanel, BorderLayout.CENTER);

		JPanel theFindPanel = new JPanel();

		JLabel comp = new JLabel("Level:");
		comp.setFont(LOG_FONT);
		theFindPanel.add(comp);
		levelBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int logLevel = 3 - levelBox.getSelectedIndex();
				AEWorkspace.getInstance().setDefaultUserConfiguration(".defaultLogLevel", Integer.toString(logLevel));
				logList.setLevel(logLevel);
				fLogTextArea.invalidate();
				fLogTextArea.repaint();
				fLogTextArea.revalidate();
				fLogScrollPanel.invalidate();
				fLogScrollPanel.repaint();
			}
		});
		theFindPanel.add(levelBox);

		JButton theClearButton = new JButton(AEFrame.getIcon("clean.png"));
		theClearButton.setFont(LOG_FONT);
		theClearButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				logList.clear();
				fLogTextArea.invalidate();
				fLogTextArea.repaint();
				fLogTextArea.revalidate();
				fLogScrollPanel.invalidate();
				fLogScrollPanel.repaint();
			}
		});

		theFindPanel.add(theClearButton);

		if (!mainLog) {
			JButton theCloseButton = new JButton(AEFrame.getIcon("close.png"));
			theCloseButton.setFont(LOG_FONT);
			theCloseButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					fTaskEditor.removeActivePresentationPanel();
				}
			});

			theFindPanel.add(theCloseButton);
		}

		JPanel theLogControlPanel = new JPanel(new BorderLayout());
		theLogControlPanel.add(theFindPanel, BorderLayout.EAST);
		JPanel theLogLevelPanel = new JPanel();

		theLogControlPanel.add(theLogLevelPanel, BorderLayout.WEST);

		fPanel.add(theLogControlPanel, BorderLayout.NORTH);

		JPanel panel = new JPanel(new BorderLayout());
		JPanel panel4 = new JPanel();
		panel4.add(fLogToEnd);
		panel4.add(fDeleteOldRec);

		panel4.add(this.messageBar);
		panel.add(panel4, BorderLayout.WEST);
		fPanel.add(panel, BorderLayout.SOUTH);
		fLogToEnd.setSelected(
				"true".equals(AEWorkspace.getInstance().getDefaultUserConfiguration(".Edit.LogToEnd", "true")));
		fLogToEnd.addActionListener(this);

		fDeleteOldRec.setSelected(
				"true".equals(AEWorkspace.getInstance().getDefaultUserConfiguration(".Edit.DeleteOldRec", "true")));
		fDeleteOldRec.addActionListener(this);

		fLogTextArea.addKeyListener(fTaskEditor);
		fLogTextArea.setFont(LOG_FONT);
		fLogScrollPanel.getViewport().add(fLogTextArea);

		fTaskEditor.outputPaneAdd(this);
	}

	public void actionPerformed(ActionEvent e) {
		if (e != null && e.getSource() == fLogToEnd) {
			AEWorkspace.getInstance().setDefaultUserConfiguration(".Edit.LogToEnd",
					fLogToEnd.isSelected() ? "true" : "false");
			return;
		}
		if (e != null && e.getSource() == fDeleteOldRec) {
			AEWorkspace.getInstance().setDefaultUserConfiguration(".Edit.DeleteOldRec",
					fDeleteOldRec.isSelected() ? "true" : "false");
			return;
		}
	}

	public void info(Object o) {
		appendText(2, o);
		log.info(o);
	}

	public void debug(Object o) {
		if (o instanceof Throwable) {
			StringWriter theStringWriter = new StringWriter();
			((Throwable) o).printStackTrace(new PrintWriter(theStringWriter));
			appendText(3, theStringWriter.toString());
		} else {
			appendText(3, o);
			log.debug(o);
		}
	}

	public void debug(Object o, Throwable aThrowable) {
		appendText(3, o);

		StringWriter theStringWriter = new StringWriter();
		aThrowable.printStackTrace(new PrintWriter(theStringWriter));
		appendText(3, theStringWriter.toString());

		log.error(o, aThrowable);
	}

	public void error(Object o) {
		appendText(0, o);
		log.error(o);
	}

	public void error(Object o, Throwable aThrowable) {
		StringWriter theStringWriter = new StringWriter();
		aThrowable.printStackTrace(new PrintWriter(theStringWriter));
		appendText(0, ObjectUtils.toString(o) + "\n" + theStringWriter.toString());
		log.error(o, aThrowable);
	}

	public void warn(Object o) {
		appendText(1, o);
		log.error(o);
	}

	synchronized private void appendText(int logLevel, Object o) {

		logList.add(new LogRecord(logLevel, o), fDeleteOldRec.isSelected());

		if (fLogToEnd.isSelected()) {
			this.fLogTextArea.setModel(this.fLogTextArea.getModel());
			this.fLogScrollPanel.setViewportView(this.fLogTextArea);
			JScrollBar verticalScrollBar = fLogScrollPanel.getVerticalScrollBar();
			verticalScrollBar.setValue(verticalScrollBar.getMaximum());
		} else {
			this.fLogScrollPanel.setViewportView(this.fLogTextArea);
		}

	}

	public void warn(Object o, Throwable aThrowable) {
		appendText(1, o);
		StringWriter theStringWriter = new StringWriter();
		aThrowable.printStackTrace(new PrintWriter(theStringWriter));
		appendText(1, theStringWriter.toString());
		log.error(o, aThrowable);
	}

	public JPanel getPanel() {
		return fPanel;
	}

	@Override
	public void setEnabled(boolean b) {
		// TODO Auto-generated method stub

	}

	public static class LogRecord {

		private Object message;

		private int logLevel;

		private Date time;

		private String type;

		private String source;

		public LogRecord(int logLevel, Object o) {
			if (o instanceof Map) {
				Map map = (Map) o;
				message = new HashMap();
				((Map) message).putAll(map);

			} else if (o instanceof AELogRecord) {
				type = ((AELogRecord) o).getType();
				message = ((AELogRecord) o).getMessage();

				if (message instanceof Map) {
					Map map = (Map) message;
					message = new HashMap();
					((Map) message).putAll(map);
				}

				source = ((AELogRecord) o).getVarName();
			} else {
				message = o;
			}
			this.logLevel = logLevel;
			this.time = new Date();
		}

		public Object getMessage() {
			return message;
		}

		public long getTime() {
			return time.getTime();
		}

		public Object getResume() {
			return message;
		}

		public int getLogLevel() {
			return logLevel;
		}

		public String getType() {
			return type;
		}

		@Override
		public String toString() {
			if (message instanceof byte[]) {
				return new String((byte[]) message);
			}
			return ObjectUtils.toString(message, null);
		}

		public String getSource() {
			return source;
		}

		public void setSource(String source) {
			this.source = source;
		}

		public String getText() {
			return ObjectUtils.toString(message);
		}

	}

}
