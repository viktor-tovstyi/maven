package com.nave.anteater;

import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.FileInputStream;
import java.net.URI;

import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.xml.easyparser.Node;

class JAttachButton extends JLabel implements MouseListener {

	private static final long serialVersionUID = 1L;

	private String fFileName;

	private String fDesc;

	private String width;

	private String height;

	private WorkPlace workplace;

	public JAttachButton(WorkPlace workplace, Node aFileNode) {

		this.workplace = workplace;
		TaskProcessor processor = workplace.getTaskProcessor();
		String name = aFileNode.getAttribute("name");

		File file = workplace.getManager().getFile(processor.getBaseDir(), name);
		if (file != null && file.exists()) {
			fFileName = file.getAbsolutePath();
		} else {
			fFileName = name;
		}
		
		setToolTipText(name);

		fDesc = aFileNode.getAttribute("description");
		width = aFileNode.getAttribute("width");
		height = aFileNode.getAttribute("height");
		addMouseListener(this);
		setCursor(new Cursor(Cursor.HAND_CURSOR));
		setIcon(AEFrame.getIcon("doc.png"));
		if (fDesc != null) {
			setToolTipText(fDesc);
		}
	}

	public void mouseClicked(MouseEvent e) {

		try {
			String theType = null;

			if (StringUtils.startsWithIgnoreCase(fFileName, "http")) {
				Desktop.getDesktop().browse(new URI(fFileName));
			} else if (fFileName.toUpperCase().endsWith(".HTM") || fFileName.toUpperCase().endsWith(".HTML")) {
				theType = "text/html";
			} else if (fFileName.toUpperCase().endsWith(".TXT")) {
				theType = "text/plain";
			} else if (fFileName.toUpperCase().endsWith(".RTF")) {
				theType = "text/rtf";
			} else {
				Desktop.getDesktop().open(new File(fFileName));
			}

			if (theType != null) {
				JDialog theAttachFrame = new JDialog(workplace.getAeFrame(), fDesc, false);

				theAttachFrame.setLocation(100, 100);

				theAttachFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				String theText = IOUtils.toString(new FileInputStream(
						workplace.getManager().getFile(workplace.getTaskProcessor().getBaseDir(), fFileName)));
				JEditorPane editorPane = new JEditorPane(theType, theText);
				editorPane.setEditable(false);
				JScrollPane theScroll = new JScrollPane(editorPane);
				theAttachFrame.setContentPane(theScroll);
				theAttachFrame.pack();
				Dimension size = theAttachFrame.getSize();
				if (size.getWidth() > 700)
					size.width = 700;
				if (size.getHeight() > 500)
					size.height = 500;

				try {
					if (width != null)
						size.width = Integer.parseInt(width);
					if (height != null)
						size.height = Integer.parseInt(height);
				} catch (Exception e1) {
					//
				}

				theAttachFrame.setSize(size);

				theAttachFrame.setVisible(true);
			} 

		} catch (Exception e1) {
			if (workplace.getManager().isConsoleDefaultInput(null) == false)
				JOptionPane.showMessageDialog(JOptionPane.getRootFrame(), e1.getMessage(), "Attach opening is failed",
						JOptionPane.ERROR_MESSAGE);
			workplace.getLog().error("Throubles with coping attach.", e1);
		}

	}

	public void mouseEntered(MouseEvent e) {

	}

	public void mouseExited(MouseEvent e) {

	}

	public void mousePressed(MouseEvent e) {

	}

	public void mouseReleased(MouseEvent e) {

	}

}
