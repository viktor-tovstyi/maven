package com.nave.anteater.view.panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.Properties;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public class BarChart extends PresentationPanel {
	private static final long serialVersionUID = 1L;

	private DefaultCategoryDataset dataset;
	private JFreeChart chart = null;

	public BarChart(Properties params) throws Exception {
		super(params);
		String title = params.getProperty("title");
		String xAxisLabel = params.getProperty("xAxisLabel");
		String yAxisLabel = params.getProperty("yAxisLabel");

		dataset = new DefaultCategoryDataset();
		chart = ChartFactory.createBarChart(title, xAxisLabel, yAxisLabel, dataset, PlotOrientation.VERTICAL, true,
				true, false);

		chart.setBackgroundPaint(Color.white);
		add(new ChartPanel(chart, false), BorderLayout.CENTER);
	}

	synchronized public void out(Object data, Properties properties) {
		if (data instanceof String) {
			double value = Double.parseDouble((String) data);
			Comparable row = properties.getProperty("row");
			Comparable column = properties.getProperty("column");
			dataset.addValue(value, row, column);
		}
	}
}