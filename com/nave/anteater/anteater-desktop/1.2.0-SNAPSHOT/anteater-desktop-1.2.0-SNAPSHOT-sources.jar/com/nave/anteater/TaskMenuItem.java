package com.nave.anteater;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenuItem;

public class TaskMenuItem extends JMenuItem {

	private static final long serialVersionUID = -4999333547754164224L;
	private TaskEditor taskEditor;

	public TaskMenuItem(String name, final TaskEditor taskEditor) {
		super(name);
		this.taskEditor = taskEditor;
		addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				taskEditor.select();
				taskEditor.runTask();
			}
		});
	}

	public AEPanel getTaskEditor() {
		return taskEditor;
	}

	@Override
	public void paint(Graphics g) {
		setEnabled(!taskEditor.isRunning());
		super.paint(g);
	}

}
