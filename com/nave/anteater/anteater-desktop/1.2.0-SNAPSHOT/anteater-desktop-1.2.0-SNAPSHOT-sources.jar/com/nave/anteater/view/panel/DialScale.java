package com.nave.anteater.view.panel;

import java.awt.BorderLayout;
import java.awt.Font;
import java.util.Properties;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.dial.DialBackground;
import org.jfree.chart.plot.dial.DialCap;
import org.jfree.chart.plot.dial.DialPlot;
import org.jfree.chart.plot.dial.DialTextAnnotation;
import org.jfree.chart.plot.dial.DialValueIndicator;
import org.jfree.chart.plot.dial.StandardDialFrame;
import org.jfree.chart.plot.dial.StandardDialScale;
import org.jfree.data.general.DefaultValueDataset;

public class DialScale extends PresentationPanel {
	private static final long serialVersionUID = 1L;

	private DefaultValueDataset dataset;

	private DialPlot dialplot;

	private double lower;

	private double upper;

	private double increment;

	private int count;

	public DialScale(Properties params) throws Exception {
		super(params);
		dataset = new DefaultValueDataset();

		String title = params.getProperty("title", "");
		String label = params.getProperty("label", "");
		lower = Double.parseDouble(params.getProperty("lower", "0"));
		upper = Double.parseDouble(params.getProperty("upper", "100"));
		increment = Double.parseDouble(params.getProperty("increment", "10"));
		count = Integer.parseInt(params.getProperty("count", "10"));

		dialplot = new DialPlot();
		dialplot.setDataset(dataset);
		dialplot.setDialFrame(new StandardDialFrame());
		dialplot.setBackground(new DialBackground());
		DialTextAnnotation dialtextannotation = new DialTextAnnotation(label);
		dialtextannotation.setFont(new Font("Dialog", 1, 14));
		dialtextannotation.setRadius(0.69999999999999996D);
		dialplot.addLayer(dialtextannotation);
		DialValueIndicator dialvalueindicator = new DialValueIndicator(0);
		dialplot.addLayer(dialvalueindicator);
		StandardDialScale standarddialscale = new StandardDialScale(lower, upper, -120D, -300D, 10D, 4);
		standarddialscale.setMajorTickIncrement(increment);
		standarddialscale.setMinorTickCount(count);
		standarddialscale.setTickRadius(0.88D);
		standarddialscale.setTickLabelOffset(0.14999999999999999D);
		standarddialscale.setTickLabelFont(new Font("Dialog", 0, 14));
		dialplot.addScale(0, standarddialscale);
		dialplot.addPointer(new org.jfree.chart.plot.dial.DialPointer.Pin());
		DialCap dialcap = new DialCap();
		dialplot.setCap(dialcap);
		JFreeChart jfreechart = new JFreeChart(title, dialplot);

		ChartPanel chartpanel = new ChartPanel(jfreechart);
		add(chartpanel);
	}

	synchronized public void out(Object data, Properties properties) {
		double value = 0;

		if (data instanceof String) {
			value = Double.parseDouble((String) data);
		}

		String type = properties.getProperty("type");

		if (type == null) {
			dataset.setValue(value);
		} 
	}

}