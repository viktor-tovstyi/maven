package com.nave.anteater.view.panel;

import java.awt.BorderLayout;
import java.util.Properties;

import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class TextPanel extends PresentationPanel {
	private static final long serialVersionUID = -6679978094828718987L;
	private JTextArea fTextArrea = new JTextArea();
	JScrollPane scroll = new JScrollPane(fTextArrea);

	public TextPanel(Properties params) {
		super(params);
		fTextArrea.setEditable(true);
		add(scroll, BorderLayout.CENTER);
	}

	@Override
	public void out(Object value, Properties properties) {
		int length = fTextArrea.getText().length();
		boolean scrollOn = fTextArrea.getCaretPosition() == length || length == 0;
		fTextArrea.append(value + "\n");
		if (scrollOn) {
			length = fTextArrea.getText().length();
			fTextArrea.setCaretPosition(length);
			JScrollBar verticalScrollBar = scroll.getVerticalScrollBar();
			verticalScrollBar.setValue(verticalScrollBar.getMaximum());
		}
	}

}