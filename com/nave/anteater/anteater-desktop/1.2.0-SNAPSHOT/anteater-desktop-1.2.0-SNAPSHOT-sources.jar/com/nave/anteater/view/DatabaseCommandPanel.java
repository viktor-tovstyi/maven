package com.nave.anteater.view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JToolBar;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;

import com.nave.anteater.AEFrame;
import com.nave.anteater.AEManager;
import com.nave.anteater.Editor;
import com.nave.anteater.TaskEditor;
import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.sql.LocalDataSource;
import com.nave.anteater.util.sql.SQLQuery;
import com.nave.anteater.util.xml.easyparser.Node;

public class DatabaseCommandPanel extends JPanel
		implements TableModel, Runnable, ActionListener, KeyListener, AeEditPanel {
	private static final long serialVersionUID = 5726093964589241008L;

	public int MAX_NUMBER_ROWS = 65000;

	JSplitPane theJSplitPane = new JSplitPane();

	Editor theJTextArea = new Editor();

	SQLQuery theQuery = null;

	JDialogPopupMenu fPopupMenu = new JDialogPopupMenu(theJTextArea);

	int theColumnCount = 0;

	ArrayList fRowsList = new ArrayList();

	String[] fColumnName;

	ArrayList fTableModelListener = new ArrayList();

	JTable fTableResult = new JTable();

	Thread fThread = null;

	private TaskEditor editor;

	JButton theRunJButton = new JButton("Run", AEFrame.getIcon("run.png"));

	JComboBox<String> connections = new JComboBox<String>();

	static Properties fCallableHelperProperties = new Properties();

	private static final String ADD_NEW_HELPER = "Add this helper";

	public DatabaseCommandPanel(TaskEditor editor) throws Exception {
		this.editor = editor;

		setLayout(new BorderLayout());

		theJSplitPane.setTopComponent(new JScrollPane(theJTextArea));

		theJTextArea.addKeyListener(new CodeHelper(this, editor.getLog()));
		theJTextArea.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 1 && e.getButton() == MouseEvent.BUTTON3) {
					showPopupMenu();
				}

				if (e.getClickCount() == 3) {
					runStatement();
				}
			}

		});

		fPopupMenu.add(createMenuItem("select * from"));

		fPopupMenu.addSeparator();
		fPopupMenu.add(createMenuItem(ADD_NEW_HELPER));
		fPopupMenu.add(createMenuItem("Run statement"));

		theRunJButton.addActionListener(this);
		theRunJButton.setToolTipText("Run F9");

		JToolBar theJToolBar = new JToolBar();
		theJToolBar.add(connections);

		theJToolBar.add(new JSeparator(JSeparator.VERTICAL));

		theJToolBar.add(theRunJButton);

		JButton theCommitButton = new JButton("Commit");
		theCommitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					theQuery.commit();
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(theJSplitPane, e1.getMessage());
					e1.printStackTrace();
				}
			}
		});

		theJToolBar.add(theCommitButton);

		JButton theRollbackButton = new JButton("Rollback");
		theRollbackButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					theQuery.rollback();
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(theJSplitPane, e1.getMessage());
					e1.printStackTrace();
				}
			}
		});
		theJToolBar.add(theRollbackButton);

		JButton theBreakButton = new JButton("Break");
		theBreakButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					theQuery.close();
					theQuery = new SQLQuery(getConnectionName());
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(theJSplitPane, e1.getMessage());
					e1.printStackTrace();
				}
			}
		});
		theJToolBar.add(theBreakButton);

		JButton theSaveButton = new JButton(AEFrame.getIcon("save.png"));
		theSaveButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				saveSqlNote();
			}
		});
		theJToolBar.add(theSaveButton);

		JPanel theToolPanel = new JPanel(new BorderLayout());
		theToolPanel.add(theJToolBar, BorderLayout.WEST);

		add(theToolPanel, BorderLayout.NORTH);

		theJSplitPane.setOrientation(JSplitPane.VERTICAL_SPLIT);
		theJSplitPane.setOneTouchExpandable(true);

		add(theJSplitPane, BorderLayout.CENTER);
		theJSplitPane.setBottomComponent(new JScrollPane(fTableResult));

		try {
			FileInputStream theFileInputStream = new FileInputStream("sql.helper.properties");
			fCallableHelperProperties.load(theFileInputStream);
			theFileInputStream.close();

			for (Enumeration en = fCallableHelperProperties.propertyNames(); en.hasMoreElements();) {
				String theName = (String) en.nextElement();
				fPopupMenu.add(createMenuItem(theName), 0);
			}
		} catch (IOException e1) {
			System.out.println(e1.getMessage());
		}

		Set<String> connectionNames = LocalDataSource.getConnectionNames();
		for (String connectionName : connectionNames) {
			connections.addItem(connectionName);
		}
		if (connectionNames.size() > 0) {
			connections.setSelectedIndex(0);
		}
		connections.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				initQuery();
			}
		});
	}

	private void initQuery() {
		String connectionName = getConnectionName();
		try {
			theQuery = new SQLQuery(connectionName);
		} catch (Exception e) {
			String message = ExceptionUtils.getRootCauseMessage(e);
			IllegalArgumentException illegalArgumentException = new IllegalArgumentException("Connection: " + connectionName + ", Error: " + message, e);
			editor.createLog("SQL", false).error(ExceptionUtils.getStackTrace(illegalArgumentException));
			throw illegalArgumentException;
		}
	}

	public String getConnectionName() {
		int selectedIndex = connections.getSelectedIndex();
		return connections.getItemAt(selectedIndex < 0 ? 0 : selectedIndex);
	}

	private JMenuItem createMenuItem(String string) {
		JMenuItem theJMenuItem = new JMenuItem(string);
		theJMenuItem.addActionListener(this);
		return theJMenuItem;
	}

	private JMenuItem createCallableMenuItem(String string) {
		if (getRunLine() != null && string != null) {
			fCallableHelperProperties.setProperty(string, getRunLine());
		}
		JMenuItem theJMenuItem = new JMenuItem(string);
		theJMenuItem.addActionListener(this);
		return theJMenuItem;
	}

	public void setDividerLocation(int aDevideLocation) {
		theJSplitPane.setDividerLocation(aDevideLocation);
	}

	public void run() {
		theRunJButton.setEnabled(false);
		fTableResult.setModel(new DefaultTableModel());
		ResultSet theResultSet = null;

		try {

			String theRequest = getRunLine();

			theRequest = editor.getTaskProcessor().replaceProperties(theRequest);
			theRequest = StringEscapeUtils.unescapeXml(theRequest).trim();
			if (theRequest.endsWith(";"))
				theRequest = theRequest.substring(0, theRequest.length() - 1);

			editor.setInPropgress(true);
			if (theQuery == null) {
				initQuery();
			}
			theResultSet = theQuery.forResultSet(theRequest);

			theColumnCount = theResultSet.getMetaData().getColumnCount();

			fRowsList.clear();

			fColumnName = new String[theColumnCount];
			StringBuffer buffer = new StringBuffer();
			buffer.append("Query: " + theRequest + "\nColumn list:\n");
			for (int i = 1; i < theColumnCount + 1; i++) {
				fColumnName[i - 1] = theResultSet.getMetaData().getColumnName(i);
				String string = fColumnName[i - 1];
				buffer.append(i + ". " + theResultSet.getMetaData().getColumnClassName(i) + " " + string.toLowerCase()
						+ ";\n");
			}

			buffer.append("Result set:\n");

			while (theResultSet.next()) {

				String[] theRec = new String[theColumnCount];
				for (int theColumn = 1; theColumn < theColumnCount + 1; theColumn++) {
					theRec[theColumn - 1] = theQuery.getStringValue(theResultSet, theColumn);
				}

				fRowsList.add(theRec);

				buffer.append(StringUtils.join(theRec, ", "));
				buffer.append("\n");

				if (fRowsList.size() > MAX_NUMBER_ROWS) {
					for (int theColumn = 1; theColumn < theColumnCount + 1; theColumn++) {
						theRec[theColumn - 1] = "...";
					}
					fRowsList.add(theRec);
					break;
				}
			}

			editor.createLog("SQL", false).info(buffer.toString());

			fTableResult.setModel(this);
			fTableResult.invalidate();
			fTableResult.repaint();
		} catch (SQLException e1) {
			JOptionPane.showMessageDialog(this, e1.getMessage());
			e1.printStackTrace();
		} catch (Exception e1) {
			JOptionPane.showMessageDialog(this, StringUtils.defaultString(e1.getMessage(), e1.getClass().getName()));
			e1.printStackTrace();
		} finally {
			editor.setInPropgress(false);
		}

		int theListenersCount = fTableModelListener.size();
		for (int i = 0; i < theListenersCount; i++) {
			TableModelListener theTableModelListener = (TableModelListener) fTableModelListener.get(i);
			theTableModelListener.tableChanged(new TableModelEvent(this));
		}

		theRunJButton.setEnabled(true);
	}

	private String getRunLine() {
		String theRequest = theJTextArea.getSelectedText();
		if (theRequest == null || theRequest.trim().length() == 0)
			theRequest = theJTextArea.getText();
		return theRequest;
	}

	public int getRowCount() {
		return fRowsList.size();
	}

	public int getColumnCount() {
		return theColumnCount;
	}

	public String getColumnName(int columnIndex) {
		return fColumnName[columnIndex];
	}

	public Class getColumnClass(int columnIndex) {
		return String.class;
	}

	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return true;
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
		String[] theText = (String[]) fRowsList.get(rowIndex);
		if (theText != null && columnIndex < theText.length)
			return theText[columnIndex];
		return null;
	}

	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {

	}

	public void addTableModelListener(TableModelListener l) {
		fTableModelListener.add(l);
	}

	public void removeTableModelListener(TableModelListener l) {
		fTableModelListener.remove(l);
	}

	public void actionPerformed(ActionEvent e) {
		if ("Run".equals(e.getActionCommand())) {
			runQuery();
		}
		if ("Run statement".equals(e.getActionCommand())) {
			runStatement();
		}
		int caretPosition = theJTextArea.getCaretPosition();
		if ("select * from".equals(e.getActionCommand())) {
			theJTextArea.insert("SELECT * FROM ", caretPosition);
		}
		if (ADD_NEW_HELPER.equals(e.getActionCommand())) {
			String inputValue = JOptionPane.showInputDialog("Please input helper name");
			fPopupMenu.add(createCallableMenuItem(inputValue), 0);
			try {
				FileOutputStream theFileOutputStream = new FileOutputStream("sql.helper.properties");
				fCallableHelperProperties.store(theFileOutputStream, null);
				theFileOutputStream.close();
			} catch (IOException e1) {
				System.out.println(e1.getMessage());
			}
		} else {
			String theHelperLine = fCallableHelperProperties.getProperty(e.getActionCommand());
			if (theHelperLine != null) {

				String selectedValue = "";
				try {
					String selectedText = theJTextArea.getSelectedText();
					if (selectedText == null || selectedText.length() == 0) {

						if (caretPosition > 1) {
							String text = theJTextArea.getText();
							if (text.charAt(caretPosition - 1) != ' ') {
								int startPosition = text.lastIndexOf(' ', caretPosition);
								if (startPosition >= 0) {
									theJTextArea.setSelectionStart(startPosition + 1);
								} else {
									theJTextArea.setSelectionStart(0);
								}
								theJTextArea.setSelectionEnd(caretPosition);
								selectedText = theJTextArea.getSelectedText();
							}
						}
					}

					String theCommandLine = theHelperLine;

					if (selectedText == null)
						selectedText = "";
					theCommandLine = theHelperLine.replaceAll("%SELECT%", selectedText);

					theCommandLine = editor.getTaskProcessor().replaceProperties(theCommandLine);
					theCommandLine = StringEscapeUtils.unescapeXml(theCommandLine);

					if (theCommandLine.trim().charAt(0) != '$') {
						List forArrayValues = theQuery.forArrayValues(theCommandLine);
						if (forArrayValues.size() == 1) {
							selectedValue = (String) forArrayValues.get(0);
						} else if (forArrayValues.size() > 1) {
							selectedValue = (String) JOptionPane.showInputDialog(null, "Choose one", "Input",
									JOptionPane.INFORMATION_MESSAGE, null, forArrayValues.toArray(), (String)forArrayValues.get(0));
						}
					} else {
						selectedValue = theCommandLine;
					}

					if (selectedText != null && selectedText.length() > 0) {
						theJTextArea.replaceRange(selectedValue, theJTextArea.getSelectionStart(),
								theJTextArea.getSelectionEnd());
					} else {
						theJTextArea.insert(selectedValue, caretPosition);
					}

				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}

	}

	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_F9)
			actionPerformed(new ActionEvent(this, 0, "Run"));
		if (e.getKeyCode() == KeyEvent.VK_SPACE && e.isControlDown()) {
			showPopupMenu();
		}
	}

	private void showPopupMenu() {
		Point magicCaretPosition = theJTextArea.getLocation();

		Point caretPosition = theJTextArea.getCaret().getMagicCaretPosition();
		int theX = 0;
		int theY = 0;

		if (caretPosition != null) {
			theX = (int) (magicCaretPosition.getX() + caretPosition.getX());
			theY = (int) (magicCaretPosition.getY() + theJTextArea.getCaret().getMagicCaretPosition().getY());
		}

		fPopupMenu.show(theJTextArea, theX, theY);
	}

	public void keyReleased(KeyEvent e) {
	}

	public void keyTyped(KeyEvent e) {

	}

	private void runStatement() {
		int caretPosition = theJTextArea.getCaretPosition();
		String text = ";\n" + theJTextArea.getText() + ";\n";
		int end = text.indexOf(";\n", caretPosition);
		int start = text.lastIndexOf(";\n", caretPosition);
		while (Character.isWhitespace(text.charAt(start++)))
			;
		theJTextArea.setSelectionStart(start - 1);
		theJTextArea.setSelectionEnd(end);

		runQuery();
	}

	private void runQuery() {
		fThread = new Thread(this);
		fThread.start();
	}

	public void saveSqlNote() {
		Node taskNode = editor.getTaskNode();
		Node[] nodes = taskNode.getNodes("Note");
		Node node = nodes.length > 0 ? nodes[0] : null;

		String text = theJTextArea.getText();
		if (node == null) {
			node = new Node("Note");
			node.setAttribute("type", "sql");
			Node theNode = new Node(Node.TEXT_TEAG_NAME);
			theNode.setText("\n" + text + "\n");
			node.add(theNode);
			taskNode.add(node);

		} else {
			node.getNodes(Node.TEXT_TEAG_NAME)[0].setText("\n" + text + "\n");
		}

		editor.setTaskNode(taskNode);
		editor.saveTask();
	}

	public void setText(String text) {
		theJTextArea.setText(text);
	}

	public int getCaretPosition() {
		return theJTextArea.getCaretPosition();
	}

	public Component getComponent() {
		return theJTextArea;
	}

	public Point getMagicCaretPosition() {
		return theJTextArea.getCaret().getMagicCaretPosition();
	}

	public AEManager getManager() {
		return editor.getManager();
	}

	public TaskProcessor getTaskProcessor() {
		return editor.getTaskProcessor();
	}

	public String getText() {
		return theJTextArea.getText();
	}

	public void replaceRange(String text, int i, int caretPosition2) {
		theJTextArea.replaceRange(text, i, caretPosition2);
	}

	public void runTask() {
		run();
	}

	public void save() {
		saveSqlNote();
	}

	public void undo() {

	}

	public JDialogPopupMenu contextHelp(KeyEvent e, JDialogPopupMenu menu) {
		return fPopupMenu;
	}

	public void format() {
		// TODO Auto-generated method stub

	}

	public Editor getEditor() {
		return theJTextArea;
	}

}