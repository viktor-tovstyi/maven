package com.nave.anteater;

public enum InputDialogType {
	MAP, VAR, PWD, TASKS, FILE

}
