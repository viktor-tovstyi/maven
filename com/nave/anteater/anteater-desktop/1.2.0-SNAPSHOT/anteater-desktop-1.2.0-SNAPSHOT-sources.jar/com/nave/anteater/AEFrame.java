package com.nave.anteater;

import java.awt.AWTEvent;
import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.AWTEventListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowStateListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.border.EmptyBorder;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.AEUtils;
import com.nave.anteater.util.UIUtils;
import com.nave.anteater.util.xml.easyparser.Node;
import com.nave.anteater.view.ConfigurationEditor;
import com.nave.anteater.view.JDialogPopupMenu;
import com.nave.anteater.view.ListLoggPanel.LogRecord;
import com.nave.anteater.view.TextLoggPanel;

public class AEFrame extends JFrame {

	public static final String LOOK_AND_FEEL_CLASS_NAME = "LOOK_AND_FEEL_CLASS_NAME";

	public static final String TAKE_IT_EASY = "Take it easy";

	private static final String MENU_TAG_NAME = "Menu";

	private static final int USER_ACTION_NOTIFY_TIMEOUT = 3000;

	private static final String MENU_TAB_NAME = "Menu";

	private static final String RESTART_ALL_RUNNING_TASKS = "Restart all running tasks";

	private static final double ICON_SIZE = 80.0;

	public AEWorkspace getWorkspace() {
		return workspace;
	}

	private static final long serialVersionUID = 1L;

	private static final int COMPACT_THRESHOLD = 400;

	private static final String LOGO_ERROR_JPG = "logo-error.png";

	private static final String LOGO_FATAL_JPG = "logo-fatal.png";

	private static final String ICON16_JPG = "icon16.jpg";

	private static final String CHECK_POINT_ICON = "check-point.PNG";

	private static final String QUESTION_ICON = "question-sign.PNG";

	static final String LOGO_JPG = "logo.png";

	static final String TAKE_IT_EASY_JPG = "take-it-easy.png";

	private static final String LOGO_CHAINED = "logo-chained.png";

	static final String APP_TITLE = "Anteater";

	private static final String CONF_REFRESH_COMMAND = "Refresh recipes";

	private EnvPropertiesTable varTable;

	private TaskEditor failedEditor = null;

	private SoundManager soundManager;

	private boolean menuDisabled;

	private CustomizedMenu customizedMenu;

	public class UIChoiceTaskRunner extends MultiTaskRunDialogImpl implements MultiTaskRunDialog {

		private static final long serialVersionUID = 1L;

		public UIChoiceTaskRunner(String name, TaskProcessor taskProcessor, boolean useHistory) {
			super(AEFrame.this, name, taskProcessor, useHistory);
		}

	}

	private AEWorkspace workspace;

	private JTabbedPane tabbedPanel;

	private Component fCustomizedMenu;

	private JFrame logMessageFrame;

	private TextLoggPanel textArea;

	private JProgressBar progress;

	private JButton theJButton;

	private JCheckBox fConsoleDefaultInputBox;

	private JButton theLogo;

	private JDialogPopupMenu leftMenu;
	private JPanel panel;

	private ConfigurationEditor configurationEditor;

	private Logger log = Logger.getLogger(AEFrame.class);

	private boolean compactStyle;

	private CheckpointsDialog checkpointsDialog;

	private RecipesPanel recipesPanel;

	private Long lastUserActionTime;

	public AEFrame() {
		super(APP_TITLE);
		setMinimumSize(new Dimension(256, 204));

		logMessageFrame = new JFrame("Log message");
		workspace = new DesktopWorkspace(this) {
			@Override
			public void refreshTaskPath() throws IOException {
				super.refreshTaskPath();
				recipesPanel.refreshTaskPathTable();
			}
		};

		tabbedPanel = new JTabbedPane();
		textArea = new TextLoggPanel();
		progress = new JProgressBar();
		theJButton = new JButton(CONF_REFRESH_COMMAND);
		fConsoleDefaultInputBox = new JCheckBox(TAKE_IT_EASY);
		fConsoleDefaultInputBox
				.setSelected(Boolean.valueOf(System.getProperty(ConfigConstants.TAKE_IT_EASY_MODE, "false")));

		theLogo = new JButton(getIcon(getLogo()));
		leftMenu = new JDialogPopupMenu(theLogo);
		panel = new JPanel(new BorderLayout());

		recipesPanel = new RecipesPanel(workspace) {

			public TaskEditor editTask(String name) {
				return AEFrame.this.editTask(name);
			}

		};

		soundManager = new SoundManager(this);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JOptionPane.setRootFrame(this);

		compactStyle = !isCompactStyle();
		createFrame(compactStyle);

		addComponentListener(new ComponentAdapter() {

			public void componentResized(ComponentEvent e) {
				checkLayoutStyle();
			}
		});

		addWindowStateListener(new WindowStateListener() {
			public void windowStateChanged(WindowEvent e) {
				checkLayoutStyle();
			}
		});

		JMenuItem menuItem = new JMenuItem(RESTART_ALL_RUNNING_TASKS);
		menuItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				for (int i = 0; i < tabbedPanel.getTabCount(); i++) {
					Component comp = tabbedPanel.getComponentAt(i);
					if (comp instanceof TaskPanel) {
						TaskPanel taskPanel = (TaskPanel) comp;
						TaskEditor taskEditor = taskPanel.getTaskEditor();
						if (taskEditor.isRunning()) {
							taskEditor.stopTest();
							taskEditor.runTask();
						}
					}
				}
			}
		});
		leftMenu.add(menuItem);

		checkpointsDialog = new CheckpointsDialog(AEFrame.this);

		Toolkit.getDefaultToolkit().addAWTEventListener(new AWTEventListener() {
			@Override
			public void eventDispatched(AWTEvent event) {
				if (event instanceof MouseEvent) {
					lastUserActionTime = System.currentTimeMillis();
					getSoundManager().stop();
				}
				if (event instanceof KeyEvent) {
					lastUserActionTime = System.currentTimeMillis();
					getSoundManager().stop();
				}
			}
		}, AWTEvent.MOUSE_EVENT_MASK | AWTEvent.MOUSE_MOTION_EVENT_MASK | AWTEvent.KEY_EVENT_MASK);

		lookAndFeel();

	}

	private boolean isCompactStyle() {
		double width = getSize().getWidth();
		return width < COMPACT_THRESHOLD;
	}

	private void checkLayoutStyle() {
		boolean newStyle = isCompactStyle();
		varTable.refresh();
		if (newStyle != compactStyle) {
			try {
				setStyle(newStyle);
				compactStyle = newStyle;
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
	}

	private void createFrame(boolean compackStyle) {

		setIconImage(getIcon(ICON16_JPG).getImage());
		addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent arg0) {
				AEWorkspace.getInstance().setDefaultUserConfiguration(".win_position_x",
						String.valueOf(getLocation().getX()));
				AEWorkspace.getInstance().setDefaultUserConfiguration(".win_position_y",
						String.valueOf(getLocation().getY()));
				AEWorkspace.getInstance().setDefaultUserConfiguration(".win_position_w",
						String.valueOf(getSize().width));
				AEWorkspace.getInstance().setDefaultUserConfiguration(".win_position_h",
						String.valueOf(getSize().height));
				super.windowClosing(arg0);
			}

		});

		theLogo.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				if (!isMenuDisabled()) {
					if (failedEditor != null) {
						try {
							setSelectedComponent(failedEditor.getMainPanel());
						} catch (Exception e) {
							String name = showDialogTestSelect();
							runTask(name);
						}
						failedEditor = null;
						theLogo.setIcon(getIcon(getLogo()));
					} else {
						String name = showDialogTestSelect();
						run(name);
					}
				} else {
					if (failedEditor != null) {
						setSelectedComponent(failedEditor.getMainPanel());
						failedEditor = null;
						theLogo.setIcon(getIcon(getLogo()));
					}
				}
			}

			private void run(String name) {
				if (fCustomizedMenu != null) {
					tabbedPanel.add(MENU_TAB_NAME, fCustomizedMenu);
				}
				try {
					for (int i = 0; i < tabbedPanel.getTabCount(); i++) {
						Component comp = tabbedPanel.getComponentAt(i);
						if (comp instanceof TaskPanel) {
							TaskPanel taskPanel = (TaskPanel) comp;
							TaskEditor taskEditor = taskPanel.getTaskEditor();
							String title = taskEditor.getTaskNode().getAttribute("name");
							if (StringUtils.equals(title, name) && !taskEditor.isRunning()) {
								taskEditor.runTask();
								return;
							}
						}
					}

					runTask(name);
				} catch (ConfigurationException e) {
					e.printStackTrace();
				}
			}

		});

		theLogo.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				if (e.getButton() == 3) {
					leftMenu.show(theLogo, 0, 0);
				}
			}
		});

		setStyle(compackStyle);

		pushOnTop();
		logMessageFrame.getContentPane().add(textArea.getPanel());
		logMessageFrame.setSize(new Dimension(750, 400));
		logMessageFrame.setLocation(100, 100);

		textArea.getLogTextArea().addKeyListener(new KeyAdapter() {

			@Override
			public void keyReleased(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_ESCAPE)
					logMessageFrame.setVisible(false);
			}

		});
	}

	public static ImageIcon getIcon(String name) {
		name = "/images/ui/" + name;
		URL resource = AEFrame.class.getResource(name);
		if (resource == null) {
			throw new IllegalArgumentException("Resource is not found: " + name);
		}
		ImageIcon imageIcon = new ImageIcon(resource);
		return imageIcon;
	}

	private void setStyle(boolean compackStyle) {
		fConsoleDefaultInputBox.setOpaque(false);
		fConsoleDefaultInputBox.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				theLogo.setIcon(getIcon(getLogo()));
			}
		});

		getContentPane().removeAll();

		panel.removeAll();
		progress.setStringPainted(true);
		// progress.setVisible(false);
		panel.add(theLogo, BorderLayout.NORTH);
		JPanel comp = new JPanel(new BorderLayout());
		comp.add(fConsoleDefaultInputBox, BorderLayout.WEST);
		JButton checkpointList = new JButton(Character.toString((char) 9016));
		checkpointList.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				checkpointsDialog.showDialog();
			}
		});
		checkpointList.setToolTipText("Checkpoint List");
		checkpointList.setFont(new Font(checkpointList.getFont().getName(), Font.PLAIN, 16));
		checkpointList.setBorder(new EmptyBorder(0, 0, 0, 0));
		checkpointList.setBorderPainted(false);
		comp.add(checkpointList, BorderLayout.EAST);
		panel.add(comp, BorderLayout.CENTER);
		panel.add(progress, BorderLayout.SOUTH);

		if (compackStyle) {
			getContentPane().add(panel, BorderLayout.NORTH);
			getContentPane().add(tabbedPanel, BorderLayout.CENTER);

		} else {

			JPanel leftPanel = new JPanel(new BorderLayout());
			leftPanel.setBorder(BorderFactory.createBevelBorder(0));

			leftPanel.add(panel, BorderLayout.NORTH);
			leftPanel.add(createConfirPanel(), BorderLayout.CENTER);
			JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, tabbedPanel);
			splitPane.setDividerLocation(230);

			getContentPane().add(splitPane);

		}
		setAlwaysOnTop(compackStyle);
	}

	public void start() throws Exception {

		setControlEnabled(false);
		loadConfiguration();

		boolean menuDisabled = isMenuDisabled();
		setControlEnabled(!menuDisabled);

		if (menuDisabled) {
			theLogo.setIcon(getIcon(LOGO_CHAINED));
		}

		if (fCustomizedMenu != null && !isMenuDisabled()) {
			tabbedPanel.add(MENU_TAB_NAME, fCustomizedMenu);
			setSelectedComponent(fCustomizedMenu);
			fCustomizedMenu = null;
		}

		SwingUtilities.invokeLater(() -> {
			lookAndFeel();
		});
	}

	public void setSelectedComponent(Component comp) {
		tabbedPanel.setSelectedComponent(comp);
	}

	protected TaskEditor editTask(String name) {
		TaskEditor taskEditor = null;
		taskEditor = new TaskEditor(this);
		if (name != null) {
			taskEditor.setActiveTest(name);
		}
		String logName = StringUtils.defaultString(name, TaskProcessor.STARTUP);
		taskEditor.edit(logName);
		addTaskPanel(taskEditor, logName);
		return taskEditor;
	}

	private void addTaskPanel(TaskEditor taskEditor, String name) {
		taskEditor.showPanel(tabbedPanel, name);
		leftMenu.add(new TaskMenuItem(name, taskEditor));
	}

	protected void setControlEnabled(boolean aEnabled) {
		theLogo.setIcon(getIcon(getLogo()));
		theLogo.setCursor(new Cursor(Cursor.HAND_CURSOR));
	}

	public String taskFileNameConflict(String aKey, String aCurrentFile, String aNewFile) throws Exception {
		StringBuffer theStringBuffer = new StringBuffer();

		theStringBuffer.append("<html><body>");
		theStringBuffer.append("Duplication file for task with name: '" + aKey + "'<br>");
		theStringBuffer.append("Registration file: '" + aCurrentFile + "'<br>");
		theStringBuffer.append("Conflict file: '" + aNewFile + "'<br>");
		theStringBuffer.append("<br>");
		theStringBuffer.append("Please select priority folder:<br>");
		theStringBuffer.append("</body></html>");

		String theFirstFile = new File(aNewFile).getParent();
		String theSecondFile = new File(aCurrentFile).getParent();

		Object[] possibleValues = { theFirstFile, theSecondFile };

		StringBuffer theMessageBuffer = new StringBuffer();
		theMessageBuffer.append("Duplication file for task with name: '" + aKey + "' ");

		String thePriorityFolder = null;
		List<String> priorityFolders = getWorkspace().getPriorityFolders();
		if (priorityFolders.contains(theFirstFile)) {
			thePriorityFolder = theFirstFile;
			theMessageBuffer.append("presetting selection file: " + aNewFile);
		} else if (priorityFolders.contains(theSecondFile)) {
			thePriorityFolder = theSecondFile;
			theMessageBuffer.append("presetting selection file: " + aCurrentFile);
		} else {
			thePriorityFolder = (String) JOptionPane.showInputDialog(this, theStringBuffer.toString(),
					"Conflict of variants recipes", JOptionPane.INFORMATION_MESSAGE, null, possibleValues,
					possibleValues[0]);
			theMessageBuffer.append("manual selection priority folder: " + thePriorityFolder);
		}

		priorityFolders.add(thePriorityFolder);

		if (thePriorityFolder == null) {
			StringBuffer fBuffer = new StringBuffer();
			fBuffer.append("Duplication file for task with name: '" + aKey + "': ");
			fBuffer.append("Registration file: '" + aCurrentFile + "', ");
			fBuffer.append("Conflict file: '" + aNewFile + "'");
			throw new Exception(fBuffer.toString());
		}

		if (theSecondFile != null && theSecondFile.equals(thePriorityFolder))
			aNewFile = aCurrentFile;

		log.warn(theMessageBuffer.toString());
		return aNewFile;
	}

	public void refreshTaskPath() throws IOException {
		getWorkspace().refreshTaskPath();
		recipesPanel.refreshTaskPathTable();
	}

	public String inputValue(String aDesc, String aName, String aValue, String type) {
		String description = aDesc + aName;
		if (aValue == null) {
			aValue = AEWorkspace.getInstance().getDefaultUserConfiguration(".inputValue." + aName, aValue);
			description = description + " (last value)";
		}
		pushOnTop();
		switch ((String) ObjectUtils.defaultIfNull(type, StringUtils.EMPTY)) {
		case "password":
			aValue = inputPassword(aName, aValue);
			break;
		case "map":
			aValue = inputMap(aName, aValue);
			break;

		default:
			aValue = simpleInput(aName, aValue, null);
		}
		AEWorkspace.getInstance().setDefaultUserConfiguration(".inputValue." + aName, aValue);
		return aValue;
	}

	private String simpleInput(String name, Object values, Object defaultValue) {
		String result = null;

		JPanel panel = new JPanel(new BorderLayout());
		JLabel label = new JLabel(name);
		panel.add(label, BorderLayout.NORTH);

		JComponent inputField;
		if (values instanceof String || values == null) {
			inputField = new JTextField(20);
			((JTextField) inputField).setText((String) values);
			panel.add(inputField, BorderLayout.CENTER);
		} else {
			inputField = new JComboBox((Object[]) values);
			((JComboBox<String>) inputField).setSelectedItem(defaultValue);
			panel.add(inputField, BorderLayout.CENTER);
		}

		CheckPointBox vip = new CheckPointBox(name, this, InputDialogType.VAR);
		panel.add(vip, BorderLayout.SOUTH);

		String[] options = new String[] { "OK", "Cancel" };
		Frame rootFrame = JOptionPane.getRootFrame();
		ImageIcon icon = getCheckpointIcon(InputDialogType.VAR, name);

		soundManager.play();

		int option = JOptionPane.showOptionDialog(rootFrame, panel, "Input a value", JOptionPane.NO_OPTION,
				JOptionPane.PLAIN_MESSAGE, icon, options, options[0]);

		vip.saveCheckpointFlag();
		soundManager.stop();

		switch (option) {
		case JOptionPane.OK_OPTION:
			if (values instanceof String || values == null) {
				result = ((JTextField) inputField).getText();
			} else {
				result = (String) ((JComboBox) inputField).getSelectedItem();
			}
			break;
		case JOptionPane.CANCEL_OPTION:
		case JOptionPane.NO_OPTION:
			result = null;
			break;
		case JOptionPane.CLOSED_OPTION:
			throw new TaskCancelingException();
		}

		return result;
	}

	private ImageIcon getCheckpointIcon(InputDialogType type, String name) {
		ImageIcon icon = null;
		Boolean checkPointFlag = CheckPointBox.getCheckPointFlag(type, name);
		if (checkPointFlag != null && checkPointFlag) {
			icon = getIcon(CHECK_POINT_ICON);
		} else {
			icon = getIcon(QUESTION_ICON);
		}
		return icon;
	}

	private String inputMap(String description, String aValue) {
		final Map<String, String> map = AEUtils.convertStringToMap(aValue);

		Set<Entry<String, String>> entrySet = map.entrySet();
		Object[][] data = new Object[map.size()][];
		int i = 0;
		for (Entry<String, String> entry : entrySet) {
			Object[] row = new Object[2];
			row[0] = entry.getKey();
			row[1] = entry.getValue();
			data[i++] = row;
		}

		Object[] columnNames = { "Name", "Value" };
		final JTable table = new JTable(data, columnNames) {
			@Override
			public Dimension getPreferredScrollableViewportSize() {
				Dimension d = getPreferredSize();
				int n = getRowHeight();
				return new Dimension(d.width, (n * map.size()));
			}
		};
		table.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		table.setCellSelectionEnabled(true);

		JPanel jPanel = new JPanel();
		jPanel.setLayout(new BorderLayout());
		JScrollPane sp = new JScrollPane(table);
		jPanel.add(sp, BorderLayout.CENTER);

		CheckPointBox vip = new CheckPointBox(description, this, InputDialogType.MAP);
		jPanel.add(vip, BorderLayout.SOUTH);

		jPanel.add(new JLabel(description), BorderLayout.NORTH);
		String[] options = new String[] { "OK", "Cancel" };
		Frame rootFrame = JOptionPane.getRootFrame();

		soundManager.play();

		int option = JOptionPane.showOptionDialog(rootFrame, jPanel, "Input the map property", JOptionPane.NO_OPTION,
				JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
		vip.saveCheckpointFlag();
		soundManager.stop();

		String result = null;
		if (option == -1) {
			throw new TaskCancelingException();
		}
		if (option == 0) // pressing OK button
		{
			Map<String, String> resultMap = new HashMap<>(map);
			for (int j = 0; j < map.size(); j++) {
				resultMap.put((String) data[j][0], (String) data[j][1]);
			}
			result = resultMap.toString();
		}

		return result;
	}

	private String inputPassword(String description, String aValue) {
		String result = null;

		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		JLabel label = new JLabel(description);
		JPasswordField pass = new JPasswordField(20);
		pass.setText(aValue);
		panel.add(label);
		panel.add(pass);

		CheckPointBox vip = new CheckPointBox(description, this, InputDialogType.PWD);
		panel.add(vip);

		String[] options = new String[] { "OK", "Cancel" };
		Frame rootFrame = JOptionPane.getRootFrame();

		soundManager.play();

		int option = JOptionPane.showOptionDialog(rootFrame, panel, "Input a password", JOptionPane.NO_OPTION,
				JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
		vip.saveCheckpointFlag();
		soundManager.stop();

		if (option == 0) // pressing OK button
		{
			char[] password = pass.getPassword();
			result = new String(password);
		}

		return result;
	}

	public String showDialogTestSelect() {

		String theValue = AEWorkspace.getInstance().getDefaultUserConfiguration(".defaultTest", null);

		if (fCustomizedMenu == null) {
			Object[] testArray = recipesPanel.getMenuTasks().toArray();
			theValue = (String) JOptionPane.showInputDialog(this, null, MENU_TAB_NAME, JOptionPane.QUESTION_MESSAGE,
					null, testArray, theValue);
			AEWorkspace.getInstance().setDefaultUserConfiguration(".defaultTest", theValue);
		} else {
			fCustomizedMenu.setVisible(true);
			theValue = null;
		}

		return theValue;
	}

	protected void createToolBar(CustomizedMenu menu) {
		JPanel panel = new JPanel();

		GridLayout mgr = new GridLayout(menu.size(), 1);
		mgr.setVgap(4);
		panel.setLayout(mgr);
		panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

		int i = 0;
		for (CustomizedMenu.Item item : menu) {

			JTaskButton theButton = new JTaskButton(item.getTaskNode());

			theButton.setText((++i) + ". " + item.getName());
			theButton.setToolTipText(item.getToolTip());
			theButton.setFont(new Font("Arial", Font.BOLD, 16));
			theButton.setHorizontalAlignment(SwingConstants.LEFT);

			if (item.getImage() != null) {
				File file = new File(getWorkspace().getTasksMap().getProperty(item.getName()));
				if (file.exists()) {
					String icon = new File(file.getParent(), item.getImage()).getAbsolutePath();
					ImageIcon defaultIcon = new ImageIcon(icon);
					int iconHeight = defaultIcon.getIconHeight();
					int iconWidth = defaultIcon.getIconWidth();
					double mass = ICON_SIZE / iconHeight;
					if (mass > (80.0 / iconWidth)) {
						mass = 80.0 / iconWidth;
					}
					BufferedImage createResizedCopy = createResizedCopy(defaultIcon.getImage(),
							(int) (iconHeight * mass), (int) (iconWidth * mass), false);
					theButton.setIcon(new ImageIcon(createResizedCopy));
				}
			}

			panel.add(theButton);
		}
		JPanel wrapPanel = new JPanel(new BorderLayout(4, 4));
		wrapPanel.add(BorderLayout.NORTH, panel);
		fCustomizedMenu = new JScrollPane(wrapPanel);
	}

	BufferedImage createResizedCopy(Image originalImage, int scaledWidth, int scaledHeight, boolean preserveAlpha) {
		int imageType = preserveAlpha ? BufferedImage.TYPE_INT_RGB : BufferedImage.TYPE_INT_ARGB;
		BufferedImage scaledBI = new BufferedImage(scaledWidth, scaledHeight, imageType);
		Graphics2D g = scaledBI.createGraphics();
		if (preserveAlpha) {
			g.setComposite(AlphaComposite.Src);
		}
		g.drawImage(originalImage, 0, 0, scaledWidth, scaledHeight, null);
		g.dispose();
		return scaledBI;
	}

	public void message(String string) {
		JOptionPane.showMessageDialog(this, string);
	}

	public class JTaskButton extends JButton implements ActionListener {

		private static final long serialVersionUID = 1L;

		protected Node fTaskNode;

		protected boolean fMultiThread;

		public JTaskButton(Node aTaskNode) {
			// setBorder(BorderFactory.createEtchedBorder());
			fTaskNode = aTaskNode;
			String theTask = fTaskNode.getAttribute("task");
			recipesPanel.setMenuTask(theTask);
			addActionListener(this);
			fMultiThread = "enabled".equals(aTaskNode.getAttribute("multi"));
			setFont(new Font("Dialog", Font.BOLD, 14));
		}

		public boolean isMultiThread() {
			return fMultiThread;
		}

		public void actionPerformed(ActionEvent e) {

			try {
				TaskEditor taskEditor = new TaskEditor(AEFrame.this);
				String theTask = fTaskNode.getAttribute("task");
				if (theTask != null) {
					String name = fTaskNode.getAttribute("name");
					if (name == null)
						name = theTask;
					addTaskPanel(taskEditor, name);
					taskEditor.start(theTask);
				}

			} catch (Throwable e1) {
				e1.printStackTrace();
			}
		}
	}

	public String getTestPath(String name) {

		String property = getWorkspace().getTestsDescList().getProperty(name);
		return property == null ? name : property;
	}

	private JTabbedPane createConfirPanel() {

		varTable = new EnvPropertiesTable(this);
		JScrollPane theScrollPane = new JScrollPane(varTable);

		JPanel theButtonsPanel = new JPanel();
		JButton theButton = new JButton(AEFrame.getIcon("save.png"));
		theButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				SwingUtilities.invokeLater(new Runnable() {
					@Override
					public void run() {
						saveEnvProperties();
					}
				});
			}
		});
		theButtonsPanel.add(theButton);

		theButton = new JButton(AEFrame.getIcon("default.png"));
		theButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				SwingUtilities.invokeLater(new Runnable() {
					@Override
					synchronized public void run() {
						String customConfPropFileName = getWorkspace()
								.getCustomConfPropFileName(getWorkspace().getConfigurationName());

						closeAllTasks();
						changeConfiguration(customConfPropFileName);
					}
				});
			}
		});
		theButtonsPanel.add(theButton);

		JPanel panel = new JPanel(new BorderLayout(4, 4));

		theButton = new JButton("Show", AEFrame.getIcon("hierarchy.png"));
		theButton.setEnabled(true);
		theButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				JButton source = (JButton) arg0.getSource();
				if ("Show".equals((source).getText())) {
					source.setText("Hiden");
					try {
						setSelectedComponent(configurationEditor);
					} catch (Exception e) {
						configurationEditor = new ConfigurationEditor(AEFrame.this);
						tabbedPanel.addTab("Environments", configurationEditor);
						setSelectedComponent(configurationEditor);
					}
				} else {
					tabbedPanel.remove(configurationEditor);
					source.setText("Show");
				}

			}
		});

		panel.add(theButton, BorderLayout.EAST);

		JPanel theSysvarButtonsPanel = new JPanel(new BorderLayout(4, 4));
		theSysvarButtonsPanel.add(theScrollPane, BorderLayout.CENTER);
		theSysvarButtonsPanel.add(panel, BorderLayout.NORTH);
		theSysvarButtonsPanel.add(theButtonsPanel, BorderLayout.SOUTH);

		JPanel recPanel = new JPanel();
		recPanel.setLayout(new BorderLayout());
		recPanel.add(recipesPanel, BorderLayout.CENTER);

		JPanel comp = new JPanel();

		JButton theCreate = new JButton(AEFrame.getIcon("create.png"));
		theCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TaskEditor taskEditor;
				try {
					taskEditor = new TaskEditor(AEFrame.this);

					String taskName = JOptionPane.showInputDialog(JOptionPane.getRootFrame(), "Task name");
					if (taskName != null) {
						addTaskPanel(taskEditor, taskName);
						taskEditor.create(taskName);
						taskEditor.showEditorPane();
					}

				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		});
		comp.add(theCreate);

		JButton theRefresh = new JButton(AEFrame.getIcon("refresh.png"));
		theRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					workspace.refreshTaskPath();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		});
		comp.add(theRefresh);

		recPanel.add(comp, BorderLayout.SOUTH);

		JTabbedPane tablePane = new JTabbedPane();
		tablePane.add("Recipes", recPanel);
		tablePane.add("Environment", theSysvarButtonsPanel);

		theJButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				refreshTaskMap();
			}
		});

		return tablePane;
	}

	public Long getLastUserActionTime() {
		return lastUserActionTime;
	}

	public void loadConfiguration() throws Exception {
		loadConfiguration(null);
	}

	protected void loadConfiguration(String confName) throws Exception {
		String currentConfName = getWorkspace().getConfigurationName();
		String loadConfiguration = getWorkspace().loadConfiguration(confName, true);

		Object laf = getWorkspace().getSystemVariables().get("LOOK_AND_FEEL_CLASS_NAME");
		if (laf == null) {
			LookAndFeelInfo[] installedLookAndFeels = UIManager.getInstalledLookAndFeels();
			List<String> lafList = new ArrayList<>();
			for (LookAndFeelInfo lookAndFeelInfo : installedLookAndFeels) {
				lafList.add(lookAndFeelInfo.getClassName());
			}
			getWorkspace().getSystemVariables().put("LOOK_AND_FEEL_CLASS_NAME", lafList);
		}

		Node configNode = workspace.getConfigNode();
		String menuName = configNode.getAttribute("menu");
		Node[] theToolBarNodes = configNode.getNodes(MENU_TAG_NAME);
		if (StringUtils.isNotBlank(menuName)) {
			if (menuName != null) {
				Node findNode = configNode.findNode(MENU_TAG_NAME, "name", menuName);
				if (findNode != null) {
					theToolBarNodes = new Node[] { findNode };
				}
			}
		}

		if (theToolBarNodes != null && theToolBarNodes.length > 0) {
			customizedMenu = createToolBar(theToolBarNodes);
			if (customizedMenu.size() == 0) {
				menuDisabled = true;
			} else {
				menuDisabled = false;
			}
		} else {
			menuDisabled = false;
		}

		setTitle(loadConfiguration + " - " + APP_TITLE);

		if (!StringUtils.equals(currentConfName, loadConfiguration)) {
			tabbedPanel.removeAll();
		}

		varTable.refresh();
		recipesPanel.refreshTaskPathTable();
		getWorkspace().runSetupNodes(); // TODO: potentially bug
		lookAndFeel();

	}

	protected CustomizedMenu createToolBar(Node[] aToolBarNodes) {
		CustomizedMenu menu = new CustomizedMenu();

		for (int k = 0; k < aToolBarNodes.length; k++) {
			Node theNode = aToolBarNodes[k];
			Node[] theButtonsNode = theNode.getNodes("item");

			if (theButtonsNode.length > 0) {
				String name = theNode.getAttribute("name");
				if (name != null)
					menu.setTitle(name);

				for (int i = 0; i < theButtonsNode.length; i++) {
					Node theItemNode = theButtonsNode[i];
					menu.addItem(theItemNode);
				}

			}
		}

		createToolBar(menu);
		return menu;
	}

	public void removeTab(TaskEditor editor) {
		tabbedPanel.remove(editor.getMainPanel());
		for (int i = 0; i < leftMenu.getComponentCount(); i++) {
			Component component = leftMenu.getComponent(i);
			if (component instanceof TaskMenuItem) {
				TaskMenuItem taskMenuItem = (TaskMenuItem) component;
				if (taskMenuItem.getTaskEditor() == editor) {
					leftMenu.remove(taskMenuItem);
				}
			}
		}
	}

	public void showText(LogRecord text, TaskProcessor taskEditor) {
		logMessageFrame.setVisible(true);
		textArea.clear();
		out(text, taskEditor);
	}

	public void out(LogRecord text, TaskProcessor taskEditor) {
		textArea.info(text, taskEditor);
	}

	public void runTask(String name) {
		if (name != null) {
			TaskEditor taskEditor = null;
			try {
				taskEditor = new TaskEditor(this);
				addTaskPanel(taskEditor, name);
				taskEditor.start(name);
			} catch (ConfigurationException e) {
				refreshRecipeMap(taskEditor);
			}
		}
	}

	public void refreshRecipeMap(TaskEditor taskEditor) {
		removeTab(taskEditor);
		int showConfirmDialog = JOptionPane.showConfirmDialog(this, "Recipe file is not found. Refresh recipe map?");
		if (showConfirmDialog == JOptionPane.OK_OPTION) {
			refreshTaskMap();
		}
	}

	public void setTestPath(String name, String path) {
		recipesPanel.refreshTaskPathTable();
		tabbedPanel.setTitleAt(tabbedPanel.getSelectedIndex(), name);
	}

	@Override
	public void pack() {
		// super.pack();
		int theX = (int) Float
				.parseFloat(AEWorkspace.getInstance().getDefaultUserConfiguration(".win_position_x", "0"));
		int theY = (int) Float
				.parseFloat(AEWorkspace.getInstance().getDefaultUserConfiguration(".win_position_y", "0"));
		int theW = Integer.parseInt(AEWorkspace.getInstance().getDefaultUserConfiguration(".win_position_w", "680"));
		int theH = Integer.parseInt(AEWorkspace.getInstance().getDefaultUserConfiguration(".win_position_h", "500"));

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

		if (theX < screenSize.getWidth() - 20 && theY < screenSize.getHeight() - 20) {
			setLocation(theX, theY);
			setSize(theW, theH);

			if (!isCompactStyle()) {
				setAlwaysOnTop(false);
				setAlwaysOnTop(true);
			}
		}
	}

	void refreshTaskMap() {
		Thread thread = new Thread(new Runnable() {

			public void run() {
				theJButton.setEnabled(false);
				try {
					setControlEnabled(false);
					refreshTaskPath();
					setControlEnabled(true);

				} catch (IOException e1) {
					JOptionPane.showMessageDialog(AEFrame.this,
							"<html>Incorrect TESTDIR value.<br/><br/><i>" + e1.getMessage() + "</i></html>");
					e1.printStackTrace();
				}
				theJButton.setEnabled(true);
			}

		});
		thread.start();
	}

	public void checkFailure(TaskEditor editor) {
		theLogo.setIcon(getIcon(LOGO_ERROR_JPG));
		if (editor != null) {
			failedEditor = editor;
		}
	}

	public void criticalError(TaskEditor editor) {
		theLogo.setIcon(getIcon(LOGO_FATAL_JPG));
		if (editor != null) {
			failedEditor = editor;
		}
	}

	public void setConsoleDefaultInput(boolean defaultMode) {
		fConsoleDefaultInputBox.setSelected(defaultMode);
		theLogo.setIcon(getIcon(getLogo()));
	}

	public UIChoiceTaskRunner getChoiceTaskRunner(MultiTaskRunDialog name, TaskProcessor taskProcessor, Object setup) {
		return new UIChoiceTaskRunner(name.getName(), taskProcessor, setup == null);
	}

	public void startTaskNotify(TaskEditor editor) {
		if (failedEditor == editor)
			theLogo.setIcon(getIcon(getLogo()));
	}

	protected void createAboutPanel() {
		JToolBar theToolBar = new JToolBar();
		theToolBar.setFloatable(false);
		getContentPane().add(theToolBar, BorderLayout.SOUTH);
	}

	public void progressValue(int i, int length, boolean success) {
		if (length > 0) {
			progress.setVisible(true);
			progress.setValue(i);
			progress.setMaximum(length);
			progress.setMinimum(0);

			progress.setForeground(success ? Color.green.darker() : Color.red.darker());

		} else {
			progress.setVisible(false);

		}
	}

	public String inputSelectChoice(String name, String[] aValues, String defaultValue, TaskProcessor taskProcessor) {
		if (defaultValue == null && aValues.length > 0) {
			defaultValue = AEWorkspace.getInstance().getDefaultUserConfiguration(".choice." + name, aValues[0]);
		}

		if (workspace.isConsoleDefaultInput(name) == false) {
			pushOnTop();
			defaultValue = simpleInput(name, aValues, defaultValue);

			AEWorkspace.getInstance().setDefaultUserConfiguration(".choice." + name, defaultValue);
		}

		return defaultValue;
	}

	public void pushOnTop() {
		if (!isAlwaysOnTop()) {
			setAlwaysOnTop(true);
			setAlwaysOnTop(false);
		}
	}

	public boolean isConsoleDefaultInput() {
		return fConsoleDefaultInputBox.isSelected();
	}

	public void resetConfiguration() {
		tabbedPanel.removeAll();

	}

	public void resetUserAction() {
		lastUserActionTime = null;
	}

	public void fireBuzzAction() {
		fireBuzzAction(null);
	}

	public void fireBuzzAction(Runnable runnable) {
		if (isUserInactive()) {
			buzzAction(runnable);
		} else {
			if (runnable != null) {
				runnable.run();
			}
		}
	}

	private void buzzAction(Runnable runnable) {

		soundManager.play();

		boolean alwaysOnTop = isAlwaysOnTop();
		if (alwaysOnTop == false) {
			setAlwaysOnTop(true);
		}

		if (getState() == Frame.ICONIFIED) {
			setState(Frame.NORMAL);
		}

		Thread buzzThread = new Thread(new Runnable() {
			private Color color = Color.MAGENTA;
			private int borderSize = 10;
			private int period = 200;

			@Override
			public void run() {
				boolean bordered = true;
				while (!Thread.currentThread().isInterrupted()) {
					setBorder(bordered);
					bordered = !bordered;
					try {
						Thread.sleep(period);
					} catch (InterruptedException e) {
						break;
					}
				}
			}

			private void setBorder(boolean bordered) {
				JPanel glassPane = (JPanel) getContentPane();
				if (bordered) {
					glassPane.setBorder(
							BorderFactory.createMatteBorder(borderSize, borderSize, borderSize, borderSize, color));
				} else {
					glassPane.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.LIGHT_GRAY));
				}
				glassPane.repaint();
			}
		});
		buzzThread.start();

		if (runnable == null) {
			JOptionPane.showMessageDialog(getContentPane(), "Process finished!", "Notification",
					JOptionPane.INFORMATION_MESSAGE);
		} else {
			runnable.run();
		}

		soundManager.stop();

		((JPanel) getContentPane()).setBorder(BorderFactory.createMatteBorder(0, 0, 0, 0, Color.LIGHT_GRAY));
		buzzThread.interrupt();
		setAlwaysOnTop(alwaysOnTop);
	}

	public String choiceValue(String name, Object[] values, String title, Logger log) {
		String defaultValue = null;
		if (values != null && values.length > 0) {
			defaultValue = (String) values[0];
		}
		String result = AEWorkspace.getInstance().getDefaultUserConfiguration(".choiceValue." + name, defaultValue);
		pushOnTop();
		if (workspace.isConsoleDefaultInput(name) == false) {
			result = simpleInput(name, values, result);
			AEWorkspace.getInstance().setDefaultUserConfiguration(".choiceValue." + name, result);
		}

		return result;
	}

	private void changeConfiguration(String customConfPropFileName) {

		File theConfFile = new File(customConfPropFileName);
		boolean result = theConfFile.delete();
		getWorkspace().loadConfProperties(new Properties());

		try {
			String configurationName = getWorkspace().getConfigurationName();
			loadConfiguration(configurationName);
			lookAndFeel();

		} catch (Exception e1) {
			log.error("Config variables refresh is failed.", e1);
		}
	}

	private void closeAllTasks() {
		for (int i = 0; i < tabbedPanel.getTabCount(); i++) {
			Component comp = tabbedPanel.getComponentAt(i);
			if (comp instanceof TaskPanel) {
				TaskPanel taskPanel = (TaskPanel) comp;
				TaskEditor taskEditor = taskPanel.getTaskEditor();
				if (taskEditor.isRunning()) {
					taskEditor.stopTest();
				}
			}
		}
	}

	public void saveEnvProperties() {
		String customConfPropFileName = getWorkspace().getCustomConfPropFileName(getWorkspace().getConfigurationName());

		File theConfDir = getWorkspace().getHomeConfigurationsDir();
		if (theConfDir.exists() && theConfDir.isDirectory()) {
			theConfDir.mkdirs();
		}

		Properties theConfProp = new Properties();

		Set<Entry<String, Object>> entrySet = getWorkspace().getSystemVariables().entrySet();
		for (Entry<String, Object> entry : entrySet) {
			Object value = entry.getValue();
			if (value instanceof String) {
				theConfProp.setProperty(entry.getKey(), (String) value);
			} else if (value instanceof List) {
				theConfProp.setProperty(entry.getKey(), (String) ((List) value).get(0));
			}
		}

		try {
			FileOutputStream theFile = new FileOutputStream(customConfPropFileName);
			theConfProp.store(theFile, null);
			theFile.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		try {
			refreshTaskPath();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public CustomizedMenu getCustomizedMenu() {
		return customizedMenu;
	}

	public boolean isMenuDisabled() {
		return menuDisabled;
	}

	private String getLogo() {
		return fConsoleDefaultInputBox.isSelected() ? TAKE_IT_EASY_JPG : LOGO_JPG;
	}

	public boolean isUserInactive() {
		Long lastUserActionTime = getLastUserActionTime();
		return lastUserActionTime == null
				|| (lastUserActionTime + USER_ACTION_NOTIFY_TIMEOUT) < System.currentTimeMillis();
	}

	public SoundManager getSoundManager() {
		return soundManager;
	}

	public void setSoundManager(SoundManager soundManager) {
		this.soundManager = soundManager;
	}

	public void lookAndFeel() {
		Object laf = getWorkspace().getSystemVariables().get("LOOK_AND_FEEL_CLASS_NAME");
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				UIUtils.applyLookAndFeel(laf, AEFrame.this, logMessageFrame, checkpointsDialog.getDialog(), tabbedPanel,
						varTable, panel, configurationEditor, recipesPanel.getTable());
			}
		});
	}
}
