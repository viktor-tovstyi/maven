package com.nave.anteater.view;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import org.apache.commons.lang.ObjectUtils;

import com.nave.anteater.AEFrame;
import com.nave.anteater.TaskEditor;
import com.nave.anteater.processor.TaskProcessor;

public class VariableViewPanel extends JPanel {

	private static final long serialVersionUID = 2888716197417976230L;

	private JTable fVariablesTable = new JTable();

	private TaskEditor editor;

	private Vector<Vector<String>> fVariables = new Vector<>();

	public VariableViewPanel(TaskEditor editor) {
		setLayout(new BorderLayout());
		this.editor = editor;
		
		fVariablesTable.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		fVariablesTable.setCellSelectionEnabled(true);

		JPanel panel = new JPanel(new BorderLayout());
		JButton button = new JButton(AEFrame.getIcon("refresh.png"));
		button.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				SwingUtilities.invokeLater(() -> refreshData());
			}

		});

		panel.add(button, BorderLayout.EAST);
		add(panel, BorderLayout.NORTH);
		add(new JScrollPane(fVariablesTable), BorderLayout.CENTER);

		refreshData();
	}

	public void refreshData() {
		if (editor.getTaskProcessor() != null) {
			synchronized (fVariables) {
				fVariables.removeAllElements();
				Map<String, Object> variables = new HashMap<String, Object>(TaskProcessor.getGlobalVariables());
				variables.putAll((Map<String, Object>) editor.getTaskProcessor().getVariables());
				loadProperties(variables);
				
				Vector<String> columnNames = new Vector<>();
				columnNames.add("Name");
				columnNames.add("Value");

				DefaultTableModel dataModel = new DefaultTableModel(fVariables, columnNames) {
					@Override
					public boolean isCellEditable(int row, int column) {
						return false;
					}
				};
				fVariablesTable.setModel(dataModel);
			}

			fVariablesTable.repaint();
		}
	}

	private void loadProperties(Map<String, Object> variables) {
		Set tehKeySet = variables.keySet();
		Object[] theKeys = tehKeySet.toArray();
		Arrays.sort(theKeys);

		for (int theCurId = 0; theCurId < theKeys.length; theCurId++) {

			Vector theCurrentRow = new Vector();

			String key = (String) theKeys[theCurId];
			Object theValue = variables.get(key);

			theCurrentRow.add(key);
			if (theValue instanceof String) {
				theCurrentRow.add(theValue);
			} else if (theValue instanceof String[]) {
				StringBuffer theBuffer = new StringBuffer();
				String[] valueArray = (String[]) theValue;
				theBuffer.append("{ARRAY}[");
				for (int i = 0; i < valueArray.length; i++) {
					theBuffer.append(valueArray[i]);
					if (i < valueArray.length - 1) {
						theBuffer.append("][");
					}
				}
				theBuffer.append(']');
				theCurrentRow.add(theBuffer.toString());
			} else if (theValue instanceof Map) {
				StringBuffer theBuffer = new StringBuffer();
				Map valueArray = (Map) theValue;
				theBuffer.append("{MAP}[" + ObjectUtils.toString(valueArray));
				theBuffer.append(']');
				theCurrentRow.add(theBuffer.toString());
			}
			fVariables.add(theCurrentRow);
		}
	}
}
