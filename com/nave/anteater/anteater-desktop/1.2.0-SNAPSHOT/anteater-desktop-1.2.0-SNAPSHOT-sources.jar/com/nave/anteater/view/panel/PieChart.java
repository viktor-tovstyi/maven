package com.nave.anteater.view.panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.Properties;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

public class PieChart extends PresentationPanel {
	private static final long serialVersionUID = 1L;

	private DefaultPieDataset dataset;
	private JFreeChart chart = null;

	public PieChart(Properties params) throws Exception {
		super(params);
		String title = params.getProperty("title");

		dataset = new DefaultPieDataset();
		chart = ChartFactory.createPieChart(title, dataset, true, true, true);

		chart.setBackgroundPaint(Color.white);
		add(new ChartPanel(chart, false), BorderLayout.CENTER);
	}

	synchronized public void out(Object data, Properties properties) {
		if (data instanceof String) {
			double value = Double.parseDouble((String) data);
			Comparable key = properties.getProperty("key");
			dataset.setValue(key, value);
		}
	}
}