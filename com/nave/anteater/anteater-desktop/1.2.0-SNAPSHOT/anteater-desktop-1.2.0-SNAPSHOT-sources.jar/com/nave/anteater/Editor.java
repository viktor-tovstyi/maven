package com.nave.anteater;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JTextArea;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.Document;
import javax.swing.undo.UndoManager;

import org.apache.commons.lang.StringUtils;

public class Editor extends JTextArea {

	private static final long serialVersionUID = -298735473495909314L;
	private final UndoManager undo = new UndoManager();

	public Editor() {
		super();
		Document doc = getDocument();

		doc.addUndoableEditListener(new UndoableEditListener() {
			public void undoableEditHappened(UndoableEditEvent evt) {
				undo.addEdit(evt.getEdit());
			}
		});

		addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode() == KeyEvent.VK_Z && e.isControlDown()) {
					undo();
				} else if (e.getKeyCode() == KeyEvent.VK_Y && e.isControlDown()) {
					redo();
				}
			}
		});

	}

	public void redo() {
		if (undo.canRedo()) {
			undo.redo();
		}
	}

	public void undo() {
		if (undo.canUndo()) {
			undo.undo();
		}
	}

	public void removeLine() {
		int caretPosition = getCaretPosition();
		String text = getText();
		int start = StringUtils.lastIndexOf(text, "\n", caretPosition - 1);
		start = start < 0 ? 0 : start + 1;
		int end = StringUtils.indexOf(text, "\n", caretPosition);
		end = end < 0 ? text.length() - 1 : end + 1;
		start = start < end ? start : end;
		replaceRange("", start, end);
		setCaretPosition(start == 0 ? 0 : start);
	}

	public void setOriginalText(String xmlText) {
		setText(xmlText);
	}

}
