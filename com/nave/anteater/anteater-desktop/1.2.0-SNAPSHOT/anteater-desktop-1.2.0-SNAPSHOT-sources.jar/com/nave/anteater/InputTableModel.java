package com.nave.anteater;

import java.util.Map;

import javax.swing.table.AbstractTableModel;

import com.nave.anteater.util.xml.easyparser.Node;

public class InputTableModel extends AbstractTableModel {

	private static final long serialVersionUID = 2907837684253858613L;
	
	private Node[] theResultVariablesNodes = null;
	private Map<String, Object> variables;

	public InputTableModel(TemplateProcessor unit, Node[] theResultVariablesNodes, Map<String, Object> variables) {
		
		this.theResultVariablesNodes = theResultVariablesNodes;
		this.variables = variables;

		for (Node node : theResultVariablesNodes) {
			String value = unit.replaceProperties(node.getAttribute("value"));
			String name = node.getAttribute("name");
			if (value != null)
				this.variables.put(name, value);
			if (this.variables.get(name) == null) {
				value = node.getAttribute("default");
				if (value != null)
					this.variables.put(name, value);
			}
		}
	}

	public int getColumnCount() {
		return 2;
	}

	public int getRowCount() {
		return theResultVariablesNodes.length;
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
		String name = theResultVariablesNodes[rowIndex].getAttribute("name");
		return columnIndex == 0 ? name : variables.get(name);
	}

	@Override
	public String getColumnName(int column) {
		return column == 0 ? "Property name" : "Value";
	}

	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return columnIndex == 1;
	}

	@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
		variables.put(theResultVariablesNodes[rowIndex].getAttribute("name"), aValue);
	}

}
