package com.nave.anteater;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.plaf.basic.BasicComboBoxEditor;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableColumn;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.UIUtils;

class MultiTaskRunDialogImpl extends AbstractTableModel
		implements MultiTaskRunDialog, WindowListener, Iterator<String> {

	private int currentIndex = -1;

	private static final String MULTI_TASK_RUN_DIALOG_PROP_NAME = "MultiTaskRunDialog";

	private static final long serialVersionUID = 1L;

	private JDialog dialog;

	private JComboBox<String> nameBox = new JComboBox<String>();

	private String[] taskNames;

	private JTable table;

	private List<String> activeTaskArray = new ArrayList<String>();

	private String[] status;

	boolean start = false;

	private JCheckBox exceptionIgnoreCheck = new JCheckBox(AEFrame.getIcon("not-ignore-exception.png"));

	private String hoiceName;

	JButton startButton = new JButton(AEFrame.getIcon("run.png"));

	JButton button1 = new JButton(AEFrame.getIcon("select-all.png"));

	JButton button2 = new JButton(AEFrame.getIcon("deselect-all.png"));

	private boolean errorrState = false;

	private boolean closeDialog = false;

	private AEFrame frame;

	private boolean editable = true;

	private boolean useHistory;

	public MultiTaskRunDialogImpl(final AEFrame frame, String theChoiceNames, TaskProcessor taskProcessor,
			final boolean useHistory) {
		this.frame = frame;
		dialog = new JDialog(frame, theChoiceNames, false);
		frame.pushOnTop();
		dialog.addWindowListener(this);
		this.hoiceName = theChoiceNames;
		editable = true;
		this.useHistory = useHistory;
	}

	public void showDialog(String name, String[] theNames) {
		if (frame.getWorkspace().isConsoleDefaultInput(name)) {
			start = true;
		}

		closeDialog = false;
		this.taskNames = theNames;

		table = new JTable(this);

		TableColumn column = table.getColumnModel().getColumn(0);
		column.setMaxWidth(40);
		column.setHeaderValue("Run");
		column.setCellEditor(new DefaultCellEditor(new JCheckBox()));

		TableColumn column1 = table.getColumnModel().getColumn(1);
		column1.setHeaderValue("Task name");

		TableColumn column2 = table.getColumnModel().getColumn(2);
		column2.setMaxWidth(60);
		column2.setHeaderValue("Result");

		JPanel panel = new JPanel();
		String presetListStr = AEWorkspace.getInstance()
				.getDefaultUserConfiguration("MultiTaskRunDialog_preset:" + this.hoiceName, "");
		if (presetListStr != null) {
			String[] presetList = StringUtils.split(presetListStr, ";");
			for (String presetName : presetList) {
				nameBox.addItem(presetName);
			}
		}
		nameBox.setEditable(true);
		nameBox.setEnabled(true);
		BasicComboBoxEditor anEditor = new BasicComboBoxEditor() {
			@Override
			protected JTextField createEditorComponent() {
				JTextField createEditorComponent = super.createEditorComponent();
				createEditorComponent.setEditable(true);
				return createEditorComponent;
			}
		};
		nameBox.setEditor(anEditor);

		nameBox.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				loadPreset();

				nameBox.setEditable(true);
				BasicComboBoxEditor anEditor = new BasicComboBoxEditor() {
					@Override
					protected JTextField createEditorComponent() {
						JTextField createEditorComponent = super.createEditorComponent();
						createEditorComponent.setEditable(true);
						return createEditorComponent;
					}
				};
				nameBox.setEditor(anEditor);
			}
		});
		dialog.getContentPane().add(nameBox, BorderLayout.NORTH);
		dialog.getContentPane().add(new JScrollPane(table), BorderLayout.CENTER);

		startButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				start = true;
				savePreset();
			}
		});
		panel.add(startButton);

		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				for (String name : taskNames) {
					activeTaskArray.add(name);
				}
				table.updateUI();
				if (editable && useHistory)
					saveConfig();
			}
		});
		panel.add(button1);

		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				activeTaskArray.clear();
				table.updateUI();
				if (editable && useHistory)
					saveConfig();
			}
		});
		panel.add(button2);

		loadPreset();

		exceptionIgnoreCheck.setSelectedIcon(AEFrame.getIcon("ignore-exception.png"));
		panel.add(exceptionIgnoreCheck);
		JButton closeButton = new JButton(AEFrame.getIcon("close.png"));
		closeButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				savePreset();
				dialog.setVisible(false);
				dialog.dispose();
				closeDialog = true;
			}

		});
		panel.add(closeButton);

		JPanel comp = new JPanel(new BorderLayout());
		comp.add(panel, BorderLayout.CENTER);

		CheckPointBox vip = new CheckPointBox(name, frame, InputDialogType.TASKS);
		comp.add(vip, BorderLayout.SOUTH);
		vip.saveCheckpointFlag();

		dialog.getContentPane().add(comp, BorderLayout.SOUTH);

		dialog.pack();
		UIUtils.applyPreferedView(dialog, MULTI_TASK_RUN_DIALOG_PROP_NAME, theNames.length * 19 + 50);
		if (frame.getWorkspace().isConsoleDefaultInput(hoiceName) == false) {
			dialog.setVisible(true);
		}

		status = new String[taskNames.length];

		table.addKeyListener(new KeyListener() {

			public void keyTyped(KeyEvent e) {
				if (e.getKeyChar() == '\n' && startButton.isEnabled()) {
					start = true;
				}
			}

			public void keyReleased(KeyEvent e) {
				// TODO Auto-generated method stub

			}

			public void keyPressed(KeyEvent e) {
				// TODO Auto-generated method stub

			}
		});
		dialog.getRootPane().setDefaultButton(startButton);
		startButton.requestFocus();

		frame.getSoundManager().play();

		while (start != true && closeDialog == false) {
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				//
			}
		}

		frame.getSoundManager().stop();

		startButton.setEnabled(false);

		button1.setEnabled(false);
		button2.setEnabled(false);

		exceptionIgnoreCheck.setEnabled(false);
	}

	private void loadPreset() {
		if (editable && useHistory) {
			String aName = getPresetDataName();
			String defaultTasks = AEWorkspace.getInstance().getDefaultUserConfiguration(aName, null);
			if (defaultTasks != null) {
				activeTaskArray.clear();
				String[] strings = StringUtils.split(defaultTasks, ";");
				for (String taskName : strings) {
					if (ArrayUtils.indexOf(taskNames, taskName) >= 0)
						activeTaskArray.add(taskName);
				}
			}
		}
		table.updateUI();
	}

	private void savePreset() {
		LinkedHashSet<String> presetList = new LinkedHashSet<>();
		presetList.add((String) nameBox.getEditor().getItem());
		for (int i = 0; i < nameBox.getItemCount(); i++) {
			presetList.add(nameBox.getItemAt(i));
		}

		String values = StringUtils.join(presetList.toArray(), ";");
		AEWorkspace.getInstance().setDefaultUserConfiguration(
				"MultiTaskRunDialog_preset:" + MultiTaskRunDialogImpl.this.hoiceName, values);

		saveConfig();
	}

	private void saveConfig() {
		AEWorkspace.getInstance().setDefaultUserConfiguration(getPresetDataName(),
				StringUtils.join(activeTaskArray.toArray(), ';'));
	}

	private String getPresetDataName() {
		String presetName = (String) nameBox.getEditor().getItem();
		String aName = "MultiTaskRunDialog" + (StringUtils.isNotBlank(presetName) ? "." + presetName : "") + ":"
				+ this.hoiceName;
		return aName;
	}

	public Iterator<String> getSelectedTasks() {

		List<String> list = new ArrayList<String>();
		if (closeDialog && start == false)
			return new ArrayList().iterator();

		return this;
	}

	@Override
	public boolean hasNext() {
		currentIndex++;
		int i;
		for (i = currentIndex; i < taskNames.length; i++) {
			String name = taskNames[i];
			if (activeTaskArray.contains(name)) {
				break;
			}
		}
		currentIndex = i;

		boolean hasNext = currentIndex < taskNames.length;
		return hasNext;
	}

	@Override
	public String next() {
		String taskName = taskNames[currentIndex];
		return taskName;
	}

	public void begin(String taskName) {
		int row = ArrayUtils.indexOf(taskNames, taskName);
		this.status[row] = "in progress";
		table.updateUI();
	}

	public void done() {
		if (errorrState) {
			start = false;
			// button.setEnabled(true);
			button1.setEnabled(true);
			button2.setEnabled(true);
			table.setEnabled(true);
		} else {
			dialog.setVisible(false);
			dialog.dispose();
		}
		errorrState = true;
	}

	public void end(String taskName, boolean statusOk) {
		int row = ArrayUtils.indexOf(taskNames, taskName);
		this.status[row] = statusOk ? "ok" : "failed";
		table.updateUI();
		if (statusOk == false)
			errorrState = true;
	}

	public boolean isExceptionIgnore() {
		return exceptionIgnoreCheck.isSelected();
	}

	public int getColumnCount() {
		return 3;
	}

	public int getRowCount() {
		return taskNames.length;
	}

	public Object getValueAt(int row, int coll) {
		if (coll == 0) {
			String name = taskNames[row];
			return activeTaskArray.contains(name);
		}
		if (coll == 2) {
			String status = this.status[row];
			return status == null ? "" : status;
		}
		return taskNames[row];
	}

	@Override
	public Class<?> getColumnClass(int coll) {
		if (coll == 0)
			return Boolean.class;
		return String.class;
	}

	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		boolean waiting = rowIndex > currentIndex;
		return columnIndex == 0 && editable && waiting;
	}

	@Override
	public void setValueAt(Object arg0, int row, int coll) {
		if (coll == 0) {
			String name = taskNames[row];
			if (((Boolean) arg0) == true && activeTaskArray.contains(name) == false)
				activeTaskArray.add(name);
			if (((Boolean) arg0) == false)
				activeTaskArray.remove(name);
		}
		if (editable && useHistory)
			saveConfig();
	}

	public void windowActivated(WindowEvent e) {
	}

	public void windowClosed(WindowEvent e) {
	}

	public void windowClosing(WindowEvent e) {
		if (start == false) {
			activeTaskArray.clear();
			closeDialog = true;
		}

		UIUtils.saveDialogPreferedView(dialog, MULTI_TASK_RUN_DIALOG_PROP_NAME);
	}

	public void windowDeactivated(WindowEvent e) {
	}

	public void windowDeiconified(WindowEvent e) {
	}

	public void windowIconified(WindowEvent e) {
	}

	public void windowOpened(WindowEvent e) {
	}

	public void setExceptionIgnore(boolean flag) {
		exceptionIgnoreCheck.setSelected(flag);
	}

	public void select(String[] activeTaskArray, boolean defaultMode) {
		this.activeTaskArray.clear();
		for (String activeTask : activeTaskArray)
			this.activeTaskArray.add(activeTask);

		if (defaultMode) {
			start = true;
			editable = false;
		}

	}

	public boolean isStarted() {
		return start;
	}

	public String getName() {
		return hoiceName;
	}

}