package com.nave.anteater.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Desktop;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;

import com.nave.anteater.AEFrame;
import com.nave.anteater.TaskEditor;
import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.xml.easyparser.EasyParser;
import com.nave.anteater.util.xml.easyparser.Node;
import com.nave.anteater.view.ListLoggPanel.LogRecord;

public class TextLoggPanel extends LoggPanel implements ActionListener {

	private JTextArea fLogTextArea = new JTextArea();

	List<String> supportedTypes = new ArrayList<>();
	{
		supportedTypes.add("txt");
		supportedTypes.add("html");
		supportedTypes.add("xml");
		supportedTypes.add("json");
		supportedTypes.add("url");
		supportedTypes.add("path");
		supportedTypes.add("uri");
	}

	private JPanel theLogPanel = new JPanel(new BorderLayout());

	private JTextField fFindText = new JTextField(12);

	private JCheckBox fLogToEnd = new JCheckBox("auto scrolling.");

	private JScrollPane fLogScrollPanel;

	JButton theFormatButton = new JButton("Format");

	private TaskEditor fTaskEditor;

	private JPanel fPanel;

	private TaskProcessor processor;

	private FileDialog theFileDialog;

	private JComboBox<String> propertiesNames = new JComboBox<String>();

	private JComboBox<String> typeBox = new JComboBox<String>(
			supportedTypes.toArray(new String[supportedTypes.size()]));

	private Object originData;

	public TextLoggPanel() {
		this(null, "");
	}

	public TextLoggPanel(TaskEditor aTaskEditor, String aName) {
		super(aName);

		fTaskEditor = aTaskEditor;

		fLogTextArea.setDoubleBuffered(true);

		fLogScrollPanel = new JScrollPane(fLogTextArea);
		theLogPanel.add(fLogScrollPanel, BorderLayout.CENTER);

		JToolBar toolBar = new JToolBar();

		if (fTaskEditor != null) {
			JButton theClearButton = new JButton(AEFrame.getIcon("clean.png"));
			theClearButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					fLogTextArea.setText("");
				}
			});
			toolBar.add(theClearButton);
		} else {
			theFormatButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					format();
				}
			});

			toolBar.add(propertiesNames);
			toolBar.add(typeBox);
			toolBar.add(theFormatButton);

			JButton theClearButton = new JButton("$...{} Replace");

			theClearButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					String text = fLogTextArea.getText();
					try {
						int caretPosition = fLogTextArea.getCaretPosition();
						String replaceProperties = processor.replaceProperties(text);
						replaceProperties = replaceProperties.replaceAll("<br/>", "\n");
						// replaceProperties =
						// EasyParser.replaseReferense(replaceProperties);
						fLogTextArea.setText(replaceProperties);
						if (caretPosition < replaceProperties.length())
							fLogTextArea.setCaretPosition(caretPosition);
					} catch (Exception e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(getPanel()),
								"$...{} replacer failed.");
					}
				}
			});

			propertiesNames.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					print();
				}
			});

			toolBar.add(theClearButton);
			theClearButton = new JButton("Open");

			theClearButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						String selectedItem = (String) typeBox.getSelectedItem();
						String text = fLogTextArea.getText();
						openFile(text, selectedItem);
					} catch (IOException e1) {
						JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(getPanel()),
								"File opening failed.");
					}
				}

			});
			toolBar.add(theClearButton);

			theClearButton = new JButton(AEFrame.getIcon("save.png"));

			theClearButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {
						String text = fLogTextArea.getText();
						if (theFileDialog == null)
							theFileDialog = new FileDialog(JOptionPane.getRootFrame(), "Save log line.",
									FileDialog.SAVE);
						theFileDialog.setFile(StringUtils.left(text.trim(), 12) + ".txt");
						theFileDialog.setVisible(true);
						File theFile = new File(theFileDialog.getDirectory() + theFileDialog.getFile());
						FileOutputStream theFileOutputStream = new FileOutputStream(theFile);
						theFileOutputStream.write(text.getBytes("UTF-8"));
						theFileOutputStream.close();
					} catch (Exception e1) {
						e1.printStackTrace();
						JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(getPanel()),
								"File is not saved.");
					}
				}
			});
			toolBar.add(theClearButton);
		}

		toolBar.add(new JLabel("Text: "));
		toolBar.add(fFindText);
		fFindText.setEnabled(true);

		JButton theFindButton = new JButton("Find");
		theFindButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String text = fFindText.getText();
				try {
					findText(text);

				} catch (Exception e1) {
					JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(theLogPanel),
							"Replesing properties is failed.");
				}
			}
		});

		fFindText.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if (e.getKeyChar() == '\n') {
					String text = fFindText.getText();
					findText(text);
				}
			}
		});

		theFindButton.setEnabled(true);
		toolBar.add(theFindButton);

		if (fTaskEditor != null) {
			JButton theCloseButton = new JButton(AEFrame.getIcon("close.png"));
			theCloseButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					fTaskEditor.removeActivePresentationPanel();
				}
			});

			toolBar.add(theCloseButton);
		}

		theLogPanel.add(toolBar, BorderLayout.NORTH);

		JPanel panel = new JPanel(new BorderLayout());
		JPanel panel4 = new JPanel();
		if (fTaskEditor != null)
			panel4.add(fLogToEnd);

		panel.add(panel4, BorderLayout.WEST);
		// theLogPanel.add(panel, BorderLayout.SOUTH);

		if (fTaskEditor != null) {
			fLogToEnd.setSelected(false); // "true".equals(fTaskEditor.getDefaultUserConfiguration(".Edit.LogToEnd",
			// "false")));
			fLogToEnd.addActionListener(this);
		}

		fLogTextArea.setEditable(true);
		if (fTaskEditor != null)
			fLogTextArea.addKeyListener(fTaskEditor);
		fLogTextArea.setFont(new Font("Monospaced", Font.PLAIN, 11));
		fPanel = theLogPanel;

		if (fTaskEditor != null)
			fTaskEditor.outputPaneAdd(this);
	}

	public void actionPerformed(ActionEvent e) {

		if (e != null && e.getSource() == fLogToEnd) {
			// fTaskEditor.setDefaultUserConfiguration(".Edit.LogToEnd",
			// fLogToEnd.isSelected() ? "true" : "false");
			return;
		}

	}

	public void info(Object o, TaskProcessor processor) {
		this.processor = processor;
		setType(o);
		if (fTaskEditor == null)
			appendText(o);
	}

	private void format() {
		String text = fLogTextArea.getText();
		String type = StringUtils.upperCase(getType());

		switch (type) {
		case "XML":
			try {

				int indexOf2 = text.indexOf("?>");
				if (indexOf2 < 0)
					indexOf2 = 0;
				int indexOf = text.indexOf('<', indexOf2);
				int lastIndexOf = text.lastIndexOf(">") + 1;

				Node object = new EasyParser().getObject(text.substring(indexOf, lastIndexOf));
				fLogTextArea.setText(text.substring(0, indexOf) + (indexOf > 0 ? "\n" : "") + object.getXMLText()
						+ text.substring(lastIndexOf));

			} catch (Exception e1) {
				fLogTextArea.setText(text);
				JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(getPanel()), "XML formating failed.");
			}
			break;
		case "JSON":
			try {
				fLogTextArea.setText(new JSONObject(text).toString(2));
			} catch (JSONException e1) {
				fLogTextArea.setText(text);
				JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(getPanel()), "JSON formating failed.");
			}
			break;
		case "URL":
			try {
				StringBuilder formatedText = new StringBuilder();
				String trim = text.replace(" ", "");
				trim = trim.replace("\n", "");
				URL url = new URL(trim);
				formatedText.append(url.getProtocol() + "://");
				formatedText.append(url.getHost());
				if (url.getPort() > 0)
					formatedText.append(":" + url.getPort());
				formatedText.append(url.getPath());

				List<NameValuePair> parse = URLEncodedUtils.parse(url.toURI(), "UTF-8");
				if (parse.size() > 0) {
					formatedText.append("\n");
					String delim = "?";
					for (NameValuePair nameValuePair : parse) {
						formatedText.append(delim + nameValuePair.getName() + "=" + nameValuePair.getValue() + "\n");
						delim = "&";
					}
				}
				fLogTextArea.setText(formatedText.toString());
			} catch (Exception e1) {
				JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(getPanel()),
						"URI transformation failed.\n" + e1.getMessage());
			}
			break;
		}
	}

	protected void setType(Object o) {
		String type = StringUtils.defaultIfBlank(((LogRecord) o).getType(), "txt");

		if (o instanceof LogRecord) {
			if (((LogRecord) o).getMessage() instanceof String) {

				if (StringUtils.startsWith((String) ((LogRecord) o).getMessage(), "<?xml")) {
					type = "xml";
				}

				type = StringUtils.defaultIfEmpty(type, supportedTypes.get(0));
				if (!supportedTypes.contains(type.toLowerCase())) {
					supportedTypes.add(type);
					this.typeBox.addItem(type);
				}
				this.typeBox.setSelectedItem(type);

			} else if (StringUtils.isNotBlank(type)) {
				if (StringUtils.startsWith(ObjectUtils.toString(o), "<?xml")) {
					type = "xml";
					this.typeBox.setSelectedItem(type);
				} else {
					this.typeBox.setSelectedItem(type);
					if (!StringUtils.equals(this.typeBox.getSelectedItem().toString(), type)) {
						this.typeBox.addItem(type);
					}
					this.typeBox.setSelectedItem(type);
				}
			}
		}
	}

	private void setPropertiesList(Set keySet) {
		for (Object object : keySet) {
			String key = (String) object;
			if (StringUtils.isNotBlank(key)) {
				propertiesNames.addItem(key);
			}
		}
		propertiesNames.setVisible(true);
	}

	private void cleanPropertiesList() {
		propertiesNames.removeAllItems();
		propertiesNames.setVisible(false);
	}

	public void debug(Object o) {
		setType(o);
		if (o instanceof Throwable) {
			StringWriter theStringWriter = new StringWriter();
			((Throwable) o).printStackTrace(new PrintWriter(theStringWriter));
			if (fTaskEditor == null)
				appendText(theStringWriter.toString());
		} else {
			if (fTaskEditor == null)
				appendText(o);
		}
	}

	public void debug(Object o, Throwable aThrowable) {
		setType(o);
		if (fTaskEditor == null) {
			appendText(o);

			StringWriter theStringWriter = new StringWriter();
			aThrowable.printStackTrace(new PrintWriter(theStringWriter));
			appendText(theStringWriter.toString());
		}

	}

	public void error(Object o) {
		setType(o);
		if (fTaskEditor == null)
			appendText(o);
	}

	public void error(Object o, Throwable aThrowable) {
		setType(o);
		if (fTaskEditor == null) {
			appendText(o);
			StringWriter theStringWriter = new StringWriter();
			aThrowable.printStackTrace(new PrintWriter(theStringWriter));
			appendText(theStringWriter.toString());
		}
	}

	public void warn(Object o) {
		setType(o);
		if (fTaskEditor == null)
			appendText(o);
	}

	synchronized private void appendText(Object o) {
		this.originData = o;
		cleanPropertiesList();

		LogRecord record = (LogRecord) o;
		String type = record.getType();

		Object message = record.getMessage();
		if (message instanceof Map && !"json".equals(type)) {
			Map propertiesData = (Map) ((LogRecord) o).getMessage();
			setPropertiesList(propertiesData.keySet());
		}

		print();
	}

	private void print() {
		fLogTextArea.setText("");
		if (originData instanceof LogRecord) {
			LogRecord rec = (LogRecord) originData;
			Object data = rec.getMessage();

			String type = getType();
			if (data instanceof Map && !"json".equals(type)) {
				data = ((Map) data).get(propertiesNames.getSelectedItem());
			}

			String text;
			
			if (data instanceof byte[]) {
				try {
					text = new String((byte[]) data, "UTF-8");
				} catch (UnsupportedEncodingException e) {
					throw new IllegalArgumentException(e);
				}
			} else if (data != null && data.getClass().isArray()) {
				Object[] array = (Object[]) data;
				text = ArrayUtils.toString(array);

			} else if (data != null && data instanceof List) {
				text = StringUtils.join((List) data, "\n");

			} else if ("json".equals(type)) {
				if (data instanceof Map) {
					text = new JSONObject((Map) data).toString();
				} else {
					text = ObjectUtils.toString(data, "<null>");
				}
			} else {
				text = ObjectUtils.toString(data, "<null>");
			}

			fLogTextArea.append(text);

		} else {

			fLogTextArea.append(ObjectUtils.toString(originData));
		}
		int lastIndexOf = fLogTextArea.getText().lastIndexOf('\n');

		fLogTextArea.append("\n");

		if (fTaskEditor != null && fLogToEnd.isSelected()) {
			if (lastIndexOf > 0)
				fLogTextArea.setCaretPosition(lastIndexOf + 1);
		}

		fLogTextArea.setCaretPosition(0);
	}

	public String getType() {
		return (String) TextLoggPanel.this.typeBox.getSelectedItem();
	}

	public void warn(Object o, Throwable aThrowable) {
		setType(o);
		if (fTaskEditor == null)
			appendText(o);
		StringWriter theStringWriter = new StringWriter();
		aThrowable.printStackTrace(new PrintWriter(theStringWriter));
		appendText(theStringWriter.toString());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.maxbill.maxtest.LoggPaneli#getPanel()
	 */
	public JPanel getPanel() {
		return fPanel;
	}

	public void findText(String text) {
		int indexOf = fLogTextArea.getText().indexOf(text, fLogTextArea.getCaretPosition() + 1);
		if (indexOf > 0) {
			fLogTextArea.setCaretPosition(indexOf);
			fLogTextArea.setSelectionStart(indexOf);
			fLogTextArea.setSelectionEnd(indexOf + text.length());
			fLogTextArea.requestFocus(true);
		} else
			JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(theLogPanel),
					"Text: \"" + text + "\" is not found.");
	}

	public void setEnabled(boolean enabled) {
		if (enabled == false)
			fLogTextArea.setBackground(Color.lightGray);
		else
			fLogTextArea.setBackground(Color.white);
	}

	public void clear() {
		fLogTextArea.setText("");
	}

	public JComponent getLogTextArea() {
		return fLogTextArea;
	}

	public static void openFile(Object originData, String type) throws IOException {

		switch (StringUtils.upperCase(type)) {
		case "URL":
			try {
				String string = ObjectUtils.toString(originData, "");
				URL url = new URL(string);
				URI uri = url.toURI();
				openWebpage(uri);
			} catch (URISyntaxException e) {
				new IOException(e);
			}
			break;

		case "URI":
			try {
				openWebpage(new URI(ObjectUtils.toString(originData, "")));
			} catch (URISyntaxException e) {
				new IOException(e);
			}
			break;

		case "PATH":
			Desktop.getDesktop().open(new File(ObjectUtils.toString(originData, "").trim()));
			break;

		default:
			File file = File.createTempFile("anteater", "." + StringUtils.defaultString(type, "txt"));
			byte[] data;
			if (originData instanceof LogRecord) {
				Object logdata = ((LogRecord) originData).getMessage();
				if (logdata instanceof byte[]) {
					data = (byte[]) logdata;
				} else {
					data = ((LogRecord) originData).toString().getBytes();
				}
			} else {
				data = ObjectUtils.toString(originData).getBytes();
			}

			FileOutputStream output = new FileOutputStream(file);
			IOUtils.write(data, output);
			output.flush();
			Desktop.getDesktop().open(file);
			output.close();
		}
	}

	public static void openWebpage(URI uri) {
		Desktop desktop = Desktop.isDesktopSupported() ? Desktop.getDesktop() : null;
		if (desktop != null && desktop.isSupported(Desktop.Action.BROWSE)) {
			try {
				desktop.browse(uri);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}