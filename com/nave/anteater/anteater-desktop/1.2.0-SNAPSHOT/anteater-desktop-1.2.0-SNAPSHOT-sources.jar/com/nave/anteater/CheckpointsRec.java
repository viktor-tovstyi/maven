package com.nave.anteater;

public class CheckpointsRec {

	public boolean state;
	public String name;
	public InputDialogType type;

	public CheckpointsRec(String name) {
		this.name = name;
	}

}
