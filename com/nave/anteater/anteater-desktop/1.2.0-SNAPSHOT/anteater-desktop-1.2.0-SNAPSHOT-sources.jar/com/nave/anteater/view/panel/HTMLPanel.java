package com.nave.anteater.view.panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.Properties;

import javax.swing.JEditorPane;
import javax.swing.JScrollPane;

import org.apache.commons.lang.ObjectUtils;

public class HTMLPanel extends PresentationPanel {

	private static final long serialVersionUID = 1L;
	private String fFrameId = null;
	private String fTitle = "";
	JEditorPane displayEditorPane = null;

	private Boolean append;

	private StringBuilder text = new StringBuilder();

	public HTMLPanel(Properties params) throws Exception {
		super(params);

		append = Boolean.valueOf(params.getProperty("append", "false"));

		displayEditorPane = new JEditorPane();
		displayEditorPane.setContentType("text/html");
		displayEditorPane.setEditable(false);
		add(new JScrollPane(displayEditorPane), BorderLayout.CENTER);
	}

	public String getFrameId() {
		return fFrameId;
	}

	public String getTitle() {
		return fTitle;
	}

	public void out(Object value, Properties properties) {
		if (append) {
			text.append(value);
		} else {
			text = new StringBuilder(ObjectUtils.toString(value));
		}

		if (displayEditorPane != null) {
			displayEditorPane.setText(text.toString());
		}
	}

	@Override
	public void setEnabled(boolean enabled) {
		setBackground(Color.lightGray);
		super.setEnabled(enabled);
	}

	public void start() {
	}

}