package com.nave.anteater.view;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.view.ListLoggPanel.LogRecord;

public interface MessageDescriptionPanel {

  public void setText(LogRecord text, TaskProcessor taskEditor);

}
