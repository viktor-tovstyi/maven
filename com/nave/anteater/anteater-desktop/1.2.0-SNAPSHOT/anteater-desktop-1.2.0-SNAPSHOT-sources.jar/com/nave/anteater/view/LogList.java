package com.nave.anteater.view;

import java.util.ArrayList;
import java.util.List;

import com.nave.anteater.view.ListLoggPanel.LogRecord;

public class LogList {

	private int logLevel;

	private List<LogRecord> debuglogs = new ArrayList<LogRecord>();
	private List<LogRecord> infologs = new ArrayList<LogRecord>();
	private List<LogRecord> warnlogs = new ArrayList<LogRecord>();
	private List<LogRecord> errorlogs = new ArrayList<LogRecord>();

	public LogList(int level) {
		logLevel = level;
	}

	public int getSize() {
		switch (logLevel) {
		case 3:
			return debuglogs.size();
		case 2:
			return infologs.size();
		case 1:
			return warnlogs.size();
		case 0:
			return errorlogs.size();

		default:
			return debuglogs.size();
		}
	}

	public LogRecord get(int index) {
		switch (logLevel) {
		case 3:
			return debuglogs.get(index);
		case 2:
			return infologs.get(index);
		case 1:
			return warnlogs.get(index);
		case 0:
			return errorlogs.get(index);

		default:
			return debuglogs.get(index);
		}
	}

	public void clear() {
		debuglogs.clear();
		infologs.clear();
		warnlogs.clear();
		errorlogs.clear();
	}

	synchronized public void add(LogRecord logRecord, boolean b) {
		
		int logLevel2 = logRecord.getLogLevel();
		switch (logLevel2) {
		case 0:
			if (b && errorlogs.size() > 50) {
				errorlogs.remove(0);
			}
			errorlogs.add(logRecord);
		case 1:
			if (b && warnlogs.size() > 50) {
				warnlogs.remove(0);
			}
			warnlogs.add(logRecord);
		case 2:
			if (b && infologs.size() > 50) {
				infologs.remove(0);
			}
			infologs.add(logRecord);
		default:
			if (b && debuglogs.size() > 50) {
				debuglogs.remove(0);
			}
			debuglogs.add(logRecord);
		}
	}

	public void setLevel(int logLevel) {
		this.logLevel = logLevel;
	}

}
