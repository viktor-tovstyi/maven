package com.nave.anteater.view;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;

import com.nave.anteater.AEFrame;
import com.nave.anteater.AEPanel;
import com.nave.anteater.util.xml.easyparser.EasyUtils;
import com.nave.anteater.util.xml.easyparser.Node;

public class ConfigurationEditor extends JPanel implements AEPanel {

	private static final long serialVersionUID = 1L;

	private JTextArea resultConfiguration;

	private ConfigurationPanel configuration;

	private AEFrame aeFrame;

	private JScrollPane scrollPane;

	public ConfigurationEditor(AEFrame aeFrame) {
		super(new BorderLayout());

		this.aeFrame = aeFrame;
		setLayout(new BorderLayout(4, 4));
		resultConfiguration = new JTextArea();
		resultConfiguration.setEditable(false);

		configuration = new ConfigurationPanel(aeFrame);
		scrollPane = new JScrollPane(configuration);

		JTabbedPane panel = new JTabbedPane();
		panel.addTab("Predefined", scrollPane);
		panel.addTab("Current", new JScrollPane(resultConfiguration));

		add(panel, BorderLayout.CENTER);
	}

	public JPanel getMainPanel() {
		return this;
	}

	public String getPanelName() {
		return "Configuration";
	}

	@Override
	public void setVisible(boolean aFlag) {
		refreshActiveConfig();
		super.setVisible(aFlag);
	}

	public void refreshActiveConfig() {
		Node configNode = aeFrame.getWorkspace().getConfigNode();
		EasyUtils.removeTagId(configNode);
		resultConfiguration.setText(configNode.getXMLText());
		try {
			configNode = aeFrame.getWorkspace().getAllConfigNode();
			configuration.setConfigNode(configNode);
			invalidate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void showPanel(JTabbedPane panel, String name) {
		if (name == null) {
			name = getPanelName();
		}
		panel.addTab(getPanelName(), this);
		panel.setSelectedComponent(this);
		panel.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
	}

}
