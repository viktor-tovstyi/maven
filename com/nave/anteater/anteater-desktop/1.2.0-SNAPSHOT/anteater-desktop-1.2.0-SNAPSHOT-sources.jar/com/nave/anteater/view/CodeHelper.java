package com.nave.anteater.view;

import java.awt.Color;
import java.awt.FileDialog;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import javax.swing.AbstractAction;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JToolTip;
import javax.swing.SwingUtilities;

import org.apache.commons.lang.ClassUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.nave.anteater.AEWorkspace;
import com.nave.anteater.OperationHolder;
import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.processor.annotation.Attr;
import com.nave.anteater.processor.annotation.Command;
import com.nave.anteater.processor.annotation.CommandExamples;
import com.nave.anteater.processor.annotation.CommandHotHepl;
import com.nave.anteater.processor.annotation.Value;
import com.nave.anteater.util.xml.easyparser.EasyParser;
import com.nave.anteater.util.xml.easyparser.Node;

public class CodeHelper extends KeyAdapter {

	public static final Font POPUP_MENU_FONT = new Font("Arial", Font.PLAIN, 9);
	private AeEditPanel editor;
	private Logger log;

	public CodeHelper(AeEditPanel editor, Logger log) {
		this.editor = editor;
		this.log = log;
	}

	@Override
	public void keyPressed(KeyEvent e) {

		if (e.getKeyCode() == KeyEvent.VK_S && e.isControlDown()) {
			editor.save();
		} else if (e.getKeyCode() == KeyEvent.VK_D && e.isControlDown()) {
			editor.getEditor().removeLine();
		} else if (e.getKeyCode() == KeyEvent.VK_F9) {
			editor.runTask();
		} else if (e.getKeyCode() == KeyEvent.VK_F && e.isControlDown()) {
			editor.format();
		} else if (e.getKeyCode() == KeyEvent.VK_SPACE && e.isControlDown()) {

			String text = editor.getText();
			int curpos = editor.getCaretPosition();

			TaskProcessor makeProcessor = editor.getTaskProcessor();
			String substring = StringUtils.substring(text, 0, curpos);
			int startExternTag = StringUtils.lastIndexOf(substring, "<Extern");
			int endExternTag = StringUtils.indexOf(substring, '>', startExternTag);
			String externTag = StringUtils.substring(substring, startExternTag, endExternTag);

			if (StringUtils.isNotBlank(externTag)) {
				externTag = externTag + "/>";
				try {
					Node externNode = new EasyParser().getObject(externTag);
					makeProcessor = makeProcessor.makeProcessor(externNode);

				} catch (Exception e1) {
					log.error("XML parsiong failed.", e1);
				}
			}

			String theStartCommand = null;
			String theStartMacroIns = null;

			for (int i = curpos - 1; i >= 0; i--) {
				char charAt = text.charAt(i);
				if (charAt == ' ') {
					break;

				} else if (charAt == '<') {
					theStartCommand = text.substring(i + 1, curpos);

					break;
				} else if (charAt == '$') {
					theStartMacroIns = text.substring(i + 1, curpos);
					break;
				}
			}

			JDialogPopupMenu menu = new JDialogPopupMenu(editor.getComponent());
			menu.setAutoscrolls(true);

			if (theStartCommand != null) {
				showCommandPopupMenu(theStartCommand, menu, makeProcessor);

			}
			if (theStartMacroIns != null) {
				showMacroPopupMenu(theStartMacroIns, menu);

			} else {
				menu = editor.contextHelp(e, menu);
			}
			Point magicCaretPosition = editor.getMagicCaretPosition();
			if (magicCaretPosition == null)
				magicCaretPosition = new Point();
			menu.show(editor.getComponent(), magicCaretPosition.x, magicCaretPosition.y);
		}
	}

	private void showMacroPopupMenu(final String theStartMacroIns, JDialogPopupMenu menu) {

		JMenuItem menuItem = new JMenuItem("$var{type:property,type:data}");
		if ("var{".startsWith(theStartMacroIns))
			menu.add(menuItem);
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Node object;
				try {
					object = new EasyParser()
							.getObject("<Data variable_name='type:property' default_value='type:data'/>");
					parsingCommandPParamters(object);
					String theStartMacroIns = getStartMacroIns();
					insertText(theStartMacroIns, "$var{" + object.getAttribute("variable_name") + ","
							+ object.getAttribute("default_value") + "}");
				} catch (Exception e1) {
					log.error("XML parsiong failed.", e1);
				}
			}
		});

		menuItem = new JMenuItem("$tag{type:property,type:data}");
		if ("var{".startsWith(theStartMacroIns))
			menu.add(menuItem);
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Node object;
				try {
					object = new EasyParser()
							.getObject("<Data variable_name='type:property' default_value='type:data'/>");
					parsingCommandPParamters(object);

					String theStartMacroIns = getStartMacroIns();

					insertText(theStartMacroIns, "$tag{" + object.getAttribute("variable_name") + ","
							+ object.getAttribute("default_value") + "}");
				} catch (Exception e1) {
					log.error("XML parsiong failed.", e1);
				}
			}
		});

		if ("call{".startsWith(theStartMacroIns))
			menuItem = new JMenuItem("$call{type:task,type:data}");
		menu.add(menuItem);
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Node object;
				try {
					object = new EasyParser().getObject("<Data task_name='type:task'/>");
					parsingCommandPParamters(object);
					insertText(getStartMacroIns(), "$call{" + object.getAttribute("task_name") + ",RETURN}");
				} catch (Exception e1) {
					log.error("XML parsiong failed.", e1);
				}
			}
		});

		if ("file{".startsWith(theStartMacroIns))
			menuItem = new JMenuItem("$file{type:path}");
		menu.add(menuItem);
		menuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Node object;
				try {
					object = new EasyParser().getObject("<Data file_name='type:path'/>");
					parsingCommandPParamters(object);
					insertText(getStartMacroIns(), "$file{" + object.getAttribute("file_name") + "}");
				} catch (Exception e1) {
					log.error("XML parsiong failed.", e1);
				}
			}
		});

	}

	private JPopupMenu showCommandPopupMenu(final String theStartCommand, JPopupMenu menu,
			TaskProcessor makeProcessor) {

		Class class1 = makeProcessor.getClass();

		Method[] methods = class1.getMethods();

		Map<Class, List<String>> namesMap = new LinkedHashMap<>();
		for (int i = 0; i < methods.length; i++) {
			Method method = methods[i];
			if (StringUtils.startsWith(method.getName(), "runCommand") || method.getAnnotation(Command.class) != null) {
				Class<?> declaringClass = method.getDeclaringClass();

				String name = StringUtils.substringAfter(method.getName(), "runCommand");
				if (StringUtils.isEmpty(name) && method.getAnnotation(Command.class) != null) {
					name = StringUtils.capitalize(method.getName());
				}

				if (name.startsWith(theStartCommand) == false)
					continue;

				if (ClassUtils.isAssignable(declaringClass, TaskProcessor.class)) {
					List<String> list = namesMap.get(declaringClass);
					if (list == null) {
						list = new ArrayList<String>();
						namesMap.put(declaringClass, list);
					}
					list.add(name);
				}
			}
		}

		Set<Class> keySet = namesMap.keySet();
		boolean first = true;
		for (Class processor : keySet) {
			List<String> list = namesMap.get(processor);
			String[] names = list.toArray(new String[list.size()]);

			String name = processor.getName();
			if (StringUtils.equals(name, TaskProcessor.class.getName())) {
				name = "Default Processor";
			}

			if (first) {
				first = false;
				List<JMenu> createPopupMenu = createPopupMenu(theStartCommand, processor, names);
				for (JMenu jMenu : createPopupMenu) {
					menu.add(jMenu);
				}

			} else {

				JMenu popupMenu = new JMenu(name);
				List<JMenu> createPopupMenu = createPopupMenu(theStartCommand, processor, names);
				for (JMenu jMenu : createPopupMenu) {
					popupMenu.add(jMenu);
				}

				popupMenu.setFont(POPUP_MENU_FONT);
				popupMenu.setForeground(Color.BLUE.darker());
				menu.add(popupMenu);

			}

		}
		return menu;

	}

	private List<JMenu> createPopupMenu(final String theStartCommand, Class class1, String[] names) {
		List<JMenu> menu = new ArrayList<JMenu>();
		Arrays.sort(names);
		for (final String name : names) {
			String[] examples = null;
			try {
				Method method = null;
				try {
					method = class1.getMethod("runCommand" + name, new Class[] { Node.class });
					CommandExamples annotation = method.getAnnotation(CommandExamples.class);
					if (annotation != null) {
						examples = annotation.value();
					}

				} catch (NoSuchMethodException e) {
					String mName = StringUtils.uncapitalize(name);
					Method[] methods = class1.getMethods();
					for (Method m : methods) {
						if (StringUtils.equals(mName, m.getName()) && m.getAnnotation(Command.class) != null) {
							method = m;
							break;
						}
					}

					StringBuilder examplesBuffer = new StringBuilder("<" + name);
					Annotation[][] parameterAnnotations = method.getParameterAnnotations();
					for (Annotation[] annotations : parameterAnnotations) {
						if (annotations[0] instanceof Attr) {
							Attr attr = (Attr) annotations[0];
							examplesBuffer.append(" ");
							examplesBuffer.append(attr.value());
							examplesBuffer.append("='");
							examplesBuffer.append(StringUtils.defaultIfBlank(attr.defaultValue(), "type:string"));
							examplesBuffer.append("'");
						}
						if (annotations[0] instanceof Value) {
							Value attr = (Value) annotations[0];
							examplesBuffer.append(" ");
							examplesBuffer.append(attr.attrName());
							examplesBuffer.append("='");
							examplesBuffer.append(StringUtils.defaultIfBlank(attr.defaultName(), "type:property"));
							examplesBuffer.append("'");
						}
					}
					examplesBuffer.append("/>");
					examples = new String[] { examplesBuffer.toString() };
				}

				CommandHotHepl hotHelp = method.getAnnotation(CommandHotHepl.class);

				if (examples != null) {

					JMenu popupMenu = new JMenu(name) {
						public JToolTip createToolTip() {
							return new JDialogPopupMenu.JMultiLineToolTip();
						}
					};

					if (hotHelp != null)
						popupMenu.setToolTipText(hotHelp.value());
					menu.add(popupMenu);

					for (String example : examples) {
						JMenuItem item = new JMenuItem(example);
						item.addActionListener(new AbstractAction(example) {

							public void actionPerformed(ActionEvent arg0) {
								insertTag(theStartCommand, arg0.getActionCommand());
							}

						});
						item.setFont(new Font("Arial", Font.ITALIC, 9));
						popupMenu.add(item);
					}
					popupMenu.setFont(POPUP_MENU_FONT);
				}

			} catch (Exception e1) {
				log.error("Popup menu creation failed.", e1);
			}
		}

		return menu;
	}

	private void insertTag(final String theStartCommand, String text) {
		try {
			Node object = new EasyParser().getObject("<example>" + text + "</example>");
			parsingCommandPParamters(object);
			StringBuilder code = new StringBuilder();
			for (Node node : object) {
				code.append(node.getXMLText());
			}
			insertText(theStartCommand, code.toString());
		} catch (Exception e) {
			log.error("Tag wizard failed.", e);
			JOptionPane.showMessageDialog(JOptionPane.getRootFrame(), e.getMessage());
		}
	}

	private void parsingCommandPParamters(Node example) {
		Properties attributes = new Properties();

		for (Node object : example) {
			for (Object name : object.getAttributes().keySet()) {
				String attribute = object.getAttribute((String) name);
				String theName = ((String) name).replace('_', ' ');
				if (attribute.startsWith("type:")) {
					attribute = attribute.substring(5);
					if (attribute.equals("integer")) {
						boolean valid = true;
						do {
							attribute = JOptionPane.showInputDialog(SwingUtilities.getRootPane(editor.getComponent()),
									"Type: " + attribute + "\nParameter: " + theName);
							if (attribute == null) {
								return;
							}

							object.setAttribute((String) name, attribute);

						} while (valid == false);

					} else if (attribute.equals("operation")) {
						Map<String, OperationHolder> operationsMethods = AEWorkspace.getInstance()
								.getOperationsMethods();
						Set<String> keySet = operationsMethods.keySet();
						showListDialog(object, name, attribute, keySet.toArray(), false, "Operations:");
						String operationName = object.getAttribute("method");
						if (!StringUtils.isEmpty(operationName)) {
							OperationHolder operationsMethod = AEWorkspace.getInstance()
									.getOperationsMethod(operationName);
							object.setAttribute("description", operationsMethod.getDescription());
							TaskProcessor processor = editor.getTaskProcessor();
							Object[] array = processor.getVariables().keySet().toArray();
							Class<?> returnType = operationsMethod.getMethod().getReturnType();
							if (returnType != void.class) {
								object.setAttribute("name", "type:property");

								if (!showListDialog(object, "name", "property", array, true, "Return: "
										+ operationsMethod.getReturnDescription() + "\nSelect variable name:")) {
									return;
								}
								;
							}

							Class<?>[] parameterTypes = operationsMethod.getMethod().getParameterTypes();
							for (int i = 0; i < parameterTypes.length; i++) {
								String type = parameterTypes[i].getName();

								object.setAttribute("arg" + (i + 1), type);
								String value = (String) JOptionPane.showInputDialog(
										SwingUtilities.getRootPane(editor.getComponent()),
										"Type: " + type + "\nParameter: " + operationsMethod.getParameterName(i),
										"Input parameter", JOptionPane.INFORMATION_MESSAGE, null, null, null);
								if (attribute == null) {
									return;
								}

								object.setAttribute("arg" + (i + 1), value);
							}
						}
						return;
					} else if (attribute.equals("attr")) {
						attribute = attributes.getProperty(theName);
						object.setAttribute((String) name, attribute);
					} else if (attribute.equals("string")) {
						attribute = JOptionPane.showInputDialog(SwingUtilities.getRootPane(editor.getComponent()),
								"Parameter: " + theName + "\nType: string", "");
						if (attribute == null) {
							return;
						}
						object.setAttribute((String) name, attribute);
					} else if (attribute.equals("integer")) {
						attribute = JOptionPane.showInputDialog(SwingUtilities.getRootPane(editor.getComponent()),
								"Parameter: " + theName + "\nType: integer", "");
						if (attribute == null) {
							return;
						}
						object.setAttribute((String) name, attribute);
					} else if (attribute.equals("double")) {
						attribute = JOptionPane.showInputDialog(SwingUtilities.getRootPane(editor.getComponent()),
								"Parameter: " + theName + "\nType: double", "");
						if (attribute == null) {
							return;
						}
						object.setAttribute((String) name, attribute);
					} else if (attribute.equals("property")) {
						TaskProcessor processor = editor.getTaskProcessor();
						if (processor == null)
							processor = new TaskProcessor(editor.getManager(), log, editor.getManager().getStartDir());
						if (!showListDialog(object, name, attribute, processor.getVariables().keySet().toArray(),
								true)) {
							return;
						}
					} else if (attribute.equals("data")) {
						TaskProcessor processor = editor.getTaskProcessor();
						if (processor == null)
							processor = new TaskProcessor(editor.getManager(), log, editor.getManager().getStartDir());
						attribute = JOptionPane.showInputDialog(SwingUtilities.getRootPane(editor.getComponent()),
								"Parameter: " + theName, "");
						if (attribute == null) {
							return;
						}
						object.setAttribute((String) name, attribute);
					} else if (attribute.equals("soap")) {
						if (!showListDialog(object, name, attribute, editor.getManager().getSoapNamesList(), true)) {
							return;
						}
					} else if (attribute.equals("task")) {
						if (!showListDialog(object, name, attribute, editor.getManager().getTestsList(), true)) {
							return;
						}
					} else if (attribute.equals("path")) {
						FileDialog theFileDialog = new FileDialog(JOptionPane.getRootFrame(), "Input path",
								FileDialog.LOAD);
						String absolutePath = editor.getTaskProcessor().getBaseDir().getAbsolutePath();
						theFileDialog.setDirectory(absolutePath);
						theFileDialog.setVisible(true);
						if (theFileDialog.getFile() != null) {
							String prefDir = theFileDialog.getDirectory();
							if (theFileDialog.getDirectory().startsWith(absolutePath)) {
								prefDir = prefDir.substring(absolutePath.length() + 1, prefDir.length());
							}
							object.setAttribute((String) name, prefDir + theFileDialog.getFile());
						}
					}

				} else if (attribute.startsWith("choice:")) {
					attribute = attribute.substring(7);
					StringTokenizer stringTokenizer = new StringTokenizer(attribute, "|");
					String[] choiceArray = new String[stringTokenizer.countTokens()];
					for (int i = 0; i < choiceArray.length; i++) {
						choiceArray[i] = stringTokenizer.nextToken();
					}
					if (!showListDialog(object, name, attribute, choiceArray, false)) {
						return;
					}
				}
			}
			attributes.putAll(object.getAttributes());
		}
	}

	private String getStartMacroIns() {
		int curpos = editor.getCaretPosition();
		String text = editor.getText();
		String theStartMacroIns = null;

		int i;
		for (i = curpos - 1; i >= 0; i--) {
			char charAt = text.charAt(i);

			if (charAt == '$') {
				theStartMacroIns = text.substring(i + 1, curpos);
				break;
			}
		}

		return (i > curpos - 7) ? theStartMacroIns : "";
	}

	private void insertText(String theStartCommand, String text) {
		int caretPosition2 = editor.getCaretPosition();
		int i = caretPosition2 - theStartCommand.length() - 1;
		editor.replaceRange(text, i, caretPosition2);
	}

	private boolean showListDialog(Node object, Object name, String attribute, Object[] sourceList, boolean b) {
		return showListDialog(object, name, attribute, sourceList, b, null);
	}

	private boolean showListDialog(Node object, Object name, String attribute, Object[] sourceList, boolean b,
			String description) {

		String type = attribute;

		Arrays.sort(sourceList);
		String newValueTitle = "<New value>";
		Object[] list = null;

		if (b) {
			list = new Object[sourceList.length + 1];
			list[0] = newValueTitle;

			for (int i = 0; i < sourceList.length; i++) {
				list[i + 1] = sourceList[i];
			}
		} else {
			list = sourceList;
		}

		String prefix = "Parameter: ";

		String message = StringUtils.defaultString(description, prefix + name + ", Type: " + type);

		attribute = (String) JOptionPane.showInputDialog(SwingUtilities.getRootPane(editor.getComponent()), message,
				"Input command attribute.", JOptionPane.INFORMATION_MESSAGE, null, list, newValueTitle);
		if (attribute == null) {
			return false;
		}

		if (newValueTitle.equals(attribute)) {
			attribute = JOptionPane.showInputDialog(SwingUtilities.getRootPane(editor.getComponent()),
					prefix + name + ", Type: " + type, "");
			if ("property".equals(type)) {
				editor.getTaskProcessor().setVariableValue(attribute, "<not-initialized>");
			}
		}

		object.setAttribute((String) name, attribute);
		return true;
	}

}
