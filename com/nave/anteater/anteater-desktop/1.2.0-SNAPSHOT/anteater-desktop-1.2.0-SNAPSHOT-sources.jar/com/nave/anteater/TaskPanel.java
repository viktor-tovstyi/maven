package com.nave.anteater;

import java.awt.BorderLayout;

import javax.swing.JPanel;

public class TaskPanel extends JPanel {

	private static final long serialVersionUID = -6223270300452300794L;

	private TaskEditor taskEditor;

	public TaskPanel(TaskEditor taskEditor) {
		super(new BorderLayout());
		this.taskEditor = taskEditor;
	}

	public TaskEditor getTaskEditor() {
		return taskEditor;
	}

}
