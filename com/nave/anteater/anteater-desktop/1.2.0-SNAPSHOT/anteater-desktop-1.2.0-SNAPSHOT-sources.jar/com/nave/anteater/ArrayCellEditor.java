package com.nave.anteater;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.swing.AbstractCellEditor;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.TableCellEditor;

import org.apache.commons.lang.StringUtils;

public class ArrayCellEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {

	private static final long serialVersionUID = 1L;
	private Object data = new ArrayList<>();

	public ArrayCellEditor(AEFrame frame) {
	}

	@Override
	public Object getCellEditorValue() {
		return data;
	}

	@Override
	public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
		data = value;
		if (value instanceof List) {
			JComboBox<String> combo = new JComboBox<String>();
			List<String> data = (List<String>) value;
			for (String str : data) {
				combo.addItem(str);
			}
			combo.addActionListener(this);
			return combo;
		} else if (value instanceof Map) {
			return new JTextField(value.toString());
		}

		return new JTextField((String) data);
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		JComboBox<String> value = (JComboBox<String>) event.getSource();
		String selected = (String) value.getSelectedItem();

		int itemCount = value.getItemCount();
		data = new ArrayList<>();
		((List) data).add(selected);
		for (int i = 0; i < itemCount; i++) {
			String itemAt = value.getItemAt(i);
			if (!StringUtils.equals(selected, itemAt)) {
				((List) data).add(itemAt);
			}
		}

	}

}