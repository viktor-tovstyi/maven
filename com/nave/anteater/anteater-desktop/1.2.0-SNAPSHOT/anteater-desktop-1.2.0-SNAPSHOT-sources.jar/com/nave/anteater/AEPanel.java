package com.nave.anteater;

import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public interface AEPanel {

	JPanel getMainPanel();

	String getPanelName();

	void showPanel(JTabbedPane panel, String name);

}
