package com.nave.anteater.view;

import javax.swing.JPanel;
import org.apache.log4j.Logger;

abstract public class LoggPanel extends Logger{

  protected LoggPanel(String arg0) {
    super(arg0);
  }

  public abstract JPanel getPanel();

  public abstract void setEnabled(boolean b); 

}