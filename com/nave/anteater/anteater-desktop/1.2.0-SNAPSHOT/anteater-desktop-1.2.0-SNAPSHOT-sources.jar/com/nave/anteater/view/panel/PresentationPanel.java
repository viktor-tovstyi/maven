package com.nave.anteater.view.panel;

import java.awt.BorderLayout;
import java.util.Properties;

import javax.swing.JPanel;

public abstract class PresentationPanel extends JPanel {

	private static final long serialVersionUID = 6840549038631221985L;
	private String frameId;

	public PresentationPanel(Properties params) {
		super(new BorderLayout());
		frameId = params.getProperty("frameId");
	}

	public abstract void out(Object value, Properties properties);

	public Object getFrameId() {
		return frameId;
	}
}
