package com.nave.anteater.view.panel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.util.Properties;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.UnknownKeyException;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class XYLineChart extends PresentationPanel {
	private static final long serialVersionUID = 1L;

	private XYSeriesCollection dataset;
	private JFreeChart chart = null;

	public XYLineChart(Properties params) throws Exception {
		super(params);
		String title = params.getProperty("title");
		String xAxisLabel = params.getProperty("xAxisLabel");
		String yAxisLabel = params.getProperty("yAxisLabel");

		dataset = new XYSeriesCollection();
		chart = ChartFactory.createXYLineChart(title, xAxisLabel, yAxisLabel, dataset, PlotOrientation.VERTICAL, true,
				true, false);

		chart.setBackgroundPaint(Color.white);
		add(new ChartPanel(chart, false), BorderLayout.CENTER);
	}

	public void start() {
	}

	synchronized public void out(Object data, Properties properties) {
		String seriesAttr = properties.getProperty("series");
		XYSeries series;

		if (seriesAttr == null) {
			if (dataset.getSeriesCount() == 0) {
				series = new XYSeries("data");
				dataset.addSeries(series);
			} else {
				series = dataset.getSeries(0);
			}
		} else {
			try {
				series = dataset.getSeries(seriesAttr);
			} catch (UnknownKeyException e) {
				series = new XYSeries(seriesAttr);
				dataset.addSeries(series);
			}
		}

		double theX = 0;
		String xAttr = properties.getProperty("x");
		if (xAttr == null) {
			theX = series.getItemCount();
		} else {
			theX = Double.parseDouble(xAttr);
		}
		try {
			if (data instanceof String) {
				double theY = Double.parseDouble((String) data);
				series.add(theX, theY);
			}
		} catch (Exception e) {
			throw new IllegalArgumentException("Invalide output data: " + data, e);
		}
	}
}