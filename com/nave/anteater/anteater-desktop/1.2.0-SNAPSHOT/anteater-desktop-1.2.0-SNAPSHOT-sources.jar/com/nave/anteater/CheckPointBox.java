package com.nave.anteater;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JCheckBox;
import javax.swing.JMenuItem;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.nave.anteater.view.JDialogPopupMenu;

public class CheckPointBox extends JCheckBox implements ChangeListener {

	public static final String CHECKPOINT_PREFIX = "CheckPoint";

	private static final long serialVersionUID = -3670107773808535274L;

	private static final String ALWAYS_SHOW_NOTIFICATIONS = "Check point";

	private String name;

	private AEFrame aeFrame;

	private InputDialogType type;

	private Color bgColor;

	public CheckPointBox(String propertyName, AEFrame aeFrame, InputDialogType type) {
		super(ALWAYS_SHOW_NOTIFICATIONS);
		this.type = type;
		name = propertyName;
		this.aeFrame = aeFrame;
		setEnabled(true);
		addChangeListener(this);

		Boolean valueOf = getCheckPointFlag(type, name);
		if (valueOf != null) {
			setSelected(valueOf);
		}

		applyBackgroungColor();
		addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 1 && e.getButton() == MouseEvent.BUTTON3) {
					showPopupMenu(e);
				}
			}

		});
	}

	private void showPopupMenu(MouseEvent e) {
		JDialogPopupMenu fPopupMenu = new JDialogPopupMenu(this);
		JMenuItem theJMenuItem = new JMenuItem("Toggle '" + AEFrame.TAKE_IT_EASY + "'");
		theJMenuItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				aeFrame.setConsoleDefaultInput(!aeFrame.isConsoleDefaultInput());
			}
		});
		fPopupMenu.add(theJMenuItem);
		fPopupMenu.show(this, e.getX(), e.getY());
	}

	public void saveCheckpointFlag() {
		boolean selected = isSelected();
		setCheckPointFlag(type, name, selected);
	}

	private void applyBackgroungColor() {
		if (this.bgColor == null) {
			bgColor = getBackground();
		}
		setBackground(isSelected() ? new Color(0xe4696a) : bgColor);
	}

	public static Boolean getCheckPointFlag(InputDialogType type, String name) {

		CheckpointsDialog instance = CheckpointsDialog.getInstance();
		if (instance != null) {
			instance.updated(type, name);
		}

		AEWorkspace aeWorkspace = AEWorkspace.getInstance();
		String propertyName = CHECKPOINT_PREFIX + "." + type + "." + name;
		String checkPoint = aeWorkspace.getDefaultUserConfiguration(propertyName, null);

		Boolean valueOf = checkPoint == null ? null : Boolean.valueOf(checkPoint);
		return valueOf;
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		saveCheckpointFlag();
		applyBackgroungColor();
	}

	public static void setCheckPointFlag(InputDialogType type, String name, boolean selected) {
		AEWorkspace instance = AEWorkspace.getInstance();
		String propertyName = CHECKPOINT_PREFIX + "." + type + "." + name;
		String value = Boolean.toString(selected);
		instance.setDefaultUserConfiguration(propertyName, value);

	}

}
