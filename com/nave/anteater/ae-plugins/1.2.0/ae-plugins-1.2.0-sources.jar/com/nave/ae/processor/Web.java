package com.nave.ae.processor;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.map.LinkedMap;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.InvalidArgumentException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.WebDriver.Window;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.CapabilityType;

import com.nave.anteater.CommandException;
import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.processor.annotation.CommandExamples;
import com.nave.anteater.util.xml.easyparser.Node;

import junit.framework.TestCase;

public class Web extends TaskProcessor {

	private static final int ALERT_TIMEOUT = 500;
	private static final String DEFAULT_DRIVER_NAME = "default";
	private static final String WEB_DRIVER_TYPE_VAR_NAME = "WEB_DRIVER_TYPE";
	private static final String DEFAULT_DRIVER_TYPE = "gecko";

	private String driverName = DEFAULT_DRIVER_NAME;
	private long timeout = 1;
	private Web webParrentProcessor;

	private String type;
	private static Map<String, String> windowMap;

	public Web(TaskProcessor aParent) {
		super(aParent);
		webParrentProcessor = getWebParrentProcessor();
		if (webParrentProcessor != null) {
			setDriver(webParrentProcessor.getDriver());
			timeout = webParrentProcessor.timeout;
		}
	}

	private Web getWebParrentProcessor() {
		TaskProcessor parent = getParent();
		while (parent != null && !(parent instanceof Web)) {
			parent = parent.getParent();
		}
		if (parent != null && parent instanceof Web) {
			return (Web) parent;
		}
		return null;
	}

	@Override
	public void init(TaskProcessor aParent, Node action) throws CommandException {
		timeout = getTimeout(action);
		super.init(aParent, action);
		String name = attr(action, "name");
		driverName = StringUtils.defaultIfEmpty(name, driverName);

		if (getDriver() == null) {
			createDriver(action);
		}

		WebDriver driver = getDriver();

		String tab = attr(action, "tab");

		if (tab != null) {
			if (windowMap == null) {
				windowMap = new HashMap<>();
				String windowId = driver.getWindowHandle();
				windowMap.put(tab, windowId);

			} else {
				String windowId = windowMap.get(tab);
				if (windowId == null) {
					createTab(driver, tab);

				} else {
					try {
						Set<String> windowHandles = driver.getWindowHandles();
						if (windowHandles.contains(windowId)) {
							driver.switchTo().window(windowId);
						} else {
							try {
								createTab(driver, tab);
							} catch (NoSuchWindowException e) {
								e.printStackTrace();
								createDriver(action);
							}
						}
					} catch (WebDriverException e) {
						windowMap.clear();
						createDriver(action);
						e.printStackTrace();
					}

				}
			}
		}

		if (getDriver() != null) {
			try {
				Window window = getDriver().manage().window();
				if (window == null) {
					quiteDriver();
				}
				window.getSize();
			} catch (WebDriverException | NullPointerException e) {
				log.debug(e);
				quiteDriver();
			}
		}
	}

	private void createTab(WebDriver driver, String tab) {
		((JavascriptExecutor) driver).executeScript("window.open()");
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		String nameOrHandle = tabs.get(tabs.size() - 1);
		windowMap.put(tab, nameOrHandle);
		try {
			driver.switchTo().window(nameOrHandle);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void createDriver(Node action) throws CommandException {
		try {
			String driverPath = replaceProperties((String) getVariableValue("WEBDRIVER_PATH"));

			String driverType = getType(action);

			String driverFileName = null;
			if (SystemUtils.IS_OS_MAC) {
				driverFileName = driverType + "driver-macos";
			}
			if (SystemUtils.IS_OS_WINDOWS) {
				driverFileName = driverType + "driver.exe";
			}

			String absolutePath;
			if (driverPath == null) {
				File startDir = getListener().getManager().getFile(getBaseDir(), "plugins/" + driverFileName);
				if (!startDir.exists()) {
					startDir = getListener().getManager().getFile(
							new File((String) getVariableValue("HOME_WORKINGDIR")), "plugins/" + driverFileName);
				}
				absolutePath = startDir.getAbsolutePath();
			} else {
				absolutePath = new File(driverPath, "plugins/" + driverFileName).getAbsolutePath();
			}

			debug("Web driver: " + absolutePath);
			String webdriverPath = "webdriver." + driverType + ".driver";
			System.setProperty(webdriverPath, absolutePath);

			String driverClass = getDriverClassName(action);

			WebDriver driver;
			switch (driverType) {
			case "gecko":
				FirefoxOptions profile = new FirefoxOptions();
				profile.addPreference("plugin.state.flash", 2);
				profile.addPreference("dom.ipc.plugins.enabled.libflashplayer.so", true);
				profile.addPreference("plugins.click_to_play", false);
				profile.addPreference("plugins.hide_infobar_for_outdated_plugin", true);

				driver = new FirefoxDriver(profile);
				break;

			case "chrome":
				ChromeOptions chromeOptions = new ChromeOptions();

				String value = action.getAttribute("deviceName");
				if (StringUtils.isNotBlank(value)) {
					Map<String, String> mobileEmulation = new HashMap<>();
					mobileEmulation.put("deviceName", value);
					chromeOptions.setExperimentalOption("mobileEmulation", mobileEmulation);
				}
				chromeOptions.addArguments("--no-sandbox");
				chromeOptions.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
				chromeOptions.addArguments("ignore-certificate-errors");

				driver = new ChromeDriver(chromeOptions);
				break;

			default:
				driver = (WebDriver) Class.forName(driverClass).newInstance();
				break;
			}

			setDriver(driver);

		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			throw new CommandException(e, this);
		}
	}

	private String getDriverClassName(Node action) {
		type = getType(action);

		String defaultDriverClass = null;
		switch (type) {
		case "chrome":
			defaultDriverClass = "org.openqa.selenium.chrome.ChromeDriver";
			break;

		default:
			defaultDriverClass = "org.openqa.selenium.firefox.FirefoxDriver";
			break;
		}

		String driverClass = StringUtils.defaultIfEmpty(attr(action, "driver"), defaultDriverClass);
		return driverClass;
	}

	private String getType(Node action) {
		String defaultDriverType = getParentDriverType();
		String driverType = StringUtils.defaultIfBlank(attr(action, "type"), defaultDriverType);
		return driverType;
	}

	private String getParentDriverType() {
		String type = null;
		Web parent = getWebParrentProcessor();
		if (parent != null) {
			type = parent.getType();
		}
		if (type == null) {
			type = StringUtils.defaultIfBlank((String) getVariableString(WEB_DRIVER_TYPE_VAR_NAME),
					DEFAULT_DRIVER_TYPE);
		}
		return type;
	}

	private String getType() {
		return type;
	}

	private boolean checkAuthAllert(Node action, long millisecond) {
		String username = attr(action, "username");
		boolean alertAccepted = false;
		if (StringUtils.isNotBlank(username)) {
			String password = attr(action, "password");
			for (int i = 0; i < millisecond && !isStoppedTest(); i += 100) {
				sleep(100);
				try {
					Alert alert = getDriver().switchTo().alert();
					alert.sendKeys(username + Keys.TAB + password);
					getDriver().switchTo().alert().accept();
					alertAccepted = true;
				} catch (Exception e) {
					// TODO: do nothing
				}
			}
		}
		return alertAccepted;
	}

	private void sleep(long millisecond) {
		try {
			Thread.sleep(millisecond);
		} catch (InterruptedException e1) {
			//
		}
	}

	@CommandExamples("<RunIfFirst>...</RunIfFirst>")
	public void runCommandRunIfFirst(Node action) throws CommandException {
		try {
			if (webParrentProcessor == null) {
				runNodes(new Node[] { action });
			} else {
				Node[] nodes = action.getNodes("Else");
				runNodes(nodes);
			}
		} catch (Exception e) {
			checkExceptionState(e);
		}
	}

	@CommandExamples("<Page url='' timeout='' username='' password=''/>")
	public void runCommandPage(Node action) {
		String attr = attr(action, "url");
		getDriver().get(attr);
		if (checkAuthAllert(action, ALERT_TIMEOUT)) {
			getDriver().get(attr);
		}
	}

	@CommandExamples({ "<Text value=''><name>...</name></Text>",
			"<Text value=''><xpath>...</xpath><className>...</className><cssSelector>...</cssSelector><id>...</id><linkText>...</linkText><partialLinkText>...</partialLinkText><tagName>...</tagName></Text>" })
	public void runCommandText(Node action) throws CommandException {
		try {
			WebElement element = findElementWithTimeout(action, true);

			String text = attr(action, "value");

			if (element != null) {
				try {
					element.clear();
				} catch (Exception e) {
					//
				}
				element.sendKeys(text);
			}

			if (StringUtils.equalsIgnoreCase("true", attr(action, "submit"))) {
				element.submit();
			}

			return;

		} catch (WebDriverException e) {
			checkExceptionState(e);
		}
	}

	@CommandExamples({ "<CloseTab name=''/>", "<CloseTab/>" })
	public void runCommandCloseTab(Node action) throws CommandException {
		String tabName = attr(action, "name");
		if (tabName != null) {
			String tabId = windowMap.get(tabName);
			getDriver().switchTo().window(tabId).close();
		} else {
			Set<String> windowHandles = getDriver().getWindowHandles();
			for (String tabId : windowHandles) {
				if (!windowMap.containsValue(tabId)) {
					getDriver().switchTo().window(tabId).close();
				}
			}
		}
	}

	@CommandExamples({
			"<Click><xpath>...</xpath><className>...</className><cssSelector>...</cssSelector><id>...</id><linkText>...</linkText><partialLinkText>...</partialLinkText><tagName>...</tagName></Click>" })
	public void runCommandClick(Node action) throws CommandException {
		WebElement element = findElementWithTimeout(action, true);

		WebDriverException exception = null;
		long timeout = getTimeout(action);
		for (long i = 0; i < timeout && !isStoppedTest(); i += 200) {
			try {
				element.click();
				return;
			} catch (WebDriverException e) {
				exception = e;
			}
			sleep(200);
		}
		checkExceptionState(exception);
		checkAuthAllert(action, 200);
	}

	@CommandExamples({ "<GetText name='result' xpath='' ></GetText>" })
	public void runCommandGetText(Node action) throws CommandException {
		try {
			WebElement element = findElementWithTimeout(action, true);
			String text = "";
			String tagName = element.getTagName();
			if ("input".equals(tagName)) {
				text = element.getAttribute("value");
			} else {
				text = element.getText();
			}
			setVariableValue(attr(action, "name"), text);
		} catch (Exception e) {
			checkExceptionState(e);
		}
	}

	@CommandExamples({ "<GetUrl name=''/>" })
	public void runCommandGetUrl(Node action) throws CommandException {
		try {
			String currentUrl = getDriver().getCurrentUrl();
			setVariableValue(attr(action, "name"), currentUrl);
		} catch (Exception e) {
			checkExceptionState(e);
		}
	}

	@CommandExamples({ "<Frame name=''>...</Frame>", "<Frame xpath=''>...</Frame>" })
	public void runCommandFrame(Node action) throws CommandException {
		String name = attr(action, "name");
		String xpath = attr(action, "xpath");

		WebDriverException exception = null;
		boolean frameSelected = false;
		for (long i = 0; i < timeout && !isStoppedTest(); i += 200) {
			try {
				if (name != null) {
					getDriver().switchTo().frame(name);

				} else if (xpath != null) {
					WebElement element = findElementWithTimeout(action, false);
					getDriver().switchTo().frame(element);
				}

				frameSelected = true;
				break;
			} catch (WebDriverException e) {
				exception = e;
			}
			sleep(200);
		}
		if (exception != null && !frameSelected && !isStoppedTest()) {
			checkExceptionState(exception);
		}

		try {
			taskNode(action);
		} finally {
			getDriver().switchTo().parentFrame();
		}
	}

	@CommandExamples({ "<ElementExists xpath=''>...</ElementExists>" })
	public void runCommandElementExists(Node action) throws CommandException {
		try {
			findElementWithTimeout(action, false);
			taskNode(action);
		} catch (Exception e) {
			// do nothing;
		}
	}

	@CommandExamples({ "<ElementNotExists xpath=''>...</ElementNotExists>" })
	public void runCommandElementNotExists(Node action) throws CommandException {
		try {
			findElementWithTimeout(action, false);
		} catch (Exception e) {
			e = (Exception) (ExceptionUtils.getRootCause(e) != null ? ExceptionUtils.getRootCause(e) : e);
			if (e instanceof NoSuchElementException) {
				taskNode(action);
			} else {
				throw new CommandException(e, this);
			}
		}
	}

	@CommandExamples({ "<CheckPage url_regex='' title_regex='' timeout=''/>" })
	public void runCommandCheckPage(Node action) throws CommandException {
		String url_regex = attr(action, "url_regex");
		String title_regex = attr(action, "title_regex");

		long timeout = getTimeout(action);
		for (long i = 0; i < timeout && !isStoppedTest(); i += 200) {
			String currentUrl = getDriver().getCurrentUrl();
			String currentTitle = getDriver().getTitle();

			if (isMatched(url_regex, currentUrl) && isMatched(title_regex, currentTitle)) {
				return;
			}
			sleep(200);
		}

		TestCase.fail("Page [" + (url_regex != null ? "url_regex:" + url_regex : " ")
				+ (title_regex != null ? "title_regex:" + title_regex : " ") + "] is not found.");
	}

	private boolean isMatched(String regex, String text) {
		boolean result = true;
		if (regex != null) {
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(text);
			result = matcher.matches();
		}
		return result;
	}

	private WebElement findElementWithTimeout(Node action, boolean inner) throws CommandException {
		WebElement findElement = null;
		Exception exception = null;
		long timeout = getTimeout(action);

		for (long i = 0; i < timeout && !isStoppedTest(); i += 200) {
			try {
				findElement = findElement(action, inner);
				break;
			} catch (Exception e) {
				exception = e;
			}
			sleep(200);
		}
		if (findElement == null) {
			checkExceptionState(exception);
		}

		// debug("Element found: " + findElement);

		return findElement;
	}

	private void checkExceptionState(Exception exception) throws CommandException {
		if (exception != null && !isStoppedTest()) {
			if (exception instanceof WebDriverException) {
				throw new InvalidArgumentException(StringUtils.substringBefore(exception.getMessage(), "\n"),
						exception);
			} else {
				throw new InvalidArgumentException(exception.getMessage(), exception);
			}
		}
	}

	private long getTimeout(Node action) {
		long timeout = this.timeout;
		String timeoutAttr = attr(action, "timeout");
		if (StringUtils.isNotBlank(timeoutAttr)) {
			timeout = Long.parseLong(timeoutAttr);
		}
		return timeout;
	}

	private WebElement findElement(Node action, boolean inner) throws NoSuchElementException, CommandException {
		WebElement findElement = null;
		NoSuchElementException lastException = null;
		if (inner && action.size() > 0) {
			for (Node node : action) {
				try {
					findElement = findElementByInnerNode(node);
				} catch (NoSuchElementException e) {
					lastException = e;
					continue;
				}
			}
		} else {
			try {
				LinkedMap attributes = action.getAttributes();
				findElement = findElement(attributes);
			} catch (NoSuchElementException e) {
				lastException = e;
			}
		}
		if (findElement == null) {
			checkExceptionState(lastException);
		}
		return findElement;
	}

	private WebElement findElementByInnerNode(Node node) throws NoSuchElementException {
		String name = node.getTag();
		String value = replaceProperties(node.getInnerText());
		LinkedMap attributes = new LinkedMap();
		attributes.put(name, value);
		return findElement(attributes);
	}

	private WebElement findElement(LinkedMap attributes) throws NoSuchElementException {
		WebElement element = null;
		NoSuchElementException exceptionByMName = null;
		String attr = (String) (String) attributes.get("name");
		attr = replaceProperties(attr);
		try {
			if (attr != null) {
				return getDriver().findElement(By.name(attr));
			}
		} catch (NoSuchElementException e) {
			exceptionByMName = e;
		}

		attr = (String) attributes.get("className");
		if (attr != null) {
			return getDriver().findElement(By.className(attr));
		}
		attr = (String) attributes.get("cssSelector");
		if (attr != null) {
			return getDriver().findElement(By.cssSelector(attr));
		}
		attr = (String) attributes.get("id");
		if (attr != null) {
			return getDriver().findElement(By.id(attr));
		}
		attr = (String) attributes.get("linkText");
		if (attr != null) {
			return getDriver().findElement(By.linkText(attr));
		}
		attr = (String) attributes.get("partialLinkText");
		if (attr != null) {
			return getDriver().findElement(By.partialLinkText(attr));
		}
		attr = (String) attributes.get("tagName");
		if (attr != null) {
			return getDriver().findElement(By.tagName(attr));
		}
		attr = (String) attributes.get("xpath");
		if (attr != null) {
			return getDriver().findElement(By.xpath(attr));
		}

		if (exceptionByMName != null && element == null) {
			throw exceptionByMName;
		}
		return element;
	}

	@CommandExamples("<Title name='' />")
	public void runCommandTitle(Node action) {
		WebDriver driver = getDriver();
		if (driver != null) {
			setVariableValue(attr(action, "name"), driver.getTitle());
		} else {
			setVariableValue(attr(action, "name"), null);
		}
	}

	@CommandExamples({ "<CloseDriver />" })
	public void runCommandCloseDriver(Node action) throws CommandException {
		quiteDriver();
	}

	@CommandExamples({ "<DeleteCookie except='type:property'/>", "<DeleteCookie />", "<DeleteCookie name=''/>" })
	public void runCommandDeleteCookie(Node action) throws CommandException {
		Object except = attrValue(action, "except");
		WebDriver driver = getDriver();
		Options manage = driver.manage();

		if (except != null) {
			List<String> enaledCookies = new ArrayList<>();
			if (except instanceof String) {
				enaledCookies.add((String) except);
			} else if (except instanceof List) {
				enaledCookies = (List<String>) except;
			}

			if (!enaledCookies.isEmpty()) {
				Set<Cookie> cookies = manage.getCookies();
				StringBuilder report = new StringBuilder();
				for (Cookie cookie : cookies) {
					String name = cookie.getName();
					String value = cookie.getValue();
					if (!enaledCookies.contains(name)) {
						manage.deleteCookieNamed(name);
						report.append("\n" + name + "=" + value);
					}
				}
				if (report.length() > 0) {
					debug("Removed cookies: " + report);
				}
			}
		} else {
			String cookieName = attr(action, "name");

			if (StringUtils.isBlank(cookieName)) {
				Set<Cookie> cookies = manage.getCookies();
				if (cookies.size() > 0) {
					StringBuilder report = new StringBuilder("Removed cookies: ");
					for (Cookie cookie : cookies) {
						report.append("\n" + cookie.getName() + "=" + cookie.getValue());
					}
					debug(report);
				}

				getDriver().manage().deleteAllCookies();

			} else {
				getDriver().manage().deleteCookieNamed(cookieName);
			}

		}
	}

	@CommandExamples({ "<CookieReport name='type:property'/>" })
	public void runCommandCookieReport(Node action) throws CommandException {
		String name = attr(action, "name");
		Map<String, String> report = (Map<String, String>) getVariableValue(name);
		if (report == null) {
			report = new LinkedMap();
		}
		WebDriver driver = getDriver();
		Options manage = driver.manage();
		Set<Cookie> cookies = manage.getCookies();
		for (Cookie cookie : cookies) {
			report.put(cookie.getName(), cookie.getValue());
		}
		setVariableValue(name, report);
	}

	@Override
	public void complete(boolean success) {
	}

	private void quiteDriver() {
		if (getDriver() != null) {
			try {
				getDriver().quit();
			} catch (Exception e) {
				//
			}
			setDriver(null);
		}
	}

	private WebDriver getDriver() {
		return WebDriverManager.getDriver(driverName);
	}

	private WebDriver setDriver(WebDriver webDriver) {
		return WebDriverManager.setDriver(driverName, webDriver);
	}

}
