package com.nave.ae.processor;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.nave.anteater.ILogger;
import com.nave.anteater.Logger;

/**
 * This abstract class for getting connect to DB in JNDI and Local part.
 */
abstract public class AbstractConnectionProvider {

	private final static ILogger log = new Logger("AbstractConnectionProvider");
	private Connection fConnection = null;

	private static int fOpenCount = 0;

	public boolean isLogRaport() {
		return fLogRaport;
	}

	public void setLogRaport(boolean aLogRaport) {
		fLogRaport = aLogRaport;
	}

	private boolean fLogRaport = false;

	public AbstractConnectionProvider(String connectionName) throws SQLException {
		DataSource fDataSource = new LocalDataSource(connectionName);
		fConnection = fDataSource.getConnection();
		fOpenCount++;

		if (fLogRaport) {
			log.debug("Getting DB connection from " + getSourceCallPoint());
		}
	}

	private String getSourceCallPoint() {

		StackTraceElement[] theStackTrace = new Exception().getStackTrace();

		if (theStackTrace != null) {

			for (int i = 0; i < theStackTrace.length; i++) {
				if (theStackTrace[i].getClassName().indexOf("com.maxbill.util.sql") != 0) {
					StackTraceElement theStackTraceElement = theStackTrace[i];
					String theFromCall = theStackTraceElement.getMethodName() + "("
							+ theStackTraceElement.getClassName() + ":" + theStackTraceElement.getLineNumber()
							+ ") Open: " + fOpenCount;
					return theFromCall;
				}

			}
		}

		return new String("Opened: " + fOpenCount);
	}

	public void setAutoCommit(boolean aAutoCommit) throws SQLException {
		fConnection.setAutoCommit(aAutoCommit);
	}

	public void close() {
		try {
			if (!fConnection.isClosed()) {
				fConnection.close();
			}
			fOpenCount--;
			if (fLogRaport) {
				log.debug("Close DB connection from " + getSourceCallPoint());
			}
		} catch (Exception e) {
			log.error("Exception in close block: ", e);
		}
	}

	public Connection connection() {
		return fConnection;
	}

	protected void finalize() throws Throwable {
		if (fConnection != null && fConnection.isClosed() == false) {
			close();
			log.debug("Finalize closed DB connection.");
		}
	}

	public void commit() throws SQLException {
		try {
			fConnection.commit();
		} catch (SQLException e) {

		}
	}

	public void rollback() throws SQLException {
		fConnection.rollback();
	}
}
