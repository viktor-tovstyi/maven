package com.nave.anteater;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import com.nave.anteater.processor.TaskProcessor;

public class ParameterIterator {
	public static final String CONCURRENTLY = "[concurrently]";
	public static final String EXHAUSTION = "[multiple]";
	public static final String SINGLE = "[single]";
	public static final String INDEPENDENT = "[independent]";

	private List fValuesArray = new ArrayList();
	private String fName;
	private int fStartStep;
	private ParameterIterator fChield;
	private String fType;
	private boolean fParent;
	private TaskProcessor fTestUnit;

	public ParameterIterator(TaskProcessor aTestUnit, String aName, int aStartStep) {
		fName = aName;
		fStartStep = aStartStep;
		fTestUnit = aTestUnit;
	}

	public void addRule(String aRuleName, String aRuleParameters, String connectionName) throws Exception {
		aRuleName = aRuleName.trim();

		if ("value".equalsIgnoreCase(aRuleName)) {
			fValuesArray.add(aRuleParameters);
			return;

		} else if ("file".equalsIgnoreCase(aRuleName)) {
			ArrayList theArrayList = loadFile(new File(fTestUnit.getBaseDir(), aRuleParameters));

			for (int i = 0; i < theArrayList.size(); i++) {
				fValuesArray.add(theArrayList.get(i));
			}
			return;

		} else if ("file".equalsIgnoreCase(aRuleName)) {
			ArrayList theArrayList = loadFile(new File(fTestUnit.getBaseDir(), aRuleParameters));

			for (int i = 0; i < theArrayList.size(); i++) {
				fValuesArray.add(theArrayList.get(i));
			}
			return;

		} else if ("enum".equalsIgnoreCase(aRuleName)) {
			StringTokenizer theStringTokenizer = new StringTokenizer(aRuleParameters, ";");
			while (theStringTokenizer.hasMoreTokens()) {
				fValuesArray.add(theStringTokenizer.nextToken());
			}
			return;

		} else if ("inc".equalsIgnoreCase(aRuleName)) {
			StringTokenizer theStringTokenizer = new StringTokenizer(fTestUnit.replaceProperties(aRuleParameters), ";");

			String theStart = null;
			String theNumbers = null;

			try {
				theStart = theStringTokenizer.nextToken();
				theNumbers = theStringTokenizer.nextToken();
			} catch (Exception e) {
			}

			if (theStart == null)
				theStart = "0";
			if (theNumbers == null)
				theNumbers = "1000";

			int theStartInt = Integer.parseInt(fTestUnit.replaceProperties(theStart));
			int theNumbersInt = Integer.parseInt(fTestUnit.replaceProperties(theNumbers));

			if (theNumbersInt > 0)
				for (int i = theStartInt; i < theStartInt + theNumbersInt; i++)
					fValuesArray.add(Integer.toString(i));
			else
				for (int i = theStartInt; i > theStartInt + theNumbersInt; i--)
					fValuesArray.add(Integer.toString(i));

			return;
		}

		throw new Exception("Incorrect rule for Iteration line: " + aRuleName + ":" + aRuleParameters);
	}

	public int count() {
		return fValuesArray.size();
	}

	public void applyValue(int aCurrentIteration, Map<String, Object> aHashtable, ArrayList aPropertiesIsSet,
			String connectionName) throws Exception {

		if (SINGLE.equalsIgnoreCase(fType)) {
			int theCurr = aCurrentIteration - fStartStep;

			if (theCurr < 0) {
				applyDefaultValue(aPropertiesIsSet, aHashtable, connectionName);
			} else if (theCurr < fValuesArray.size()) {
				putValue(aHashtable, theCurr, aPropertiesIsSet, connectionName);
			} else {
				putValue(aHashtable, 0, aPropertiesIsSet, connectionName);
			}

			return;

		} else if (INDEPENDENT.equalsIgnoreCase(fType)) {
			int theCurr = aCurrentIteration - fStartStep;

			if (theCurr < 0) {
				applyDefaultValue(aPropertiesIsSet, aHashtable, connectionName);
			} else if (theCurr < fValuesArray.size()) {
				putValue(aHashtable, aCurrentIteration, aPropertiesIsSet, connectionName);
			}

			return;

		} else {
			int theCurr = aCurrentIteration - fStartStep;
			if (fParent == false)
				return;

			applyChieldValue(aCurrentIteration - fStartStep, aHashtable, 1, theCurr < 0, aPropertiesIsSet,
					connectionName);
		}
	}

	private void putValue(Map<String, Object> aHashtable, int aCurr, ArrayList aPropertiesIsSet, String connectionName)
			throws Exception {
		String theName = getName();

		if (aCurr >= fValuesArray.size())
			aCurr = fValuesArray.size() - 1;
		String theLine = fTestUnit.replaceProperties((String) fValuesArray.get(aCurr));
		if ("null".equals(theLine) == false)
			aHashtable.put(theName, theLine);
		else if (aHashtable.containsKey(theName))
			aHashtable.remove(theName);

		aPropertiesIsSet.add(theName);
	}

	private void applyDefaultValue(ArrayList aPropertiesIsSet, Map<String, Object> aHashtable, String connectionName)
			throws Exception {
		String theName = getName();
		if (aPropertiesIsSet.contains(theName))
			return;
		aPropertiesIsSet.add(theName);
		putValue(aHashtable, 0, aPropertiesIsSet, connectionName);
	}

	protected void applyChieldValue(int aCurrentIteration, Map<String, Object> aHashtable, int aInterval,
			boolean aDefaultValue, ArrayList aPropertiesIsSet, String connectionName) throws Exception {

		if (EXHAUSTION.equalsIgnoreCase(fType)) {
			if (aDefaultValue == false) {
				int theIndex = (int) (((double) aCurrentIteration / aInterval) % fValuesArray.size());
				putValue(aHashtable, theIndex, aPropertiesIsSet, connectionName);
			} else {
				applyDefaultValue(aPropertiesIsSet, aHashtable, connectionName);
			}

			if (fChield != null) {
				fChield.applyChieldValue(aCurrentIteration, aHashtable, aInterval * count(), aDefaultValue,
						aPropertiesIsSet, connectionName);
			}
		} else if (CONCURRENTLY.equalsIgnoreCase(fType)) {
			if (aDefaultValue == false) {
				putValue(aHashtable, aCurrentIteration, aPropertiesIsSet, connectionName);
			} else {
				applyDefaultValue(aPropertiesIsSet, aHashtable, connectionName);
			}

			if (fChield != null) {
				fChield.applyChieldValue(aCurrentIteration, aHashtable, fValuesArray.size(), aDefaultValue,
						aPropertiesIsSet, connectionName);
			}
		}

	}

	public void setChield(ParameterIterator aParameterIterator) {
		fChield = aParameterIterator;
	}

	public void setType(String aType) {
		fType = aType;
	}

	public String getName() {
		return fName;
	}

	public void setParent(boolean aMultipleParent) {
		fParent = aMultipleParent;
	}

	public ArrayList loadFile(File aFile) throws Exception {
		ArrayList theProperties = new ArrayList();
		BufferedReader theFileReader = new BufferedReader(new FileReader(aFile));

		String theLine = null;
		while ((theLine = theFileReader.readLine()) != null) {
			if (theLine == null || theLine.length() == 0 || (theLine.length() > 0 && theLine.trim().charAt(0) == '#'))
				continue;

			int thePbrk = theLine.indexOf('=');

			String theName = theLine;
			if (thePbrk >= 0)
				theName = theLine.substring(0, thePbrk);

			theProperties.add(theName);
		}

		return theProperties;
	}
}
