package com.nave.anteater;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.ServerSocket;
import java.util.Map;
import java.util.Properties;

import javax.net.ssl.SSLServerSocketFactory;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.log4j.Logger;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.xml.easyparser.Node;

/**
 * @author victort
 * @version 1.0, 29-Jul-2005
 */
public class TestRunner implements RecipeListener {

	public static int STATUS_SUCCESS = 0;

	public static int STATUS_FAILED = 1;

	public static String RUN_MODE_APPLICATION = "Application";

	public static String RUN_MODE_WEB = "Web";

	protected Node fConfigNode;

	private Map<String, Object> fSystemVariables;

	private TaskProcessor processor = null;

	private String fNameTask;

	private String fRunMode = RUN_MODE_APPLICATION;

	private int fStatus = STATUS_SUCCESS;

	protected AEManager manager;

	private Node fTaskNode;

	private Logger log = Logger.getLogger("TestRunner");

	public TestRunner(AEManager manager) {
		this(manager, manager.getConfigNode(), manager.getSystemVariables());
	}

	public TestRunner(AEManager manager, Node aConfigNode, Map<String, Object> aSystemVariables) {
		fConfigNode = aConfigNode;
		this.manager = manager;
		fSystemVariables = aSystemVariables;
		this.manager.addRunner(this);
	}

	public TaskProcessor getTaskProcessor() {
		return processor;
	}

	public Node getTaskNode() {
		return fTaskNode;
	}

	public void setProcessor(TaskProcessor processor) {
		this.processor = processor;
	}

	public void makeRecipe(String file) throws CommandException {
		setProcessor(new TaskProcessor(fConfigNode, fSystemVariables, this, manager.getStartDir(), getLog(),
				getTaskProcessor()));
		getTaskProcessor().make(file);
	}

	public void runTest(Node testNode[]) throws Exception {
		setTaskNode(testNode[0]);
		processor = new TaskProcessor(fConfigNode, fSystemVariables, this, manager.getStartDir(), getLog(),
				getTaskProcessor());
		processor.runNodes(testNode);
		endTask(false);
	}

	public void setTaskNode(Node object) {
		fTaskNode = object;
	}

	public void criticalError(CommandException aThrowable, TaskProcessor processor) {
		this.endTask(true);
		fStatus = STATUS_FAILED;
		StringBuilder taskTrace = new StringBuilder(aThrowable.getTaskTrace() + "\n\n");
		Throwable rootCause = ExceptionUtils.getRootCause(aThrowable);
		processor.getLogger().error(taskTrace.toString(), (Throwable) ObjectUtils.defaultIfNull(rootCause, aThrowable));
	}

	public void checkFailure(CommandException e, TaskProcessor processor) {
		fStatus = STATUS_FAILED;
		processor.getLogger().error("Check Failure. Message: " + e.getMessage() + "\n" + e.getTaskTrace());
		this.endTask(true);
		getLog().debug(e);
	}

	public void startTask(String aNameTask) {
		setTestName(aNameTask);
	}

	public void setTestName(String aNameTask) {
		fNameTask = aNameTask;
	}

	public void setProgress(String aCurrentTaskName, long aMaxTags, long aCurrTags, boolean aErrorState) {
	}

	public AEManager getManager() {
		return manager;
	}

	public void endTask(boolean aErrorState) {
		manager.removeRunner(this);
	}

	public void changeVariable(String aAttribut, Object aValue) {
	}

	public void startCommand(int i) {
	}

	public void startChildProcess(TaskProcessorThread aMaxTestRunnable) {
	}

	public void stopChildProcess(TaskProcessorThread aMaxTestRunnable) {
	}

	public Node getConfigNode() {
		return fConfigNode;
	}

	public void stopTest() {
		if (processor != null) {
			processor.stop();
		}
	}

	public String getTitle() {
		return fNameTask;
	}

	public String inputFile(File aDefaultFile, TaskProcessor taskProcessor) {
		return aDefaultFile.getAbsolutePath();
	}

	public String inputSelectChoice(String aNameDialog, String[] aValues, String aDefaultValue,
			TaskProcessor taskProcessor) {
		if (aValues != null && aValues.length > 0)
			return aValues[0];
		return null;
	}

	public void aboutTest(String theTaskName, Node aCurrentAction) {

	}

	public void setRunMode(String aMode) {
		fRunMode = aMode;
	}

	public String getRunMode() {
		return fRunMode;
	}

	public void exceptionIgnored(Throwable e) {
		getLog().debug("Exception ignored. Message: " + e.getLocalizedMessage());
	}

	public Logger getLog() {
		return log;
	}

	public int getStatus() {
		return fStatus;
	}

	public ServerSocket createPort(int thePort, String aDescription) throws IOException {
		ServerSocket serverSocket = null;

		if (thePort < 0) {
			SSLServerSocketFactory factory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
			serverSocket = factory.createServerSocket(-thePort);
		} else {
			serverSocket = new ServerSocket(thePort);
		}

		return serverSocket;
	}

	public void closePort(int thePort) {
	}

	public void errorInformation(TaskProcessor processor, Throwable e, Node aTaskNode) throws CommandException {
		throw new CommandException(e, processor);
	}

	public void outToFrame(TaskProcessor processor, Properties aProperties, Object aTheValue) throws Exception {
	}

	public void runCommandFrame(Properties params) throws Throwable {
	}

	public Logger createLog(String aName, boolean mainLog) {
		return log;
	}

	public void dbPropertiesCheck(Properties aProperties) {
		if (aProperties.getProperty("type") == null)
			aProperties.setProperty("type", "local");

		if (aProperties.getProperty("driver") == null)
			aProperties.setProperty("driver", "oracle.jdbc.OracleDriver");

	}

	public Map<String, Object> getSystemVariables() {
		return fSystemVariables;
	}

	public void setLog(Logger log) {
		this.log = log;
	}

	public static void main(String... args) throws Exception {

		try {
			AEWorkspace workspace = new AEWorkspace();
			CommandServer.createCommandServer(workspace, args);

			System.out.println("Giant anteater searches for a meal ...");
			System.out.println("Loading configuration ...");
			workspace.loadConfiguration(true);
			workspace.runSetupNodes();

			for (String name : args) {
				TestRunner runTask = workspace.runTask(name, false);
				if (runTask.getStatus() == STATUS_FAILED) {
					System.exit(STATUS_FAILED);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			System.exit(STATUS_FAILED);
		}

	}

	public void pause() {
	}

	public void resume() {
	}
}
