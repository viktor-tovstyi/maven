package com.nave.anteater.util;

import java.util.Objects;

public class TestCase {

	public static void assertFalse(String message, boolean equals) {
		if (equals) {
			throw new AssertionFailedError(message);
		}
	}

	public static void assertEquals(String message, Object expected, Object actual) {
		boolean equals = Objects.equals(expected, actual);

		if (!equals) {
			if (message == null) {
				message = String.format("Expected: %s, Actual: %s", expected, actual);
			}
			throw new AssertionFailedError(message);
		}
	}

	public static void fail(String message) {
		throw new AssertionFailedError(message);
	}

	public static void assertNotNull(String message, Object value) {
		if (value == null) {
			throw new AssertionFailedError(message);
		}
	}

	public static void assertTrue(String message, boolean value) {
		if (!value) {
			throw new AssertionFailedError(message);
		}
	}

}
