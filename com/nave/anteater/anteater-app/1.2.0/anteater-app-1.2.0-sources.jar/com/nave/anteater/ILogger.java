package com.nave.anteater;

public interface ILogger {

	public void info(Object message);

	public void debug(Object message);

	public void debug(Object message, Throwable t);

	public void warn(Object message);

	public void error(Object message);

	public void error(Object message, Throwable t);

	public String getName();

}
