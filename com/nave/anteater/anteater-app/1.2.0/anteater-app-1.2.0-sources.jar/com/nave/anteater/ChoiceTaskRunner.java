package com.nave.anteater;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;

public class ChoiceTaskRunner implements MultiTaskRunDialog {

	private String[] taskNames;

	List<String> activeTaskArray = new ArrayList<String>();

	String[] status;

	boolean start = false;

	private String name;

	private boolean errorrState = false;

	private boolean closeDialog = false;

	private boolean exceptionIgnore;

	private boolean useHistory;

	private boolean visible;

	private boolean notifyMe;

	public ChoiceTaskRunner(String name, final boolean useHistory) {
		this.name = name;
		this.useHistory = useHistory;
		this.setVisible(true);
	}

	public void showDialog(String name, String[] theNames, boolean notifyMe) {

		this.notifyMe = notifyMe;
		closeDialog = false;
		this.taskNames = theNames;

		if (useHistory) {
			String defaultTasks = AEWorkspace.getInstance().getDefaultUserConfiguration("MultiTaskRunDialog:" + this.name, "");

			String[] strings = StringUtils.splitPreserveAllTokens(defaultTasks, ";");
			for (String taskName : strings) {
				if (ArrayUtils.indexOf(taskNames, taskName) >= 0 && !activeTaskArray.contains(taskName))
					activeTaskArray.add(taskName);
			}
		}

		status = new String[taskNames.length];
	}
	
	public Iterator<String> getSelectedTasks() {

		List<String> list = new ArrayList<String>();
		if (closeDialog && start == false)
			return list.iterator();
		for (String name : taskNames) {
			if (activeTaskArray.contains(name))
				list.add(name);
		}

		return list.iterator();
	}

	public void begin(String taskName) {
		int row = ArrayUtils.indexOf(taskNames, taskName);
		this.status[row] = "in progress";

	}

	public void done() {
		if (errorrState) {
			start = false;
		}
		errorrState = true;
	}

	public void end(String taskName, boolean statusOk) {
		int row = ArrayUtils.indexOf(taskNames, taskName);
		this.status[row] = statusOk ? "ok" : "failed";
		if (statusOk == false)
			errorrState = true;
	}

	public boolean isExceptionIgnore() {
		return exceptionIgnore;
	}

	public int getColumnCount() {
		return 3;
	}

	public int getRowCount() {
		return taskNames.length;
	}

	public Object getValueAt(int row, int coll) {
		if (coll == 0) {
			String name = taskNames[row];
			return activeTaskArray.contains(name);
		}
		if (coll == 2) {
			String status = this.status[row];
			return status == null ? "" : status;
		}
		return taskNames[row];
	}

	public void select(String[] activeTaskArray, boolean defaultMode) {
		this.activeTaskArray.clear();
		for (String activeTask : activeTaskArray)
			this.activeTaskArray.add(activeTask);

		if (defaultMode) {
			start = true;
		}
	}

	public boolean isStarted() {
		return start;
	}

	public void setExceptionIgnore(boolean exceptionIgnore) {
		this.exceptionIgnore = exceptionIgnore;
	}

	public String getName() {
		return name;
	}

	public void start() {
		start = true;
	}

	public String[] getTaskNames() {
		return taskNames;
	}

	@Override
	public boolean isVisible() {
		return visible;
	}

	public void setVisible(boolean visible) {
		this.visible = visible;
	}

}