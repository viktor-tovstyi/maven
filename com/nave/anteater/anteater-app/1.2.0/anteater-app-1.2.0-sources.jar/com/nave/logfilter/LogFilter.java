package com.nave.logfilter;

public interface LogFilter {

	public String filter(String text);

}
