package com.nave.anteater;

import java.io.File;
import java.util.Map;

import org.apache.log4j.Logger;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.xml.easyparser.Node;

public interface AEManager {

	File getStartDir();

	void message(String string);

	String inputSelectChoice(String theChoiceNames, String[] theNames, String defaultValue, TaskProcessor taskProcessor);

	String inputFile(String name, File theFile, Logger log, TaskProcessor taskProcessor);
	
	void inputDataTable(TemplateProcessor unit, Node aTableNode, Map<String, Object> aVariables, TaskProcessor taskProcessor) throws Exception;

	boolean confirmation(TaskProcessor unit, String message) throws Exception;
	
	String inputValue(String theDesc, String theAttribut, String value, Logger log, String type);

	String getTestPath(String newName);

	void getRemoveTestPath(String oldName);

	void setTestPath(String newName, String path);

	Object[] getTestsList();

	String getWorkingDir();

	MultiTaskRunDialog tasksChoice(MultiTaskRunDialog choiceRunner, String[] theNames, boolean exceptionIgnoreFlag, Object setup, TaskProcessor taskProcessor, boolean visible);
	
	String choiceValue(String s, String name, Object[] aPossibleValues, Logger log);

	File getFile(File aParentDir, String aThePathAttribut);

	Map<String, Object> getSystemVariables();

	void setConsoleDefaultInput(boolean defaultMode);

	boolean isConsoleDefaultInput(String varName);

	void createDBConnection(Node theDS, Map<String, Object> variables);

	TestRunner runTask(String name, boolean async);

	Node getConfigNode();

	void startTaskNotify(TestRunner task);
	
	void progressText(String name);
	
	void progressValue(int i, int length, boolean success);
	
	File[] getTestDirs();

	void addRunner(TestRunner testRunner);

	void removeRunner(TestRunner testRunner);

	void finished(String aTestFile);
}
