package com.nave.anteater;

import java.io.File;
import java.util.Map;

import com.nave.anteater.processor.MessageHandler;
import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.xml.easyparser.Node;

public interface AEManager {

	File getStartDir();

	String inputSelectChoice(String theChoiceNames, String[] theNames, String defaultValue, TaskProcessor taskProcessor,
			boolean notifyMe);

	String inputFile(String name, File theFile, ILogger log, TaskProcessor taskProcessor);

	void inputDataTable(TemplateProcessor unit, Node aTableNode, boolean notifyMe) throws Exception;

	boolean confirmation(TaskProcessor unit, String description, String message, boolean notifyMe) throws Exception;

	String inputValue(String theDesc, String theAttribut, String value, ILogger log, String type, boolean notifyMe);

	String getTestPath(String newName);

	void getRemoveTestPath(String oldName);

	void setTestPath(String newName, String path);

	Object[] getTestsList();

	String getWorkingDir();

	MultiTaskRunDialog tasksChoice(MultiTaskRunDialog choiceRunner, String[] theNames, boolean exceptionIgnoreFlag,
			Object setup, TaskProcessor taskProcessor, boolean visible);

	String choiceValue(String s, String name, Object[] aPossibleValues, ILogger log, boolean notifyMe);

	File getFile(File aParentDir, String aThePathAttribut);

	Map<String, Object> getSystemVariables();

	void setConsoleDefaultInput(boolean defaultMode);

	boolean isConsoleDefaultInput(String varName);

	TestRunner runTask(String name, boolean async);

	Node getConfigNode();

	void startTaskNotify(TestRunner task);

	void progressText(String name);

	void progressValue(int i, int length, boolean success);

	File[] getTestDirs();

	void addRunner(TestRunner testRunner);

	void removeRunner(TestRunner testRunner);

	void finished(String aTestFile);

	MessageHandler message(TaskProcessor taskProcessor, String message, String description, boolean notifyMe);
}
