package com.nave.anteater.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;

import com.nave.anteater.TemplateProcessor;
import com.nave.anteater.util.xml.easyparser.EasyParser;
import com.nave.anteater.util.xml.easyparser.Node;

public class AEUtils {

	public static InputStream getInputStream(String aFileName, File aBaseDir)
			throws FileNotFoundException, IOException, MalformedURLException {
		InputStream theInputStream = null;

		if ('/' == aFileName.charAt(0) || '\\' == aFileName.charAt(0)) {
			theInputStream = new FileInputStream(aFileName);

		} else if (aFileName.startsWith("jar:file:")) {
			theInputStream = new URL(aFileName.replace('\\', '/')).openStream();

		} else if (aBaseDir.toString().startsWith("jar:file:")) {

			String basePath = aBaseDir.toString();
			basePath = StringUtils.substringBefore(basePath, "!") + "!"
					+ StringUtils.substringAfter(basePath, "!").replace('\\', '/');
			String spec = basePath + "/" + aFileName.replace('\\', '/');
			theInputStream = new URL(spec).openStream();

		} else {
			File file = new File(aFileName);
			if (!file.exists()) {
				file = new File(aBaseDir, aFileName);
			}
			theInputStream = new FileInputStream(file);

		}
		return theInputStream;
	}

	public static String loadResource(String aFileName, File aBaseDir, String aEncode)
			throws IOException, ParseException {
		Validate.notEmpty(aFileName, "Request file name is empty.");

		InputStream theInputStream = AEUtils.getInputStream(aFileName, aBaseDir);

		String theEncode = aEncode;

		Node theHead = null;
		try {

			byte[] theBuffer = IOUtils.toByteArray(theInputStream);
			theInputStream.read(theBuffer);

			int theEndHead = 0;

			String theDocHead = new String(theBuffer, "UTF-8");
			if (theDocHead.indexOf("<?xml") == 0) {
				theEndHead = theDocHead.indexOf("?>");
				EasyParser theParser = new EasyParser();
				theHead = theParser.getObject(theDocHead.substring(0, theEndHead) + "/>");
				theEncode = theHead.getAttribute("encoding");
				theEndHead += 2;
			}

			if (theEncode == null)
				theEncode = "UTF-8";

			return new String(theBuffer, theEncode);

		} finally {
			if (theInputStream != null)
				theInputStream.close();
		}

	}

	public static Map<String, String> convertStringToMap(String value) {
		Map<String, String> theValue = null;
		if (value != null) {
			Properties props = new Properties();
			try {
				Map<String, String> map2 = new LinkedHashMap<String, String>();
				for (Map.Entry<Object, Object> e : props.entrySet()) {
					map2.put((String) e.getKey(), (String) e.getValue());
				}
				String replace = value.substring(1, value.length() - 1).replace(", ", "\n");
				props.load(new StringReader(replace));
				theValue = new TreeMap<>();
				Set<Entry<Object, Object>> entrySet = props.entrySet();
				for (Entry<Object, Object> entry : entrySet) {
					theValue.put((String) entry.getKey(), (String) entry.getValue());
				}
			} catch (IOException e1) {
				// skip
			}
		}

		return theValue;
	}

	public static String format(String text) {
		StringBuilder formatedText = new StringBuilder();

		boolean jsonDetected = false;
		for (int i = 0; i < text.length(); i++) {
			char charAt = text.charAt(i);

			if (charAt == '{') {
				jsonDetected = true;
			}
			if (!jsonDetected) {
				formatedText.append(charAt);
			} else {
				StringBuilder jsonBody = new StringBuilder();

				int counter = 0;
				for (; i < text.length(); i++) {
					charAt = text.charAt(i);

					if (charAt == '{') {
						counter++;
					}

					if (charAt == '}') {
						counter--;
					}

					jsonBody.append(charAt);

					if (counter < 1) {
						jsonDetected = false;
						break;
					}
				}

				int length = formatedText.toString().trim().length();
				formatedText.setLength(length);
				if (length > 0) {
					formatedText.append("\n");
				}

				try {
					formatedText.append(new JSONObject(jsonBody.toString()).toString(2));
				} catch (JSONException e) {
					formatedText.append(jsonBody.toString());
				}
			}
		}
		return formatedText.toString();
	}

	public static boolean isEmpty(Object value) {
		boolean result;
		if (value instanceof String) {
			result = StringUtils.isEmpty((String) value);
		} else if (value instanceof String[]) {
			result = ((String[]) value).length == 0;
		} else {
			result = value == null;
		}
		return result;
	}

	public static String maskEmail(String text) {
		String atSignSymbol = "@";
		String[] terminator = new String[] { " ", "=", "\"", "'", "\t", "\n", "\r" };
		int notMaskLength = 5;

		if (StringUtils.indexOf(text, atSignSymbol) > 0) {
			String[] split = StringUtils.split(text, atSignSymbol);
			boolean skipNext = false;
			for (int i = 0; i < split.length; i++) {
				String line = split[i];
				int index = StringUtils.lastIndexOfAny(line, terminator);
				int maskLength = line.length() - index - notMaskLength;

				if (skipNext) {
					skipNext = false;
				} else {
					if (notMaskLength + maskLength <= 1) {
						skipNext = true;
					} else {
						int curMaskLength = maskLength;
						if (i < split.length - 1) {
							int startMask = index + notMaskLength + 1;
							if(startMask >= line.length()) {
								startMask = index + 1;
								curMaskLength = line.length() - startMask;
							}
							split[i] = StringUtils.substring(line, 0, startMask)
									+ StringUtils.repeat("*", curMaskLength);
						} else {
							split[i] = line;
						}
						if (i > 0) {
							line = split[i];
							index = StringUtils.indexOfAny(line, terminator);
							if (index < 0) {
								index = line.length();
							}
							index = index - notMaskLength;
							split[i] = StringUtils.repeat("*", index)
									+ StringUtils.substring(line, index, line.length());
						}
					}
				}
			}
			text = StringUtils.join(split, atSignSymbol);
		}
		return text;
	}

}
