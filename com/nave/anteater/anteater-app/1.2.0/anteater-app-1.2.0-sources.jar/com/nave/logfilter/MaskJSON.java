package com.nave.logfilter;

import java.util.Map;

public class MaskJSON implements LogFilter {

	private String name;

	public MaskJSON(Map<String, String> params) {
		this.name = params.get("name");
	}

	public String filter(String text) {
		String regex = "(?<=" + name + "=')[^']+?(?=')|(?<=\"" + name + "\":\")[^\"]+?(?=\")|(?<=\"" + name + "\":.\")[^\"]+?(?=\")";
		text = text.replaceAll(regex, "****");
		return text;
	}

}
