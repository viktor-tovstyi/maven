package com.nave.anteater.util.xml.easyparser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.ParseException;
import java.util.ArrayList;

import org.apache.commons.lang.StringEscapeUtils;

/**
 * @author victort
 */
public class EasyParser {

	final static boolean debug = false;

	public EasyParser() {
	}

	public Node getObject(InputStream aInputStream) throws ParserException {
		try {
			StringBuffer theBuffer = new StringBuffer();

			BufferedReader theInputStream = new BufferedReader(new InputStreamReader(aInputStream, "UTF-8"));

			String theLine = null;
			while ((theLine = theInputStream.readLine()) != null) {
				theBuffer.append(theLine);
			}

			// String theEncode = "UTF-8";

			int theEndHead = 0;

			String theDocHead = theBuffer.toString();
			if (theDocHead.indexOf("<?xml") == 0) {
				theEndHead = theDocHead.indexOf("?>");
				theEndHead += 2;
			}

			return getObject(theBuffer.substring(theEndHead));

		} catch (Exception e) {
			throw new ParserException(e);
		}
	}

	public Node getObject(String theXML) throws ParseException {

		if (theXML == null) {
			return null;
		}

		int start = -1;
		do {
			start++;
			start = theXML.indexOf("<", start);
		} while (theXML.charAt(start + 1) == '!' && theXML.charAt(start + 2) == '-');

		if (start < 0)
			start = 0;

		theXML = replaceComment(theXML.substring(start));

		theXML = theXML.trim();

		if (theXML.charAt(0) != '<' || theXML.charAt(theXML.length() - 1) != '>') {
			// text block
			int theEndText = theXML.indexOf('<');
			if (theEndText < 0) {
				theEndText = theXML.length();
			}

			Node theNode = new Node(Node.TEXT_TEAG_NAME);
			String theText = StringEscapeUtils.unescapeXml(theXML.substring(0, theEndText));
			theNode.setText(theText);
			return theNode;
		}

		theXML = theXML.substring(1).trim();

		int theEndPos;

		for (theEndPos = 0; theEndPos < theXML.length() && theXML.charAt(theEndPos) != ' '
				&& theXML.charAt(theEndPos) != '\r' && theXML.charAt(theEndPos) != '>'
				&& theXML.charAt(theEndPos) != '\n'; theEndPos++) {
			if (theXML.charAt(theEndPos) == '/') {
				Node theNode = new Node(theXML.substring(0, theEndPos));
				theNode.setNill(true);
				return theNode;
			}
		}

		if (theXML.charAt(theEndPos - 1) == '>') {
			theEndPos--;
		}

		String theTagName = theXML.substring(0, theEndPos);

		theXML = theXML.substring(theEndPos).trim();

		int theTagEndPos = theXML.indexOf('>');

		boolean theEmptyTag = theTagEndPos != 0 && theXML.charAt(theTagEndPos - 1) == '/';

		Node theNode = new Node(theTagName);
		theNode.setNill(theEmptyTag);

		String theAttributeText = theXML.substring(0, theTagEndPos).trim();
		parseAtributeText(theNode, theAttributeText);

		theTagEndPos++;

		theXML = theXML.substring(theTagEndPos).trim();

		if (theEmptyTag == false) {

			int theInnerTagEndPos = getEndTagPosition(theTagName, theXML, 1);

			if (theInnerTagEndPos < 0) {
				throw new RuntimeException("Not found tag: " + "</" + theTagName + ">\nin text:\n" + theXML);
			}

			String theInnerText = theXML.substring(0, theInnerTagEndPos).trim();

			Node[] theNodeArray = getObjectArray(theInnerText);
			if (theNodeArray.length > 0) {
				for (int i = 0; i < theNodeArray.length; i++) {
					theNode.addInnerTag(theNodeArray[i]);
				}
			}
		}

		return theNode;
	}

	private String replaceComment(String theXML) {

		int theStartComment = 0;
		int theEndComment = 0;
		StringBuffer theBuffer = new StringBuffer();

		while ((theStartComment = theXML.indexOf("<!--", theEndComment)) >= 0) {
			theBuffer.append(theXML.substring(theEndComment, theStartComment));
			theEndComment = theXML.indexOf("-->", theStartComment) + 3;

			if (theEndComment > 0) {
				theBuffer.append("<Comment>");
				theBuffer.append(theXML.substring(theStartComment + 4, theEndComment - 3).replaceAll("<", "&lt;")
						.replaceAll(">", "&gt;"));
				theBuffer.append("</Comment>");
			}

		}

		theBuffer.append(theXML.substring(theEndComment));
		String s = theBuffer.toString();
		theBuffer.setLength(0);
		theBuffer = null;

		return deleteDoctype(s);

	}

	private static String deleteDoctype(String theXML) {
		int theStartComment = 0;
		int theEndComment = 0;
		StringBuffer theBuffer = new StringBuffer();

		while ((theStartComment = theXML.indexOf("<!DOCTYPE", theEndComment)) >= 0) {
			theBuffer.append(theXML.substring(theEndComment, theStartComment));
			theEndComment = theXML.indexOf(">", theStartComment) + 1;
		}

		theBuffer.append(theXML.substring(theEndComment));
		String s = theBuffer.toString();
		theBuffer.setLength(0);
		theBuffer = null;

		return s;
	}

	private int getEndTagPosition(String theTagName, String theXML, int theLevet) throws ParseException {

		int theTagEndPos = 0;
		int theInnerTagEndPos = 0;
		int theStart = 0;

		int theCounter = theLevet;

		String theTag = "</" + theTagName + ">";

		do {
			theTagEndPos = theXML.indexOf(theTag, theStart);

			theInnerTagEndPos = theXML.indexOf("<" + theTagName + " ", theStart);
			if (theInnerTagEndPos < 0) {
				theInnerTagEndPos = theXML.length();
			}

			int theInnerTagEndPos1 = theXML.indexOf("<" + theTagName + "/", theStart);
			if (theInnerTagEndPos1 >= 0) {
				theInnerTagEndPos = Math.min(theInnerTagEndPos1, theInnerTagEndPos);
			}

			theInnerTagEndPos1 = theXML.indexOf("<" + theTagName + ">", theStart);
			if (theInnerTagEndPos1 >= 0) {
				theInnerTagEndPos = Math.min(theInnerTagEndPos1, theInnerTagEndPos);
			}

			theInnerTagEndPos1 = theXML.indexOf("<" + theTagName + "\r", theStart);
			if (theInnerTagEndPos1 >= 0) {
				theInnerTagEndPos = Math.min(theInnerTagEndPos1, theInnerTagEndPos);
			}

			theInnerTagEndPos1 = theXML.indexOf("<" + theTagName + "\n", theStart);
			if (theInnerTagEndPos1 >= 0) {
				theInnerTagEndPos = Math.min(theInnerTagEndPos1, theInnerTagEndPos);
			}

			if (theTagEndPos > theInnerTagEndPos && theInnerTagEndPos >= 0) {
				// Check for an empty tag.
				int theEndPbrk = theXML.indexOf(">", theInnerTagEndPos);
				if (theXML.charAt(theEndPbrk - 1) != '/') {
					theCounter++;
				}
			} else {
				theCounter--;
			}

			theStart = Math.min(theTagEndPos, theInnerTagEndPos) + 1;

			if (theTagEndPos < 0) {
				throw new ParseException("The closing tag " + theTag + " is not retrieved. ", 0);
			}

		} while (theCounter > 0);

		return theTagEndPos;
	}

	public Node[] getObjectArray(String theXML) throws ParseException {
		if (theXML == null) {
			return null;
		}

		theXML = replaceComment(theXML);
		ArrayList<Node> theNodeArray = new ArrayList<Node>();

		theXML = theXML.trim();

		while (theXML.length() > 0) {

			Node theInnerTag = getObject(theXML);
			theNodeArray.add(theInnerTag);
			if (theInnerTag == null) {
				break;
			}

			if (theInnerTag.isNill()) {
				theXML = theXML.substring(theXML.indexOf("/>") + 2);
			}
			if (theInnerTag.isNill() == false && theInnerTag.getText() == null) {
				int theInnerTagEndPos = getEndTagPosition(theInnerTag.getTag(), theXML, 0);
				String theEndTag = "</" + theInnerTag.getTag() + ">";

				theXML = theXML.substring(theInnerTagEndPos + theEndTag.length()).trim();
			}

			String theText = theInnerTag.getText();
			if (theInnerTag.isNill() && theText != null) {
				int theEndText = theXML.indexOf('<');
				if (theEndText < 0) {
					theEndText = theXML.length();
				}
				theXML = theXML.substring(theEndText);
			}
		}

		int theNumberNode = theNodeArray.size();

		Node[] theResult = new Node[theNumberNode];

		for (int i = 0; i < theNumberNode; i++) {
			theResult[i] = (Node) theNodeArray.get(i);
		}

		return theResult;
	}

	public void parseAtributeText(Node aNode, String aAttributeText) {

		if (aAttributeText.length() > 0 && aAttributeText.charAt(aAttributeText.length() - 1) == '/') {
			aAttributeText = aAttributeText.substring(0, aAttributeText.length() - 1);
		}

		while (aAttributeText.length() > 0) {

			aAttributeText = aAttributeText.trim();
			int theEndLine = aAttributeText.indexOf('=');

			String theName = aAttributeText.substring(0, theEndLine).trim();
			aAttributeText = aAttributeText.substring(theEndLine + 1).trim();

			char theBChar = aAttributeText.charAt(0);
			int theBeginValue = 1;
			int theEndValue = 0;

			if (theBChar == '"' || theBChar == '\'') {
				theEndValue = aAttributeText.indexOf(theBChar, 1);
			} else {
				for (theEndValue = 0; theEndValue < aAttributeText.length() && aAttributeText.charAt(theEndValue) != ' '
						&& aAttributeText.charAt(theEndValue) != '\r'
						&& aAttributeText.charAt(theEndValue) != '\n'; theEndValue++) {
					;
				}
				theBeginValue = 0;
			}

			String theValue = aAttributeText.substring(theBeginValue, theEndValue);
			theValue = StringEscapeUtils.unescapeXml(theValue);
			aNode.setAttribute(theName, theValue);
			aAttributeText = aAttributeText.substring(theEndValue + 1);
		}
	}

	public Node load(String filePath) throws ParserException, ParseException, IOException {
		if (new File(filePath).exists()) {
			return new EasyParser().getObject(new File(filePath));
		}

		URL entryUrl = new URL(filePath);
		InputStream is = entryUrl.openStream();
		return new EasyParser().getObject(is);
	}

	public Node getObject(File theXMLFile) throws IOException, ParseException {
		int theLength = (int) theXMLFile.length();
		byte[] theBuffer = new byte[theLength];
		Node object = null;

		try (FileInputStream theInputStream = new FileInputStream(theXMLFile)) {
			theInputStream.read(theBuffer);
			theInputStream.close();

			String theEncode = "UTF-8";

			int theEndHead = 0;

			String theDocHead = new String(theBuffer, "UTF-8");
			if (theDocHead.indexOf("<?xml") == 0) {
				theEndHead = theDocHead.indexOf("?>");
				Node theHead = getObject(theDocHead.substring(0, theEndHead) + "/>");
				theEncode = theHead.getAttribute("encoding");
				theEndHead += 2;
			}

			if (theEncode == null)
				theEncode = "UTF-8";
			String theXML = new String(theBuffer, theEndHead, theBuffer.length - theEndHead, theEncode);
			theBuffer = null;

			object = getObject(theXML);
		}

		return object;
	}

	public static String replaceProperties(String aValue, String aFragment, String aNewFragment) {
		int theBeginPos = 0;
		int theEndPos = 0;

		if (aValue == null) {
			return aValue;
		}

		StringBuffer theStringBuffer = new StringBuffer();

		while (true) {
			theBeginPos = aValue.indexOf(aFragment, theEndPos);
			if (theBeginPos < 0) {
				break;
			}

			theStringBuffer.append(aValue.substring(theEndPos, theBeginPos));
			theEndPos = theBeginPos + aFragment.length();

			theStringBuffer.append(aNewFragment);
		}

		theStringBuffer.append(aValue.substring(theEndPos));

		return theStringBuffer.toString();
	}

}
