package com.nave.anteater;

import java.awt.Color;
import java.util.ArrayList;

import org.apache.commons.lang3.StringUtils;

import com.nave.anteater.util.xml.easyparser.Node;

public class CustomizedMenu extends ArrayList<CustomizedMenu.Item> {

	private static final long serialVersionUID = 1L;

	public class Item {

		private Node taskNode;
		private String name;
		private String toolTip;
		private String image;
		private Color color;
		private String description;

		public Item(Node node) {
			taskNode = node;

			this.name = taskNode.getAttribute("name");
			if (this.name == null)
				this.name = taskNode.getAttribute("task");

			this.toolTip = taskNode.getAttribute("tooltip");
			this.image = taskNode.getAttribute("icon");

			String colorStr = taskNode.getAttribute("color");
			if (colorStr != null) {
				Color color;
				try {
					color = (Color) Color.class.getDeclaredField(colorStr.toLowerCase()).get(null);
					setColor(color);
				} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException
						| SecurityException e) {
					e.printStackTrace();
				}
			}

			description = node.getInnerXMLText();
		}

		public String getName() {
			return name;
		}

		public String getToolTip() {
			return toolTip;
		}

		public String getIcon() {
			return image;
		}

		public Node getTaskNode() {
			return taskNode;
		}

		public Color getColor() {
			return color;
		}

		public void setColor(Color color) {
			this.color = color;
		}

		public String getDescription() {
			return StringUtils.defaultString(description, "");
		}

	}

	private String title;
	private Color color;

	public void setTitle(String title) {
		this.title = title;
	}

	public void addItem(Node taskNode) {
		add(new Item(taskNode));
	}

	public String getTitle() {
		return title;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

}
