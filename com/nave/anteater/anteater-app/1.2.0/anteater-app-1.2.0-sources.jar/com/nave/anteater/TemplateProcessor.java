package com.nave.anteater;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.sling.commons.json.JSONArray;
import org.apache.sling.commons.json.JSONException;
import org.apache.sling.commons.json.JSONObject;

import com.nave.anteater.util.AEUtils;
import com.nave.anteater.util.xml.easyparser.Node;

public class TemplateProcessor {

	protected static final String MAPPED_VAR_DELIM = "::";

	protected Properties fSoftwareGuids = new Properties();

	protected Map<String, Object> fVariables = new HashMap<String, Object>();

	protected Map<String, Object> fParameters = new HashMap<String, Object>();

	protected static Map<String, Object> fGlobalVariables = new HashMap<String, Object>();

	protected Node fConfigNode;

	private File fBaseDir;

	public File getBaseDir() {
		return fBaseDir;
	}

	public void setBaseDir(File theBaseDir) {
		this.fBaseDir = theBaseDir;
	}

	public TemplateProcessor(Map<String, Object> variables, Node configNode, File baseDir) {
		super();
		fVariables = variables;
		fConfigNode = configNode;
		setBaseDir(baseDir);
	}

	public String replaceProperties(String aValue) {
		if (aValue == null)
			return null;

		do {
			aValue = replaceProperties(aValue, false);
		} while (aValue.indexOf("$var{") >= 0);

		return aValue;
	}

	protected String replaceProperties(String aValue, boolean aUseDefaultValue) {
		aValue = replaceFile(aValue);
		String theStartKey = "$var{";
		String theEndKey = "}";
		int theBeginPos = 0;
		int theEndPos = 0;
		if (aValue == null) {
			return aValue;
		}
		StringBuffer theStringBuffer = new StringBuffer();
		while (true) {
			theBeginPos = aValue.indexOf(theStartKey, theEndPos);
			if (theBeginPos < 0) {
				break;
			}
			theStringBuffer.append(aValue.substring(theEndPos, theBeginPos));
			theEndPos = aValue.indexOf(theEndKey, theBeginPos);
			if (theEndPos < 0) {
				throw new RuntimeException("Variable getting incorrect syntax, absent symbol '" + theEndKey + "'.");
			}
			String theNameProperty = aValue.substring(theBeginPos + theStartKey.length(), theEndPos);
			String theDefaultValue = null;
			// default value checking
			int defaultPos = theNameProperty.indexOf(',');
			if (defaultPos >= 0) {
				theDefaultValue = theNameProperty.substring(defaultPos + 1);
				theNameProperty = theNameProperty.substring(0, defaultPos);
			}
			String theValue = null;

			if ("THREAD_INFO".equals(theNameProperty)) {
				theValue = Thread.currentThread().toString();

			} else if (StringUtils.startsWith(theNameProperty, "\\")) {
				theValue = StringEscapeUtils.unescapeJava(theNameProperty);

			} else if (StringUtils.startsWith(theNameProperty, "\\")) {
				theValue = StringEscapeUtils.unescapeJava(theNameProperty);

			} else {
				Object o = null;
				if (aUseDefaultValue == false || theDefaultValue == null) {
					o = getVariableValue(theNameProperty);
				}
				if (AEUtils.isEmpty(o) && theDefaultValue != null) {
					o = theDefaultValue;
				}

				if (o instanceof String) {
					theValue = (String) o;
				} else if (o instanceof List) {
					if (!((List) o).isEmpty()) {
						theValue = String.valueOf(((List) o).get(0));
					} else {
						theValue = StringUtils.EMPTY;
					}

				} else if (o instanceof byte[]) {
					theValue = new String((byte[]) o);
				} else {
					theValue = ObjectUtils.toString(o);
				}

			}

			remarkExtendsReplacer(theStringBuffer, theValue, "/*$var{" + theNameProperty + "}*/");
			theEndPos += theEndKey.length();
		}
		theStringBuffer.append(aValue.substring(theEndPos));

		return replaceTag(replaceCall(theStringBuffer.toString()));
	}

	private void remarkExtendsReplacer(StringBuffer aStringBuffer, String aValue, String aRemark) {
		String s = null;
		if (aStringBuffer.length() >= 4) {
			s = aStringBuffer.substring(aStringBuffer.length() - 4);
		}
		if ("';--".equals(s)) {
			int theEnd = 0;
			for (theEnd = aStringBuffer.length() - 5;; theEnd--) {
				char c = aStringBuffer.charAt(theEnd);
				if (c == '\'') {
					break;
				}
			}
			aStringBuffer.setLength(theEnd);
			aStringBuffer.append('\'');
			aStringBuffer.append(aValue);
			aStringBuffer.append('\'');
			aStringBuffer.append(';');
			if (aRemark != null) {
				aStringBuffer.append(" " + aRemark);
			}
		} else {
			s = null;
			if (aStringBuffer.length() >= 3) {
				s = aStringBuffer.substring(aStringBuffer.length() - 3);
			}
			if (";--".equals(s)) {
				int theEnd = 0;
				for (theEnd = aStringBuffer.length() - 4;; theEnd--) {
					char c = aStringBuffer.charAt(theEnd);
					if (c == ' ' || c == '=') {
						break;
					}
				}
				aStringBuffer.setLength(theEnd + 1);
				aStringBuffer.append(aValue);
				aStringBuffer.append(';');
				if (aRemark != null) {
					aStringBuffer.append(" " + aRemark);
				}
			} else {
				s = null;
				if (aStringBuffer.length() >= 2) {
					s = aStringBuffer.substring(aStringBuffer.length() - 2);
				}
				if ("--".equals(s)) {
					aStringBuffer.setLength(aStringBuffer.length() - 2);
					aStringBuffer.append(aValue);
				} else {
					aStringBuffer.append(aValue);
				}
			}
		}
	}

	protected String replaceCall(String aValue) {
		return aValue;
	}

	protected String replaceTag(String aValue) {
		String theStartKey = "$tag{";
		String theEndKey = "}";
		int theBeginPos = 0;
		int theEndPos = 0;
		if (aValue == null) {
			return aValue;
		}
		StringBuffer theStringBuffer = new StringBuffer();
		while (true) {
			theBeginPos = aValue.indexOf(theStartKey, theEndPos);
			if (theBeginPos < 0) {
				break;
			}
			theStringBuffer.append(aValue.substring(theEndPos, theBeginPos));
			theEndPos = aValue.indexOf(theEndKey, theBeginPos);
			if (theEndPos < 0) {
				throw new RuntimeException("Tag created is incorrect syntax, absent symbol '" + theEndKey + "'.");
			}
			String theLine = aValue.substring(theBeginPos + theStartKey.length(), theEndPos);
			int thePbrk = theLine.indexOf(',');
			String theTagName = theLine;
			String theNameVar = theLine;
			if (thePbrk > 0) {
				theTagName = theLine.substring(0, thePbrk);
				theNameVar = theLine.substring(thePbrk + 1);
			}
			Object o = getVariableValue(theNameVar);
			String theValue = null;
			if (o instanceof String) {
				theValue = (String) o;
			}
			if (o instanceof List && !((List) o).isEmpty()) {
				theValue = String.valueOf(((List) o).get(0));
			}
			if (theValue != null) {
				theStringBuffer.append('<');
				theStringBuffer.append(theTagName);
				theStringBuffer.append('>');
				theValue = theValue.replaceAll("\"", "&quot;");
				theValue = theValue.replaceAll("\'", "&apos;");
				theValue = theValue.replaceAll("<", "&lt;");
				theValue = theValue.replaceAll(">", "&gt;");
				theStringBuffer.append(theValue);
				theStringBuffer.append("</");
				theStringBuffer.append(theTagName);
				theStringBuffer.append('>');
			} else {
				theStringBuffer.append('<');
				theStringBuffer.append(theTagName);
				theStringBuffer.append("/>");
			}
			theEndPos += theEndKey.length();
		}
		theStringBuffer.append(aValue.substring(theEndPos));
		return theStringBuffer.toString();
	}

	protected String replaceFile(String aValue) {
		String theStartKey = "$file{";
		String theEndKey = "}";
		int theBeginPos = 0;
		int theEndPos = 0;
		if (aValue == null) {
			return aValue;
		}
		StringBuffer theStringBuffer = new StringBuffer();
		while (true) {
			theBeginPos = aValue.indexOf(theStartKey, theEndPos);
			if (theBeginPos < 0) {
				break;
			}
			theStringBuffer.append(aValue.substring(theEndPos, theBeginPos));
			theEndPos = aValue.indexOf(theEndKey, theBeginPos);
			if (theEndPos < 0) {
				throw new RuntimeException(
						"Insert file marcer is incorrect syntax, absent symbol '" + theEndKey + "'.");
			}
			String theLine = aValue.substring(theBeginPos + theStartKey.length(), theEndPos);
			int thePbrk = theLine.indexOf(',');
			String theFileName = theLine;
			String theEncodeVar = "UTF-8";
			if (thePbrk > 0) {
				theFileName = theLine.substring(0, thePbrk);
				theEncodeVar = theLine.substring(thePbrk + 1);
			}
			String theXML;
			try {
				theXML = AEUtils.loadResource(theFileName, getBaseDir(), theEncodeVar);
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
			theXML = replaceProperties(theXML);
			remarkExtendsReplacer(theStringBuffer, theXML, null);
			theEndPos += theEndKey.length();
		}
		theStringBuffer.append(aValue.substring(theEndPos));
		return theStringBuffer.toString();
	}

	public Object getVariableValue(String aAttribut) {
		if (aAttribut == null)
			return null;
		aAttribut = toUpperCaseName(aAttribut);
		if ("BASEDIR".equals(aAttribut))
			return getBaseDir().getPath();
		return getVariableValue(aAttribut, true);
	}

	public String getVariableString(String aAttribut) {
		Object variableValue = getVariableValue(aAttribut);

		if (variableValue instanceof List) {
			List theStringArr = (List) variableValue;
			if (theStringArr.size() > 0) {
				variableValue = theStringArr.get(0);
			}
		}

		return ObjectUtils.toString(variableValue);
	}

	public String toUpperCaseName(String aAttribut) {
		String result = null;
		if (aAttribut.indexOf(MAPPED_VAR_DELIM) >= 0) {
			result = StringUtils.substringBefore(aAttribut, MAPPED_VAR_DELIM).toUpperCase() + MAPPED_VAR_DELIM
					+ StringUtils.substringAfter(aAttribut, MAPPED_VAR_DELIM);
		} else {
			result = aAttribut.toUpperCase();
		}
		return result;
	}

	public Object getVariableValue(String aAttribut, boolean aArrayTrimed) {
		Object o = null;
		aAttribut = toUpperCaseName(aAttribut);
		Map<String, Object> theVariables = fVariables;
		if (aAttribut.startsWith("!"))
			theVariables = fGlobalVariables;

		boolean isMappedVar = aAttribut.indexOf(MAPPED_VAR_DELIM) > 0;
		if (isMappedVar) {
			o = getValueByPath(aAttribut, theVariables);

		} else {
			o = theVariables.get(aAttribut);
		}

		if (o instanceof List) {
			List theStringArr = (List) o;
			if (theStringArr.size() == 1 && aArrayTrimed) {
				o = theStringArr.get(0);
			}
		}

		if (fParameters.get(aAttribut) != null) {
			o = fParameters.get(aAttribut);
		}

		if (o instanceof JSONArray) {
			JSONArray array = (JSONArray) o;
			String[] value = new String[array.length()];
			for (int i = 0; i < value.length; i++) {
				value[i] = ObjectUtils.toString(array.opt(i));
			}
			o = value;
		}

		return o;
	}

	private Object getValueByPath(String aAttribut, Map<String, Object> theVariables) {
		Object o = null;
		String mapVarName = StringUtils.substringBefore(aAttribut, MAPPED_VAR_DELIM);
		try {
			Object object = theVariables.get(mapVarName);
			if (object instanceof String && ((String) object).stripLeading().startsWith("{")) {
				object = new JSONObject(ObjectUtils.toString(object));
			}

			@SuppressWarnings("unchecked")
			Object mapVar = object;

			mapVarName = StringUtils.substringAfter(aAttribut, MAPPED_VAR_DELIM);

			if (mapVar instanceof Map) {
				o = getNestedValue(mapVarName, (Map) mapVar);
			} else if (mapVar instanceof JSONObject) {
				JSONObject json = (JSONObject) object;
				o = getNestedJsonValue(mapVarName, (JSONObject) json);
			}

		} catch (ClassCastException | JSONException e) {
			e.printStackTrace();
			o = null;
		}
		return o;
	}

	private Object getNestedValue(String varName, Map<String, Object> mapVar) {
		Object o;
		if (mapVar != null) {
			String mapVarName = StringUtils.substringBefore(varName, MAPPED_VAR_DELIM);
			o = mapVar.get(mapVarName);

			mapVarName = StringUtils.substringAfter(varName, MAPPED_VAR_DELIM);
			if (StringUtils.isNotBlank(mapVarName) && o instanceof Map) {
				o = getNestedValue(mapVarName, (Map<String, Object>) o);
			}

		} else {
			o = null;

		}
		return o;
	}

	private Object getNestedJsonValue(String varName, Object json) throws JSONException {
		Object o = null;
		try {
			if (json != null) {
				String mapVarName = StringUtils.substringBefore(varName, MAPPED_VAR_DELIM);
				if (json instanceof JSONObject) {
					o = ((JSONObject) json).get(mapVarName);
				} else if (json instanceof JSONArray) {
					JSONArray array = (JSONArray) json;
					if (NumberUtils.isNumber(mapVarName)) {
						o = array.get(Integer.parseInt(mapVarName));
					} else {
						o = null;
					}
				}

				mapVarName = StringUtils.substringAfter(varName, MAPPED_VAR_DELIM);
				if (StringUtils.isNotBlank(mapVarName)) {
					o = getNestedJsonValue(mapVarName, o);
				}

			} else {
				o = null;

			}
		} catch (JSONException e) {
			o = null;
		}
		return o;
	}

	public File getFile(String theFileAttribut) {
		return new File(theFileAttribut);
	}

	public static Map<String, Object> getGlobalVariables() {
		return fGlobalVariables;
	}

	public void setVariableValue(String aAttribut, final Object aValue) {

		if (aAttribut == null) {
			return;
		}

		aAttribut = toUpperCaseName(aAttribut);

		Map<String, Object> variables = this.fVariables;
		if (aAttribut.startsWith("!")) {
			variables = fGlobalVariables;
		}
		boolean isMappedVar = aAttribut.indexOf(MAPPED_VAR_DELIM) > 0;
		if (aValue != null) {
			if (isMappedVar) {
				String mapVarName = StringUtils.substringBefore(aAttribut, MAPPED_VAR_DELIM);

				Object value = variables.get(mapVarName);
				if (value instanceof JSONObject) {
					String varName = StringUtils.substringAfter(aAttribut, MAPPED_VAR_DELIM);
					setJsonValue(value, varName, aValue);
					return;

				} else if (!(value instanceof Map)) {
					variables.put(mapVarName, new HashMap());
				}
				@SuppressWarnings("unchecked")
				Map<String, Object> mapVar = (Map<String, Object>) variables.get(mapVarName);

				if (mapVar == null) {
					mapVar = new HashMap<String, Object>();
					variables.put(mapVarName, mapVar);
				}

				String varName = StringUtils.substringAfter(aAttribut, MAPPED_VAR_DELIM);
				mapVar.put(varName, aValue);

			} else {
				variables.put(aAttribut, aValue);
			}

		} else {
			if (isMappedVar) {
				String mapVarName = StringUtils.substringBefore(aAttribut, MAPPED_VAR_DELIM);
				Map<?, ?> mapVar = (Map<?, ?>) variables.get(mapVarName);
				if (mapVar != null) {
					mapVar.remove(aAttribut);
				}

			} else {
				variables.remove(aAttribut);
			}

		}
	}

	private void setJsonValue(Object value, String name, final Object aValue) {
		String varName = StringUtils.substringBefore(name, MAPPED_VAR_DELIM);
		String nestedName = StringUtils.substringAfter(name, MAPPED_VAR_DELIM);

		JSONObject json = (JSONObject) value;
		try {
			if (StringUtils.isEmpty(nestedName)) {
				json.put(varName, aValue);

			} else {
				Object object = json.get(varName);
				setJsonValue(object, nestedName, aValue);
			}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
