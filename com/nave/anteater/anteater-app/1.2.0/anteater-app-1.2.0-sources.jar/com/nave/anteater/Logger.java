package com.nave.anteater;

public class Logger implements ILogger {

	private org.apache.log4j.Logger logger;

	public Logger(String name) {
		logger = org.apache.log4j.Logger.getLogger(name);
	}

	@Override
	public void info(Object message) {
		logger.info(message);
	}

	@Override
	public void debug(Object message) {
		logger.debug(message);
	}

	@Override
	public void debug(Object message, Throwable t) {
		debug(message, t);
	}

	@Override
	public void warn(Object message) {
		logger.warn(message);
	}

	@Override
	public void error(Object message) {
		logger.error(message);
	}

	@Override
	public void error(Object message, Throwable t) {
		logger.error(message, t);
	}

	@Override
	public String getName() {
		return logger.getName();
	}

}
