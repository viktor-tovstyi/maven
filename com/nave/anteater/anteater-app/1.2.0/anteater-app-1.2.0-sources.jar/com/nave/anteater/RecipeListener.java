package com.nave.anteater;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.xml.easyparser.Node;

public interface RecipeListener {

	void setProgress(String aCurrentTaskName, long aMaxTags, long aCurrTags, boolean aErrorState);

	void startTask(String aNameTask);

	void endTask(boolean aErrorState);

	void changeVariable(String aAttribut, Object aValue);

	void startCommand(int i);

	void startChildProcess(TaskProcessorThread aMaxTestRunnable);

	void stopChildProcess(TaskProcessorThread aMaxTestRunnable);

	void criticalError(CommandException aThrowable, TaskProcessor processor);

	void checkFailure(CommandException e, TaskProcessor processor);

	void aboutTest(String theTaskName, Node aCurrentAction);

	String getRunMode();

	void exceptionIgnored(Throwable e);

	ServerSocket createPort(int thePort, String aDescription) throws IOException;

	void closePort(int thePort);

	void errorInformation(TaskProcessor processor, Throwable e, Node aTaskNode) throws CommandException;

	void outToFrame(TaskProcessor processor, Properties aProperties, Object theValue) throws Exception;

	void runCommandFrame(Properties params) throws Throwable;

	ILogger createLog(String aLogName, boolean mainLog);

	void dbPropertiesCheck(Properties aProperties);

	AEManager getManager();

	void pause();

	void resume();

	void stopTest();
	
	public boolean isNotifyMe();
}
