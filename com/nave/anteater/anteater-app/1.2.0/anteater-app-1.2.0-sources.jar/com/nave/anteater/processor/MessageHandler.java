package com.nave.anteater.processor;

public class MessageHandler {

	public void close() {
		// TODO Auto-generated method stub
		
	}

}
