package com.nave.logfilter;

import java.util.Map;

import com.nave.anteater.util.AEUtils;

public class MaskEmail implements LogFilter {

	public MaskEmail(Map<String, String> params) {
	}

	public String filter(String text) {
		text = AEUtils.maskEmail(text);
		return text;
	}

}
