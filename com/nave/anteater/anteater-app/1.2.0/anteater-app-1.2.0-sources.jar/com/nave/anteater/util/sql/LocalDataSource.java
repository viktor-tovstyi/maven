package com.nave.anteater.util.sql;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLWarning;
import java.util.HashMap;
import java.util.Properties;
import java.util.Set;

import javax.sql.DataSource;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

public class LocalDataSource implements DataSource {

	private static final String DEFAULT_CONNECTION_NAME = "[main]";

	private final static Logger log = Logger.getLogger(LocalDataSource.class);

	private static HashMap<String, Properties> fProperties = new HashMap<String, Properties>();

	private String connectionName;

	public LocalDataSource(String connectionName) {
		this.connectionName = connectionName;
	}

	public int getLoginTimeout() throws SQLException {
		return 0;
	}

	public void setLoginTimeout(final int seconds) throws SQLException {
	}

	public PrintWriter getLogWriter() throws SQLException {
		return null;
	}

	public void setLogWriter(final PrintWriter out) throws SQLException {
	}

	public Connection getConnection() throws SQLException {
		String connectionName = StringUtils.defaultIfEmpty(this.connectionName, DEFAULT_CONNECTION_NAME);
		Properties properties = fProperties.get(connectionName);
		return getConnection(properties.getProperty("username"), properties.getProperty("password"));
	}

	public Connection getConnection(final String username, final String password) throws SQLException {
		Connection connection = null;
		String connectionName = StringUtils.defaultIfEmpty(this.connectionName, DEFAULT_CONNECTION_NAME);
		Properties properties = fProperties.get(connectionName);
		String url = properties.getProperty("url");
		connection = DriverManager.getConnection(url, username, password);

		SQLWarning warning = connection.getWarnings();
		while (null != warning) {
			String message = warning.getMessage();
			log.warn(message);
			warning = warning.getNextWarning();
		}

		return connection;
	}

	public static void setConnectionProperties(String connectionName, final Properties aProperties) {
		connectionName = StringUtils.defaultIfEmpty(connectionName, DEFAULT_CONNECTION_NAME);

		fProperties.put(connectionName, aProperties);

		log.debug("Connection [" + connectionName + "] to:");
		log.debug("Driver: " + aProperties.getProperty("driver"));
		log.debug("URL: " + aProperties.getProperty("url"));
		log.debug("Username: " + aProperties.getProperty("username"));
		String password = aProperties.getProperty("password");
		if (password != null) {
			password = StringUtils.leftPad("", password.length(), "*");
		}
		log.debug("Password: " + password);

		try {
			Driver driver = (Driver) Class.forName(aProperties.getProperty("driver")).newInstance();
			DriverManager.registerDriver(driver);

		} catch (final Exception ex) {
			throw new RuntimeException(
					"Cannot load/register jdbc fDriver: " + aProperties.getProperty("driver") + ": " + ex.getMessage());
		}
	}

	public <T> T unwrap(final Class<T> iface) throws SQLException {
		return null;
	}

	public boolean isWrapperFor(final Class<?> iface) throws SQLException {
		return false;
	}

	public java.util.logging.Logger getParentLogger() throws SQLFeatureNotSupportedException {
		return null;
	}

	public static Set<String> getConnectionNames() {
		return fProperties.keySet();
	}
}
