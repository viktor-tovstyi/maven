package com.nave.anteater;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.xml.easyparser.Node;

public class TaskProcessorThread implements Runnable {

	public static final String THREAD_ID = "THREAD_ID";

	private Node task;
	private File baseDir;
	private TaskProcessor parent;
	private TaskProcessor processor;
	private ILogger log;
	private Map<String, Object> variables = new HashMap<String, Object>();

	public TaskProcessorThread(TaskProcessor parent, Node task, File aBaseDir, ILogger aLog) {
		this.parent = parent;
		parent.regChildProcess(this);

		this.task = task;
		baseDir = aBaseDir;
		log = aLog;

		processor = new TaskProcessor(parent.getConfigNode(), parent.getStartVariables(), parent.getListener(), null, log,
				parent);

		processor.setTestListener(parent.getListener());
	}

	public void run() {

		Node theRunNode = new Node("Recipe");
		theRunNode.setAttributes(task.getAttributes());
		theRunNode.add(task);
		String name = theRunNode.getAttribute("description");
		log.debug("Thread '" + name + "' is started.");
		try {
			variables.putAll(parent.getVariables());
			processor.processTesting(theRunNode, variables, baseDir);

		} catch (Throwable e) {
			log.error("Exception in thread. Error: " + e.getMessage());
			log.debug("Stack trace", e);

		} finally {

			parent.unregChildProcess(this);
			log.debug("Thread '" + name + "' is stopped.");
		}
	}

	public void stopTest() {
		processor.stop();
	}

	public void getVaribleValue(String aName, String aValue) {
		variables.put(aName, aValue);
	}

	public TaskProcessor getProcessor() {
		return processor;
	}

	public TaskProcessorThread clone(int cloneId) {
		TaskProcessorThread clone;
		if (cloneId == 0) {
			clone = this;
		} else {
			String aLogName = this.log.getName() + " #" + cloneId;
			ILogger log = parent.getListener().createLog(aLogName, false);
			clone = new TaskProcessorThread(parent, task, baseDir, log);
		}
		clone.processor.setVariableValue(THREAD_ID, String.valueOf(cloneId));
		return clone;
	}
}
