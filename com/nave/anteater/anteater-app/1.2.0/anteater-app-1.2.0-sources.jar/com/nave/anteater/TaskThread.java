package com.nave.anteater;

public class TaskThread extends Thread {

	private TestRunner place;
	private String testFile;

	public TaskThread(TestRunner place, String testFile) {
		this.place = place;
		this.testFile = testFile;
	}

	public void run() {
		try {
			place.makeRecipe(testFile);
		} catch (Throwable e) {
			place.getLogger().error("Task faled.", e);
		}
	}
}
