package com.nave.anteater;

public class ConfigConstants {

	public static final String AECONFIG_SYS_PRPERTY_NAME = "ae";
	
	public static final String AE_CONFIG_XML = "ae.xml";
	
	public static final String CONFIG_NAME_SYS_PRPERTY_NAME = "configName";

	public static final String TAKE_IT_EASY_MODE = "takeItEasy";

}
