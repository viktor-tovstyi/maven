package com.nave.anteater;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang.ObjectUtils;

public class AELogRecord {

	private Object message;
	private String type;
	private String varName;

	public AELogRecord(Object text, String type, String varName) {
		this.message = text;
		this.type = type;
		this.varName = varName;
	}

	@Override
	public String toString() {
		return getText();
	}

	public String getText() {
		if (message instanceof byte[]) {
			return new String((byte[]) message);
		} else if (message instanceof Properties) {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			Properties pr = (Properties) message;
			try {
				pr.store(out, null);
			} catch (IOException e) {
				throw new IllegalArgumentException(e);
			}
			return out.toString();
		} else if (message instanceof Map) {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			Map<String, Object> map = (Map<String, Object>) message;
			
			Set<Entry<String, Object>> entrySet = map.entrySet();
			Properties pr = new Properties();
			for (Entry<String, Object> entry : entrySet) {
				Object value = entry.getValue();
				if (value instanceof String) {
					pr.setProperty(entry.getKey(), ObjectUtils.toString(value));
				}
			}
			
			try {
				pr.store(out, null);
			} catch (IOException e) {
				throw new IllegalArgumentException(e);
			}
			return out.toString();
		}
		return ObjectUtils.toString(message, null);
	}

	public Object getMessage() {
		return message;
	}

	public String getType() {
		return type;
	}

	public String getVarName() {
		return varName;
	}

	public void setVarName(String varName) {
		this.varName = varName;
	}
	
}
