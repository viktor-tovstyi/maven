package com.nave.anteater.util.xml.easyparser;

public class ParserException extends Exception {

	public ParserException(Exception e) {
		super(e);
	}

}
