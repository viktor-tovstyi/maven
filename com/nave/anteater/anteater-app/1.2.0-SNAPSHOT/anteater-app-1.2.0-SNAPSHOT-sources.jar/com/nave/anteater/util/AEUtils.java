package com.nave.anteater.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.Validate;

import com.nave.anteater.TemplateProcessor;
import com.nave.anteater.util.xml.easyparser.EasyParser;
import com.nave.anteater.util.xml.easyparser.Node;

public class AEUtils {

	public static InputStream getInputStream(String aFileName, File aBaseDir)
			throws FileNotFoundException, IOException, MalformedURLException {
		InputStream theInputStream = null;

		if ('/' == aFileName.charAt(0) || '\\' == aFileName.charAt(0)) {
			theInputStream = new FileInputStream(aFileName);

		} else if (aFileName.startsWith("jar:file:")) {
			theInputStream = new URL(aFileName.replace('\\', '/')).openStream();

		} else if (aBaseDir.toString().startsWith("jar:file:")) {

			String basePath = aBaseDir.toString();
			basePath = StringUtils.substringBefore(basePath, "!") + "!"
					+ StringUtils.substringAfter(basePath, "!").replace('\\', '/');
			String spec = basePath + "/" + aFileName.replace('\\', '/');
			theInputStream = new URL(spec).openStream();

		} else {
			File file = new File(aFileName);
			if (!file.exists()) {
				file = new File(aBaseDir, aFileName);
			}
			theInputStream = new FileInputStream(file);

		}
		return theInputStream;
	}

	public static String loadResource(String aFileName, File aBaseDir, String aEncode)
			throws IOException, ParseException {
		Validate.notEmpty(aFileName, "Request file name is empty.");

		InputStream theInputStream = AEUtils.getInputStream(aFileName, aBaseDir);

		String theEncode = aEncode;

		Node theHead = null;
		try {

			byte[] theBuffer = IOUtils.toByteArray(theInputStream);
			theInputStream.read(theBuffer);

			int theEndHead = 0;

			String theDocHead = new String(theBuffer, "UTF-8");
			if (theDocHead.indexOf("<?xml") == 0) {
				theEndHead = theDocHead.indexOf("?>");
				EasyParser theParser = new EasyParser();
				theHead = theParser.getObject(theDocHead.substring(0, theEndHead) + "/>");
				theEncode = theHead.getAttribute("encoding");
				theEndHead += 2;
			}

			if (theEncode == null)
				theEncode = "UTF-8";

			return new String(theBuffer, theEncode);

		} finally {
			if (theInputStream != null)
				theInputStream.close();
		}

	}

	public static boolean isExceptionIgnore(TemplateProcessor tp, final Node aCurrentAction) {
		String attribute = tp.replaceProperties(aCurrentAction.getAttribute("exception"));
		final boolean theIgnoredExceptionState = "ignored".equals(attribute)
				|| "ignore".equals(aCurrentAction.getAttribute("exception"));
		return theIgnoredExceptionState;
	}

	public static Map<String, String> convertStringToMap(String value) {
		Map<String, String> theValue = null;
		if (value != null) {
			Properties props = new Properties();
			try {
				Map<String, String> map2 = new LinkedHashMap<String, String>();
				for (Map.Entry<Object, Object> e : props.entrySet()) {
					map2.put((String) e.getKey(), (String) e.getValue());
				}
				String replace = value.substring(1, value.length() - 1).replace(", ", "\n");
				props.load(new StringReader(replace));
				theValue = new TreeMap<>();
				Set<Entry<Object, Object>> entrySet = props.entrySet();
				for (Entry<Object, Object> entry : entrySet) {
					theValue.put((String) entry.getKey(), (String) entry.getValue());
				}
			} catch (IOException e1) {
				// skip
			}
		}

		return theValue;
	}

}
