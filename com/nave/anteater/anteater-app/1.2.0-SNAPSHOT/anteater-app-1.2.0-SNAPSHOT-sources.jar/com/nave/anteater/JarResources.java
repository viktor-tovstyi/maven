package com.nave.anteater;

import java.io.*;
import java.util.*;
import java.util.zip.*;

public final class JarResources {

	private Hashtable htSizes = new Hashtable();
	private Hashtable htJarContents = new Hashtable();
	private File jarFileName;

	public JarResources(File jarFileName) {
		this.jarFileName = jarFileName;
		init();
	}

	public byte[] getResource(String name) {
		return (byte[]) htJarContents.get(name);
	}

	private void init() {
		try {
			ZipFile zf = new ZipFile(jarFileName);
			Enumeration e = zf.entries();
			while (e.hasMoreElements()) {
				ZipEntry ze = (ZipEntry) e.nextElement();
				htSizes.put(ze.getName(), new Integer((int) ze.getSize()));
			}
			zf.close();

			FileInputStream fis = new FileInputStream(jarFileName);
			BufferedInputStream bis = new BufferedInputStream(fis);
			ZipInputStream zis = new ZipInputStream(bis);
			ZipEntry ze = null;
			while ((ze = zis.getNextEntry()) != null) {
				if (ze.isDirectory()) {
					continue;
				}

				int size = (int) ze.getSize();
				if (size == -1) {
					size = ((Integer) htSizes.get(ze.getName())).intValue();
				}

				byte[] b = new byte[(int) size];
				int rb = 0;
				int chunk = 0;
				while (((int) size - rb) > 0) {
					chunk = zis.read(b, rb, (int) size - rb);
					if (chunk == -1) {
						break;
					}
					rb += chunk;
				}

				// add to internal resource hashtable
				htJarContents.put(ze.getName(), b);
			}
		} catch (NullPointerException e) {
			//
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
