package com.nave.anteater;

import java.util.Iterator;

public interface MultiTaskRunDialog {

	void showDialog(String name, String[] theNames);

	Iterator<String> getSelectedTasks();

	void begin(String taskName);

	void end(String taskName, boolean statusOk);

	boolean isExceptionIgnore();

	void done();

	void setExceptionIgnore(boolean flag);

	void select(String[] attribute, boolean defaultMode);

	boolean isStarted();

	String getName();

}
