package com.nave.anteater.util.sql;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Writer;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import oracle.jdbc.OracleTypes;
import oracle.sql.CLOB;

public class BaseConnectionProvider extends AbstractConnectionProvider {
	private final static Logger log = Logger.getLogger(BaseConnectionProvider.class);

	public BaseConnectionProvider(String connectionName) throws SQLException {
		super(connectionName);
	}

	protected String fQueryLine;

	private long fStartTime;
	private long fEndTime;

	public String getQueryLine() {
		return fQueryLine;
	}

	public long getExecuteTime() {
		if (fStartTime == 0 || fEndTime == 0)
			return -1;
		return fEndTime - fStartTime;
	}

	protected void startPoint() {
		fStartTime = System.currentTimeMillis();
	}

	protected void finishPoint() {
		fEndTime = System.currentTimeMillis();
	}

	public String getStringValue(ResultSet aResultSet, int aColumn) throws SQLException {

		String theResult = null;
		int aOracleType = aResultSet.getMetaData().getColumnType(aColumn);

		switch (aOracleType) {

		case OracleTypes.BIT:
		case OracleTypes.BINARY:
			theResult = Byte.toString(aResultSet.getByte(aColumn));
			break;

		case OracleTypes.INTEGER:
		case OracleTypes.SMALLINT:
		case OracleTypes.TINYINT:
			theResult = Integer.toString(aResultSet.getInt(aColumn));
			break;

		case OracleTypes.DECIMAL:
			theResult = Integer.toString(aResultSet.getInt(aColumn));
			break;

		case OracleTypes.NUMERIC:
			BigDecimal theBigDecimal = aResultSet.getBigDecimal(aColumn);
			if (theBigDecimal != null)
				theResult = theBigDecimal.toString();
			break;

		case OracleTypes.BIGINT:
			theResult = aResultSet.getBigDecimal(aColumn).toString();
			break;

		case OracleTypes.FLOAT:
			theResult = Float.toString(aResultSet.getFloat(aColumn));
			break;

		case OracleTypes.REAL:
			theResult = Double.toString(aResultSet.getDouble(aColumn));
			break;

		case OracleTypes.DOUBLE:
			theResult = Double.toString(aResultSet.getDouble(aColumn));
			break;

		case OracleTypes.NVARCHAR:
			theResult = aResultSet.getNString(aColumn);
			break;

		case OracleTypes.CHAR:
		case OracleTypes.VARCHAR:
			theResult = aResultSet.getString(aColumn);
			break;

		case OracleTypes.LONGVARCHAR:
			break;

		case OracleTypes.DATE:
			Date theDate = aResultSet.getDate(aColumn);
			if (theDate != null)
				theResult = theDate.toString();
			break;

		case OracleTypes.TIME:
			theResult = aResultSet.getTime(aColumn).toString();
			break;

		case OracleTypes.TIMESTAMPLTZ:
		case OracleTypes.TIMESTAMPTZ:
		case OracleTypes.TIMESTAMP:
			Timestamp timestamp = aResultSet.getTimestamp(aColumn);
			if (timestamp != null)
				theResult = timestamp.toString();
			break;

		case OracleTypes.VARBINARY:
			break;

		case OracleTypes.LONGVARBINARY:
			break;

		case OracleTypes.ROWID:
			theResult = Long.toString(aResultSet.getLong(aColumn));
			break;

		case OracleTypes.CURSOR:
			break;

		case OracleTypes.BLOB:
			Blob blob = aResultSet.getBlob(aColumn);
			try {
				if (blob != null) {
					theResult = new String(IOUtils.toByteArray(blob.getBinaryStream()));
				}
			} catch (IOException e) {
				new SQLException(e);
			}
			break;

		case OracleTypes.CLOB:
			Clob clob = aResultSet.getClob(aColumn);
			try {
				if (clob != null) {
					theResult = IOUtils.toString(clob.getAsciiStream());
				}
			} catch (IOException e) {
				new SQLException(e);
			}
			break;

		case OracleTypes.BFILE:
			break;

		case OracleTypes.STRUCT:
			break;

		case OracleTypes.ARRAY:
			break;

		case OracleTypes.REF:
			break;

		case OracleTypes.OPAQUE:
			break;

		case OracleTypes.JAVA_STRUCT:
			break;

		case OracleTypes.JAVA_OBJECT:
			break;

		case OracleTypes.PLSQL_INDEX_TABLE:
			break;

		case OracleTypes.NULL:
			break;

		case OracleTypes.OTHER:
			break;

		case OracleTypes.FIXED_CHAR:
			break;

		case OracleTypes.DATALINK:
			break;

		case OracleTypes.BOOLEAN:
			break;
		}
		return theResult;
	}

	/**
	 * Creates the Oracle CLOB with read/write option
	 * 
	 * @param clobData
	 *            the input clob data
	 * 
	 * @return CLOB
	 * 
	 * @throws SQLException
	 * @throws java.io.IOException
	 */
	public CLOB createClob(String clobData) throws SQLException, IOException {
		log.debug("Start CLOB creation");
		long theTime = System.currentTimeMillis();
		CLOB clob = null;
		CallableStatement functionPs = connection().prepareCall("{ call DBMS_LOB.createtemporary (?, TRUE) }");
		functionPs.registerOutParameter(1, OracleTypes.CLOB);
		functionPs.execute();
		clob = (CLOB) functionPs.getObject(1);
		clob.open(CLOB.MODE_READWRITE);
		Writer clobWriter = clob.getCharacterOutputStream();
		clobWriter.write(clobData);
		clobWriter.flush();
		clobWriter.close();
		clob.close();
		log.debug("End CLOB creation in " + (System.currentTimeMillis() - theTime) + " ms");
		return clob;
	}

	/**
	 * Creates the Oracle CLOB with read/write option
	 * 
	 * @param clobDataFile
	 *            the input clob data
	 * 
	 * @return CLOB
	 * 
	 * @throws SQLException
	 * @throws IOException
	 */
	public CLOB createClob(File clobDataFile) throws SQLException, IOException {
		log.debug("Start CLOB creation from file " + clobDataFile.getCanonicalPath());
		long theTime = System.currentTimeMillis();
		CLOB clob = null;
		CallableStatement functionPs = connection().prepareCall("{ call DBMS_LOB.createtemporary (?, TRUE) }");
		functionPs.registerOutParameter(1, OracleTypes.CLOB);
		functionPs.execute();
		clob = (CLOB) functionPs.getObject(1);
		clob.open(CLOB.MODE_READWRITE);

		byte[] clobDataArray = new byte[(int) clobDataFile.length()];
		FileInputStream fin = new FileInputStream(clobDataFile);
		BufferedInputStream bufClobData = new BufferedInputStream(fin);
		bufClobData.read(clobDataArray);
		OutputStream clobOutputStream = clob.getAsciiOutputStream();
		clobOutputStream.write(clobDataArray);
		clobOutputStream.close();
		clob.close();
		fin.close();
		log.debug("End CLOB creation in " + (System.currentTimeMillis() - theTime) + " ms");
		return clob;
	}

}
