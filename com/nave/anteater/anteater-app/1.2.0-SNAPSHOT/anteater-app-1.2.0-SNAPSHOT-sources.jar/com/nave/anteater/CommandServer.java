package com.nave.anteater;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;

public class CommandServer {

	private static final String STATUS = "/status";
	private static final String HOST = "127.0.0.1";
	protected static final String STOP = "/stop";
	protected static final String RESTART = "/restart";

	static public void createCommandServer(AEWorkspace workspace, String[] args) {
		String commandPort = System.getProperty("commandPort");
		if (commandPort != null && NumberUtils.isNumber(commandPort)) {
			int port = Integer.parseInt(commandPort);
			try {
				openCommandPort(port, workspace);
				if ((ArrayUtils.getLength(args) > 0 && StringUtils.startsWith(args[0], "/"))) {
					System.out.println("Anteater (port: " + port + ") is not found.");
					System.exit(1);
				}

			} catch (BindException e) {
				if (args.length > 0) {
					try {
						Socket socket = new Socket(HOST, port);
						for (String command : args) {
							socket.getOutputStream().write(command.getBytes());
							socket.getOutputStream().write('\n');
							socket.getOutputStream().flush();
							int read = socket.getInputStream().read();
							socket.close();
							if (read == 2) {
								System.out.println("Anteater on port: " + commandPort + " stopped.");
								read = 0;

							} else {
								System.out.println("Anteater (port: " + port + ") returned code:" + read);
							}

							System.exit(read);
						}
						socket.close();

					} catch (IOException e1) {
						e1.printStackTrace();
					}

					System.out.println("Status check is failed.");
					System.exit(2);

				} else {
					System.out.println("Anteater (port: " + port + "): " + e.getMessage());
					System.exit(0);
				}

			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Status check is failed.");
				System.exit(3);
			}

			if (ArrayUtils.getLength(args) > 0 && StringUtils.equalsIgnoreCase(STOP, args[0])) {
				System.out.println("Anteater (port: " + port + ") is not found.");
				System.exit(1);
			}
		}

	}

	private static void openCommandPort(final int commandPort, final AEWorkspace workspace) throws IOException {
		final ServerSocket serverSocket = new ServerSocket(commandPort);
		Thread thread = new Thread() {
			public void run() {
				try {
					Socket accept;
					while (true) {
						int result = 0;
						accept = serverSocket.accept();
						BufferedReader stream = new BufferedReader(new InputStreamReader(accept.getInputStream()));
						boolean isStopCommand = true;
						try {
							while (true) {
								String line = stream.readLine();
								if (line == null) {
									break;
								}

								if (StringUtils.equalsIgnoreCase(STATUS, line)) {
									result = 10;
									isStopCommand = false;
									break;

								} else if (StringUtils.equalsIgnoreCase(RESTART, line)) {
									String configurationName = workspace.getConfigurationName();
									workspace.stopAllRunners();
									workspace.resetConfiguration();
									workspace.loadConfiguration(configurationName, true);
									try {
										workspace.runSetupNodes();
									} catch (Exception e) {
										e.printStackTrace();
										result = 1;
									}
									result = 0;
									isStopCommand = false;
									break;

								} else if (StringUtils.equalsIgnoreCase(STOP, line)) {
									result = 2;
									isStopCommand = true;
									break;

								} else if (StringUtils.isNotBlank(line)) {
									try {
										workspace.runTask(line, true);
										isStopCommand = false;
									} catch (Exception e) {
										result = 1;
									}
								}

							}

							accept.getOutputStream().write(result);
							accept.getOutputStream().flush();
							accept.close();

							if (isStopCommand) {
								System.out.println("Anteater on port: " + commandPort + " stopped.");
								System.exit(3);
							}

						} catch (IOException e) {
							e.printStackTrace();

						}
					}
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			};
		};
		thread.start();
	}

}
