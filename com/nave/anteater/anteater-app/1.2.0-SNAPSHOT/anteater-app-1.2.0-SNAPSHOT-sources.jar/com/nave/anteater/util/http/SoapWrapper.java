package com.nave.anteater.util.http;

import java.util.Properties;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.log4j.Logger;

public interface SoapWrapper {
	void init(Properties aInitNode, Logger aLog);

	void request(String aService, HttpServletRequest aRequest, HttpServletResponse aResponse) throws Throwable;

	String getName();
}