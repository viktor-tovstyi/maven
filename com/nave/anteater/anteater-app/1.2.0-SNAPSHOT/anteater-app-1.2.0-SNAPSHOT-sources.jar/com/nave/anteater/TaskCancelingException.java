package com.nave.anteater;

public class TaskCancelingException extends RuntimeException {

}
