package com.nave.anteater;

public class ConfigurationException extends RuntimeException {

	public ConfigurationException(String string, Exception e) {
		super(string, e);
	}

	public ConfigurationException(String string) {
		super(string);
	}

}
