package com.nave.anteater;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Map;

import com.nave.anteater.processor.TaskProcessor;

public class TestIterator {
    private int fCurrentIteration;

    private int fIterationCount;
    private ArrayList fParameterIteratorArray = new ArrayList();

    private String fType = ParameterIterator.SINGLE;
    private ArrayList fNamePropertiesIsSet = new ArrayList();

    public TestIterator(TaskProcessor processor, InputStream input, String connectionName) throws Exception {
        fIterationCount = 0;
        BufferedReader theBufferedReader = new BufferedReader(new InputStreamReader(input));
        String theLine = null;

        int theMultipleCount = 1;
        ParameterIterator theCurrParameterIterator = null;
        boolean theSinglePresent = false;

        while ((theLine = theBufferedReader.readLine()) != null) {
        	
            if (theLine.length() > 0 && theLine.charAt(0) == '#') continue;

            int thePbrkEndName = theLine.indexOf(':');
            if (thePbrkEndName < 0) {
                theLine = theLine.trim();

                if (ParameterIterator.INDEPENDENT.equalsIgnoreCase(theLine)) {
                    if (theMultipleCount > 1) fIterationCount += theMultipleCount;
                    theCurrParameterIterator = null;
                    theMultipleCount = 1;
                    fType = theLine;
                } else if (ParameterIterator.CONCURRENTLY.equalsIgnoreCase(theLine)) {
                    if (theMultipleCount > 1) fIterationCount += theMultipleCount;
                    theCurrParameterIterator = null;
                    theMultipleCount = 1;
                    fType = theLine;
                } else if (ParameterIterator.EXHAUSTION.equalsIgnoreCase(theLine)) {
                    if (theMultipleCount > 1) fIterationCount += theMultipleCount;
                    theCurrParameterIterator = null;
                    theMultipleCount = 1;
                    fType = theLine;
                } else if (ParameterIterator.SINGLE.equalsIgnoreCase(theLine)) {
                    if (theMultipleCount > 1) fIterationCount += theMultipleCount;
                    theMultipleCount = 1;
                    theCurrParameterIterator = null;
                    fType = theLine;
                } else if (theLine.length() == 0) {
                    continue;
                } else {
                    throw new IOException("Incorrect line in itteration rule file, is absent ':' in line: " + theLine);
                }

                continue;
            }

            String theName = theLine.substring(0, thePbrkEndName);
            String theRules = theLine.substring(thePbrkEndName + 1).trim();

            ParameterIterator theParameterIterator = new ParameterIterator(processor, theName, fIterationCount);

            int thePbrkEndRule = theRules.indexOf(':');

            String theRuleName = theRules;
            String theRuleParameters = null;

            if (thePbrkEndRule >= 0) {
                theRuleName = theRules.substring(0, thePbrkEndRule);
                theRuleParameters = theRules.substring(thePbrkEndRule + 1);
                theParameterIterator.addRule(theRuleName, theRuleParameters, connectionName);
            } else 
            {
                theParameterIterator.addRule("value", theRules, connectionName);             
            }

            if (ParameterIterator.SINGLE.equalsIgnoreCase(fType)) {
            	if(theParameterIterator.count() > 1){
                     fIterationCount += theParameterIterator.count() - 1;
            	}
            	theSinglePresent = true;
                theParameterIterator.setType(ParameterIterator.SINGLE);
            } else  if (ParameterIterator.EXHAUSTION.equalsIgnoreCase(fType)) {
                if (theCurrParameterIterator != null) {
                    theCurrParameterIterator.setChield(theParameterIterator);
                } else {
                    theParameterIterator.setParent(true);                    
                }

                theMultipleCount *= theParameterIterator.count();
                theCurrParameterIterator = theParameterIterator;
                theParameterIterator.setType(ParameterIterator.EXHAUSTION);
            }
            else  if (ParameterIterator.CONCURRENTLY.equalsIgnoreCase(fType)) {
                if (theCurrParameterIterator != null) {
                    theCurrParameterIterator.setChield(theParameterIterator);
                } else {
                    theParameterIterator.setParent(true);
                    fIterationCount += theParameterIterator.count();
                }

                theCurrParameterIterator = theParameterIterator;
                theParameterIterator.setType(ParameterIterator.CONCURRENTLY);
            }
            else  if (ParameterIterator.INDEPENDENT.equalsIgnoreCase(fType)) {
                theParameterIterator.setType(ParameterIterator.INDEPENDENT);
            }

            fParameterIteratorArray.add(theParameterIterator);
        }

        if (theMultipleCount > 1 || 
           (ParameterIterator.EXHAUSTION.equalsIgnoreCase(fType) && theCurrParameterIterator != null) ) 
           			fIterationCount += theMultipleCount;
           			
        if (theSinglePresent) fIterationCount++; //for SINGLE
    }

    public int count() {
        return fIterationCount;
    }

    public void nextIteration(Map<String, Object> aHashtable, String connectionName) 
    throws Exception {

        fNamePropertiesIsSet.clear();

        for (int i = 0; i < fParameterIteratorArray.size(); i++) {
            ParameterIterator theParameterIterator = (ParameterIterator) fParameterIteratorArray.get(i);
            theParameterIterator.applyValue(fCurrentIteration, aHashtable, fNamePropertiesIsSet, connectionName);
        }

        fCurrentIteration++;
    }


    public String[] getPropertiesList() {
        ArrayList theArrayList = new ArrayList();

        for (int i = 0; i < fParameterIteratorArray.size(); i++) {
            ParameterIterator theElem = (ParameterIterator) fParameterIteratorArray.get(i);
            String theName = theElem.getName();
            if (theArrayList.contains(theName) == false) {
                theArrayList.add(theName);
            }
        }

        String[] theReturn = new String[theArrayList.size()];

        for (int i = 0; i < theArrayList.size(); i++) {
            theReturn[i] = (String) theArrayList.get(i);
        }

        return theReturn;
    }
}
