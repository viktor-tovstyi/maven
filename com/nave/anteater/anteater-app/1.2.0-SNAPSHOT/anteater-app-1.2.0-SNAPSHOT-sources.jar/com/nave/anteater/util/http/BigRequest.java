package com.nave.anteater.util.http;

import java.io.*;
import java.text.MessageFormat;
import java.util.Properties;

import org.apache.commons.lang.SystemUtils;

import com.nave.anteater.RecipeListener;

public class BigRequest {
	private String fNumDetails;
	private String fTitle = "Huge order requester";
	private Properties theProperties = new Properties();

	private static String fHeader;
	private static String fBodyTnv;
	private static String fEnd;

	private long fOrderId;
	private RecipeListener fMaxTestListener;

	public void generation() throws IOException {
		File theTmpFile = File.createTempFile("tmp", "req", SystemUtils.getUserDir());

		FileOutputStream theFileOutputStream = new FileOutputStream(theTmpFile);

		Object[] theRguments = new Object[1];
		theRguments[0] = Long.toString(fOrderId);

		theFileOutputStream.write(MessageFormat.format(fHeader, theRguments).getBytes());

		int theLength = 0;
		theLength = Integer.parseInt(fNumDetails);

		fMaxTestListener.startTask(fTitle + " (Generation)");

		for (int i = 0; i < theLength; i++) {
			Object[] theRguments1 = new Object[1];
			theRguments1[0] = Integer.toString(i);
			theFileOutputStream.write(MessageFormat.format(fBodyTnv, theRguments1).getBytes());
			progressListener(theLength, i);
		}

		theFileOutputStream.write(fEnd.getBytes());
		theFileOutputStream.close();

		fMaxTestListener.startTask(fTitle + " (Generation)" + " Length: " + (theTmpFile.length() / 1024) + "kB)");
	}

	public void transmit(String aUrlParam, File aFile) throws IOException {
		setUrlParam(aUrlParam);

		fMaxTestListener.startTask(fTitle + " (Transmit)");
		sendRequest(aFile);

		fOrderId++;

		theProperties.setProperty("order_id", Long.toString(fOrderId));
		theProperties.store(new FileOutputStream("hugereq.properties"), "Huge request properties");
	}

	private void sendRequest(File aFile) {
		// To change body of created methods use File | Settings | File
		// Templates.
	}

	private void setUrlParam(String aText) {
		// To change body of created methods use File | Settings | File
		// Templates.
	}

	public BigRequest(RecipeListener aMaxTestListener, String aNumDetails) throws IOException {

		fMaxTestListener = aMaxTestListener;
		fMaxTestListener.startTask("Big order generation");

		fHeader = getText("header.xml", fHeader);
		fBodyTnv = getText("detail.xml", fBodyTnv);

		try {
			theProperties.load(new FileInputStream("hugereq.properties"));
		} catch (IOException e) {
			fOrderId = 1;
			theProperties.setProperty("order_id", Long.toString(fOrderId));
			theProperties.store(new FileOutputStream("hugereq.properties"), "Huge request properties");
		}
		fOrderId = Long.parseLong(theProperties.getProperty("order_id", "1"));

		int thePbrkKb = aNumDetails.indexOf("kB");
		if (thePbrkKb > 0) {
			aNumDetails = aNumDetails.substring(0, thePbrkKb);
			int theSize = Integer.parseInt(aNumDetails);
			theSize *= 1024;
			aNumDetails = Integer.toString((int) (theSize - fHeader.length() - fEnd.length()) / fBodyTnv.length());
		}

		int thePbrkM = aNumDetails.indexOf("M");
		if (thePbrkM > 0) {
			aNumDetails = aNumDetails.substring(0, thePbrkM);
			int theSize = Integer.parseInt(aNumDetails);
			theSize *= 1024 * 1024;
			aNumDetails = Integer.toString((int) (theSize - fHeader.length() - fEnd.length()) / fBodyTnv.length());
		}

		fNumDetails = aNumDetails;
	}

	private String getText(String aFile, String aDefault) {
		char theSourceBuffer[] = null;
		File theDetailSourceFile = null;
		try {
			theDetailSourceFile = new File(aFile);
			FileReader theFileReader = new FileReader(theDetailSourceFile);
			try {
				theSourceBuffer = new char[(int) theDetailSourceFile.length()];
				theFileReader.read(theSourceBuffer);
			} finally {
				theFileReader.close();
			}
		} catch (IOException e) {
			System.out.println("Pleace create source detail file <" + theDetailSourceFile.getAbsoluteFile() + ">.");
			return aDefault;
		}

		return new String(theSourceBuffer);
	}

	protected void progressListener(int aSize, int aJ) {
	}

}
