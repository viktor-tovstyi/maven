package com.nave.anteater;

import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.Properties;

import org.apache.commons.lang.ClassUtils;
import org.apache.commons.lang.StringUtils;

public class OperationHolder {

	private Method method;
	private Class<?> operationClass;
	private Properties prop = new Properties();

	public OperationHolder(Class<?> operationClass, Method method)
			throws InstantiationException, IllegalAccessException {
		this.method = method;
		this.operationClass = operationClass;
		try {
			URL resource = operationClass.getResource(ClassUtils.getShortClassName(operationClass) + ".properties");
			InputStream openStream = resource.openStream();
			prop.load(openStream);
		} catch (Exception e) {
			//
		}
	}

	public Method getMethod() {
		return method;
	}

	public void setMethod(Method method) {
		this.method = method;
	}

	public Object invoke(Object instance, Object[] args)
			throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, InstantiationException {
		return method.invoke(instance, args);
	}

	public Object newInstance() throws InstantiationException, IllegalAccessException {
		return operationClass.newInstance();
	}

	public String getParameterName(int i) {
		String name = prop.getProperty(method.getName() + ".param[" + i + "]");
		return StringUtils.defaultIfBlank(name, "arg" + (i + 1));
	}

	public String getReturnDescription() {
		String description = prop.getProperty(method.getName() + ".return");
		return StringUtils.defaultIfBlank(description, "");
	}

	public String getDescription() {
		String description = prop.getProperty(method.getName() + ".description", "");
		description = StringUtils.trim(StringUtils.substringBefore(description, "."));
		description = StringUtils.trim(StringUtils.substringBefore(description, "<p"));
		return description;
	}

	public Class getOperationClass() {
		return operationClass;
	}

}
