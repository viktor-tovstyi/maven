package com.nave.anteater.util.xml.easyparser;

import java.util.ArrayList;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.commons.collections.map.LinkedMap;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;

/**
 * @author victort
 */
public class Node extends ArrayList<Node> {

	private static final long serialVersionUID = 1L;

	public static final String TEXT_TEAG_NAME = "$Text";

	public static final String TAG_ID = "$ID";

	final static boolean debug = false;

	protected int MAXATTRINLINE = 6;

	protected final int SAMPLENODE = 0;

	protected final int TEXNode = 1;

	private String fTagName;

	private Node fOwnerWriter = null;

	private LinkedMap fAttribute = new LinkedMap();

	private boolean fNill = true;

	private String fText;

	private boolean fIgnoreSpaceInText = false;

	public Node(String aTagName) {
		fTagName = aTagName;
	}

	public Node(String aTagName, Map<String, String> aAttribute, ArrayList aNodes) {
		this(aTagName);
		fTagName = aTagName;
		if (aAttribute != null) {
			fAttribute = new LinkedMap(aAttribute);
		}
		if (aNodes != null) {
			for (int i = 0; i < aNodes.size(); i++) {
				Node theNode = (Node) aNodes.get(i);
				addInnerTag(theNode);
			}
		}

	}

	public boolean isNill() {
		return fNill;
	}

	public void setNill(boolean aNill) {
		fNill = aNill;
		if (aNill) {
			clear();
		}
	}

	public LinkedMap getAttributes() {
		return fAttribute;
	}

	public String getAttribute(String aName) {
		return (String) fAttribute.get(aName);
	}

	public void setAttribute(String aName, String aValue) {
		if (aName != null && aName.length() > 0 && Character.isLetter(aName.charAt(0))) {
			fAttribute.put(aName, aValue);
		}
	}

	public void setAttribute(String aName, boolean aValue) {
		fAttribute.put(aName, aValue ? "true" : "false");
	}

	public void setAttribute(String aName, long aValue) {
		fAttribute.put(aName, Long.toString(aValue));
	}

	public void setAttributes(Map<String, String> aAttributes) {
		fAttribute = new LinkedMap(aAttributes);
	}

	public void setAttribute(String aName, double aValue) {
		fAttribute.put(aName, Double.toString(aValue));
	}

	protected void addInnerTag(Node aNode) {
		if (aNode == this) {
			throw new RuntimeException("Self inserting node.");
		}
		aNode.setOwner(this);
		add(aNode);
	}

	protected void setOwner(Node aOwnerWriter) {
		fOwnerWriter = aOwnerWriter;
	}

	protected int getLevel() {
		if (fOwnerWriter == null) {
			return 0;
		}
		return fOwnerWriter.getLevel() + 1;
	}

	private String getAttributeLine(int aLevel, String aKey) {
		StringBuffer theBuffer = new StringBuffer();

		if (fAttribute.size() > MAXATTRINLINE) {
			theBuffer.append(getFormatingTab(aLevel));
		} else {
			theBuffer.append(' ');
		}

		theBuffer.append(aKey);
		theBuffer.append("=\"");

		String theValueOut = (String) fAttribute.get(aKey);
		theValueOut = replace(theValueOut);

		theBuffer.append(theValueOut);
		theBuffer.append('\"');

		return theBuffer.toString();
	}

	public static String replace(String aValueOut) {
		if (aValueOut != null) {
			aValueOut = EasyParser.replaceProperties(aValueOut, "\"", "&quot;");
			// aValueOut = EasyParser.replaceProperties(aValueOut, "\'",
			// "&apos;");
			aValueOut = EasyParser.replaceProperties(aValueOut, "<", "&lt;");
			aValueOut = EasyParser.replaceProperties(aValueOut, ">", "&gt;");
		}
		return aValueOut;
	}

	public String getXMLText() {
		if (fText != null) {
			return fText;
		}
		if (TEXT_TEAG_NAME.equals(fTagName)) {
			return new String();
		}

		if (debug) {
			System.out.println("-- getXMLText()");
		}

		String text = getXMLText(0);

		return text;
	}

	protected String getXMLText(int aLevel) {
		if (fText != null) {
			return getXMLText();
		}
		if (TEXT_TEAG_NAME.equals(fTagName)) {
			return new String();
		}

		if (debug) {
			System.out.println("-- getXMLText( int aLevel )");
		}

		aLevel++;

		StringBuffer theBuffer = new StringBuffer();

		theBuffer.append(getFormatingTab(aLevel));

		if ("Comment".equals(fTagName) == false) {
			theBuffer.append('<');
			theBuffer.append(fTagName);

			if (fAttribute.size() > 0) {
				Set<String> theEnumKey = fAttribute.keySet();

				for (String name : theEnumKey) {
					if (fAttribute.size() > MAXATTRINLINE) {
						theBuffer.append("\r\n");
					}
					theBuffer.append(getAttributeLine(aLevel, name));
				}
			}

			if (size() == 0) {
				theBuffer.append(" />");
			} else {
				theBuffer.append('>');

				if ((size() > 0 || fAttribute.size() > MAXATTRINLINE)
						&& TEXT_TEAG_NAME.equals(getNode(0).getTag()) == false) {
					theBuffer.append("\r\n");
				}

				for (int theCurrent = 0; theCurrent < size(); theCurrent++) {
					if (debug) {
						System.out.println("-- getXMLText( int aLevel ) for ( int theCurrent... ");
					}
					theBuffer.append(getInnerXMLText(aLevel, theCurrent));
				}

				if (TEXT_TEAG_NAME.equals(getNode(0).getTag()) == false) {
					theBuffer.append(getFormatingTab(aLevel));
				}

				theBuffer.append("</");
				theBuffer.append(fTagName);
				theBuffer.append('>');
			}
		} else {
			theBuffer.append("<!--");
			for (int theCurrent = 0; theCurrent < size(); theCurrent++) {
				theBuffer.append(getInnerXMLText(aLevel, theCurrent).replaceAll("&lt;", "<").replaceAll("&gt;", ">")
						.replaceAll("&amp;", "&").replaceAll("&quot;", "\"").replaceAll("&apos;", "\'"));
			}
			theBuffer.append("-->");
		}

		theBuffer.append(" \r\n");
		return theBuffer.toString();
	}

	private String getFormatingTab(int aLevel) {
		StringBuffer theBuffer = new StringBuffer();
		for (int theTab = 1; theTab < aLevel; theTab++) {
			theBuffer.append("\t");
		}
		return theBuffer.toString();
	}

	private String getInnerXMLText(int aLevel, int theInnerTag) {
		Node theNode = (Node) get(theInnerTag);
		return theNode.getXMLText(aLevel);
	}

	public String getTag() {
		return fTagName;
	}

	public Node[] getNodes(String aTag) {
		if (aTag.indexOf("*/") == 0) {
			return new Node[] { findNode(aTag.substring(2), null, null) };
		}

		if (aTag.indexOf("/") > 0) {
			return getNodesPatch(aTag);
		}

		int theNumberNode = size();

		ArrayList theResultArrayList = new ArrayList();

		for (int i = 0; i < theNumberNode; i++) {
			Node theCurrenNode = (Node) get(i);
			String theTagName = theCurrenNode.getTag();
			int theLengPreffix = theTagName.indexOf(':');
			if (theLengPreffix >= 0) {
				theTagName = theTagName.substring(theLengPreffix + 1);
			}
			if (theTagName.equals(aTag)) {
				theResultArrayList.add(theCurrenNode);
			}
		}

		Node[] theResult = new Node[theResultArrayList.size()];
		for (int i = 0; i < theResultArrayList.size(); i++) {
			theResult[i] = (Node) theResultArrayList.get(i);
		}

		return theResult;
	}

	private Node[] getNodesPatch(String aPatch) {
		StringTokenizer theStringTokenizer = new StringTokenizer(aPatch, "/");

		Node theCurrenNode = this;
		Node[] theResult = null;

		while (theStringTokenizer.hasMoreTokens() && theCurrenNode != null) {
			theResult = theCurrenNode.getNodes(theStringTokenizer.nextToken());
			if (theCurrenNode == null) {
				theResult = null;
				break;
			}

			if (theResult != null && theResult.length > 0) {
				theCurrenNode = theResult[0];
			}
		}

		return theResult;
	}

	public void setText(String aText) {

		aText = replace(aText);

		if (fIgnoreSpaceInText) {
			StringBuffer theBuffer = null;
			StringTokenizer theTokenizer = new StringTokenizer(aText, " \n\r");
			theBuffer = new StringBuffer();
			boolean theFirstToken = true;
			while (theTokenizer.hasMoreTokens()) {
				if (theFirstToken) {
					theFirstToken = false;
				} else {
					theBuffer.append(' ');
				}

				theBuffer.append(theTokenizer.nextToken());
			}
			fText = theBuffer.toString();
		} else {
			fText = aText;
		}
	}

	public String getText() {
		return StringEscapeUtils.unescapeXml(fText);
	}

	public Node findNode(String aTagName, String aAttributeName, String aAttributeValue) {
		int theNumberNode = size();

		String tag = getTag();
		int prefixpoint = tag.indexOf(':');
		if (prefixpoint >= 0) {
			tag = tag.substring(prefixpoint + 1);
		}

		String theAttribut = null;
		if (aAttributeName != null) {
			theAttribut = getAttribute(aAttributeName);
		}

		if (aTagName == null || tag.equals(aTagName)) {
			if (aAttributeName != null) {
				if (ObjectUtils.equals(theAttribut, aAttributeValue)) {
					return this;
				}
			} else {
				return this;
			}
		}

		for (int i = 0; i < theNumberNode; i++) {
			Node theCurrenNode = (Node) get(i);
			Node node = theCurrenNode.findNode(aTagName, aAttributeName, aAttributeValue);
			if (node != null) {
				return node;
			}
		}

		return null;
	}

	public Node[] findNodes(String aTagName, String aAttributeName, String aAttributeValue) {
		int theNumberNode = size();

		Vector noresVector = new Vector();

		for (int i = 0; i < theNumberNode; i++) {
			Node theCurrenNode = (Node) get(i);

			String theAttribut = null;
			if (aAttributeName != null)
				theAttribut = theCurrenNode.getAttribute(aAttributeName);

			if ((theCurrenNode.getTag().equals(aTagName) || aTagName == null)
					&& ((theAttribut != null && (aAttributeValue == null || theAttribut.equals(aAttributeValue)))
							|| aAttributeName != null)) {
				noresVector.add(theCurrenNode);
			}

			Node[] nodes = theCurrenNode.findNodes(aTagName, aAttributeName, aAttributeValue);
			for (int j = 0; j < nodes.length; j++) {
				noresVector.add(nodes[j]);
			}
		}

		Node[] result = new Node[noresVector.size()];
		for (int i = 0; i < result.length; i++) {
			result[i] = (Node) noresVector.get(i);
		}

		return result;
	}

	public void setTag(String aTagName) {
		fTagName = aTagName;
	}

	public Node getNode(int i) {
		return (Node) get(i);
	}

	public void removeNode(String theAttributeName, String theAttributeValue) {
		removeNode(this, theAttributeName, theAttributeValue);
	}

	private void removeNode(Node aNode, String theAttributeName, String theAttributeValue) {
		for (int i = 0; i < aNode.size(); i++) {
			Node theCurrentNode = (Node) aNode.get(i);
			String theAttribut = theCurrentNode.getAttribute(theAttributeName);
			if (theAttribut != null && theAttribut.equals(theAttributeValue)) {
				aNode.remove(i);
				return;
			} else {
				removeNode(theCurrentNode, theAttributeName, theAttributeValue);
			}
		}
	}

	class TagCounter {
		public int number = 0;

		public int getNumber() {
			return number++;
		}
	}

	public Vector getVector(boolean aNodesCounter) {
		TreeVector hashtable = new TreeVector();
		TagCounter numberCommand = null;
		if (aNodesCounter)
			numberCommand = new TagCounter();

		Object o = nodeHashtables(this, numberCommand);
		if (o == null) {
			o = new Vector();
		}
		hashtable.add(o);

		return hashtable;
	}

	private Object nodeHashtables(Node aNode, TagCounter aNumberCommand) {
		TreeVector hashtable = new TreeVector();

		Node key = aNode;

		int number = -1;

		if (aNumberCommand != null)
			number = aNumberCommand.getNumber();

		if (TEXT_TEAG_NAME.equals(aNode.getTag()) == false) {
			if (number > 0)
				key.setAttribute(TAG_ID, number);

			Node key1 = new Node(aNode.getTag());
			LinkedMap aAttributes = new LinkedMap(aNode.getAttributes());
			aAttributes.remove(TAG_ID);
			key1.setAttributes(aAttributes);
			String s = key1.getXMLText().replace('\n', ' ').trim();
			if (s.length() > 0) {
				s = s.substring(1, s.length() - 3);
			}

			hashtable.setTitle(s);

			int numberNodes = aNode.size();

			for (int i = 0; i < numberNodes; i++) {
				hashtable.addElement(nodeHashtables((Node) aNode.get(i), aNumberCommand));
			}

		} else {
			String text = aNode.getText();

			if (text != null) {
				return text;
			} else {
				return '<' + aNode.getTag() + "/>";
			}
		}

		return hashtable;
	}

	private static class TreeVector extends Vector {
		private String fTitle;

		public synchronized String toString() {
			return fTitle;
		}

		public void setTitle(String aS) {
			fTitle = aS;
		}
	}

	@Override
	public String toString() {
		return getXMLText();
	}

	public Node[] getTextNodes() {
		return getNodes(TEXT_TEAG_NAME);
	}

	public String getInnerText() {
		Node[] nodes = getTextNodes();
		if (nodes.length > 0) {
			return nodes[0].getText();
		}
		return StringUtils.EMPTY;
	}

	public String getInnerXMLText() {
		StringBuilder xml = new StringBuilder();
		for (Node node : this) {
			xml.append(node.getXMLText());
			xml.append('\n');
		}
		return xml.toString();
	}
}
