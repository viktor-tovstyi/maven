package com.nave.anteater.util.http;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Locale;

public class HTTPStringResponse implements HttpServletResponse {
	private StringWriter fStringBuffer = new StringWriter();

	public HTTPStringResponse() {
	}

	public void addCookie(Cookie aCookie) {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public boolean containsHeader(String s) {
		return false; // To change body of implemented methods use File |
						// Settings | File Templates.
	}

	public String encodeURL(String s) {
		return null; // To change body of implemented methods use File |
						// Settings | File Templates.
	}

	public String encodeRedirectURL(String s) {
		return null; // To change body of implemented methods use File |
						// Settings | File Templates.
	}

	public String encodeUrl(String s) {
		return null; // To change body of implemented methods use File |
						// Settings | File Templates.
	}

	public String encodeRedirectUrl(String s) {
		return null; // To change body of implemented methods use File |
						// Settings | File Templates.
	}

	public void sendError(int i, String s) throws IOException {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public void sendError(int i) throws IOException {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public void sendRedirect(String s) throws IOException {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public void setDateHeader(String s, long l) {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public void addDateHeader(String s, long l) {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public void setHeader(String s, String s1) {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public void addHeader(String s, String s1) {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public void setIntHeader(String s, int i) {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public void addIntHeader(String s, int i) {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public void setStatus(int i) {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public void setStatus(int i, String s) {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public String getCharacterEncoding() {
		return null; // To change body of implemented methods use File |
						// Settings | File Templates.
	}

	public ServletOutputStream getOutputStream() throws IOException {
		return null; // To change body of implemented methods use File |
						// Settings | File Templates.
	}

	public PrintWriter getWriter() throws IOException {
		return new PrintWriter(fStringBuffer);
	}

	public void setContentLength(int i) {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public void setContentType(String s) {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public void setBufferSize(int i) {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public int getBufferSize() {
		return 0; // To change body of implemented methods use File | Settings |
					// File Templates.
	}

	public void flushBuffer() throws IOException {
	}

	public void resetBuffer() {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public boolean isCommitted() {
		return false; // To change body of implemented methods use File |
						// Settings | File Templates.
	}

	public void reset() {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public void setLocale(Locale aLocale) {
		// To change body of implemented methods use File | Settings | File
		// Templates.
	}

	public String toString() {
		return fStringBuffer.toString();
	}

	public Locale getLocale() {
		return null; // To change body of implemented methods use File |
						// Settings | File Templates.
	}

	public String getContentType() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setCharacterEncoding(String arg0) {
		// TODO Auto-generated method stub

	}
}