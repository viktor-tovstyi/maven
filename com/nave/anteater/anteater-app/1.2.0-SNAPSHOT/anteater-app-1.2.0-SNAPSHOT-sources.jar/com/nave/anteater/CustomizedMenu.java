package com.nave.anteater;

import java.util.ArrayList;

import com.nave.anteater.util.xml.easyparser.Node;

public class CustomizedMenu extends ArrayList<CustomizedMenu.Item> {

	private static final long serialVersionUID = 1L;

	public class Item {
		
		private Node taskNode;
		private String name;
		private String toolTip;
		private String image;

		public Item(Node node) {
			taskNode = node;
			
			this.name = taskNode.getAttribute("name");
			if (this.name == null)
				this.name = taskNode.getAttribute("task");

			this.toolTip = taskNode.getAttribute("tooltip");
			this.image = taskNode.getAttribute("image");
		}

		public String getName() {
			return name;
		}

		public String getToolTip() {
			return toolTip;
		}

		public String getImage() {
			return image;
		}

		public Node getTaskNode() {
			return taskNode;
		}

	}

	private String title;

	public void setTitle(String title) {
		this.title = title;
	}

	public void addItem(Node taskNode) {
		add(new Item(taskNode));
	}

	public String getTitle() {
		return title;
	}

}
