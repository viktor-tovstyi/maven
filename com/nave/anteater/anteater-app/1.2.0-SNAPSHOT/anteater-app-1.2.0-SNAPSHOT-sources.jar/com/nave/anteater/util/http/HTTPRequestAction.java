package com.nave.anteater.util.http;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.URL;
import java.util.Properties;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import org.apache.log4j.Logger;

/**
 * @author victort
 */
public class HTTPRequestAction {

	private URL fHostDestination = null;
	private OutputStream theWriter = null;
	private InputStream theReader = null;

	private Properties fHeadProperties = new Properties();
	private String encode = "UTF-8";
	private String httpVersion = "1.1";

	public HTTPRequestAction(URL aHostDestination) {
		fHostDestination = aHostDestination;
	}

	public byte[] request(byte[] aData, String theCharSet, int length, Logger aLog) throws IOException {
		int port = fHostDestination.getPort();

		String protocol = fHostDestination.getProtocol();

		Socket socket = null;

		if ("http".equals(protocol)) {
			socket = new Socket(fHostDestination.getHost(), port > 0 ? port : 80);
		} else if ("https".equals(protocol)) {
			SSLSocketFactory f = (SSLSocketFactory) SSLSocketFactory.getDefault();
			SSLSocket c = (SSLSocket) f.createSocket(fHostDestination.getHost(), port > 0 ? port : 443);
			c.startHandshake();
			socket = c;
		} else {
			throw new IllegalArgumentException("Protocol: " + protocol + " is not supported.");
		}

		socket.setSoTimeout(3000);
		encode = theCharSet;

		theWriter = socket.getOutputStream();
		theReader = new BufferedInputStream(socket.getInputStream());

		writeData(aData, length);
		theWriter.flush();

		aLog.debug("Response reading ...");
		byte[] theResponse = readData(theReader);

		theWriter.close();
		theReader.close();
		socket.close();

		return theResponse;
	}

	private void writeData(byte[] aData, int length) throws IOException {
		write("POST " + fHostDestination.getPath() + " HTTP/" + httpVersion + "\n");
		// write("Content-Type: text/xml; charset=" + theCharSet.toLowerCase() +
		// "\n");
		write("Content-Type: text/xml; charset=" + encode.toLowerCase() + "\n");

		write("Accept: text/xml, application/dime, multipart/related, text/*\n");
		write("User-Agent: Anteater\n");
		write("Host: " + fHostDestination.getHost() + ":" + fHostDestination.getPort() + "\n");
		write("Cache-Control: no-cache\n");
		write("Pragma: no-cache\n");
		write("SOAPAction: \"\"\n");
		if (length < 0)
			length = aData.length;
		write("Content-Length: " + length + "\n");
		write("\n");

		theWriter.write(aData);
		theWriter.write('\n');
	}

	private void write(String s) throws IOException {
		theWriter.write(s.getBytes(encode));
	}

	protected byte[] readData(InputStream aReader) throws IOException {
		ByteArrayOutputStream theBuffer = new ByteArrayOutputStream();

		byte[] theByteData = readLine(aReader);

		if (theByteData.length > 0) {
			if (theByteData[0] == 'H') {
				String status = new String(theByteData, encode);
				fHeadProperties.setProperty("status", status);
				while (fillHeadProperties(aReader))
					;

			} else {
				return theByteData;
			}
		}

		try {
			while ((theByteData = readLine(aReader)).length > 0) {
				theBuffer.write(theByteData);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}

		return theBuffer.toByteArray();
	}

	private boolean fillHeadProperties(InputStream aReader) throws IOException {
		byte[] readLine = readLine(aReader);

		String theResult = new String(readLine, encode);
		if (theResult.trim().length() == 0) {
			return false;
		}

		int theDelim = theResult.indexOf(':');
		if (theDelim >= 0) {
			String theName = theResult.substring(0, theDelim);
			String theValue = theResult.substring(theDelim + 1).trim();
			fHeadProperties.setProperty(theName, theValue);
		}

		return true;
	}

	public Properties getHeadProperties() {
		return fHeadProperties;
	}

	private byte[] readLine(InputStream aReader) {
		int theByte;
		ByteArrayOutputStream theBuffer = new ByteArrayOutputStream();
		try {
			while ((theByte = aReader.read()) != -1 && theByte != '\n') {
				theBuffer.write(theByte);
			}
		} catch (IOException e) {
		}

		return theBuffer.toByteArray();
	}
}
