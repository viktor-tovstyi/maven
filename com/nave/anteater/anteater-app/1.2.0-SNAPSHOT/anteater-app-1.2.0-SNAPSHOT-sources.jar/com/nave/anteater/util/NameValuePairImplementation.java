package com.nave.anteater.util;

import org.apache.http.NameValuePair;

public class NameValuePairImplementation implements NameValuePair {

	private String name;
	private String value;

	public NameValuePairImplementation(String name, String value) {
		this.name = name;
		this.value = value;
	}

	@Override
	public String getName() {
		return name;
	}

	@Override
	public String getValue() {
		return value;
	}
}
