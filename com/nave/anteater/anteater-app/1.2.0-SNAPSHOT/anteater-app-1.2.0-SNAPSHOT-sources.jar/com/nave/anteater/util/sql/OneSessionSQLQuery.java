package com.nave.anteater.util.sql;

import javax.naming.NamingException;

import java.sql.SQLException;
import java.util.List;
import java.util.Properties;

public class OneSessionSQLQuery {
	public static List forArrayValues(String aQueryLine, String connectionName) throws SQLException, NamingException {
		SQLQuery theQuery = null;
		List theStrings = null;
		try {
			theQuery = new SQLQuery(connectionName);
			theStrings = theQuery.forArrayValues(aQueryLine);
		} finally {
			if (theQuery != null)
				theQuery.close();
		}
		return theStrings;
	}

	public static Properties forFields(String aQueryLine, String connectionName) throws SQLException, NamingException {
		SQLQuery theQuery = null;
		Properties theProperties = null;
		try {
			theQuery = new SQLQuery(connectionName);
			theProperties = theQuery.forFields(aQueryLine);
		} finally {
			if (theQuery != null)
				theQuery.close();
		}
		return theProperties;
	}

	public static Properties[] forArrayFields(String aQueryLine, String connectionName) throws SQLException, NamingException {
		SQLQuery theQuery = null;
		Properties[] theProperties = null;
		try {
			theQuery = new SQLQuery(connectionName);
			theProperties = theQuery.forArrayFields(aQueryLine);
		} finally {
			if (theQuery != null)
				theQuery.close();
		}
		return theProperties;
	}

}
