package com.nave.anteater.util.http;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URL;

import org.apache.log4j.Logger;

import com.nave.anteater.util.AEUtils;
import com.nave.anteater.util.xml.easyparser.EasyParser;
import com.nave.anteater.util.xml.easyparser.Node;

public class SoapRequestMaker {

	public static Object soapAction(String aRequestText, String aHost, Logger aLog) throws Exception {
		return soapAction(aRequestText, aHost, aLog, -1);
	}

	public static Object soapAction(String aRequestText, String aHost, Logger aLog, int length) throws Exception {
		Object theResponseText = requestAction(aRequestText, aHost, aLog, length);

		if (theResponseText instanceof String) {
			String theValue = (String) theResponseText;
			int theBeginIndex = theValue.indexOf("?>") + 2;
			if (theBeginIndex < 2)
				theBeginIndex = 0;
			theResponseText = theValue.substring(theBeginIndex, theValue.length());
		}

		return theResponseText;
	}

	public static Object requestAction(String aRequestText, String aHost, Logger aLog, int length) throws Exception {

		String theEncode = "UTF-8";
		int theEndHead = 0;

		if (aRequestText.indexOf("<?xml") == 0) {
			theEndHead = aRequestText.indexOf("?>");
			EasyParser theParser = new EasyParser();
			Node theHead = theParser.getObject(aRequestText.substring(0, theEndHead) + "/>");
			theEncode = theHead.getAttribute("encoding");
			theEndHead += 2;
		}

		aLog.debug("Prepare string for request, Encoding: " + theEncode);
		byte[] theBytes = aRequestText.getBytes(theEncode);

		HTTPRequestAction theRequestAction = new HTTPRequestAction(new URL(aHost));
		byte[] theResponseText = theRequestAction.request(theBytes, theEncode, length, aLog);
		Object result = null;
		if (theResponseText.length == 0) {
			result = theRequestAction.getHeadProperties();
		} else {
			result = new String(theResponseText, theEncode);
		}

		theEndHead = 0;
		if (aRequestText.indexOf("<?xml") == 0) {
			theEndHead = aRequestText.indexOf("?>");
			EasyParser theParser = new EasyParser();
			Node theHead = theParser.getObject(aRequestText.substring(0, theEndHead) + "/>");
			theEncode = theHead.getAttribute("encoding");
			theEndHead += 2;
		}

		return result;
	}

	public static String xmlfileToString(String aFileName, File aBaseDir) throws Exception, FileNotFoundException {
		return AEUtils.loadResource(aFileName, aBaseDir, "UTF-8");
	}

}
