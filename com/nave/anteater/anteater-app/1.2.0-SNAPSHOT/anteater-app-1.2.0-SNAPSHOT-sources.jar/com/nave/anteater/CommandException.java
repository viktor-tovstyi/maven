package com.nave.anteater;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.xml.easyparser.Node;

import java.util.Vector;

public class CommandException extends Exception {

	private static final long serialVersionUID = 1L;
	private Vector<Vector<String>> callTaskTrace;
	private Node theCurrentAction;

	public CommandException(Throwable targetException, TaskProcessor unit) {
		super(targetException);
		this.callTaskTrace = unit.getCallTaskTrace();
	}

	public CommandException(String string, TaskProcessor processor) {
		super(string);
		this.callTaskTrace = processor.getCallTaskTrace();
	}

	public CommandException(Throwable targetException, TaskProcessor unit, Node theCurrentAction) {
		this(targetException, unit);
		this.theCurrentAction = theCurrentAction;
	}

	public String getTaskTrace() {
		StringBuffer theText = new StringBuffer();
		if (theCurrentAction != null) {
			theText.append("Command:\n");
			theText.append(theCurrentAction.getXMLText());
			theText.append("\n");
		}

		theText.append("Task trace:\n");
		theText.append(getCallTaskTraceText(callTaskTrace));
		return theText.toString();
	}

	private String getCallTaskTraceText(Vector aVector) {

		StringBuffer theText = new StringBuffer();

		for (int i = 0; i < aVector.size(); i++) {
			Object theCurrentRec = aVector.get(i);
			if (theCurrentRec instanceof String) {
				theText.append((String) theCurrentRec);
			}
			if (theCurrentRec instanceof Vector) {
				theText.append(getCallTaskTraceText((Vector) theCurrentRec));
			}
		}

		return theText.toString();
	}

}
