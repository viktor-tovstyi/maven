package com.nave.anteater.processor;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.io.StringWriter;
import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.URLConnection;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.DateFormat;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collection;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Random;
import java.util.Set;
import java.util.Stack;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.jar.Attributes;
import java.util.jar.JarFile;
import java.util.jar.Manifest;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.NamingException;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.swing.JOptionPane;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.LinkedMap;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.junit.runner.Description;
import org.junit.runner.JUnitCore;
import org.junit.runner.Request;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;

import com.nave.anteater.AEException;
import com.nave.anteater.AELogRecord;
import com.nave.anteater.AEManager;
import com.nave.anteater.AEWorkspace;
import com.nave.anteater.ChoiceTaskRunner;
import com.nave.anteater.CommandException;
import com.nave.anteater.JarClassLoader;
import com.nave.anteater.MultiTaskRunDialog;
import com.nave.anteater.OperationHolder;
import com.nave.anteater.RecipeListener;
import com.nave.anteater.TaskCancelingException;
import com.nave.anteater.TaskProcessorThread;
import com.nave.anteater.TemplateProcessor;
import com.nave.anteater.TestIterator;
import com.nave.anteater.TestRunner;
import com.nave.anteater.processor.annotation.Attr;
import com.nave.anteater.processor.annotation.Command;
import com.nave.anteater.processor.annotation.CommandExamples;
import com.nave.anteater.processor.annotation.CommandHotHepl;
import com.nave.anteater.processor.annotation.Value;
import com.nave.anteater.util.AEUtils;
import com.nave.anteater.util.NameValuePairImplementation;
import com.nave.anteater.util.http.HTTPStringRequest;
import com.nave.anteater.util.http.HTTPStringResponse;
import com.nave.anteater.util.http.ServerAction;
import com.nave.anteater.util.http.SoapRequestMaker;
import com.nave.anteater.util.http.SoapWrapper;
import com.nave.anteater.util.sql.PLQuery;
import com.nave.anteater.util.sql.SQLQuery;
import com.nave.anteater.util.xml.easyparser.EasyParser;
import com.nave.anteater.util.xml.easyparser.EasyUtils;
import com.nave.anteater.util.xml.easyparser.Node;

import gnu.jel.CompiledExpression;
import gnu.jel.Evaluator;
import gnu.jel.Library;
import junit.framework.AssertionFailedError;
import junit.framework.TestCase;

public class TaskProcessor extends TemplateProcessor {

	public static final String STARTUP = "Startup";

	protected Logger log;

	private String fTestName;

	public Map<String, Object> fStartVariables;

	private boolean fIteratorMode = false;

	protected RecipeListener recipeListener;

	private boolean fstoppedTest = false;

	private boolean fMainLoopCommand = false;

	protected Vector<TaskProcessorThread> fChildThreads = new Vector<TaskProcessorThread>();

	private File fStartBaseDir;

	protected String fTestFile;

	private boolean fMainProcessor = true;

	private TaskProcessor fParent = null;

	private final Stack<String> fStackTask = new Stack<String>();

	private PLQuery theTPLQuery = null;

	private Library lib = null;

	private Random fRandom;

	private boolean fPauseOn;

	private TaskProcessor externProcessor = null;

	private Object monitor = new Object();

	private int breakFlag;

	private Map<String, SQLQuery> connectionMap = new HashMap<String, SQLQuery>();

	private List<ThreadPoolExecutor> threadPoolList = new ArrayList<ThreadPoolExecutor>();

	private Map<Class<?>, Object> operationObjects = new HashMap<Class<?>, Object>();

	private boolean randomSelect;

	static {
		javax.net.ssl.HttpsURLConnection.setDefaultHostnameVerifier(new javax.net.ssl.HostnameVerifier() {
			public boolean verify(String hostname, javax.net.ssl.SSLSession sslSession) {
				return true;
			}
		});

		final TrustManager[] trustAllCertificates = new TrustManager[] { new X509TrustManager() {
			@Override
			public X509Certificate[] getAcceptedIssuers() {
				return null; // Not relevant.
			}

			@Override
			public void checkClientTrusted(X509Certificate[] certs, String authType) {
				// Do nothing. Just allow them all.
			}

			@Override
			public void checkServerTrusted(X509Certificate[] certs, String authType) {
				// Do nothing. Just allow them all.
			}
		} };

		try {
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCertificates, new SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		} catch (GeneralSecurityException e) {
			throw new ExceptionInInitializerError(e);
		}
	}

	public TaskProcessor(final TaskProcessor aParent) {
		this(aParent.getListener().getManager(), aParent.getLog(), aParent.getBaseDir());
		this.fParent = aParent;
		this.fVariables = aParent.fVariables;
	}

	public TaskProcessor(AEManager manager, Logger log, File baseDir) {
		super(new HashMap<String, Object>(manager.getSystemVariables()), new Node(""), baseDir);
		this.log = log;
	}

	public TaskProcessor(final Node aConfigNode, final Map<String, Object> aStartVariables,
			final RecipeListener aMaxTestListener, final File aStartDir, final Logger aLog,
			final TaskProcessor aParent) {
		this(aParent);
		init(aConfigNode, aStartVariables, aMaxTestListener, aStartDir, aLog);
	}

	public void init(final Node action, final Map<String, Object> aStartVariables,
			final RecipeListener aMaxTestListener, final File aStartDir, final Logger aLog) {
		this.log = aLog;

		this.fConfigNode = action;
		this.fStartVariables = aStartVariables;
		if (aStartDir != null) {
			this.fStartBaseDir = aStartDir;
			setBaseDir(aStartDir);
		}

		if (this.fStartVariables != null) {
			this.fVariables.putAll(this.fStartVariables);
		}

		setMaxTestListener(aMaxTestListener);
	}

	public void init(final TaskProcessor aParent, Node action) throws CommandException {
		this.fMainProcessor = false;
		this.log = aParent.log;
		this.fConfigNode = aParent.fConfigNode;
		this.fStartVariables = aParent.fStartVariables;
		this.fStartBaseDir = aParent.fStartBaseDir;
		setBaseDir(aParent.getBaseDir());
		this.fVariables = aParent.fVariables;
		setMaxTestListener(aParent.recipeListener);
		this.fParent = aParent;
	}

	protected Map<String, Object> processTesting(final String aTestFileName, final Map<String, Object> aVariables,
			final File aBaseDir) throws Throwable {
		this.fVariables = aVariables;
		final File theBaseDir = getBaseDir();
		setBaseDir(aBaseDir);
		processTesting(aTestFileName);
		setBaseDir(theBaseDir);
		return this.fVariables;
	}

	protected void processTesting(final String aTestFileName) throws CommandException {
		if (aTestFileName == null) {
			return;
		}

		Node theNode;
		try {
			theNode = new EasyParser().load(aTestFileName);

		} catch (Exception e) {
			throw new CommandException("Recipe is not found: " + aTestFileName, this);

		}

		this.recipeListener.startTask(getTestName(theNode));
		processTesting(theNode, this.fVariables, new File(aTestFileName).getParentFile());
	}

	public void processTesting(final Node theNode, final Map<String, Object> aVariables, final File aBaseDir)
			throws CommandException {

		this.fVariables = new HashMap<String, Object>();
		if (aVariables != null) {
			this.fVariables.putAll(aVariables);
		}
		setBaseDir(aBaseDir);

		if (this.fStartBaseDir == null) {
			this.fStartBaseDir = getBaseDir();
		}
		final String theDepends = theNode.getAttribute("depends");
		if (theDepends != null) {
			final StringTokenizer theStringTokenizer = new StringTokenizer(theDepends, ";");
			while (theStringTokenizer.hasMoreTokens()) {
				processTesting(theStringTokenizer.nextToken());
				setBaseDir(this.fStartBaseDir);
			}
		}

		taskNode(theNode);
	}

	public void taskNode(final Node aNode) throws CommandException {

		if (this.fstoppedTest) {
			return;
		}

		Node theCurrentAction = null;

		if (getBaseDir() != null) {
			setVariableValue("BASEDIR", getBaseDir().getPath());
		}

		CommandException theTroubles = null;

		final Vector<Node> theFinallyVector = new Vector<Node>();
		String theTaskDescription = getTaskDescription(aNode);

		final String defaultIfEmpty = StringUtils.defaultIfEmpty(theTaskDescription,
				aNode != null ? "<" + aNode.getTag() + ">" : "<NULL>");
		this.fStackTask.push(defaultIfEmpty);

		if (theTaskDescription == null) {
			theTaskDescription = "";
		}
		int i = 0;
		int theNumberOperation = -1;
		try {
			if (aNode != null)
				while (++theNumberOperation < aNode.size() && this.fstoppedTest == false) {

					theCurrentAction = (Node) aNode.get(theNumberOperation);

					final String theRunMode = theCurrentAction.getAttribute("runMode");
					if (theRunMode != null && theRunMode.equals(this.recipeListener.getRunMode()) == false) {
						continue;
					}

					String theDescription = theCurrentAction.getAttribute("description");

					theDescription = replaceProperties(theDescription);
					if (theDescription != null) {
						theDescription = replaceProperties(theDescription);
						debug("Task: " + theDescription);
					}

					if (this.fIteratorMode == false) {
						progress(aNode.size(), i++, theTaskDescription, false);
					}

					if ("Logger".equals(theCurrentAction.getTag())) {
						continue;
					}

					try {
						final String tagName = theCurrentAction.getTag();

						if ("Else".equals(tagName)) {
							continue;
						}

						if ("Break".equals(tagName)) {
							breakFlag++;
							break;
						}

						if ("Stop".equals(tagName)) {
							String ifNull = theCurrentAction.getAttribute("ifNull");
							if (ifNull != null) {
								String replaceProperties = replaceProperties(ifNull);
								if (getVariableValue(replaceProperties) == null) {
									stop();
									break;
								}
							} else {
								stop();
								break;
							}
						}

						if ("Finally".equals(tagName)) {
							theFinallyVector.add(theCurrentAction);
							continue;
						}

						if (this.fstoppedTest) {
							return;
						}
						startCommandInformation(theCurrentAction);

						try {
							// old style call
							final Method theMethod = getClass().getMethod("runCommand" + tagName.replace('$', '_'),
									new Class[] { Node.class });
							theMethod.invoke(this, new Object[] { theCurrentAction });
						} catch (NoSuchMethodException e) {
							Method[] methods = getClass().getMethods();
							for (Method method : methods) {
								Command annotation = method.getAnnotation(Command.class);
								if (annotation != null) {
									String name = method.getName();
									if (name.equals(StringUtils.uncapitalize(tagName))) {
										Annotation[][] parameterAnnotations = method.getParameterAnnotations();
										int parameterCount = method.getParameterTypes().length;
										Object[] params = new Object[parameterCount];
										for (int j = 0; j < parameterAnnotations.length; j++) {
											Annotation[] annotations = parameterAnnotations[j];
											Class<? extends Annotation> annotationType = annotations[0]
													.annotationType();
											if (annotationType == Attr.class) {
												Object val = ConvertUtils.convert(
														attr(theCurrentAction, ((Attr) annotations[0]).value()),
														method.getParameterTypes()[j]);
												params[j] = ObjectUtils.defaultIfNull(val,
														((Attr) annotations[0]).defaultValue());
											}
											if (annotationType == Value.class) {
												String propName = attr(theCurrentAction,
														((Value) annotations[0]).attrName());
												propName = StringUtils.defaultString(propName,
														((Value) annotations[0]).defaultName());
												params[j] = ConvertUtils.convert(getVariableValue(propName),
														method.getParameterTypes()[j]);
											}
										}
										method.invoke(this, params);
										break;
									}
								}
							}
						}

					} catch (final InvocationTargetException e) {
						if (!isStoppedTest()) {
							final String theCurExceptionState = replaceProperties(
									theCurrentAction.getAttribute("exception"));
							if ("ignored".equals(theCurExceptionState) || "ignore".equals(theCurExceptionState)) {
								this.recipeListener.exceptionIgnored(e);

							} else if ("paused".equals(theCurExceptionState) || "trace".equals(theCurExceptionState)) {
								theTroubles = new CommandException(e.getTargetException(), this);
								try {
									this.recipeListener.errorInformation(this, e.getTargetException(),
											theCurrentAction);
									theTroubles = null;
								} catch (final CommandException e1) {
									this.log.error(e1.getTaskTrace());
									stop();
									theTroubles = null;
									break;
								}
							} else {
								Throwable cause = ExceptionUtils.getCause(e);

								if (cause instanceof TaskCancelingException) {
									recipeListener.stopTest();
									// to do nothing.

								} else if (cause instanceof CommandException) {
									theTroubles = (CommandException) cause;
								} else {
									theTroubles = new CommandException(cause, this, theCurrentAction);
								}
								break;
							}
						}
					} catch (final Throwable e) {
						if (!isStoppedTest()) {
							theTroubles = new CommandException(e, this);
						}
					}

					finally {
						doPause();

						if (this.fIteratorMode == false) {
							progress(aNode.size(), i, theTaskDescription, theTroubles != null);
						}
					}
				}
		} finally {

			boolean stoppedTest = fstoppedTest;
			fstoppedTest = false;
			for (Node node : theFinallyVector) {
				try {
					taskNode(node);
				} catch (final Throwable aThrowable) {
					this.log.error(
							"Exception in finally block.\n" + new CommandException(aThrowable, this).getTaskTrace(),
							aThrowable);
				}
			}
			fstoppedTest = stoppedTest;
		}

		this.fStackTask.pop();
		String theName = null;

		try {
			theName = (this.fStackTask.lastElement());
		} catch (final Exception e) {
		}

		if (theName != null) {
			this.recipeListener.startTask(theName);
		}

		progress(100, 100, "", false);

		if (theTroubles != null) {
			if (theTroubles instanceof AEException) {
				throw theTroubles;
			}

			if (isMainProcessor() && this.fStackTask.size() == 0) {

				final String theExceptionMode = replaceProperties(aNode.getAttribute("exception"));
				if ("ignored".equals(theExceptionMode) || "ignore".equals(theExceptionMode)) {
					this.recipeListener.exceptionIgnored(theTroubles);
					return;

				} else if ("paused".equals(theExceptionMode) || "trace".equals(theExceptionMode)) {
					try {
						this.recipeListener.errorInformation(this, theTroubles, theCurrentAction);
						theTroubles = null;
					} catch (final Exception e1) {
						this.log.error(e1.getMessage() + "\n" + new CommandException(e1, this).getTaskTrace());
						stop();
						theTroubles = null;
					}

				} else {
					if (theTroubles.getCause() instanceof AssertionFailedError) {
						this.recipeListener.checkFailure(theTroubles, this);
						theTroubles = null;
					} else {
						this.recipeListener.criticalError(theTroubles, this);
					}
				}
			}

			if (theTroubles != null) {
				throw theTroubles;
			}
		}

	}

	public boolean isMainProcessor() {
		return this.fMainProcessor;
	}

	public String getTestName() {
		return this.fTestName;
	}

	public void regChildProcess(final TaskProcessorThread aMaxTestRunnable) {
		this.recipeListener.startChildProcess(aMaxTestRunnable);
		this.fChildThreads.add(aMaxTestRunnable);
	}

	public void unregChildProcess(final TaskProcessorThread aMaxTestRunnable) {
		this.recipeListener.stopChildProcess(aMaxTestRunnable);
		this.fChildThreads.remove(aMaxTestRunnable);
	}

	public Node getConfigNode() {
		return this.fConfigNode;
	}

	public Map<String, Object> StartVariables() {
		return this.fStartVariables;
	}

	public RecipeListener getListener() {
		return this.recipeListener;
	}

	public Map<String, Object> getVariables() {
		return this.fVariables;
	}

	public int getChildThreads() {
		return this.fChildThreads.size();
	}

	private Logger getLog() {
		return log;
	}

	public void runNodes(final Node[] aTheNodes) throws Exception {

		for (int i = 0; i < aTheNodes.length; i++) {
			if (this.fstoppedTest) {
				break;
			}
			final Node theNode = aTheNodes[i];
			taskNode(theNode);
		}
	}

	public void setMaxTestListener(final RecipeListener aMaxTestListener) {
		this.recipeListener = aMaxTestListener;
	}

	public void startCommandInformation(final Node aTheCurrentAction) {
		final String theID = aTheCurrentAction.getAttribute(Node.TAG_ID);
		if (this.recipeListener != null && theID != null) {
			this.recipeListener.startCommand(Integer.parseInt(theID));
		}
	}

	private String getTestName(final Node aNode) {
		String theAttribut = aNode.getAttribute("name");
		if (theAttribut == null || theAttribut.trim().length() == 0) {
			theAttribut = aNode.getAttribute("description");
		}
		return replaceProperties(theAttribut);
	}

	private String getTaskDescription(final Node aNode) {
		if (aNode == null) {
			return null;
		}
		String theTaskDescription = aNode.getAttribute("name");
		if (theTaskDescription == null || theTaskDescription.trim().length() == 0) {
			theTaskDescription = aNode.getAttribute("description");
		}
		final String theTag = aNode.getTag();
		if (theTag.equals("Recipe")) {
			startTask(theTaskDescription, aNode.getAttribute("description"));
		} else if (theTag.equals(STARTUP)) {
			if (theTaskDescription == null) {
				theTaskDescription = STARTUP;
			}
			startTask(theTaskDescription, STARTUP);
		} else {
			theTaskDescription = aNode.getAttribute("description");
		}
		return theTaskDescription;
	}

	private void startTask(String name, String description) {
		this.fTestName = name;
		this.recipeListener.startTask(name);

		String defaultString = StringUtils.defaultString(description, name);
		if (defaultString == null) {
			if (description == null) {
				description = name;
			}
			description = replaceProperties(description);
			debug("Recipe: " + defaultString);
		}
	}

	@CommandExamples({ "<Regexp name='type:property' source='' regex='' />" })
	public void runCommandRegexp(final Node aCurrentAction) throws Throwable {
		final String theName = replaceProperties(aCurrentAction.getAttribute("name"));
		final String source = replaceProperties(aCurrentAction.getAttribute("source"));
		String variableValue = (String) getVariableValue(source);

		String theText = null;
		String regex = replaceProperties(aCurrentAction.getAttribute("regex"));
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(variableValue);
		if (matcher.find()) {
			theText = matcher.group(1);
		}

		setVariableValue(theName, theText);
	}

	@CommandHotHepl("<html>Replaces each substring of this string</html>")
	@CommandExamples({ "<Replace name='type:property' oldChar='type:integer' newChar='type:integer'/>",
			"<Replace name='type:property' regex='' replacement=''/>" })
	public void runCommandReplace(final Node aCurrentAction) throws Throwable {
		final String theName = replaceProperties(aCurrentAction.getAttribute("name"));
		Object variableValue = getVariableValue(theName);
		String theText = null;
		if (variableValue instanceof String) {
			theText = (String) variableValue;
		} else if (variableValue instanceof byte[]) {
			theText = new String((byte[]) variableValue);
		}
		theText = replaceProperties(theText);

		final String theOldChar = replaceProperties(aCurrentAction.getAttribute("oldChar"));
		final String theNewChar = replaceProperties(aCurrentAction.getAttribute("newChar"));
		if (theOldChar != null) {
			try {
				theText = theText.replace((char) Integer.parseInt(theOldChar), (char) Integer.parseInt(theNewChar));
			} catch (NumberFormatException e) {
				theText = theText.replace(theOldChar, theNewChar);
			}
		}

		final String regex = replaceProperties(aCurrentAction.getAttribute("regex"));
		final String replacement = replaceProperties(aCurrentAction.getAttribute("replacement"));
		if (regex != null && theText != null) {
			theText = theText.replaceAll(regex, replacement);
		}

		setVariableValue(theName, theText);
	}

	@CommandHotHepl("<html>Data checking.</html>")
	@CommandExamples({
			"<CheckValue actual='type:string' expected='type:string' mode='choice:normal|trimLines' onErrorMsg='type:string'/>",
			"<CheckValue value='type:string' regex='type:string' onErrorMsg='type:string'/>" })
	public void runCommandCheckValue(final Node aCurrentAction) throws Throwable {

		final String theErrorMsg = replaceProperties(aCurrentAction.getAttribute("onErrorMsg"));

		final String theRegex = replaceProperties(aCurrentAction.getAttribute("regex"));

		if (theRegex == null) {
			final boolean theTrimLines = "trimLines".equals(replaceProperties(aCurrentAction.getAttribute("mode")));
			try {
				String actual = replaceProperties(aCurrentAction.getAttribute("actual"));
				String expected = replaceProperties(aCurrentAction.getAttribute("expected"));
				if (theTrimLines) {
					actual = getTrimmedLines(actual);
					expected = getTrimmedLines(expected);
				}

				final boolean unequal = "unequal".equals(replaceProperties(aCurrentAction.getAttribute("condition")));
				if (unequal) {
					TestCase.assertFalse(theErrorMsg, StringUtils.equals(expected, actual));
				} else {
					TestCase.assertEquals(theErrorMsg, expected, actual);
				}
			} catch (final Throwable e) {
				taskNode(aCurrentAction);
				throw e;
			}
		} else {
			final String theValue = replaceProperties(aCurrentAction.getAttribute("value"));
			final Pattern p = Pattern.compile(theRegex);
			final Matcher m = p.matcher(theValue);
			if (m.find() == false) {
				taskNode(aCurrentAction);
				TestCase.fail("Regex validation failed. Regex:" + theRegex + ", value:" + theValue);
			}
		}

	}

	private String getTrimmedLines(String theValue1) throws IOException {
		final BufferedReader theStringReader = new BufferedReader(new StringReader(theValue1));
		String theLine = "";
		final StringBuffer theBuffer = new StringBuffer();
		while ((theLine = theStringReader.readLine()) != null) {
			final String theTrimmedLine = theLine.trim();
			if (theTrimmedLine.length() > 0) {
				theBuffer.append(theTrimmedLine);
				theBuffer.append('\n');
			}
		}
		theValue1 = theBuffer.toString();
		return theValue1;
	}

	@CommandHotHepl("<html>Asserts that an object isn't null.</html>")
	@CommandExamples({ "<CheckNotNull name='type:property' onErrorMsg='type:string'/>" })
	public void runCommandCheckNotNull(final Node aCurrentAction) throws Throwable {
		final String theName = replaceProperties(aCurrentAction.getAttribute("name"));
		final String theErrorMsg = replaceProperties(aCurrentAction.getAttribute("onErrorMsg"));
		Object theValue = getVariableValue(theName);
		if (theValue != null && theValue instanceof String[] && ((String[]) theValue).length == 0) {
			theValue = null;
		}
		try {
			TestCase.assertNotNull(theErrorMsg, theValue);
		} catch (final Throwable e) {
			taskNode(aCurrentAction);
			throw e;
		}
	}

	@CommandHotHepl("<html>Interactive choice command.</html>")
	@CommandExamples({
			"<Choice name='type:property' mode='choice:default|table'>"
					+ "<Task name='type:string'>...</Task></Choice>",
			"<Choice name='type:property' mode='choice:default|table' type='call-task'>"
					+ "<Task name='type:task'/></Choice>",
			"<Choice name='type:property'><Task name='type:string'>...</Task><Started>...</Started></Choice>",
			"<Choice name='type:property' setup='type:property' runAllTaskName='type:string' mode='choice:default|table' type='choice:default|call-task'>"
					+ "<Task name='type:string'>...</Task><Started>...</Started></Choice>" })
	public void runCommandChoice(final Node aCurrentAction) throws Throwable {

		final String nameOfChoice = replaceProperties(aCurrentAction.getAttribute("name"));
		final String theRunAllTaskName = replaceProperties(aCurrentAction.getAttribute("runAllTaskName"));
		final boolean callType = "call-task".equals(replaceProperties(aCurrentAction.getAttribute("type")));
		final Node[] theVariablesNodes = aCurrentAction.getNodes("Task");

		final Map<String, Node> theTablesNodes = new HashMap<String, Node>();

		final List<String> theNamesList = new ArrayList<String>();
		final String theMode = replaceProperties(aCurrentAction.getAttribute("mode"));

		for (int i = 0; i < theVariablesNodes.length; i++) {
			if (this.fstoppedTest) {
				break;
			}

			final String replaceProperties = replaceProperties(theVariablesNodes[i].getAttribute("name"));

			if ("table".equals(theMode) && replaceProperties != null && replaceProperties.equals(theRunAllTaskName)) {
				continue;
			}

			theNamesList.add(replaceProperties);
			theTablesNodes.put(replaceProperties, theVariablesNodes[i]);
		}

		final String[] theNames = new String[theNamesList.size()];
		for (int i = 0; i < theNamesList.size(); i++) {
			theNames[i] = theNamesList.get(i);
		}

		debug("Task list: " + nameOfChoice);

		final ArrayList<String> theActiveNodes = new ArrayList<String>();

		if ("table".equals(theMode)) {

			final String exceptionIgnore = replaceProperties(aCurrentAction.getAttribute("exception"));
			boolean startsWith = false;
			if (exceptionIgnore != null) {
				startsWith = exceptionIgnore.startsWith("ignore");
			}
			final String setupStr = aCurrentAction.getAttribute("setup");
			final Object variableValue = getVariableValue(setupStr);
			final MultiTaskRunDialog inputSelectChoice = this.recipeListener.getManager().tasksChoice(
					new ChoiceTaskRunner(nameOfChoice, setupStr == null), theNames, startsWith, variableValue, this);

			try {
				final Iterator<String> selectedTasks = inputSelectChoice.getSelectedTasks();
				while (selectedTasks.hasNext()) {
					String selectedTask = (String) selectedTasks.next();
					inputSelectChoice.begin(selectedTask);
					try {

						if (callType) {
							runCommandTask(theTablesNodes.get(selectedTask));
						} else {
							taskNode(theTablesNodes.get(selectedTask));
						}
						inputSelectChoice.end(selectedTask, true);

					} catch (final Throwable e) {
						inputSelectChoice.end(selectedTask, false);
						if (inputSelectChoice.isExceptionIgnore() == false) {
							throw e;
						}
					}

				}
			} finally {
				inputSelectChoice.done();
				if (inputSelectChoice.isStarted()) {
					Node[] nodes = aCurrentAction.getNodes("Started");
					for (Node node : nodes) {
						taskNode(node);
					}
				}
			}

		} else {
			if (this.recipeListener.getManager() != null) {
				final String setupStr = aCurrentAction.getAttribute("setup");
				Object variableValue = getVariableValue(setupStr);

				final String inputSelectChoice = this.recipeListener.getManager().inputSelectChoice(nameOfChoice,
						theNames, ObjectUtils.toString(variableValue, null), this);
				if (inputSelectChoice != null) {
					theActiveNodes.add(inputSelectChoice);
				}
			}

			debug("Select task: " + (theActiveNodes != null ? theActiveNodes : "<not chosen>"));

			if (theActiveNodes.size() > 0) {
				if (theActiveNodes.get(0).equals(theRunAllTaskName) == false) {

					if (callType) {
						runCommandTask(theTablesNodes.get(theActiveNodes.get(0)));
					} else {
						taskNode(theTablesNodes.get(theActiveNodes.get(0)));
					}

				} else {
					for (int i = 0; i < theNames.length; i++) {
						final String theActiveNode = theNames[i];
						if (theActiveNode.equals(theRunAllTaskName) == false) {
							if (callType) {
								runCommandTask(theTablesNodes.get(theActiveNode));
							} else {
								taskNode(theTablesNodes.get(theActiveNode));
							}
						}
					}
				}
			}
		}
	}

	@CommandHotHepl("<html>Runnable block. Should be use with &lt;Threads/&gt;.</html>")
	@CommandExamples({ "<Runnable name='type:property' threadLog='true'>...</Runnable>" })
	public void runCommandRunnable(final Node aCurrentAction) throws Throwable {
		final String theName = replaceProperties(aCurrentAction.getAttribute("name"));
		String theNameThreads = getTestName(aCurrentAction);
		if (theNameThreads == null) {
			theNameThreads = "Thread";
		}

		boolean threadLog = Boolean.valueOf(StringUtils.defaultIfBlank(attr(aCurrentAction, "threadLog"), "false"));
		Logger theLog = this.log;
		if (threadLog) {
			theLog = this.recipeListener.createLog(theNameThreads, false);
		}

		Node task = new Node("Task");
		task.setAttribute("description", aCurrentAction.getAttribute("name"));
		task.addAll(aCurrentAction);
		final TaskProcessorThread runnable = new TaskProcessorThread(this, task, getBaseDir(), theLog);
		setVariableValue(theName, runnable);
	}

	@CommandHotHepl("<html>Sorts the array of objects.</html>")
	@CommandExamples({ "<Sort name='type:property' type='choice:natural|random' />" })
	public void runCommandSort(final Node aCurrentAction) throws Throwable {
		final String theName = replaceProperties(aCurrentAction.getAttribute("name"));
		String theType = replaceProperties(aCurrentAction.getAttribute("type"));
		if (theType == null) {
			theType = "natural";
		}

		final Object theObject = getVariableValue(theName);
		if (theObject instanceof String[]) {
			String[] theArray = (String[]) theObject;
			if ("natural".equals(theType)) {
				Arrays.sort(theArray);
			} else if ("random".equals(theType)) {
				theArray = randomSort(theArray);
			} else {
				throw new Exception("Sort type should be following value: natural, random.");
			}
			setVariableValue(theName, theArray);
		}
	}

	private String[] randomSort(final String[] aArray) {
		final Vector<String> theVector = new Vector<String>();
		for (int i = 0; i < aArray.length; i++) {
			theVector.add(aArray[i]);
		}
		final String[] theResult = new String[theVector.size()];

		for (int l = 0; l < aArray.length; l++) {
			final int theNumber = (int) (Math.random() * (theVector.size()));
			theResult[l] = theVector.elementAt(theNumber);
			theVector.removeElementAt(theNumber);
		}

		return theResult;
	}

	@CommandHotHepl("<html>Searches the specified array for the specified object.</html>")
	@CommandExamples({ "<CheckInArray value='type:string' array='type:property' onErrorMsg='type:string'/>" })
	public void runCommandCheckInArray(final Node aCurrentAction) throws Throwable {
		final String theValue = replaceProperties(aCurrentAction.getAttribute("value"));
		final String theArrayName = replaceProperties(aCurrentAction.getAttribute("array"));
		final String theErrorMsg = replaceProperties(aCurrentAction.getAttribute("onErrorMsg"));
		final Object theObject = getVariableValue(theArrayName);
		if (theObject != null && theObject instanceof String[]) {
			final String[] theValues = (String[]) theObject;
			Arrays.sort(theValues);
			try {
				TestCase.assertTrue(theErrorMsg, Arrays.binarySearch(theValues, theValue) >= 0);
			} catch (final Throwable e) {
				taskNode(aCurrentAction);
				throw e;
			}
		}
	}

	@CommandHotHepl("<html>Waiting command in millisecond.</html>")
	@CommandExamples({ "<Wait delay='type:integer'/>", "<Wait/>" })
	public void runCommandWait(final Node aCurrentAction) throws Throwable {
		final String theValue = replaceProperties(aCurrentAction.getAttribute("delay"));
		if (theValue != null) {
			synchronized (monitor) {
				try {
					monitor.wait(Integer.parseInt(theValue));
				} catch (InterruptedException e) {
					getLog().debug(e.getMessage());
					stop();
				}
			}
		} else {
			pause();
		}
	}

	@CommandHotHepl("<html>Presentation panel frame.</html>")
	@CommandExamples({
			"<Frame frameId='type:string' reuse='false' type='TextPanel'/><Out frameId='type:attr' level='debug'/>",
			"<Frame frameId='type:string' reuse='false' type='HTMLPanel'/><Out frameId='type:attr' level='debug'/>",
			"<Frame frameId='type:string' reuse='false' type='XYLineChart' title='type:string' xAxisLabel='type:string' yAxisLabel='type:string'/><Out frameId='type:attr' series='type:string' x='type:integer' level='debug'/>",
			"<Frame frameId='type:string' reuse='false' type='BarChart' title='type:string' xAxisLabel='type:string' yAxisLabel='type:string'/><Out frameId='type:attr' row='type:string' column='type:string' level='debug'/>",
			"<Frame frameId='type:string' reuse='false' type='PieChart' title='type:string' /><Out frameId='type:attr' key='type:string' level='debug'/>",
			"<Frame frameId='type:string' reuse='false' type='DialScale' title='type:string' label='type:string' lower='type:double' upper='type:double' increment='type:double' count='type:integer'/><Out frameId='type:attr' level='debug'/>" })
	public void runCommandFrame(final Node aCurrentAction) throws Throwable {
		this.recipeListener.runCommandFrame(replaceAttributes(aCurrentAction));
	}

	@CommandHotHepl("<html></html>")
	@CommandExamples({ "<Formater name='type:property' type='choice:xml|http-get-request'/>" })
	public void runCommandFormater(final Node aCurrentAction) throws Throwable {
		final String theNameAttribut = replaceProperties(aCurrentAction.getAttribute("name"));
		final String theTypeAttribut = replaceProperties(aCurrentAction.getAttribute("type"));
		Object theValue = getVariableValue(theNameAttribut);
		if (theValue instanceof String) {
			theValue = new String[] { (String) theValue };
		}
		if (theValue instanceof String[]) {
			final String[] theValueArray = (String[]) theValue;
			for (int i = 0; i < theValueArray.length; i++) {
				if (this.fstoppedTest) {
					break;
				}
				if ("xml".equals(theTypeAttribut)) {
					final EasyParser theParser = new EasyParser();
					String theCurrentValue = theValueArray[i];
					theCurrentValue = prepareXml(theCurrentValue);
					final Node object = theParser.getObject(theCurrentValue);
					theValueArray[i] = object.getXMLText();
				}
			}
			if (theValueArray.length > 2) {
				setVariableValue(theNameAttribut, theValueArray);
			} else if (theValueArray.length == 1) {
				setVariableValue(theNameAttribut, theValueArray[0]);
			} else {
				setVariableValue(theNameAttribut, null);
			}
		}
	}

	static public String prepareXml(String theCurrentValue) {
		final int head = theCurrentValue.indexOf("<?");
		if (head >= 0) {
			final int end = theCurrentValue.indexOf("?>");
			theCurrentValue = theCurrentValue.substring(end + 2).trim();
		}
		return theCurrentValue;
	}

	@CommandExamples({ "<Trim name='type:property'/>" })
	public void runCommandTrim(final Node aCurrentAction) throws Throwable {
		String name = replaceProperties(aCurrentAction.getAttribute("name"));
		final Object theNameAttribut = getVariableValue(name);
		String trim = StringUtils.trim(ObjectUtils.toString(theNameAttribut));
		setVariableValue(name, trim);
	}

	@CommandHotHepl("<html></html>")
	@CommandExamples({ "<Xslt name='type:property' xml='type:string' xsl='type:string'/>" })
	public void runCommandXslt(final Node aCurrentAction) throws Throwable {
		final String theNameAttribut = replaceProperties(aCurrentAction.getAttribute("name"));
		final String theXmlAttribut = replaceProperties(aCurrentAction.getAttribute("xml"));
		final String theXslAttribut = replaceProperties(aCurrentAction.getAttribute("xsl"));
		final StringWriter theStringWriter = new StringWriter();

		if (theXmlAttribut == null || theXmlAttribut.trim().length() == 0 || "null".equals(theXmlAttribut)) {
			debug("Xml document is empty, transform disable.");
			return;
		}

		if (theXslAttribut == null || theXslAttribut.trim().length() == 0 || "null".equals(theXslAttribut)) {
			debug("Xsl document is empty, transform disable.");
			return;
		}

		try {
			final Source xslSource = new StreamSource(new StringReader(theXslAttribut));
			final Transformer transformer = TransformerFactory.newInstance().newTransformer(xslSource);
			final Source xmlSource = new StreamSource(new StringReader(theXmlAttribut));

			transformer.transform(xmlSource, new StreamResult(theStringWriter));

		} catch (final Throwable e) {
			debug("XML Data to transformation:\n" + theXmlAttribut);
			debug("XSL:\n" + theXslAttribut);
			this.log.error("Xsl transformation is failed.", e);
			throw e;
		}

		setVariableValue(theNameAttribut, theStringWriter.toString());
	}

	@CommandHotHepl("<html></html>")
	@CommandExamples({ "<Out name='type:property'/>", "<Out frameId='type:string'/>",
			"<Out name='type:property' level='choice:info|debug|warn|error'/>",
			"<Out name='type:property' level='choice:info|debug|warn|error'> ... </Out>",
			"<Out level='choice:info|debug|warn|error'>... $var{...}</Out>",
			"<Out file='type:path' append='choice:true|false' encoding='UTF-8'/>" })
	public void runCommandOut(final Node aCurrentAction) throws Throwable {
		final String theAttribut = replaceProperties(aCurrentAction.getAttribute("name"));
		String theOutFileNameAttribut = replaceProperties(aCurrentAction.getAttribute("file"));
		String theLevelAttribut = replaceProperties(aCurrentAction.getAttribute("level"));
		if (theLevelAttribut == null) {
			theLevelAttribut = "info";
		}
		String type = replaceProperties(aCurrentAction.getAttribute("type"));

		theLevelAttribut = StringUtils.defaultIfEmpty(theLevelAttribut, "text");

		FileOutputStream theFileOutputStream = null;
		if (theOutFileNameAttribut != null) {
			String theAppendAttribut = replaceProperties(aCurrentAction.getAttribute("append"));
			if (theAppendAttribut == null) {
				theAppendAttribut = "true";
			}
			theOutFileNameAttribut = replaceProperties(theOutFileNameAttribut);
			final File file = getFile(theOutFileNameAttribut);
			file.getParentFile().mkdirs();
			theFileOutputStream = new FileOutputStream(file, "true".equals(theAppendAttribut));
		}
		String theEncoding = replaceProperties(aCurrentAction.getAttribute("encoding"));
		if (theEncoding == null) {
			theEncoding = "UTF-8";
		}

		String theTextOut = null;
		String varName = theAttribut;
		final Node[] theNodes = aCurrentAction.getTextNodes();
		if (theNodes.length > 0) {
			theTextOut = replaceProperties(theNodes[0].getText());
		} else if (aCurrentAction.size() > 0) {
			theTextOut = replaceProperties(aCurrentAction.getInnerXMLText());
		}

		if (theTextOut != null) {
			if (theAttribut != null) {
				varName = theTextOut + ": " + varName;
			}
			if (theFileOutputStream != null) {
				theFileOutputStream.write(theTextOut.getBytes(theEncoding));
			}

			Properties attributes = replaceAttributes(aCurrentAction);
			this.recipeListener.outToFrame(this, attributes, theTextOut);
		}

		if (theAttribut != null) {
			Object theValue = getVariableValue(theAttribut);

			if (theValue instanceof byte[]) {
				if (theFileOutputStream != null) {
					final byte[] value = (byte[]) theValue;
					theFileOutputStream.write(value);
					theFileOutputStream.close();
					return;
				} else {
					outputLog(varName, theLevelAttribut, theValue, type);
					return;
				}
			}

			if (theValue == null) {
				outputLog(varName, theLevelAttribut, null, type);

			} else if (theValue instanceof String) {
				if (theFileOutputStream == null) {
					outputLog(varName, theLevelAttribut, theValue.toString(), type);
				} else {
					theFileOutputStream.write(theValue.toString().getBytes(theEncoding));
				}

				this.recipeListener.outToFrame(this, replaceAttributes(aCurrentAction), theValue);

			} else if (theValue instanceof String[]) {
				final StringBuffer theBuffer = new StringBuffer();
				final String[] theValueArray = (String[]) theValue;
				for (int i = 0; i < theValueArray.length; i++) {
					if (this.fstoppedTest) {
						break;
					}
					theBuffer.append(theValueArray[i]).append("\n");
					this.recipeListener.outToFrame(this, replaceAttributes(aCurrentAction), theValueArray[i]);
				}
				if (theFileOutputStream == null) {
					outputLog(varName, theLevelAttribut, theBuffer.toString(), type);
				} else {
					theFileOutputStream.write(theBuffer.toString().getBytes(theEncoding));
				}
			} else {
				outputLog(varName, theLevelAttribut, theValue, type);
				this.recipeListener.outToFrame(this, replaceAttributes(aCurrentAction), theValue);
			}
		} else {
			outputLog(varName, theLevelAttribut, theTextOut, type);
		}

		if (theFileOutputStream != null) {
			theFileOutputStream.flush();
			theFileOutputStream.close();
		}
	}

	private Properties replaceAttributes(Node aCurrentAction) {
		LinkedMap attributes = aCurrentAction.getAttributes();
		Properties properties = MapUtils.toProperties(attributes);
		Set<Entry<Object, Object>> entrySet = properties.entrySet();
		Properties props = new Properties();
		for (Entry<Object, Object> entry : entrySet) {
			String key = (String) entry.getKey();
			String value = (String) entry.getValue();

			String replaceProperties = replaceProperties(value);
			props.setProperty(key, replaceProperties);
		}
		return props;
	}

	private void outputLog(String varName, final String theLevelAttribut, final Object theTextOut, String type) {

		AELogRecord logRecord = new AELogRecord(theTextOut, type, varName);

		if ("info".equals(theLevelAttribut)) {
			this.log.info(logRecord);
		}
		if ("error".equals(theLevelAttribut)) {
			this.log.error(logRecord);
		}
		if ("debug".equals(theLevelAttribut)) {
			debug(logRecord);
		}
		if ("warn".equals(theLevelAttribut)) {
			this.log.warn(logRecord);
		}
	}

	@CommandHotHepl("<html></html>")
	@CommandExamples({ "<About><description><h1>My Description</h1></description><author name='' mail=''/></About>",
			"<About><author name='' mail='' messager='' phone=''/><version task=''><product name='' value=''/></version><attach><file name='' width='' height=''/></attach></About>" })
	public void runCommandAbout(final Node aCurrentAction) throws Throwable {
	}

	@CommandExamples({ "<Exist name='type:property' text='' value=''/>",
			"<Exist name='type:property' array='type:property' value=''/>" })
	public void runCommandExist(final Node aCurrentAction) throws Throwable {
		final String theName = replaceProperties(aCurrentAction.getAttribute("name"));
		final String theText = replaceProperties(aCurrentAction.getAttribute("text"));
		final String theArrayName = replaceProperties(aCurrentAction.getAttribute("array"));
		final String theValue = replaceProperties(aCurrentAction.getAttribute("value"));

		if (theArrayName != null) {
			final Object variableValue = getVariableValue(theArrayName);
			if (variableValue instanceof String[]) {
				final String[] variableValueArray = (String[]) variableValue;
				for (int i = 0; i < variableValueArray.length; i++) {
					if (theValue.equals(variableValueArray[i])) {
						setVariableValue(theName, "true");
						return;
					}
				}
			}

			if (variableValue instanceof String) {
				final String value = (String) variableValue;
				if (theValue.equals(value)) {
					setVariableValue(theName, "true");
					return;
				}
			}
			setVariableValue(theName, "false");
		} else {
			if (theText == null || theValue == null || theName == null) {
				return;
			}
			final int indexOf = theText.indexOf(theValue);
			setVariableValue(theName, indexOf >= 0 ? "true" : "false");
		}
	}

	@CommandExamples({
			"<Load name='type:property' file='type:path' timeout='2000' mode='choice:default|noreplace|escapeJS|bytes'/>",
			"<Load name='type:property' url='' timeout='2000' mode='choice:default|noreplace|escapeJS|bytes'/>",
			"<Load name='type:property' xml='' timeout='2000' mode='choice:default|noreplace|escapeJS|bytes'/>" })
	public void runCommandLoad(final Node aCurrentAction) throws Throwable {
		final boolean theNoreplace = "noreplace".equals(aCurrentAction.getAttribute("mode"));
		final boolean theDefaultValue = "default".equals(aCurrentAction.getAttribute("mode"));
		final boolean escapeJSValue = "escapeJS".equals(aCurrentAction.getAttribute("mode"));
		final boolean bytes = "bytes".equals(aCurrentAction.getAttribute("mode"));
		final boolean base64 = "base64".equals(aCurrentAction.getAttribute("mode"));

		String theEncoding = replaceProperties(aCurrentAction.getAttribute("encoding"));
		if (theEncoding == null) {
			theEncoding = "UTF-8";
		}

		final String theUrl = replaceProperties(aCurrentAction.getAttribute("url"));
		final String theName = replaceProperties(aCurrentAction.getAttribute("name"));
		int timeout = Integer.parseInt(StringUtils.defaultIfBlank(attr(aCurrentAction, "timeout"), "2000"));

		if (theUrl != null) {
			URL url = new URL(theUrl);
			long startTime = System.currentTimeMillis();
			while (System.currentTimeMillis() < startTime + timeout) {
				if (this.fstoppedTest) {
					break;
				}
				try {
					URLConnection openConnection = url.openConnection();
					openConnection.setReadTimeout(timeout);
					byte[] byteArray = IOUtils.toByteArray(openConnection.getInputStream());
					if (escapeJSValue) {
						String data = StringEscapeUtils.escapeJavaScript(new String(byteArray));
						setVariableValue(theName, data);
					} else {
						setVariableValue(theName, new String(byteArray, theEncoding));
					}
					return;

				} catch (IOException e) {
					synchronized (monitor) {
						monitor.wait(200);
					}
				}
			}
		}

		String theXMLFile = attr(aCurrentAction, "file");
		if (theXMLFile == null) {
			theXMLFile = aCurrentAction.getAttribute("xml");
		}

		theXMLFile = replaceProperties(theXMLFile);

		final boolean theDialog = isActiveInitFor(aCurrentAction, "console");

		if (theDialog) {
			File theFile = null;
			if (theXMLFile != null) {
				theFile = getFile(theXMLFile);
			}
			theXMLFile = this.recipeListener.getManager().inputFile(theName, theFile, log, this);
		}

		if ((base64 || bytes) && theXMLFile != null) {
			File file = getFile(theXMLFile);
			debug("Loading file: " + file);
			if (file.exists()) {
				try (FileInputStream input = new FileInputStream(file)) {
					Object byteArray = IOUtils.toByteArray(input);
					if (base64) {
						byteArray = Base64.getEncoder().encodeToString((byte[]) byteArray);
					}
					setVariableValue(theName, byteArray);
				}
			} else {
				throw new FileNotFoundException(file.getAbsolutePath());
			}
			return;
		}

		if (theXMLFile != null) {
			int iterations = timeout / 1000;
			if (iterations == 0 && timeout > 0) {
				iterations = 1;
			}
			for (int i = 0; i < iterations; i++) {
				if (this.fstoppedTest) {
					break;
				}
				try {

					String theXML = AEUtils.loadResource(theXMLFile, getBaseDir(), theEncoding);
					if (theNoreplace == false) {
						theXML = replaceProperties(theXML, theDefaultValue);
					}
					if (escapeJSValue) {
						String data = StringEscapeUtils.escapeJavaScript(theXML);
						setVariableValue(theName, data);
					} else {
						setVariableValue(theName, theXML);
					}
					break;
				} catch (final FileNotFoundException e) {
					synchronized (monitor) {
						monitor.wait(1000);
					}
					continue;
				} catch (final Exception e) {
					throw e;
				}
			}
		} else {
			if (isActiveInitFor(aCurrentAction, "mandatory")) {
				stop();
			}
		}

	}

	private boolean isActiveInitFor(final Node action, String value) {
		return StringUtils.contains(attr(action, "init"), value);
	}

	@CommandExamples({ "<Remove file=''/>", "<Remove name='type:property' history='true'/>" })
	public void runCommandRemove(final Node aCurrentAction) throws Throwable {
		String theFileName = aCurrentAction.getAttribute("file");
		if (theFileName != null) {
			theFileName = replaceProperties(theFileName);
			final File theFile = getFile(theFileName);
			if (theFile.isDirectory()) {
				FileUtils.deleteDirectory(theFile);
			} else {
				if (theFile.delete() == false) {
					new Exception("File '" + theFile.getAbsolutePath() + "' is not deleted.");
				}
			}
		}
		String theVarName = aCurrentAction.getAttribute("name");
		if (theVarName != null) {
			theVarName = replaceProperties(theVarName);
			setVariableValue(theVarName, null);
			if ("true".equals(attr(aCurrentAction, "history"))) {
				AEWorkspace.getInstance().setDefaultUserConfiguration(".inputValue." + theVarName, null);
			}
		}
	}

	@CommandExamples({ "<Soap name='type:soap' request='type:property' response='type:property'/>",
			"<Soap request='type:property' response='type:property' host='http:// ...'/>" })
	public void runCommandSoap(final Node aCurrentAction) throws Throwable {
		final String theName = replaceProperties(aCurrentAction.getAttribute("name"));
		String theUrl = null;
		if (theName == null) {
			String attribute = aCurrentAction.getAttribute("host");
			theUrl = replaceProperties(attribute);
		}
		final Node theSoapNode = this.fConfigNode.findNode("Soap", "name", theName);
		if (theSoapNode == null && theUrl == null) {
			this.log.error("Please definited tag <Soap> name='" + theName + "' in testconfig.xml");
			return;
		}

		String theHost = null;
		if (theUrl == null) {
			theHost = replaceProperties(theSoapNode.getAttribute("host"));
		} else {
			theHost = theUrl;
		}
		final String theRequest = replaceProperties(aCurrentAction.getAttribute("request"));
		final String theResponse = replaceProperties(aCurrentAction.getAttribute("response"));
		String theRequestText = "";
		if (theRequest != null) {
			theRequestText = (String) getVariableValue(theRequest);
		}
		if (theRequestText == null) {
			throw new Exception("Request text is empty.");
		}
		if (theHost == null) {
			throw new Exception("URL to host is null.");
		}

		Object theValue = null;

		if (theSoapNode != null && theSoapNode.getAttribute("class") != null) {
			final SoapWrapper theInstance = this.recipeListener.getManager().getSoapWrapper(theName);

			if (theInstance == null) {
				throw new Exception("SoapWrapper class not found. Name: '" + theName + "' Class: '"
						+ theSoapNode.getAttribute("class") + "'");
			}

			final HTTPStringResponse response = new HTTPStringResponse();
			theInstance.request(theHost, new HTTPStringRequest(theRequestText), response);

			theValue = response.toString();
		} else {
			final String thePath = replaceProperties(aCurrentAction.getAttribute("path"));
			if (thePath != null) {
				theHost = new URL(new URL(replaceProperties(theHost)), thePath).toString();
			}
			debug("Soap request to host: " + theHost);

			int length = -1;
			final String theContentLength = replaceProperties(aCurrentAction.getAttribute("content-length"));
			if (theContentLength != null) {
				length = Integer.parseInt(replaceProperties(theContentLength));
			}
			theValue = SoapRequestMaker.soapAction(theRequestText, theHost, this.log, length);
		}

		setVariableValue(theResponse, theValue);
	}

	@CommandExamples({
			"<Request method='value:get|post|[socket]' request='type:property[Map{header;body}]' response='type:property[Map{status;body}]' host='http://...' timeout='5'/>",
			"<Request method='get' response='type:property[Map{status;body}]' host='http://...' userName='' password=''><param name='' value=''/></Request>" })
	public void runCommandRequest(final Node aCurrentAction) throws Throwable {
		Object request = attrValue(aCurrentAction, "request");
		final String responseName = attr(aCurrentAction, "response");
		final String method = StringUtils.defaultIfEmpty(attr(aCurrentAction, "method"), "socket");
		String theUrl = replaceProperties(aCurrentAction.getAttribute("host"));

		String userName = attr(aCurrentAction, "userName");
		String password = attr(aCurrentAction, "password");
		HttpClientContext localContext = null;
		if (userName != null && password != null) {
			CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
			credentialsProvider.setCredentials(AuthScope.ANY,
					new UsernamePasswordCredentials(userName + ":" + password));
			localContext = HttpClientContext.create();
			localContext.setCredentialsProvider(credentialsProvider);
		}

		HttpRequestBase httpRequest = null;

		final Node[] paramNodes = aCurrentAction.getNodes("param");
		if (paramNodes != null && paramNodes.length > 0) {
			List<NameValuePairImplementation> parameters = new ArrayList<>();
			for (Node node : paramNodes) {
				String name = attr(node, "name");
				String value = attr(node, "value");

				NameValuePairImplementation nameValuePair = new NameValuePairImplementation(name, value);
				parameters.add(nameValuePair);
			}

			String query = URLEncodedUtils.format(parameters, "UTF-8");
			theUrl = theUrl + "?" + query;
		}

		if (theUrl.toLowerCase().startsWith("http")) {
			if ("get".equalsIgnoreCase(method)) {
				httpRequest = new HttpGet(theUrl);

			} else if ("post".equalsIgnoreCase(method)) {
				HttpPost httpPost = new HttpPost(theUrl);
				if (request != null) {
					final Map<String, Object> requestMap = (Map<String, Object>) request;
					Object bodyObject = requestMap.get("body");
					byte[] body = null;
					if (bodyObject instanceof byte[]) {
						body = (byte[]) bodyObject;
					} else if (bodyObject instanceof String) {
						body = ((String) bodyObject).getBytes();
					}
					httpPost.setEntity(new ByteArrayEntity(body));
				}
				httpRequest = httpPost;

			}
			String timeoutStr = replaceProperties(aCurrentAction.getAttribute("timeout"));
			timeoutStr = StringUtils.defaultIfEmpty(timeoutStr, "5");

			int timeout = Integer.parseInt(timeoutStr);
			RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout * 1000)
					.setConnectionRequestTimeout(timeout * 1000).setSocketTimeout(timeout * 1000).build();
			httpRequest.setConfig(config);
			if (request != null) {
				Map<String, String> header = (Map<String, String>) ((Map<String, Object>) request).get("header");
				if (header != null) {
					Set<Entry<String, String>> entrySet = header.entrySet();
					for (Entry<String, String> entry : entrySet) {
						httpRequest.setHeader(entry.getKey(), entry.getValue());
					}
				}
			}

			CloseableHttpResponse response;
			CloseableHttpClient httpclient = HttpClients.createDefault();

			if (localContext == null) {
				response = httpclient.execute(httpRequest);
			} else {
				response = httpclient.execute(httpRequest, localContext);
			}
			ByteArrayOutputStream body = new ByteArrayOutputStream();
			response.getEntity().writeTo(body);

			HashMap<String, Object> aValue = new HashMap<String, Object>();
			aValue.put("body", body.toByteArray());
			aValue.put("status", response.getStatusLine().getStatusCode());
			aValue.put("header", response.getAllHeaders());
			setVariableValue(responseName, aValue);
		} else {

			Socket socket = null;
			try {
				String host = StringUtils.substringBefore(theUrl, ":");
				int port = Integer.parseInt(StringUtils.substringAfter(theUrl, ":"));
				socket = new Socket(host, port);
				OutputStream outputStream = socket.getOutputStream();
				if (request instanceof byte[]) {
					IOUtils.write((byte[]) request, outputStream);
				} else if (request instanceof String) {
					IOUtils.write(((String) request).getBytes(), outputStream);
				}
				InputStream inputStream = socket.getInputStream();
				byte[] response = IOUtils.toByteArray(inputStream);
				setVariableValue(responseName, response);
			} finally {
				if (socket != null) {
					socket.close();
				}
			}

		}

	}

	@CommandExamples({ "<Operation method='type:operation' />" })
	@CommandHotHepl("<html>Custom operation method runner.</html>")
	public void runCommandOperation(final Node aCurrentAction) throws Throwable {
		String method = replaceProperties(aCurrentAction.getAttribute("method"));
		OperationHolder operationsMethod = AEWorkspace.getInstance().getOperationsMethod(method);

		if (operationsMethod == null) {
			throw new IllegalArgumentException("Operation method is not found: " + method);
		}

		Class<?>[] typeParameters = operationsMethod.getMethod().getParameterTypes();

		Object[] args = new Object[typeParameters.length];
		for (int i = 0; i < args.length; i++) {
			String replaceProperties = aCurrentAction.getAttribute("arg" + (i + 1));
			if (replaceProperties != null) {
				boolean varInjection = replaceProperties.startsWith("$var{") && replaceProperties.endsWith("}");
				String varName = "";
				if (varInjection) {
					varName = StringUtils.substring(replaceProperties, 5, replaceProperties.length() - 1);
					varInjection = !StringUtils.contains(varName, "{");
				}

				if (varInjection) {
					args[i] = ConvertUtils.convert(getVariableValue(varName), typeParameters[i]);
				} else {
					args[i] = ConvertUtils.convert(replaceProperties, typeParameters[i]);
				}
			} else {
				args[i] = null;
			}
		}

		Class operationClass = operationsMethod.getOperationClass();
		Object operation = operationObjects.get(operationClass);
		if (operation == null) {
			operation = operationsMethod.newInstance();
			operationObjects.put(operationClass, operation);
		}
		Object value = operationsMethod.invoke(operation, args);

		String name = replaceProperties(aCurrentAction.getAttribute("name"));
		if (name != null) {
			setVariableValue(name, value);
		}
	}

	@CommandExamples({ "<Server port='type:integer' request='type:property' response='type:property' > ... </Server>",
			"<Server port='type:integer' numbers='type:integer' request='type:property' response='type:property' > ... </Server>" })
	public void runCommandServer(final Node aCurrentAction) throws Throwable {

		String encoding = replaceProperties(aCurrentAction.getAttribute("charset"));
		if (encoding == null) {
			encoding = "UTF-8";
		}

		final int thePort = Integer.parseInt(replaceProperties(aCurrentAction.getAttribute("port")));
		Long maxNumber = 0L;

		final String theMaxNumbers = replaceProperties(aCurrentAction.getAttribute("numbers"));
		if (theMaxNumbers != null) {
			maxNumber = Long.parseLong(theMaxNumbers);
		}
		final String request = attr(aCurrentAction, "request");
		final String response = attr(aCurrentAction, "response");

		ServerAction server = new ServerAction(this, aCurrentAction, thePort, request, response, encoding, maxNumber);
		server.perform();
	}

	@CommandExamples({
			"<Run type='choice:sql|pl/sql' description=''><var type='choice:input|output' name='type:property'/><code> ... </code></Run>",
			"<Run type='choice:sql|pl/sql' data='fields' description=''><var type='choice:input|output' name='type:property'/><code> ... </code></Run>",
			"<Run type='choice:sql|pl/sql' outputType='choice:CLOB|VARCHAR' description=''><var type='choice:input|output' name='type:property'/><code file='type:path'/></Run>}" })
	public void runCommandRun(final Node aCurrentAction) throws Throwable {
		final boolean theIgnoredExceptionState = AEUtils.isExceptionIgnore(this, aCurrentAction);

		final String theDataAttribut = aCurrentAction.getAttribute("data");
		if ("pl/sql".equals(aCurrentAction.getAttribute("type"))) {
			runPlSqlBlock(aCurrentAction);
		} else if ("sql".equals(aCurrentAction.getAttribute("type"))) {
			if ("fields".equals(theDataAttribut)) {
				runSqlFieldsBlock(aCurrentAction, theIgnoredExceptionState);
			} else {
				runSqlBlock(aCurrentAction, theIgnoredExceptionState);
			}
		}
	}

	public void runSqlBlock(final Node aCurrentAction, final boolean aIgnoredExceptionState) throws Throwable {
		final Node[] theVarNodes = aCurrentAction.findNodes("var", "type", "output");
		final String connection = aCurrentAction.getAttribute("connection");

		final Node[] theRunNodes = aCurrentAction.getNodes("code");
		String theText = null;

		final ArrayList<ArrayList<String>> theData = new ArrayList<ArrayList<String>>();
		for (int j = 0; j < theVarNodes.length; j++) {
			theData.add(new ArrayList<String>());
		}

		for (int i = 0; i < theRunNodes.length; i++) {
			if (this.fstoppedTest) {
				break;
			}
			SQLQuery fSqlQuery = connection(connection);
			try {
				theText = replaceProperties(theRunNodes[i].getInnerText());
				startCommandInformation(theRunNodes[i]);
				debug("Request:\n" + theText);

				theText = theText.trim();
				if (theVarNodes.length > 0) {
					Statement theStatement = null;
					try {
						theStatement = fSqlQuery.connection().createStatement();
						final ResultSet theResultSet = theStatement.executeQuery(theText);

						while (theResultSet != null && theResultSet.next() && this.fstoppedTest == false) {
							for (int j = 0; j < theData.size(); j++) {
								final String theValue = fSqlQuery.getStringValue(theResultSet, j + 1);
								theData.get(j).add(theValue);
							}
						}
					} finally {
						if (theStatement != null) {
							theStatement.close();
						}
					}

					int j = 0;
					for (final ArrayList<?> theDataVector : theData) {
						Object theDataObject = null;
						if (theDataVector.size() > 1) {
							final String[] theDataObjectArray = new String[theDataVector.size()];
							for (int k = 0; k < theDataVector.size(); k++) {
								theDataObjectArray[k] = (String) theDataVector.get(k);
							}
							theDataObject = theDataObjectArray;

						} else if (theDataVector.size() == 1) {
							theDataObject = theDataVector.get(0);
						}

						setVariableValue(theVarNodes[j++].getAttribute("name"), theDataObject);
					}
				} else {
					if (theText.length() > 0) {
						fSqlQuery.execute(theText);
					}
				}

				// theQuery.close();
			} catch (final Exception e) {
				if (aIgnoredExceptionState == false) {
					if (theText != null) {
						this.log.error("Sql query: " + theText);
					}
					log.error("Stack trace", e);
					throw e;
				}
			} finally {
				if (fSqlQuery != null) {
					fSqlQuery.commit();
				}
			}
		}
	}

	protected SQLQuery connection(final String connection) throws SQLException, NamingException {
		SQLQuery tsqlQuery = connectionMap.get(connection);
		if (tsqlQuery == null) {
			tsqlQuery = new SQLQuery(connection);
			connectionMap.put(connection, tsqlQuery);
		}

		return tsqlQuery;
	}

	public void runSqlFieldsBlock(final Node aCurrentAction, final boolean aIgnoredExceptionState) throws Throwable {
		String thePropertyName = null;
		final Node[] theVarNodes = aCurrentAction.findNodes("var", "type", "output");
		final String connection = aCurrentAction.getAttribute("connection");

		if (theVarNodes != null && theVarNodes.length > 0) {
			thePropertyName = theVarNodes[0].getAttribute("name");
		}

		final Node[] theRunNodes = aCurrentAction.getNodes("code");
		String theText = null;
		for (int i = 0; i < theRunNodes.length; i++) {
			if (this.fstoppedTest) {
				break;
			}

			SQLQuery fSqlQuery = connection(connection);
			try {
				theText = replaceProperties(theRunNodes[i].getInnerText());
				startCommandInformation(theRunNodes[i]);
				debug("Request:\n" + theText);
				final Properties[] theOutArrayList = fSqlQuery.forArrayFields(theText);

				final String[] theValueArray = new String[theOutArrayList.length];
				for (int l = 0; l < theOutArrayList.length; l++) {
					if (this.fstoppedTest) {
						break;
					}
					theValueArray[l] = getFields(theOutArrayList[l]);
				}
				setVariableValue(thePropertyName, theValueArray);
			} catch (final Exception e) {
				if (aIgnoredExceptionState == false) {
					if (theText != null) {
						this.log.error("Sql query: " + theText);
					}
					log.error("Stack trace", e);
					throw e;
				}
			} finally {
				if (fSqlQuery != null) {
					fSqlQuery.commit();
				}
			}
		}
	}

	private String getFields(final Properties theOutArrayList) {
		final StringBuffer theResult = new StringBuffer();
		for (final Enumeration<?> e = theOutArrayList.propertyNames(); e.hasMoreElements();) {
			final String theName = (String) e.nextElement();
			final String theValue = theOutArrayList.getProperty(theName);
			theResult.append(theName);
			theResult.append("=");
			theResult.append(theValue);
			theResult.append(";");
		}
		return theResult.toString();
	}

	public void runPlSqlBlock(final Node aCurrentAction) throws Throwable {
		final String connection = aCurrentAction.getAttribute("connection");

		final ArrayList<Object> theVarArrayList = new ArrayList<Object>();
		final ArrayList<String> theOutVarArrayListName = new ArrayList<String>();
		final Iterator<?> theVarIterator = aCurrentAction.iterator();
		while (theVarIterator.hasNext()) {
			final Node theCurrentVar = (Node) theVarIterator.next();
			if ("input".equals(theCurrentVar.getAttribute("type"))) {
				final String theAttribut = theCurrentVar.getAttribute("name");
				if (isActiveInitFor(theCurrentVar, "mandatory")) {
					runCommandVar(theCurrentVar);
				}
				theVarArrayList.add(getVariableValue(theAttribut));
			} else if ("output".equals(theCurrentVar.getAttribute("type"))) {
				final String theAttribut = theCurrentVar.getAttribute("name");
				theOutVarArrayListName.add(theAttribut);
				theVarArrayList.add(PLQuery.VARIABLE_OUT);
			}
		}
		final Node[] theRunNodes = aCurrentAction.getNodes("code");
		for (int i = 0; i < theRunNodes.length; i++) {
			if (this.fstoppedTest) {
				break;
			}
			final Node[] theCodesNodes = theRunNodes[i].getTextNodes();
			String theCode = theRunNodes[i].getAttribute("file");
			if (theCode != null) {
				theCode = IOUtils.toString(AEUtils.getInputStream(theCode, getBaseDir()));
			}
			if (theCodesNodes != null && theCodesNodes.length > 0) {
				theCode = theCodesNodes[0].getText();
			}
			final String theText = replaceProperties(theCode);
			debug("Request:\n" + theText);
			final StringBuffer theVarList = new StringBuffer();
			for (int theCurrVar = 0; theCurrVar < theVarArrayList.size(); theCurrVar++) {
				if (this.fstoppedTest) {
					break;
				}
				theVarList.append(theCurrVar + ". " + theVarArrayList.get(theCurrVar) + "\n");
			}
			debug("Variables:\n" + theVarList.toString());
			int theOutType = Types.VARCHAR;
			final String theOutTypeAttribut = aCurrentAction.getAttribute("outputType");
			if ("CLOB".equals(theOutTypeAttribut)) {
				theOutType = Types.CLOB;
			}

			if (this.theTPLQuery == null) {
				this.theTPLQuery = new PLQuery(connection);
			}
			if (this.theTPLQuery != null) {
				final ArrayList<?> theOutArrayList = this.theTPLQuery.executeBlock(theText, theVarArrayList,
						theOutType);
				if (this.theTPLQuery != null) {
					this.theTPLQuery.commit();
				}
				for (int theCurOutNum = 0; theCurOutNum < theOutVarArrayListName.size(); theCurOutNum++) {
					if (this.fstoppedTest) {
						break;
					}
					if (theOutArrayList.get(theCurOutNum) != null) {
						final String theKey = theOutVarArrayListName.get(theCurOutNum);
						final String theValue = (String) theOutArrayList.get(theCurOutNum);
						setVariableValue(theKey, theValue);
					}
				}
			}
		}
	}

	public void runCommandTokenizer(final Node aCurrentVar) {
		final String theAttribut = aCurrentVar.getAttribute("name");
		String theDelimAttribut = aCurrentVar.getAttribute("delim");
		if (theDelimAttribut == null) {
			theDelimAttribut = ";";
		}
		final Object theObjectValue = getVariableValue(theAttribut);
		if (theObjectValue == null) {
			return;
		}
		String theLine = null;
		if (theObjectValue instanceof String) {
			theLine = (String) getVariableValue(theAttribut);
		} else if (theObjectValue instanceof String[] && ((String[]) getVariableValue(theAttribut)).length == 1) {
			theLine = ((String[]) getVariableValue(theAttribut))[0];
		}
		final ArrayList<String> theArrayList = new ArrayList<String>();
		if (theLine != null) {
			final StringTokenizer theStringTokenizer = new StringTokenizer(theLine, theDelimAttribut);
			while (theStringTokenizer.hasMoreTokens()) {
				theArrayList.add(theStringTokenizer.nextToken());
			}
			final String[] theArray = new String[theArrayList.size()];
			for (int i = 0; i < theArrayList.size(); i++) {
				if (this.fstoppedTest) {
					break;
				}
				theArray[i] = theArrayList.get(i);
			}
			setVariableValue(theAttribut, theArray);
		} else {
			debug("Tokenized empty string is ignored.");
		}
	}

	@CommandExamples({ "<Table name='The table of variables'><var name='' value=''/></Table>",
			"<Table name='The table of variables' file='type:path'><var name='' value=''/></Table>" })
	public void runCommandTable(final Node aCurrentVar) throws Throwable {
		AEManager manager = this.recipeListener.getManager();
		manager.inputDataTable(this, aCurrentVar, this.fVariables, this);
	}

	@CommandExamples({ "<Loop name='type:property' source='type:property' numbers='type:integer'> ... </Loop>",
			"<Loop numbers='type:integer'> ... </Loop>",
			"<Loop name='type:property' query='select * from ...' maxCount='type:integer'> ... </Loop>" })
	public void runCommandLoop(final Node aCurrentVar) throws Throwable {
		String theDescript = replaceProperties(aCurrentVar.getAttribute("description"));
		final String theNameAttribut = attr(aCurrentVar, "name");
		final String theQuery = replaceProperties(aCurrentVar.getAttribute("query"));
		final String connection = attr(aCurrentVar, "connection");
		boolean mainLoopCommand = false;

		if (theQuery != null) {
			final SQLQuery theSqlQuery = connection(connection);

			final Statement theStatement = theSqlQuery.connection().createStatement();
			ResultSet resultSet = null;
			final ArrayList<String[]> theArrayList = new ArrayList<String[]>();

			long theMaxCount = 0;
			String theCountStr = replaceProperties(aCurrentVar.getAttribute("maxCount"));
			if ("*".equals(theCountStr)) {
				theCountStr = (String) theSqlQuery.forArrayValues("select count(*) from (" + theQuery + ")").get(0);
				debug("Fetching count rows: " + theCountStr);
			}
			if (theCountStr != null) {
				theMaxCount = Long.parseLong(theCountStr);
			}

			try {
				try {
					if (theMaxCount > 0) {
						resultSet = theStatement.executeQuery(
								"select * from (" + theQuery + ") where rownum <= " + Long.toString(theMaxCount));
						if (this.fMainLoopCommand == false) {
							this.fMainLoopCommand = true;
							mainLoopCommand = true;
						}
						this.recipeListener.setProgress(theDescript, theMaxCount, 0, false);
					} else {
						resultSet = theStatement.executeQuery(theQuery);
					}
				} catch (final Exception e) {
					final boolean theIgnoredExceptionState = AEUtils.isExceptionIgnore(this, aCurrentVar);

					if (theIgnoredExceptionState == false) {
						if (theQuery != null) {
							this.log.error("Sql query: " + theQuery);
						}
						log.error("Stack trace", e);
						throw e;
					}
				}

				int i = 0;

				final String[] theValue = new String[resultSet.getMetaData().getColumnCount()];

				while (resultSet != null && resultSet.next() && this.fstoppedTest == false) {

					for (int m = 0; m < theValue.length; m++) {
						theValue[m] = theSqlQuery.getStringValue(resultSet, m + 1);
					}

					theArrayList.add(theValue);

					if (theValue.length == 0) {
						setVariableValue(theNameAttribut, null);
					} else if (theValue.length == 1) {
						setVariableValue(theNameAttribut, theValue[0]);
					} else {
						setVariableValue(theNameAttribut, theValue);
					}

					taskNode(aCurrentVar);

					if (theMaxCount > 0 && mainLoopCommand) {
						this.recipeListener.setProgress(theDescript, theMaxCount, ++i, false);
					}
				}

			} finally {
				resultSet.close();
				theSqlQuery.close();
				if (theMaxCount > 0 && mainLoopCommand) {
					this.fMainLoopCommand = false;
				}
			}

			return;
		}

		final String theNumbers = StringUtils.trimToNull(replaceProperties(aCurrentVar.getAttribute("numbers")));
		if (theDescript == null) {
			theDescript = "Loop";
		}
		String sourceAttribute = aCurrentVar.getAttribute("source");
		final String theAttribut = replaceProperties(sourceAttribute);
		Object theLoopArrayVar = null;
		if (theAttribut != null) {
			theLoopArrayVar = getVariableValue(theAttribut);
		}
		List theLoopArray = new ArrayList();
		if (theLoopArrayVar != null) {
			if (theLoopArrayVar instanceof String) {
				theLoopArray.add((String) theLoopArrayVar);
			} else if (theLoopArrayVar instanceof String[]) {
				List<Object> asList = Arrays.asList((String[]) theLoopArrayVar);
				theLoopArray.addAll(asList);
			} else if (theLoopArrayVar instanceof List) {
				theLoopArray = (List) theLoopArrayVar;
			} else if (theLoopArrayVar instanceof Map) {
				Map map = (Map) theLoopArrayVar;
				theLoopArray.addAll(map.keySet());
			} else {
				return;
			}
		}
		int theCount = 0;
		boolean infinityLoop = false;
		if (StringUtils.isNotBlank(theNumbers)) {
			theCount = Integer.parseInt(theNumbers);
		} else {
			if (!theLoopArray.isEmpty()) {
				theCount = theLoopArray.size();
			} else {
				infinityLoop = sourceAttribute == null;
			}
		}
		if (this.fMainLoopCommand == false) {
			this.fMainLoopCommand = true;
			mainLoopCommand = true;
		}
		try {
			for (int i = 0; (i < theCount || infinityLoop) && this.fstoppedTest == false; i++) {
				if (this.fstoppedTest) {
					break;
				}
				if (this.breakFlag > 0) {
					breakFlag--;
					break;
				}
				if (mainLoopCommand && !infinityLoop) {
					this.recipeListener.setProgress(theDescript, theCount, i, false);
				}
				startCommandInformation(aCurrentVar);
				if (theLoopArray != null) {
					if (i < theLoopArray.size()) {
						setVariableValue(theNameAttribut, theLoopArray.get(i));
					}
				} else {
					setVariableValue(theNameAttribut, ObjectUtils.toString(i));
				}
				taskNode(aCurrentVar);
			}
		} finally {
			if (mainLoopCommand) {
				this.fMainLoopCommand = false;
			}
		}
	}

	@CommandExamples({ "<Append name='type:property' value=''/>" })
	public synchronized void runCommandAppend(final Node aCurrentVar) throws Throwable {
		final String theNameAttribut = aCurrentVar.getAttribute("name");
		String theValueAttribut = aCurrentVar.getAttribute("value");
		if (theNameAttribut == null || theValueAttribut == null) {
			return;
		}
		theValueAttribut = replaceProperties(theValueAttribut);
		final Object theOldValue = getVariableValue(theNameAttribut, false);
		if (theOldValue == null) {
			return;
		}
		if (theOldValue instanceof String) {
			final String theValue1 = (String) theOldValue;
			theValueAttribut = theValue1 + theValueAttribut;
			setVariableValue(theNameAttribut, theValueAttribut);
		} else if (theOldValue instanceof String[]) {
			final boolean theUniqueTypeAttribut = "unique".equals(aCurrentVar.getAttribute("type"));

			final String[] theValue1 = (String[]) theOldValue;
			final String[] theValue2 = new String[theValue1.length + 1];

			boolean theSetNewValue = true;
			for (int i = 0; i < theValue1.length; i++) {
				if (this.fstoppedTest) {
					break;
				}

				if (theUniqueTypeAttribut && theValue1[i].equals(theValueAttribut)) {
					theSetNewValue = false;
					break;
				}

				theValue2[i] = theValue1[i];
			}

			if (theSetNewValue) {
				theValue2[theValue1.length] = theValueAttribut;
				setVariableValue(theNameAttribut, theValue2);
			}
		}
	}

	@CommandExamples({ "<Rnd name='type:property' symbols='type:integer' type='choice:number|default'/>",
			"<Rnd name='type:property' symbols='type:integer' startCode='type:integer' endCode='type:integer'/>",
			"<Rnd name='type:property' source='type:property'/>" })
	public void runCommandRnd(final Node aCurrentVar) throws Throwable {
		final String theNameAttribut = replaceProperties(aCurrentVar.getAttribute("name"));
		final String source = replaceProperties(aCurrentVar.getAttribute("source"));
		if (this.fRandom == null) {
			this.fRandom = SecureRandom.getInstance("SHA1PRNG");
		}
		if (source != null) {
			Object value = getVariableValue(source);
			if (value instanceof String[]) {
				String[] strings = (String[]) value;
				int index = this.fRandom.nextInt(strings.length);
				value = strings[index];
			}
			setVariableValue(theNameAttribut, value);
			return;
		}

		final String theSymbolsAttribut = replaceProperties(aCurrentVar.getAttribute("symbols"));
		String theTypeAttribut = replaceProperties(aCurrentVar.getAttribute("type"));
		String theDefValue = null;

		final long theBegNum = Long.parseLong(theSymbolsAttribut);
		int startCode = 0x41;
		final String startCodeStr = replaceProperties(aCurrentVar.getAttribute("startCode"));
		if (startCodeStr != null) {
			if (startCodeStr.indexOf('x') > 0) {
				startCode = Integer.parseInt(startCodeStr.substring(2), 16);
			} else {
				startCode = Integer.parseInt(startCodeStr);
			}
			theTypeAttribut = "-number";
		}

		int endCode = 0x05A;
		final String endCodeStr = replaceProperties(aCurrentVar.getAttribute("endCode"));
		if (endCodeStr != null) {
			if (endCodeStr.indexOf('x') > 0) {
				endCode = Integer.parseInt(endCodeStr.substring(2), 16);
			} else {
				endCode = Integer.parseInt(endCodeStr);
			}
			theTypeAttribut = "-number";
		}

		if ("number".equals(theTypeAttribut) == false) {
			final StringBuffer theBuffer = new StringBuffer();
			for (int i = 0; i < theBegNum; i++) {
				theBuffer.append((char) (this.fRandom.nextInt(endCode - startCode) + startCode));
			}
			theDefValue = theBuffer.toString();
		} else {
			final StringBuffer theBuffer = new StringBuffer();
			for (int i = 0; i < theBegNum; i++) {
				theBuffer.append(this.fRandom.nextInt(9));
			}
			theDefValue = theBuffer.toString();
		}
		setVariableValue(theNameAttribut, theDefValue);
	}

	@CommandExamples({ "<Inc name='type:property' increase=''/>" })
	public void runCommandInc(final Node aCurrentVar) throws Throwable {
		String theValueAttribut = aCurrentVar.getAttribute("increase");
		theValueAttribut = replaceProperties(theValueAttribut);
		long theIncLong = 1;
		if (theValueAttribut != null) {
			theIncLong = Long.parseLong(theValueAttribut);
		}
		final String theAttribut = aCurrentVar.getAttribute("name");
		final Object theOldValue = getVariableValue(theAttribut);
		if (theOldValue instanceof String) {
			final long theLongValue = Long.parseLong((String) theOldValue) + theIncLong;
			setVariableValue(theAttribut, Long.toString(theLongValue));
		}
		if (theOldValue instanceof String[] && ((String[]) theOldValue).length > 0) {
			final long theLongValue = Long.parseLong(((String[]) theOldValue)[0]) + theIncLong;
			setVariableValue(theAttribut, Long.toString(theLongValue));
		} else {
			new ClassCastException("Tag <Inc> enabled only one number argument.");
		}
	}

	@CommandExamples({
			"<If value1='' value2='' condition='unequal'> ... <Else value1='' value2='' condition=''> ... </Else></If>",
			"<If expression=''> ... </If>", "<If isNull=''> ... </If>", "<If isNotNull=''> ... </If>" })
	public void runCommandIf(final Node aCurrentVar) throws Throwable {

		String theExpressionAttribut = aCurrentVar.getAttribute("expression");
		String isNull = aCurrentVar.getAttribute("isNull");
		String isNotNull = aCurrentVar.getAttribute("isNotNull");

		if (isNull != null) {
			execIf(aCurrentVar, getVariableValue(replaceProperties(isNull)) == null);
			return;
		}

		if (isNotNull != null) {
			execIf(aCurrentVar, getVariableValue(replaceProperties(isNotNull)) != null);
			return;
		}

		if (theExpressionAttribut != null) {
			theExpressionAttribut = replaceProperties(theExpressionAttribut);
			if (this.lib == null) {
				@SuppressWarnings("rawtypes")
				final Class[] staticLib = new Class[1];
				staticLib[0] = Class.forName("java.lang.Math");
				this.lib = new Library(staticLib, null, null, null, null);
				this.lib.markStateDependent("random", null);
			}

			final CompiledExpression expr_c = Evaluator.compile(theExpressionAttribut, this.lib);
			final String s = expr_c.evaluate(null).toString();
			boolean result = "true".equals(s);
			execIf(aCurrentVar, result);

		} else {

			String theValue1Attribut = aCurrentVar.getAttribute("value1");
			String theValue2Attribut = aCurrentVar.getAttribute("value2");
			String theConditionAttribut = aCurrentVar.getAttribute("condition");

			if (theValue1Attribut == null || theValue2Attribut == null) {
				taskNode(aCurrentVar);
				return;
			}

			if (theConditionAttribut == null) {
				theConditionAttribut = "==";
			}
			theValue1Attribut = replaceProperties(theValue1Attribut);
			theValue2Attribut = replaceProperties(theValue2Attribut);

			if ("==".equals(theConditionAttribut) && theValue1Attribut.equals(theValue2Attribut)) {
				taskNode(aCurrentVar);
			} else if (("!=".equals(theConditionAttribut) || "unequal".equals(theConditionAttribut))
					&& (theValue1Attribut.equals(theValue2Attribut) == false)) {
				taskNode(aCurrentVar);
			} else if ("less".equals(theConditionAttribut)
					&& (Long.parseLong(theValue1Attribut) < Long.parseLong(theValue2Attribut))) {
				taskNode(aCurrentVar);
			} else if ("bigger".equals(theConditionAttribut)
					&& (Long.parseLong(theValue1Attribut) > Long.parseLong(theValue2Attribut))) {
				taskNode(aCurrentVar);
			} else {
				final Node[] theRunNodes = aCurrentVar.getNodes("Else");
				for (int i = 0; i < theRunNodes.length; i++) {
					runCommandIf(theRunNodes[i]);
				}
			}
		}
	}

	private void execIf(final Node aCurrentVar, boolean result) throws CommandException, Throwable {
		if (result) {
			taskNode(aCurrentVar);
		} else {
			final Node[] theRunNodes = aCurrentVar.getNodes("Else");
			for (int i = 0; i < theRunNodes.length; i++) {
				runCommandIf(theRunNodes[i]);
			}
		}
	}

	public void runCommandWhile(final Node aCurrentVar) throws Throwable {
		final String theValue1Attribut = aCurrentVar.getAttribute("value1");
		final String theValue2Attribut = aCurrentVar.getAttribute("value2");
		// String theConditionAttribut = aCurrentVar.getAttribute("condition");
		if (theValue1Attribut == null || theValue2Attribut == null) {
			return;
		}
		// if (theConditionAttribut == null) theConditionAttribut = "==";
		while (replaceProperties(theValue1Attribut).equals(replaceProperties(theValue2Attribut))) {
			taskNode(aCurrentVar);
		}
	}

	@CommandExamples({ "<Pragma event='console-input' action='default'/>",
			"<Pragma event='random-select' action='on'/>", "<Pragma event='log-window' action='single'/>" })
	public void runCommandPragma(final Node aCurrentVar) throws Throwable {
		final String theEventAttribut = aCurrentVar.getAttribute("event");
		final String theActionAttribut = aCurrentVar.getAttribute("action");

		if ("console-input".equals(theEventAttribut)) {
			boolean consoleDefaultInput = "default".equals(theActionAttribut);
			getListener().getManager().setConsoleDefaultInput(consoleDefaultInput);
		} else if ("random-select".equals(theEventAttribut)) {
			randomSelect = "on".equals(theActionAttribut);
		} else {
			this.log.error("Pragma ignored. Event: " + theEventAttribut);
		}
	}

	@CommandExamples({
			"<Threads name='type:property' threadLog='true' numbers='type:integer' multi='choice:true|false' mode='choice:wait|nowait'/>",
			"<Threads numbers='type:integer' multi='choice:true|false' mode='choice:wait|nowait'><Out name='"
					+ TaskProcessorThread.THREAD_ID + "'/></Threads>",
			"<Threads multi='choice:true|false' mode='choice:wait|nowait'><Out name='" + TaskProcessorThread.THREAD_ID
					+ "'/></Threads>" })
	@CommandHotHepl("<html>Attribute name should be <b>List&lt;Runnable&gt;<b/> type.<br/>In this case &lt;Threads&gt; commands don't have any tag inside.</html>")
	public void runCommandThreads(final Node aCurrentAction) throws Throwable {

		boolean threadLog = Boolean.valueOf(StringUtils.defaultIfBlank(attr(aCurrentAction, "threadLog"), "false"));

		final String theThreadsCountAttribut = replaceProperties(aCurrentAction.getAttribute("numbers"));
		int theThreadsCount = 1;
		if (theThreadsCountAttribut != null) {
			theThreadsCount = Integer.parseInt(theThreadsCountAttribut);
		}

		String theMultiAttribut = replaceProperties(aCurrentAction.getAttribute("multi"));
		if (theMultiAttribut == null) {
			theMultiAttribut = "true";
		}

		boolean wait = "wait"
				.equals(StringUtils.defaultIfEmpty(replaceProperties(aCurrentAction.getAttribute("mode")), "wait"));

		ThreadPoolExecutor threadPool;
		if (theMultiAttribut.equals("true")) {
			if (theThreadsCount > 0) {
				threadPool = (ThreadPoolExecutor) Executors.newFixedThreadPool(theThreadsCount);
			} else {
				threadPool = (ThreadPoolExecutor) Executors.newCachedThreadPool();
			}
		} else {
			threadPool = (ThreadPoolExecutor) Executors.newFixedThreadPool(1);
		}

		String callableListName = aCurrentAction.getAttribute("name");
		if (callableListName == null) {
			final Iterator<?> theIterator = aCurrentAction.iterator();

			if (theThreadsCount == 0) {
				while (theIterator.hasNext()) {
					final Node theNode = (Node) theIterator.next();

					String theNameThreads = getTestName(theNode);
					if (theNameThreads == null) {
						theNameThreads = "Thread";
					}

					Logger theLog = this.log;
					if (threadLog) {
						theLog = this.recipeListener.createLog(theNameThreads, false);
					}

					final TaskProcessorThread runnable = new TaskProcessorThread(this, theNode, getBaseDir(), theLog);

					threadPool.execute(runnable);

				}
			} else {
				if (aCurrentAction.size() > 1) {
					throw new Exception(
							"Invalid nodes number in the <Threads> command. Only one node is allowed for not null numbers attribute.");
				}
				final Node theNode = (Node) aCurrentAction.get(0);

				for (int i = 0; i < theThreadsCount; i++) {
					String theNameThreads = getTestName(theNode);
					String logName = "Thread #" + i;
					if (theNameThreads != null) {
						logName = theNameThreads + " #" + i;
					}

					Logger theLog = this.log;
					if (threadLog) {
						theLog = this.recipeListener.createLog(logName, false);
					}

					final TaskProcessorThread runnable = new TaskProcessorThread(this, theNode, getBaseDir(), theLog);
					runnable.getVaribleValue(TaskProcessorThread.THREAD_ID, String.valueOf(i));

					threadPool.execute(runnable);
				}
			}

		} else {
			@SuppressWarnings("unchecked")
			Object callableList = getVariableValue(callableListName);
			if (callableList instanceof List) {
				for (Runnable runnable : (List<Runnable>) callableList) {
					threadPool.execute(runnable);
				}
			} else if (callableList instanceof Runnable) {
				for (int i = 0; i < theThreadsCount; i++) {
					if (callableList instanceof TaskProcessorThread) {
						threadPool.execute(((TaskProcessorThread) callableList).clone(i));
					} else {
						threadPool.execute((Runnable) callableList);
					}
				}
			} else {
				throw new IllegalArgumentException(
						"Variable of type must be Runnable oa List<Runnable>, actually: " + callableList);
			}
		}

		if (wait) {
			String description = replaceProperties(aCurrentAction.getAttribute("description"));

			long completedTaskCount = 0;
			long size = threadPool.getTaskCount();

			threadPoolList.add(threadPool);
			do {
				completedTaskCount = threadPool.getCompletedTaskCount();
				progress(size, completedTaskCount, description, false);
				Thread.sleep(200);
			} while (completedTaskCount < size);
			threadPoolList.remove(threadPool);
		}
	}

	public void setStartDir(final File aStartBaseDir) {
		this.fStartBaseDir = aStartBaseDir;
	}

	protected void progress(final long theSize, final long aValue, String aDescription, final boolean aErrorState) {
		try {
			if (aDescription == null || aDescription.length() == 0) {
				aDescription = new String(" ");
			}
			if (this.fMainLoopCommand == false) {
				this.recipeListener.setProgress(aDescription, theSize, aValue, aErrorState);
			}
		} catch (final Throwable e) {
		}
	}

	@CommandExamples({ "<Task file='type:path'/>", "<Task name='type:task'/>", "<Task> ... </Task>" })
	public void runCommandTask(final Node action) throws Throwable {

		final boolean optional = Boolean.valueOf(attr(action, "optional", "false"));

		String taskFile = replaceProperties(action.getAttribute("file"));

		if (taskFile == null) {
			final String taskName = replaceProperties(action.getAttribute("name"));
			if (taskName != null) {
				taskFile = getListener().getManager().getTestPath(taskName);

				if (taskFile == null) {
					if (optional) {
						return;
					} else {
						throw new Exception("Task with name: '" + taskName + "' not found.");
					}
				}
			}
		} else {
			if (!(new File(taskFile)).exists()) {
				if (optional) {
					return;
				} else {
					throw new Exception("Task with name: '" + taskFile + "' not found.");
				}
			}
		}

		final File theBaseDir = getBaseDir();
		try {
			if (taskFile != null) {
				String mode = replaceProperties(action.getAttribute("mode"));
				if ("async".equals(mode)) {
					getListener().getManager().runTask(taskFile, true);

				} else {
					Properties taskParameters = MapUtils.toProperties(action.getAttributes());
					Set<Entry<Object, Object>> entrySet = taskParameters.entrySet();
					for (Entry<Object, Object> entry : entrySet) {
						String name = (String) entry.getKey();
						if (!"name".equals(name) && !"file".equals(name)) {
							String value = replaceProperties((String) entry.getValue());
							this.fParameters.put(toUpperCaseName(name), value);
						}
					}

					this.fVariables = processTesting(taskFile, this.fVariables, getBaseDir());
				}
			} else {
				taskNode(action);
			}
		} finally {
			setBaseDir(theBaseDir);
		}
	}

	public void runCommandPropertieslist(final Node aCurrentAction) throws Throwable {
		final StringBuffer theBuffer = new StringBuffer();
		final String theFileRuleAttribut = aCurrentAction.getAttribute("rule");
		final String connectionName = aCurrentAction.getAttribute("connectionName");
		String[] theRequetProperties = null;
		if (theFileRuleAttribut != null) {
			final TestIterator theTestIterator = new TestIterator(this,
					AEUtils.getInputStream(theFileRuleAttribut, getBaseDir()), connectionName);
			theRequetProperties = theTestIterator.getPropertiesList();
		}
		if (theRequetProperties == null) {
			for (String theName : this.fVariables.keySet()) {
				theBuffer.append(theName + " = " + getVariableValue(theName) + "\n");
			}
		} else {
			for (int i = 0; i < theRequetProperties.length; i++) {
				final String theName = theRequetProperties[i];
				theBuffer.append(theName + " = " + getVariableValue(theName) + "\n");
			}
		}
		debug("Properties list:\r\n" + theBuffer.toString());
	}

	@CommandExamples({ "<Iterator rule='' limit='' connectionName='' start=''> ... </Iterator>" })
	public void runCommandIterator(final Node aCurrentVar) throws Throwable {
		final String theFileRuleAttribut = aCurrentVar.getAttribute("rule");
		String theTimeAttribut = aCurrentVar.getAttribute("limit");
		String connectionName = aCurrentVar.getAttribute("connectionName");
		String theStartAttribut = aCurrentVar.getAttribute("start");
		if (theTimeAttribut == null) {
			theTimeAttribut = "3";
		}
		final long theLimit = Long.parseLong(theTimeAttribut);
		if (theStartAttribut == null) {
			theStartAttribut = "0";
		}
		final int theStart = Integer.parseInt(theStartAttribut);
		if (theFileRuleAttribut == null) {
			throw new Exception("In tag <Iterator> attribut rule is not found.");
		}
		try {
			this.fIteratorMode = true;
			final TestIterator theTestIterator = new TestIterator(this,
					AEUtils.getInputStream(theFileRuleAttribut, getBaseDir()), connectionName);
			final int theMax = theTestIterator.count();
			progress(theMax, 0, "Iteration process", false);
			debug("Iteration block. Total count: " + theMax);
			final long theStertTime = System.currentTimeMillis();
			for (int i = theStart; i < theMax; i++) {
				if (this.fstoppedTest) {
					break;
				}
				setVariableValue("Iteration", Integer.toString(i + 1));
				theTestIterator.nextIteration(this.fVariables, connectionName);
				taskNode(aCurrentVar);
				progress(theMax, i, "Iteration process", false);
				if (i == 0) {
					long theTotalTime = ((System.currentTimeMillis() - theStertTime) * theMax) / 60000;
					debug("Total Iteration time: " + Long.toString(theTotalTime) + " min.");
					if (theTotalTime > theLimit) {
						int theConfirm = 0;
						if (this.recipeListener.getManager() != null) {
							if (this.recipeListener.getManager().isConsoleDefaultInput(null) == false) {
								if (theTotalTime < 60) {
									theConfirm = JOptionPane.showConfirmDialog(
											JOptionPane.getRootFrame(), "Total Iteration time: "
													+ Long.toString(theTotalTime) + " min. \nContinue?",
											"Warning", JOptionPane.YES_NO_OPTION);
								} else {
									theTotalTime /= 60;
									theConfirm = JOptionPane.showConfirmDialog(JOptionPane.getRootFrame(),
											"Total Iteration time: " + Long.toString(theTotalTime) + " h. \nContinue?",
											"Warning", JOptionPane.YES_NO_OPTION);
								}
							}
							if (theConfirm != JOptionPane.YES_OPTION) {
								break;
							}
						}
					}
				}
			}
		} finally {
			this.fIteratorMode = false;
		}
	}

	@CommandExamples({ "<Listdir path='type:path' name='type:property'/>",
			"<Listdir path='type:path' name='type:property' tree='true'/>" })
	public void runCommandListdir(final Node aCurrentVar) throws Throwable {
		final String thePathAttribut = replaceProperties(aCurrentVar.getAttribute("path"));
		final String theNameAttribut = replaceProperties(aCurrentVar.getAttribute("name"));
		File theFile = getFile(thePathAttribut);

		if (isActiveInitFor(aCurrentVar, "console")) {
			String path = this.recipeListener.getManager().inputFile(theNameAttribut, theFile, log, this);
			if (path != null) {
				theFile = new File(path);
			}
		}

		if (theFile != null) {
			debug("Listing of directory: " + theFile.getAbsolutePath());

			final String[] theValue;
			if ("true".equals(attr(aCurrentVar, "tree"))) {
				Collection<File> files = FileUtils.listFiles(theFile, TrueFileFilter.TRUE, TrueFileFilter.TRUE);
				theValue = new String[files.size()];
				int i = 0;
				for (File file : files) {
					theValue[i++] = theFile.getAbsolutePath();
				}
			} else {
				int i = 0;
				File[] listFiles = theFile.listFiles();
				theValue = new String[listFiles.length];
				for (File file : listFiles) {
					theValue[i++] = file.getAbsolutePath();
				}
			}

			if (theValue != null) {
				Arrays.sort(theValue);
				setVariableValue(theNameAttribut, theValue);
			}
		} else {
			throw new TaskCancelingException();
		}
	}

	@Override
	public File getFile(String aThePathAttribut) {
		aThePathAttribut = replaceProperties(aThePathAttribut);
		return this.recipeListener.getManager().getFile(getBaseDir(), aThePathAttribut);
	}

	@CommandExamples({ "<Textparser text='' start='' end='' path='type:path' name='type:property'/>" })
	public void runCommandTextparser(final Node aCurrentVar) throws Throwable {
		final String theTextAttribut = replaceProperties(aCurrentVar.getAttribute("text"));
		String theStartKey = replaceProperties(aCurrentVar.getAttribute("start"));
		String theEndKey = replaceProperties(aCurrentVar.getAttribute("end"));
		if (theStartKey == null) {
			theStartKey = "${";
		}
		if (theEndKey == null) {
			theEndKey = "}$";
		}
		int theBeginPos = 0;
		int theEndPos = 0;
		while (true) {
			theBeginPos = theTextAttribut.indexOf(theStartKey, theEndPos);
			if (theBeginPos < 0) {
				break;
			}
			theEndPos = theTextAttribut.indexOf(theEndKey, theBeginPos);
			if (theEndPos < 0) {
				throw new Exception("Source text is incorrect, absent symbol '" + theEndKey + "'.");
			}
			final String theLine = theTextAttribut.substring(theBeginPos + theStartKey.length(), theEndPos);
			final int thePbrk = theLine.indexOf('=');
			final String theName = replaceProperties(theLine.substring(0, thePbrk));
			final String theValue = replaceProperties(theLine.substring(thePbrk + 1));
			setVariableValue(theName, theValue);
			theEndPos += theEndKey.length();
		}
	}

	@CommandHotHepl("<html></html>")
	@CommandExamples({ "<NetworkInterfaces name='type:property' host=''/>" })
	public void runCommandNetworkInterfaces(final Node aCurrentAction) throws Throwable {
		final String name = replaceProperties(aCurrentAction.getAttribute("name"));
		String host = replaceProperties(aCurrentAction.getAttribute("host"));
		String filterFor = replaceProperties(aCurrentAction.getAttribute("filterFor"));

		if (host == null) {
			Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
			Set<String> hostIps = new HashSet<String>();
			while (networkInterfaces.hasMoreElements()) {
				NetworkInterface nextElement = networkInterfaces.nextElement();
				Enumeration<InetAddress> inetAddresses = nextElement.getInetAddresses();
				while (inetAddresses.hasMoreElements()) {
					InetAddress nextElement2 = inetAddresses.nextElement();
					if (nextElement2 instanceof Inet4Address) {
						Inet4Address address = (Inet4Address) nextElement2;
						String hostAddress = address.getHostAddress();
						int index = hostAddress.indexOf(".");
						if (filterFor == null || StringUtils.equals(filterFor, hostAddress)
								|| StringUtils.indexOfDifference(filterFor, hostAddress) >= index) {
							hostIps.add(hostAddress);
						}
					}
				}
			}
			setVariableValue(name, new ArrayList<>(hostIps));
		} else {

			try {
				URL url = new URL(host);
				host = url.getHost();
			} catch (Exception e) {

			}

			InetAddress address1 = InetAddress.getByName(host);
			setVariableValue(name, address1.getHostAddress());
		}
	}

	@CommandExamples({ "<CheckProperties map='' type='' onErrorMsg='' caption='' columnsize='' mark=''/>" })
	public void runCommandCheckProperties(final Node aCurrentVar) throws Throwable {
		final String theMapFileAttribut = replaceProperties(aCurrentVar.getAttribute("map"));
		final String theTypeAttribut = replaceProperties(aCurrentVar.getAttribute("type"));
		final String theErrorMsg = replaceProperties(aCurrentVar.getAttribute("onErrorMsg"));
		String theCommentAttribut = replaceProperties(aCurrentVar.getAttribute("caption"));
		if (theCommentAttribut == null) {
			theCommentAttribut = "Check;Left;Right;Left value;Right value;Rule";
		}
		String theSizeAttribut = replaceProperties(aCurrentVar.getAttribute("columnsize"));
		if (theSizeAttribut == null) {
			theSizeAttribut = "6;24;24;20;64;40";
		}
		String theMark = replaceProperties(aCurrentVar.getAttribute("mark"));
		if (theMark == null) {
			theMark = " ";
		}
		String theLine = null;
		final BufferedReader theFileReader = new BufferedReader(
				new FileReader(new File(getBaseDir(), theMapFileAttribut)));
		try {

			final StringBuffer theBufferText = new StringBuffer();
			theBufferText.append("Checking value of properties:\n");
			boolean theResult = false;
			boolean theFirstIniResult = false;
			StringTokenizer theTokenizer = new StringTokenizer(theCommentAttribut, ";");
			final int theNumberColumn = theTokenizer.countTokens();
			final String[] theCaption = new String[theNumberColumn];
			for (int i = 0; i < theNumberColumn; i++) {
				theCaption[i] = theTokenizer.nextToken();
			}
			theTokenizer = new StringTokenizer(theSizeAttribut, ";");
			final int theNumberColumnTable = theTokenizer.countTokens();
			final int[] theSizeCaption = new int[theNumberColumnTable];
			for (int i = 0; i < theNumberColumnTable; i++) {
				theSizeCaption[i] = Integer.parseInt(theTokenizer.nextToken());
			}
			appendTableLine(theBufferText, theSizeCaption, theCaption, " ");
			Object theValue1 = null, theValue2 = null;

			boolean theFailed = false;
			while ((theLine = theFileReader.readLine()) != null) {
				theLine = theLine.trim();
				if (theLine.length() == 0) {
					continue;
				}
				if (theLine.charAt(0) == '#') {
					appendTableLine(theBufferText, theSizeCaption, new String[] { theLine.substring(1).trim() }, " ");
					continue;
				}
				final int thePbrk = theLine.indexOf('=');
				final String theRuleLitteral = "@rule:";
				int thePbrkRule = theLine.indexOf(theRuleLitteral);
				String theRule = null;
				boolean theCasesensitive = false;
				String theOperationRule = null;
				String theParameterRule = null;
				if (thePbrkRule >= 0) {
					theRule = theLine.substring(thePbrkRule + theRuleLitteral.length());
					final String theCasesensitiveLitteral = "casesensitive:";
					final int thePbrkCasesensitive = theRule.indexOf(theCasesensitiveLitteral);
					String theRuleLine = theRule;
					if (thePbrkCasesensitive >= 0) {
						theRuleLine = theRule.substring(thePbrkCasesensitive + theCasesensitiveLitteral.length());
						theCasesensitive = true;
					}
					final String theOperationRuleEndLitteral = ":";
					final int thePbrkOperationRuleEnd = theRule.indexOf(theOperationRuleEndLitteral);
					if (thePbrkOperationRuleEnd >= 0) {
						theOperationRule = theRuleLine.substring(0, thePbrkOperationRuleEnd);
						theParameterRule = theRuleLine.substring(thePbrkOperationRuleEnd + 1);
					}
				} else {
					thePbrkRule = theLine.length();
				}
				String theLeftLine = theLine.substring(0, thePbrk);
				final String thePropLeft = replaceProperties(theLeftLine);
				String theRightLine = theLine.substring(thePbrk + 1, thePbrkRule);
				final String thePropRight = replaceProperties(theRightLine);
				Object theValueLeftObject = thePropLeft;
				Object theValueRightObject = thePropRight;
				if ("name".equals(theTypeAttribut)) {
					String theData = thePropLeft.trim();
					boolean theValueMode = thePropLeft != null && theData.length() >= 2 && theData.charAt(0) == '['
							&& theData.charAt(theData.length() - 1) == ']';
					if (theValueMode == false) {
						theValueLeftObject = getVariableValue(theData);
						theLeftLine = thePropLeft;
					} else {
						theValueLeftObject = theData.substring(1, theData.length() - 1);
					}
					theData = thePropRight.trim();
					theValueMode = thePropLeft != null && theData.length() >= 2 && theData.charAt(0) == '['
							&& theData.charAt(theData.length() - 1) == ']';
					if (theValueMode == false) {
						theValueRightObject = getVariableValue(theData);
						theRightLine = thePropRight;
					} else {
						theValueRightObject = theData.substring(1, theData.length() - 1);
					}
				}
				if (theValueLeftObject == null) {
					theValueLeftObject = "null";
				}
				if (theValueRightObject == null) {
					theValueRightObject = "null";
				}
				if (theValueLeftObject instanceof String && theValueRightObject instanceof String) {
					// -- RULE --
					theResult = ruleTranslate(theCasesensitive, (String) (theValueLeftObject),
							(String) theValueRightObject, theOperationRule, theParameterRule);
					if (theResult == false && theFirstIniResult == false) {
						theValue1 = theValueLeftObject;
						theValue2 = theValueRightObject;
						theFirstIniResult = true;
					}
				} else {
					throw new Exception("CheckProperties operation possible only String values.");
				}
				if (theResult == false) {
					theFailed = true;
				}
				appendTableLine(theBufferText, theSizeCaption,
						new Object[] { theResult ? "ok" : "failed", theLeftLine, theRightLine, theValueLeftObject,
								theValueRightObject, theRule != null ? theRule : new String() },
						theMark);
			}
			debug(theBufferText);
			if (theFailed) {
				TestCase.assertEquals(theErrorMsg, theValue2, theValue1);
				throw new AssertionFailedError("Incorrect value:<" + theValue1 + ">");
			}

		} finally {
			theFileReader.close();
		}

	}

	private boolean ruleTranslate(final boolean aCasesensitive, String aValue, final String aValueRightObject,
			final String aOperationRule, String aParameterRule) throws Exception {
		if ("date".equals(aOperationRule)) {
			final int thePbrk = aParameterRule.indexOf(';');
			final String theLeft = aParameterRule.substring(0, thePbrk);
			final String theRight = aParameterRule.substring(thePbrk + 1);
			try {
				final DateFormat theLeftFormat = new SimpleDateFormat(theLeft);
				final DateFormat theRightFormat = new SimpleDateFormat(theRight);
				ParsePosition theParsePosition = new ParsePosition(0);
				final Date theLeftDate = theLeftFormat.parse(aValue, theParsePosition);
				if (theParsePosition.getErrorIndex() > -1) {
					return false;
				}
				theParsePosition = new ParsePosition(0);
				final Date theRightDate = theRightFormat.parse(aValueRightObject, theParsePosition);
				if (theParsePosition.getErrorIndex() > -1) {
					return false;
				}
				if ((theLeftDate != null && theRightDate == null) || (theRightDate != null && theLeftDate == null)) {
					return true;
				}
				if (theRightDate == null || theLeftDate == null) {
					return false;
				}
				return theLeftDate.compareTo(theRightDate) <= 0;
			} catch (final Throwable e) {
				return false;
			}
		}
		if ("file".equals(aOperationRule)) {
			final Map<String, Object> theMapProperties = new HashMap<String, Object>();
			loadProperties(getFile(aParameterRule), theMapProperties, aCasesensitive == false);
			if (aCasesensitive == false) {
				aValue = aValue.toUpperCase();
			}
			aValue = (String) theMapProperties.get(aValue);
			if (aValue == null) {
				aValue = "null";
			}
		}
		if ("map".equals(aOperationRule)) {
			if (aCasesensitive == false) {
				aParameterRule = aParameterRule.toUpperCase();
			}
			final Map<String, Object> theMapProperties = new HashMap<String, Object>();
			loadProperties(aParameterRule, ";", theMapProperties, aCasesensitive == false);
			if (aCasesensitive == false) {
				aValue = aValue.toUpperCase();
			}
			aValue = (String) theMapProperties.get(aValue);
			if (aValue == null) {
				aValue = "null";
			}
		}
		boolean theResult;
		if (aCasesensitive) {
			theResult = aValue.equals(aValueRightObject);
		} else {
			theResult = aValue.equalsIgnoreCase(aValueRightObject);
		}
		return theResult;
	}

	private void appendTableLine(final StringBuffer aStringBuffer, final int[] aSizeCaption, final Object[] aStrings,
			final String theMark) {
		if (aSizeCaption.length != aStrings.length) {
			for (int i = 0; i < aStrings.length; i++) {
				aStringBuffer.append(aStrings[i]);
			}
		} else {
			for (int i = 0; i < aSizeCaption.length; i++) {
				String theString = new String("NULL");
				if (aStrings[i] != null) {
					theString = aStrings[i].toString();
				}
				if (theString.length() > aSizeCaption[i]) {
					aStringBuffer.append(theString.substring(0, aSizeCaption[i]));
				} else {
					aStringBuffer.append(theString);
				}
				final StringBuffer theSpaceBuffer = new StringBuffer();
				for (int theSpace = aSizeCaption[i] - theString.length(); theSpace > 0; theSpace -= theMark.length()) {
					theSpaceBuffer.append(theMark);
				}
				if (aSizeCaption[i] - theString.length() > 0) {
					theSpaceBuffer.setLength(aSizeCaption[i] - theString.length());
					aStringBuffer.append(theSpaceBuffer);
				}
				aStringBuffer.append('|');
			}
		}
		aStringBuffer.append('\n');
	}

	@CommandExamples({ "<Command name='type:property' exitValue='type:property' cmd='' noCommandLog='true'/>" })
	public void runCommandCommand(final Node aCurrentNode) throws Throwable {
		final String theCommandAttribut = replaceProperties(aCurrentNode.getAttribute("cmd"));
		final String theNameAttribut = replaceProperties(aCurrentNode.getAttribute("name"));

		runSystemCommand(theCommandAttribut, theNameAttribut, aCurrentNode);
	}

	private void runSystemCommand(final String theCommandAttribut, final String theNameAttribut,
			final Node aCurrentNode) throws Throwable {
		final String prefix = "start ";
		if (theCommandAttribut.startsWith(prefix) == false) {
			final Process process = Runtime.getRuntime().exec(theCommandAttribut);
			try {
				final BufferedReader theOutputStream = new BufferedReader(
						new InputStreamReader(process.getInputStream()));
				String theLine;

				boolean noCommandLog = Boolean.valueOf(attr(aCurrentNode, "noCommandLog"));
				if (!noCommandLog) {
					debug("Command: " + theCommandAttribut);
				} else {
					debug("Command: ****** **** *****");
				}

				boolean line_output = aCurrentNode.size() == 0;
				final StringBuffer theBuffer = new StringBuffer();
				while ((theLine = theOutputStream.readLine()) != null && !isStoppedTest()) {
					if (breakFlag > 0) {
						breakFlag--;
						break;
					}

					if (line_output) {
						theBuffer.append(theLine);
						theBuffer.append('\n');
					} else {
						setVariableValue(theNameAttribut, theLine);
						taskNode(aCurrentNode);
					}
				}

				String exitValueName = attr(aCurrentNode, "exitValue");
				if (exitValueName != null) {
					int exitValue = process.exitValue();
					setVariableValue(exitValueName, Integer.toString(exitValue));
				}

				if (line_output) {
					if (theNameAttribut == null) {
						debug("System output:" + theBuffer.toString());
					} else {
						setVariableValue(theNameAttribut, theBuffer.toString());
					}
				}
			} finally {
				process.destroy();
				try {
					if (!process.waitFor(5, TimeUnit.SECONDS)) {
						process.destroyForcibly();
					}
				} catch (InterruptedException e) {
					Thread.currentThread().interrupt();
					process.destroyForcibly();
				}
			}

		} else {
			final Thread thread = new SystemCommandStart(theCommandAttribut.substring(prefix.length()), this.log);
			thread.start();
		}
	}

	public void runCommandParameters(final Node aCurrentVar) throws Throwable {
		if (TestRunner.RUN_MODE_WEB.equals(this.recipeListener.getRunMode())) {
			// todo:
		}
	}

	@CommandExamples({ "<ArraySize name = '' array = ''/>" })
	public void runCommandArraySize(final Node aCurrentVar) throws Throwable {
		final String theNameAttribut = replaceProperties(aCurrentVar.getAttribute("name"));
		final String theArrayNameAttribut = replaceProperties(aCurrentVar.getAttribute("array"));
		final Object theValue = getVariableValue(theArrayNameAttribut);

		int theResult = 0;
		if (theValue instanceof String[]) {
			theResult = ((String[]) theValue).length;
		} else if (theValue instanceof byte[]) {
			theResult = ((byte[]) theValue).length;
		} else if (theValue instanceof String && StringUtils.isNotBlank((String) theValue)) {
			theResult = 1;
		} else {
			theResult = 0;
		}

		setVariableValue(theNameAttribut, String.valueOf(theResult));
	}

	@CommandExamples({ "<Time name = 'type:property' action = 'choice:start|continue|pause|stop'/>",
			"<Time name = 'type:property' action = 'format' format='mm:ss:SSS'/>" })
	public void runCommandTime(final Node aCurrentVar) throws Throwable {
		final String theNameAttribut = replaceProperties(aCurrentVar.getAttribute("name"));
		final String theAction = replaceProperties(aCurrentVar.getAttribute("action"));
		final String theFormat = replaceProperties(aCurrentVar.getAttribute("format"));
		final String theTimeCaption = "Time";

		if ("start".equals(theAction)) {
			final String[] theTime = new String[] { theTimeCaption, String.valueOf(System.currentTimeMillis()), "",
					"" };
			setVariableValue(theNameAttribut, theTime);
			return;
		}

		if ("continue".equals(theAction)) {
			String[] theTime = (String[]) getVariableValue(theNameAttribut);
			if (theTime == null) {
				theTime = new String[] { theTimeCaption, String.valueOf(System.currentTimeMillis()), "",
						String.valueOf(System.currentTimeMillis()) };
			}

			if (theTime == null || theTime[3] == null || theTime[3].length() == 0) {
				throw new Exception("Timer is not paused.");
			}

			if (theTimeCaption.equals(theTime[0])) {
				final long theStart = Long.parseLong(theTime[1]);
				final long thePaused = Long.parseLong(theTime[3]);
				theTime[1] = String.valueOf(theStart + (System.currentTimeMillis() - thePaused));
				theTime[3] = "";
				setVariableValue(theNameAttribut, theTime);
			} else {
				throw new Exception("Incorrect type.");
			}
			return;
		}

		if ("pause".equals(theAction)) {
			final String[] theTime = (String[]) getVariableValue(theNameAttribut);

			if (theTime[3] != null && theTime[3].length() > 0) {
				throw new Exception("Timer is paused.");
			}
			if (theTimeCaption.equals(theTime[0])) {
				theTime[3] = String.valueOf(System.currentTimeMillis());
				setVariableValue(theNameAttribut, theTime);
			} else {
				throw new Exception("Incorrect type.");
			}
			return;
		}

		if ("stop".equals(theAction)) {
			final String[] theTime = (String[]) getVariableValue(theNameAttribut);

			final long theStart = Long.parseLong(theTime[1]);

			if (theTime[3] != null && theTime[3].length() > 0) {
				final long thePaused = Long.parseLong(theTime[3]);
				theTime[1] = String.valueOf(theStart + (System.currentTimeMillis() - thePaused));
				theTime[3] = "";
			}

			if (theTimeCaption.equals(theTime[0])) {
				theTime[2] = String.valueOf(System.currentTimeMillis());
				setVariableValue(theNameAttribut, theTime);
			} else {
				throw new Exception("Incorrect type.");
			}
			return;
		}

		if ("format".equals(theAction)) {
			final String[] theTime;
			Object variableValue = getVariableValue(theNameAttribut);
			if (variableValue instanceof String[]) {
				theTime = (String[]) variableValue;
			} else {
				theTime = new String[] { "", "0", (String) variableValue };
			}

			if (ArrayUtils.getLength(theTime) < 2) {
				throw new Exception("Timer is not defined.");
			}

			if (ArrayUtils.getLength(theTime) < 3) {
				throw new Exception("Timer is not stoped.");
			}

			String theResult = null;
			if (theFormat == null) {
				theResult = String.valueOf(Long.parseLong(theTime[2]) - Long.parseLong(theTime[1]));
			} else {
				final DateFormat dateFormat = new SimpleDateFormat(theFormat);
				long date = Long.parseLong(theTime[2]) - Long.parseLong(theTime[1]);
				theResult = dateFormat.format(new Date(date));
			}

			setVariableValue(theNameAttribut, theResult);
			return;
		}
	}

	@CommandExamples({ "<ArrayElement name='type:property' array='' elementId=''/>" })
	public void runCommandArrayElement(final Node aCurrentVar) throws Throwable {
		final String theNameAttribut = replaceProperties(aCurrentVar.getAttribute("name"));
		final String theArrayNameAttribut = replaceProperties(aCurrentVar.getAttribute("array"));
		final String theElementAttribut = replaceProperties(aCurrentVar.getAttribute("elementId"));
		final Object theValue = getVariableValue(theArrayNameAttribut);

		final int theElementId = Integer.parseInt(theElementAttribut);

		Object theResult = null;
		if (theValue instanceof String[]) {
			theResult = ((String[]) theValue)[theElementId];
		} else if (theElementId == 0) {
			theResult = theValue;
		}

		setVariableValue(theNameAttribut, theResult);
	}

	@CommandHotHepl("<html>Evaluates the expressions, representing result as a string.</html>")
	@CommandExamples({ "<Calculate name='type:property' expressions='type:string'/>" })
	public void runCommandCalculate(final Node aCurrentVar) throws Throwable {
		final String theVarName = replaceProperties(aCurrentVar.getAttribute("name"));
		final String theExpressions = replaceProperties(aCurrentVar.getAttribute("expressions"));

		if (this.lib == null) {
			@SuppressWarnings("rawtypes")
			final Class[] staticLib = new Class[1];
			staticLib[0] = Class.forName("java.lang.Math");
			this.lib = new Library(staticLib, null, null, null, null);
			this.lib.markStateDependent("random", null);
		}

		CompiledExpression expr_c = null;
		expr_c = Evaluator.compile(theExpressions, this.lib);

		if (expr_c != null) {
			if (expr_c.evaluate(null) != null) {
				setVariableValue(theVarName, expr_c.evaluate(null).toString());
			} else {
				setVariableValue(theVarName, null);
			}
		}
	}

	@CommandExamples({
			"<Switch name='type:property'><case value='' rules='ignoreCase, contains, startWith, endWith'>\n...\n</case></Switch>" })
	public void runCommandSwitch(final Node aCurrentNode) throws Throwable {
		String text = (String) attrValue(aCurrentNode, "name");
		Node[] nodes = aCurrentNode.getNodes("case");
		String mainRules = attr(aCurrentNode, "rules");

		for (Node caseNose : nodes) {
			String value = attr(caseNose, "value");
			String rules = StringUtils.defaultIfEmpty(attr(caseNose, "rules"), mainRules);

			boolean execute = true;
			boolean defaultComparator = true;
			if (rules != null) {
				if (StringUtils.contains(rules, "ignoreCase")) {
					value = StringUtils.upperCase(value);
					text = StringUtils.upperCase(text);
				}

				if (StringUtils.contains(rules, "contains")) {
					defaultComparator = false;
					if (!StringUtils.contains(text, value)) {
						execute = false;
					}
				}

				if (StringUtils.contains(rules, "startWith")) {
					defaultComparator = false;
					if (!StringUtils.startsWith(text, value)) {
						execute = false;
					}
				}

				if (StringUtils.contains(rules, "endWith")) {
					defaultComparator = false;
					if (!StringUtils.startsWith(text, value)) {
						execute = false;
					}
				}
			}

			if (defaultComparator) {
				execute = StringUtils.equals(text, value);
			}

			if (execute) {
				taskNode(caseNose);
			}
		}
	}

	@CommandExamples({ "<Parse name='type:property' source='type:property' type='json'/>" })
	public void runCommandParse(final Node aCurrentNode) throws Throwable {
		String theValue = ObjectUtils
				.toString(getVariableValue(replaceProperties(aCurrentNode.getAttribute("source"))));
		final String theNameAttribut = replaceProperties(aCurrentNode.getAttribute("name"));
		Object obj = JSONValue.parse(theValue);
		if (obj instanceof JSONObject) {
			JSONObject result = (JSONObject) JSONValue.parse(theValue);
			setVariableValue(theNameAttribut, result);
		} else if (obj instanceof JSONArray) {
			JSONArray result = (JSONArray) JSONValue.parse(theValue);
			String[] array = new String[result.size()];
			for (int i = 0; i < result.size(); i++) {
				array[i] = ObjectUtils.toString(result.get(i));
			}
			setVariableValue(theNameAttribut, array);
		}
	}

	@CommandExamples({ "<Var name='type:property' init='mandatory'/>",
			"<Var name='type:property' source='type:property' start='' end=''/>",
			"<Var name='type:property' value='' description=''/>", "<Var name='type:property'><item>...</item></Var>",
			"<Var name='type:property' type='array|number' file=\"\"/>",
			"<Var name='type:property' source='type:property' />" })
	public void runCommandVar(final Node aCurrentVar) throws Throwable {
		final String name = replaceProperties(aCurrentVar.getAttribute("name"));
		String theDesc = replaceProperties(aCurrentVar.getAttribute("description"));
		String theInit = replaceProperties(aCurrentVar.getAttribute("init"));

		Object theOldValue = getVariableValue(name);
		if ("default".equals(theInit) && theOldValue != null) {
			if (theOldValue instanceof String) {
				if (StringUtils.isNotBlank((String) theOldValue)) {
					return;
				}
			} else if (theOldValue instanceof String[] && ((String[]) theOldValue).length > 0) {
				return;
			}
		}

		if ("file".equals(theInit)) {
			loadProperties(getFile(name), this.fVariables, false);
			return;
		}
		String source = aCurrentVar.getAttribute("source");
		Object theValue = getVariableValue(name);
		if (source != null) {
			theValue = getVariableValue(replaceProperties(source));
			theOldValue = theValue;
		}

		String value = aCurrentVar.getAttribute("value");
		if (value != null) {
			theValue = replaceProperties(value);
		}

		// Item setting
		if (aCurrentVar.size() > 0) {
			if (Node.TEXT_TEAG_NAME.equals(aCurrentVar.getNode(0).getTag())) {
				final Node theTextNode = aCurrentVar.getNode(0);
				theValue = replaceProperties(theTextNode.getText());

			} else {
				String type = StringUtils.defaultIfEmpty(aCurrentVar.getAttribute("type"), "");
				switch (type) {
				case "map":
					Node[] nodes = aCurrentVar.getNodes("item");
					theValue = new LinkedHashMap<String, String>();
					for (Node node : nodes) {
						((Map) theValue).put(node.getAttribute("key"), replaceProperties(node.getInnerText()));
					}
					break;

				default:
					List<Object> theItemArray = new ArrayList<>();
					for (int i = 0; i < aCurrentVar.size(); i++) {
						final Node theCurrentAction = (Node) aCurrentVar.get(i);
						Node[] theItemNodes = theCurrentAction.getTextNodes();
						if (theItemNodes != null && theItemNodes.length == 1) {
							final String replaceProperties = replaceProperties(theItemNodes[0].getText(), true);
							theItemArray.add(replaceProperties);
						} else {
							if (theCurrentAction.size() == 1) {
								Node node = theCurrentAction.get(0);
								EasyUtils.removeAllAttributes(node, Node.TAG_ID);
								theItemArray.add(replaceProperties(node.getXMLText(), true));
							} else {
								theItemArray = null;
							}
							break;
						}
					}
					theValue = theItemArray;
				}
			}
		}

		boolean contains = StringUtils.contains(theInit, "mandatory");
		boolean isConsoleInput = StringUtils.contains(theInit, "console");
		if (StringUtils.contains(theInit, "mandatory")) {
			if (!isEmpty(theOldValue)) {
				setVariableValue(name, theValue);
			} else {
				isConsoleInput = true;
			}
		}

		String type = aCurrentVar.getAttribute("type");

		final boolean theInregerType = "number".equals(type);
		if (theInregerType) {
			String string = ObjectUtils.toString(theValue);
			if (!NumberUtils.isNumber(string)) {
				setVariableValue(name, null);
				throw new NumberFormatException(string);
			}
		}

		final boolean theArrayType = "array".equals(type);
		if (name != null && !(theValue == null && theArrayType == false)) {
			if (theArrayType) {
				char separatorChar = ',';
				if (theValue instanceof String) {
					String[] split = StringUtils.split((String) theValue, separatorChar);
					theValue = split != null ? Arrays.asList(split) : null;
				}
			}
			if (theArrayType && theValue == null) {
				theValue = new String[0];
			}

			String file = replaceProperties(aCurrentVar.getAttribute("file"));
			if (theArrayType && file != null) {
				ArrayList<String> buffer = new ArrayList<String>();

				for (String string : (String[]) theValue) {
					buffer.add(string);
				}

				InputStream inputStream = AEUtils.getInputStream(file, getBaseDir());
				String encoding = replaceProperties(aCurrentVar.getAttribute("charset"));
				if (encoding == null) {
					encoding = "UTF-8";
				}
				final BufferedReader theFileReader = new BufferedReader(new InputStreamReader(inputStream, encoding));
				try {
					String readLine;
					while ((readLine = theFileReader.readLine()) != null) {
						buffer.add(readLine);
					}
				} finally {
					theFileReader.close();
				}
				theValue = buffer;
			}

			setVariableValue(name, theValue);
		}

		if (isConsoleInput) {

			if (theDesc == null) {
				theDesc = "Please input value for variable: ";
			} else {
				theDesc = theDesc + " Variable: ";
			}

			if (theOldValue instanceof List && CollectionUtils.size(theOldValue) == 1) {
				theOldValue = ((List) theOldValue).get(0);
			}

			if (aCurrentVar.size() == 0 && (isEmpty(theOldValue) || theOldValue instanceof String)) {
				Object theInitialSelectionValue = null;
				final Object o = getVariableValue(name);
				if (o instanceof String) {
					theInitialSelectionValue = o;
				}
				if (o instanceof String[] && ((String[]) o).length > 0) {
					if (this.fRandom == null) {
						this.fRandom = SecureRandom.getInstance("SHA1PRNG");
					}
					theInitialSelectionValue = ((String[]) o)[this.fRandom.nextInt(((String[]) o).length)];
				}

				if (this.recipeListener.getManager().isConsoleDefaultInput(name)) {
					String savedSelectionValue = AEWorkspace.getInstance()
							.getDefaultUserConfiguration(".inputValue." + name, (String) theInitialSelectionValue);

					if ((o instanceof String[] && ArrayUtils.contains((String[]) o, savedSelectionValue))
							|| (o instanceof String) || o == null) {
						theInitialSelectionValue = savedSelectionValue;
					}

					setVariableValue(name, theInitialSelectionValue);
				} else {
					final Object theInputValue = this.recipeListener.getManager().inputValue(theDesc, name,
							(String) theInitialSelectionValue, log, type);

					setVariableValue(name, theInputValue);
				}

			} else {
				List possibleValues = null;
				if (theOldValue instanceof List) {
					final List theStringArray = (List) theOldValue;
					possibleValues = theStringArray;
				} else {
					possibleValues = new ArrayList();
					for (int i = 0; i < aCurrentVar.size(); i++) {
						final Node theCurrentAction = (Node) aCurrentVar.get(i);
						possibleValues.add(theCurrentAction.getInnerText());
					}
				}

				if (this.recipeListener.getManager().isConsoleDefaultInput(name)) {
					String theInitialSelectionValue = randomSelect(possibleValues);
					if (!randomSelect) {
						theInitialSelectionValue = AEWorkspace.getInstance()
								.getDefaultUserConfiguration(".choiceValue." + name, theInitialSelectionValue);

					}
					setVariableValue(name, theInitialSelectionValue);
				} else {
					final Object theValueOut = this.recipeListener.getManager().choiceValue(theDesc, name,
							possibleValues.toArray(), log);
					setVariableValue(name, theValueOut);
				}
			}
		}

		theValue = getVariableValue(name);

		String start = replaceProperties(aCurrentVar.getAttribute("start"));
		String end = replaceProperties(aCurrentVar.getAttribute("end"));

		if (StringUtils.isNotEmpty(start)) {
			if (theValue instanceof byte[]) {
				theValue = new String((byte[]) theValue);
			}
			theValue = StringUtils.substringAfter((String) theValue, start);
			if (StringUtils.isBlank((String) theValue)) {
				theValue = null;
			}
		}
		if (StringUtils.isNotEmpty(end)) {
			theValue = StringUtils.substringBefore((String) theValue, end);
			if (StringUtils.isBlank((String) theValue)) {
				theValue = null;
			}
		}
		setVariableValue(name, theValue);

		if (contains && theValue == null) {
			stop();
		}
	}

	private String randomSelect(List possibleValues) throws NoSuchAlgorithmException {
		final String theInitialSelectionValue;
		if (this.fRandom == null) {
			this.fRandom = SecureRandom.getInstance("SHA1PRNG");
		}
		theInitialSelectionValue = (String) possibleValues.get(this.fRandom.nextInt(possibleValues.size()));
		return theInitialSelectionValue;
	}

	public void runCommandNote(final Node aCurrentAction) throws Throwable {
	}

	public void runCommandComment(final Node aCurrentAction) throws Throwable {
	}

	@CommandExamples({ "<Extern plugin='type:path'>...</Extern>", "<Extern class=''>...</Extern>",
			"<Extern class='' plugin='type:path'>...</Extern>" })
	public void runCommandExtern(final Node aCurrentAction) throws Throwable {
		try {
			final TaskProcessor newInstance = makeProcessor(aCurrentAction);
			boolean success = false;
			try {
				this.externProcessor = newInstance;
				newInstance.init(this, aCurrentAction);
				newInstance.taskNode(aCurrentAction);

				this.fVariables = newInstance.fVariables;
				success = true;
			} finally {
				externProcessor.complete(success);
				externProcessor = null;
			}
		} catch (final AEException e1) {
			throw e1.getCause();
		}
	}

	public void complete(boolean success) {
		stopChilds();
	}

	@CommandHotHepl("<html></html>")
	@CommandExamples({ "<Restore/>", "<Restore except='type:property'> ... </Restore>" })
	public void runCommandRestore(final Node aCurrentAction) throws Throwable {

		if (CollectionUtils.isEmpty(aCurrentAction)) {
			final Map<String, Object> systemVariables = getListener().getManager().getSystemVariables();
			this.fVariables.clear();
			this.fVariables.putAll(systemVariables);
			debug("Task variables has been restored.");
		} else {
			String except = attr(aCurrentAction, "except");

			Map<String, Object> savedVariables = this.fVariables;
			this.fVariables = new HashMap<String, Object>(this.fVariables);
			taskNode(aCurrentAction);
			Object object = getVariableValue(except);
			this.fVariables.clear();
			this.fVariables = savedVariables;
			setVariableValue(except, object);
		}

	}

	@CommandHotHepl("<html></html>")
	@CommandExamples({ "<Finally> ... </Finally>" })
	public void runCommandFinally(final Node aCurrentAction) throws Throwable {
	}

	@CommandHotHepl("<html></html>")
	@CommandExamples({ "<Break/>" })
	public void runCommandBreak(final Node aCurrentAction) throws Throwable {
	}

	@CommandHotHepl("<html></html>")
	@CommandExamples({ "<Stop/>", "<Stop ifNull='type:property'/>" })
	public void runCommandStop(final Node aCurrentAction) throws Throwable {
	}

	@CommandExamples({ "<Sql connection=''>select a var_name1, b var_name2, ... from ... </Sql>" })
	@CommandHotHepl("<html>.</html>")
	public void runCommandSql(final Node aCurrentAction) throws Throwable {
		final String theText = replaceProperties(aCurrentAction.getInnerText());
		final String connection = aCurrentAction.getAttribute("connection");

		SQLQuery fSqlQuery = connection(connection);
		startCommandInformation(aCurrentAction);
		debug("SQL Query:  " + theText);

		final Map<String, ArrayList<Object>> outArray = new HashMap<String, ArrayList<Object>>();

		if (StringUtils.startsWithIgnoreCase(StringUtils.trim(theText), "select")) {
			final Properties[] properties = fSqlQuery.forArrayFields(theText);

			for (final Properties property : properties) {
				final Set<Object> keys = property.keySet();
				for (final Object key : keys) {
					final String name = (String) key;
					final Object object = property.get(name);
					ArrayList<Object> arrayList = outArray.get(name);
					if (arrayList == null) {
						arrayList = new ArrayList<Object>();
						outArray.put(name, arrayList);
					}
					arrayList.add(object);
				}

				final Set<String> keySet = outArray.keySet();
				for (final String arrayName : keySet) {
					final ArrayList<Object> list = outArray.get(arrayName);
					if (list.size() > 1) {
						setVariableValue(arrayName, list);

					} else {
						if (list.size() > 0) {
							setVariableValue(arrayName, list.get(0));
						}
					}
				}
			}
		} else {
			fSqlQuery.execute(theText);
		}

	}

	@CommandExamples({ "<Test class=''/>", "<Test class='' method=''/>" })
	@CommandHotHepl("<html>JUnit test runner.</html>")
	public void runCommandTest(Node action) throws Throwable {
		final String className = replaceProperties(action.getAttribute("class"));
		final String methodName = replaceProperties(action.getAttribute("method"));

		Class testClass = Class.forName(className);

		JUnitCore jUnitCore = new JUnitCore();
		RunListener listener = new RunListener() {

			@Override
			public void testAssumptionFailure(Failure failure) {
				// TODO Auto-generated method stub
				super.testAssumptionFailure(failure);
			}

			@Override
			public void testFailure(Failure failure) throws Exception {
				debug("Failure: " + failure.getMessage());
			}

			@Override
			public void testFinished(Description description) throws Exception {
				debug("Finishid: " + description.getDisplayName());
			}

			@Override
			public void testStarted(Description description) throws Exception {
				debug("Started: " + description.getDisplayName());
			}

			@Override
			public void testIgnored(Description description) throws Exception {
				debug("Ignored: " + description.getDisplayName());
			}

			@Override
			public void testRunFinished(Result result) throws Exception {
				// log.info("Finishid: " + result.);
			}

			@Override
			public void testRunStarted(Description description) throws Exception {
				// log.info("Unit test started: " + description.getDisplayName()
				// + " [" + description.getClassName() + ":"
				// + description.getMethodName() + "]");
			}

		};

		jUnitCore.addListener(listener);

		Request method;
		if (StringUtils.isEmpty(methodName)) {
			method = Request.classes(testClass);
		} else {
			method = Request.method(testClass, methodName);
		}
		Result run = jUnitCore.run(method);

		List<Failure> failures = run.getFailures();
		if (CollectionUtils.isNotEmpty(failures)) {
			StringBuilder text = new StringBuilder();
			for (Failure failure : failures) {
				text.append(failure.getTestHeader());
				text.append('\n');
				text.append(failure.getDescription());
				text.append('\n');
				text.append(failure.getMessage());
				text.append('\n');
				text.append(failure.getTrace());
			}

			throw new AssertionFailedError(text.toString());
		}
	}

	public void loadProperties(final String aParameterRule, final String aDelim,
			final Map<String, Object> aMapProperties, final boolean aNameUpperCase) throws Exception {
		final StringTokenizer theStringTokenizer = new StringTokenizer(aParameterRule, aDelim);
		while (theStringTokenizer.hasMoreTokens()) {
			final String theLine = theStringTokenizer.nextToken();
			if (theLine == null || theLine.length() == 0 || (theLine.length() > 0 && theLine.trim().charAt(0) == '#')) {
				continue;
			}
			final int thePbrk = theLine.indexOf('=');
			String theName = replaceProperties(theLine.substring(0, thePbrk));
			final String theValue = replaceProperties(theLine.substring(thePbrk + 1));
			if (aNameUpperCase) {
				theName = theName.toUpperCase();
			}
			aMapProperties.put(theName, theValue);
		}
	}

	private boolean isEmpty(Object theOldValue) {
		boolean result = false;
		if (theOldValue == null) {
			result = true;
		} else if (theOldValue instanceof String[] && ((String[]) theOldValue).length == 0) {
			result = true;
		} else if (theOldValue instanceof Map && ((Map) theOldValue).size() == 0) {
			result = true;
		}
		return result;
	}

	public void setVariableValue(String name, final Object value) {
		if (name != null) {
			super.setVariableValue(name, value);
			if (this.recipeListener != null && name.startsWith("!") == false) {
				this.recipeListener.changeVariable(name, value);
			}
		}
	}

	public void loadProperties(final File aFile, final Map<String, Object> theProperties, final boolean aNameUpperCase)
			throws Exception {
		final BufferedReader theFileReader = new BufferedReader(new FileReader(aFile));
		try {
			String theLine = null;
			while ((theLine = theFileReader.readLine()) != null) {
				if (theLine == null || theLine.length() == 0
						|| (theLine.length() > 0 && theLine.trim().charAt(0) == '#')) {
					continue;
				}
				final int thePbrk = theLine.indexOf('=');
				if (thePbrk < 0) {
					try {
						String theExtLine = replaceProperties(theLine);
						theExtLine = theExtLine.replace('\r', '\n');
						loadProperties(theExtLine, "\n", theProperties, aNameUpperCase);
					} catch (final StringIndexOutOfBoundsException e) {
						throw new Exception("Incorrect data in properties file. File: " + aFile.getAbsolutePath()
								+ "\nLine: " + theLine);
					}
					continue;
				}
				String theName = replaceProperties(theLine.substring(0, thePbrk));
				final String theValue = replaceProperties(theLine.substring(thePbrk + 1));
				if (aNameUpperCase) {
					theName = theName.toUpperCase();
				}
				theProperties.put(theName, theValue);
			}
		} finally {
			theFileReader.close();
		}
	}

	public void make(final String aTestFile) throws CommandException {
		this.fTestFile = aTestFile;
		try {
			if (this.recipeListener != null && this.fstoppedTest == false) {
				this.recipeListener.startTask(this.fTestFile);
				processTesting(this.fTestFile);
				this.recipeListener.endTask(false);
			} else {
				throw new RuntimeException();
			}

		} finally {

			if (this.fTestName != null) {
				debug("Recipe '" + this.fTestName + "' is stopped.");
			}
		}
	}

	public void stop() {
		this.fstoppedTest = true;
		if (getChildThreads() > 0) {
			debug("Child's threads: " + getChildThreads());
		}

		if (this.externProcessor != null) {
			this.externProcessor.stop();
		}

		if (this.fConfigNode == null) {
			return;
		}

		synchronized (monitor) {
			monitor.notify();
		}

		if (getParent() == null) {
			debug("Recipe is waiting stopped status ...");
		}

		if (this.theTPLQuery != null) {
			this.theTPLQuery.close();
			this.theTPLQuery = null;
		}

		Collection<SQLQuery> values = connectionMap.values();
		for (SQLQuery tsqlQuery : values) {
			tsqlQuery.close();
		}

		stopChilds();

		for (ThreadPoolExecutor pool : threadPoolList) {
			pool.shutdownNow();
		}

		while (!isStoppedTest()) {
			try {
				synchronized (monitor) {
					monitor.wait(100);
				}
			} catch (InterruptedException e) {
			}
		}

		getListener().endTask(false);
	}

	private void stopChilds() {
		for (TaskProcessorThread child : fChildThreads) {
			child.stopTest();

			while (!child.getProcessor().isStoppedTest()) {
				try {
					synchronized (monitor) {
						monitor.wait(100);
					}
				} catch (InterruptedException e) {
				}
			}
		}
	}

	private static class SystemCommandStart extends Thread {
		private final String fCommandAttribut;

		Logger fLog;

		public SystemCommandStart(final String aCommandAttribut, final Logger aLog) {
			this.fLog = aLog;
			this.fCommandAttribut = aCommandAttribut;
		}

		@Override
		public void run() {
			try {
				Runtime.getRuntime().exec(this.fCommandAttribut);
			} catch (final IOException e) {
				this.fLog.error("System command starting is failed.", e);
			}
		}

	}

	protected String replaceXmlReference(String aValue) throws Exception {
		aValue = replaceFile(aValue);
		final String theStartKey = "&#";
		final String theEndKey = ";";
		int theBeginPos = 0;
		int theEndPos = 0;
		if (aValue == null) {
			return aValue;
		}
		final StringBuffer theStringBuffer = new StringBuffer();
		while (true) {
			theBeginPos = aValue.indexOf(theStartKey, theEndPos);
			if (theBeginPos < 0) {
				break;
			}
			theStringBuffer.append(aValue.substring(theEndPos, theBeginPos));
			theEndPos = aValue.indexOf(theEndKey, theBeginPos);
			if (theEndPos < 0) {
				throw new Exception("Variable getting incorrect syntax, absent symbol '" + theEndKey + "'.");
			}
			String theNameProperty = aValue.substring(theBeginPos + theStartKey.length(), theEndPos);
			final int defaultPos = theNameProperty.indexOf(',');
			if (defaultPos >= 0) {
				theNameProperty = theNameProperty.substring(0, defaultPos);
			}
			final String theValue = new String(new char[] { (char) Integer.parseInt(theNameProperty) });
			theStringBuffer.append(theValue);
			theEndPos += theEndKey.length();
		}
		theStringBuffer.append(aValue.substring(theEndPos));
		return theStringBuffer.toString();
	}

	public TaskProcessor makeProcessor(final Node aCurrentAction)
			throws IOException, ClassNotFoundException, MalformedURLException, FileNotFoundException,
			NoSuchMethodException, InstantiationException, IllegalAccessException, InvocationTargetException {
		String theAttribut = replaceProperties(aCurrentAction.getAttribute("class"));

		if (StringUtils.indexOf(theAttribut, '.') < 0) {
			theAttribut = "com.nave.anteater.processor." + theAttribut;
		}

		final String pluginJar = replaceProperties(aCurrentAction.getAttribute("plugin"));

		Class<?> theClass = null;
		if (pluginJar != null) {
			final File file = getFile(pluginJar);

			if (file.isFile()) {
				final JarClassLoader jarLoader = new JarClassLoader(file);
				if (theAttribut == null) {
					final JarFile jarFile = new JarFile(file);
					try {
						final Manifest manifest = jarFile.getManifest();
						final Attributes mainAttributes = manifest.getMainAttributes();
						theAttribut = mainAttributes.getValue("AE-Class");
					} finally {
						jarFile.close();
					}
				}
				theClass = jarLoader.loadClass(theAttribut, true);
			} else if (file.isDirectory()) {
				URLClassLoader classLoader = new URLClassLoader(new URL[] { file.toURL() });
				theClass = classLoader.loadClass(theAttribut);
			} else {
				throw new FileNotFoundException(pluginJar);
			}

		} else {
			theClass = getClass().getClassLoader().loadClass(theAttribut);
		}

		final Constructor<?> constructor = theClass.getConstructor(new Class[] { TaskProcessor.class });
		final TaskProcessor newInstance = (TaskProcessor) constructor.newInstance(new Object[] { this });
		return newInstance;
	}

	public void runCommandJdbc(final Node aCurrentAction) throws Throwable {
		getListener().getManager().createDBConnection(aCurrentAction, fVariables);
	}

	public static String[] listToArray(final ArrayList<?> theResult) {
		final String[] theResultArray = new String[theResult.size()];
		for (int i = 0; i < theResultArray.length; i++) {
			theResultArray[i] = (String) theResult.get(i);
		}
		return theResultArray;
	}

	public TaskProcessor getParent() {
		return this.fParent;
	}

	private Vector<String> getLocalTaskTrace() {
		final Vector<String> theTraceVector = new Vector<String>();
		final Object[] theTaskTrace = this.fStackTask.toArray();
		for (int i = theTaskTrace.length - 1; i >= 0; i--) {
			final String theName = (String) theTaskTrace[i];

			if (theName != null) {
				String theLine = theName + "\n";

				if (theName.charAt(0) != '<') {
					final String theFile = getListener().getManager().getTestPath(theName);
					theLine = theName + " (" + theFile + ")\n";
				}

				if (theName != null && "null".equals(theName) == false) {
					theTraceVector.add(theLine);
				}
			}
		}
		return theTraceVector;
	}

	public Vector<Vector<String>> getCallTaskTrace() {
		final Vector<Vector<String>> theTraceVector = new Vector<Vector<String>>();
		theTraceVector.add(getLocalTaskTrace());

		TaskProcessor theParent = getParent();
		while (theParent != null) {
			theTraceVector.add(theParent.getLocalTaskTrace());
			theParent = theParent.getParent();
		}

		return theTraceVector;
	}

	public Logger getLogger() {
		return this.log;
	}

	@Override
	protected String replaceCall(final String aValue) {
		final String theStartKey = "$call{";
		final String theEndKey = "}";
		int theBeginPos = 0;
		int theEndPos = 0;
		if (aValue == null) {
			return aValue;
		}

		final StringBuffer theStringBuffer = new StringBuffer();
		while (true) {
			theBeginPos = aValue.indexOf(theStartKey, theEndPos);
			if (theBeginPos < 0) {
				break;
			}
			theStringBuffer.append(aValue.substring(theEndPos, theBeginPos));
			theEndPos = aValue.indexOf(theEndKey, theBeginPos);
			if (theEndPos < 0) {
				throw new RuntimeException("Tag created is incorrect syntax, absent symbol '" + theEndKey + "'.");
			}

			final String theLine = aValue.substring(theBeginPos + theStartKey.length(), theEndPos);
			final int thePbrk = theLine.indexOf(',');
			String theTagName = theLine;
			String theNameVar = theLine;
			if (thePbrk > 0) {
				theTagName = theLine.substring(0, thePbrk);
				theNameVar = theLine.substring(thePbrk + 1);
			} else {
				theTagName = theLine;
				theNameVar = "RETURN";
			}

			Object theObjValue = null;
			if (StringUtils.startsWith(theTagName, "fn:")) {

				if (StringUtils.equals(theTagName, "fn:currentTimeMillis")) {
					theObjValue = Long.toString(System.currentTimeMillis());
				}

			} else {

				final String theFileAttribut = getListener().getManager().getTestPath(theTagName);

				try {
					final TaskProcessor theTestUnit = new TaskProcessor(this);
					theTestUnit.init(this.fConfigNode, this.fVariables, this.recipeListener, this.fStartBaseDir,
							this.log);
					final Map<String, Object> theVariables = theTestUnit.processTesting(theFileAttribut,
							this.fVariables, getBaseDir());
					theObjValue = theVariables.get(theNameVar);

				} catch (final Throwable e) {
					throw new RuntimeException(e);
				}
			}

			String theValue = null;
			if (theObjValue instanceof String) {
				theValue = (String) theObjValue;
			}
			if (theObjValue instanceof String[] && ((String[]) theObjValue).length > 0) {
				theValue = ((String[]) theObjValue)[0];
			}
			theStringBuffer.append(theValue);
			theEndPos += theEndKey.length();

		}

		theStringBuffer.append(aValue.substring(theEndPos));
		return theStringBuffer.toString();
	}

	public void pause() {
		this.fPauseOn = true;
		if (fParent != null) {
			fParent.fPauseOn = this.fPauseOn;
		}
		if (externProcessor != null) {
			externProcessor.fPauseOn = this.fPauseOn;
		}
		for (final Enumeration<TaskProcessorThread> theEnum = this.fChildThreads.elements(); theEnum
				.hasMoreElements();) {
			final TaskProcessorThread theRunnTest = theEnum.nextElement();
			theRunnTest.getProcessor().pause();
		}
		getListener().pause();
	}

	public void resume() {
		this.fPauseOn = false;
		if (externProcessor != null) {
			externProcessor.fPauseOn = this.fPauseOn;
		}
		if (fParent != null) {
			fParent.fPauseOn = this.fPauseOn;
		}
		for (final Enumeration<TaskProcessorThread> theEnum = this.fChildThreads.elements(); theEnum
				.hasMoreElements();) {
			final TaskProcessorThread theRunnTest = theEnum.nextElement();
			theRunnTest.getProcessor().resume();
		}
		getListener().resume();
	}

	private void doPause() {
		while (this.fPauseOn) {
			try {
				synchronized (monitor) {
					monitor.wait(100);
				}
			} catch (final InterruptedException e) {
			}
		}
	}

	protected void debug(Object message) {
		log.debug(message);
	}

	protected void debug(Object message, Exception e) {
		log.debug(message, e);
	}

	public void setLogger(final Logger logger) {
		this.log = logger;
	}

	public boolean isStoppedTest() {
		return this.fstoppedTest;
	}

	public String attr(Node action, String name, String defaultValue) {
		String value = attr(action, name);
		String result = StringUtils.defaultIfEmpty(value, defaultValue);
		return result;
	}

	public String attr(Node action, String name) {
		name = replaceProperties(name);
		String value = replaceProperties(action.getAttribute(name));
		return value;
	}

	public Object attrValue(Node action, String name) {
		name = replaceProperties(name);
		String value = attr(action, name);
		return getVariableValue(value);
	}

}
