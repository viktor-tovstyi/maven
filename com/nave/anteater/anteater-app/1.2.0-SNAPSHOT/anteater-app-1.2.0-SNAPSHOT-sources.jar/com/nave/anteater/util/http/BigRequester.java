package com.nave.anteater.util.http;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.URL;

import org.apache.log4j.Logger;

import com.nave.anteater.RecipeListener;
import com.nave.anteater.processor.TaskProcessor;

/**
 * @author victort
 * @version 1.0, 09-Jun-2005
 */
public class BigRequester {
	private static Logger log = Logger.getLogger("BigRequester");
	private RecipeListener fMaxTestListener;
	private URL fHostDestination;
	private TaskProcessor processor;

	public BigRequester(URL aHostDestination, TaskProcessor processor) {
		this.fMaxTestListener = processor.getListener();
		this.processor = processor;
		this.fHostDestination = aHostDestination;
	}

	public void sendRequest(InputStream input, File aResponseFile) throws IOException {
		Socket socket = new Socket(fHostDestination.getHost(), fHostDestination.getPort());

		OutputStreamWriter osw = null;
		InputStreamReader isr = null;

		osw = new OutputStreamWriter(socket.getOutputStream());
		isr = new InputStreamReader(socket.getInputStream());

		int size = input.available();

		writeActualDataToOutputStream(osw, size, input);

		osw.flush();

		readActualDataFromInputStream(isr, new FileOutputStream(aResponseFile));

		osw.close();
		isr.close();
		socket.close();
	}

	private void writeActualDataToOutputStream(OutputStreamWriter osw, int size, InputStream fis) throws IOException {

		osw.write("POST " + fHostDestination.toString() + " HTTP/1.1\n");
		osw.write("Content-Type: text/xml; charset=utf-8\n");
		osw.write("Accept: text/xml, application/dime, multipart/related, text/*\n");

		osw.write("User-Agent: UnlimitedRequester/1.2\n");
		osw.write("Host: " + fHostDestination.getHost() + ":" + fHostDestination.getPort() + '\n');
		osw.write("Cache-Control: no-cache\n");
		osw.write("Pragma: no-cache\n");
		osw.write("SOAPAction: \"\"\n");
		osw.write("Content-Length: " + (size) + '\n');
		osw.write("\n");

		if (size > 1024 * 10) {
			log.info("Content-Length: " + (size >> 10) + "kB.\n");
		} else {
			log.info("Content-Length: " + (size) + "B.\n");
		}

		for (int i = 0; i < size && processor.isStoppedTest() == false; i++) {
			int j = fis.read();
			osw.write(j);
			if (fMaxTestListener != null)
				fMaxTestListener.setProgress("Transmit file", size, i, false);
		}
	}

	private void readActualDataFromInputStream(InputStreamReader isr, OutputStream aPrintStream) throws IOException {
		int symbol = 0;
		while ((symbol = isr.read()) != -1 && processor.isStoppedTest() == false) {
			aPrintStream.write(symbol);
		}
		isr.close();
	}

}
