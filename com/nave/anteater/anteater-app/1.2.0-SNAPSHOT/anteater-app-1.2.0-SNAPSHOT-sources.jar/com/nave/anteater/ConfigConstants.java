package com.nave.anteater;

public class ConfigConstants {

	public static final String TESTCONFIG_SYS_PRPERTY_NAME = "testconfig";
	
	public static final String TESTCONFIG_XML = "testconfig.xml";
	
	public static final String CONFIG_NAME_SYS_PRPERTY_NAME = "configName";

	public static final String TAKE_IT_EASY_MODE = "takeItEasy";

}
