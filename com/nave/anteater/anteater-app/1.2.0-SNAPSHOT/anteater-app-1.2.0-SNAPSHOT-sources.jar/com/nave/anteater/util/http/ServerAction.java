package com.nave.anteater.util.http;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.AEUtils;
import com.nave.anteater.util.xml.easyparser.Node;

public class ServerAction {
	private static final String WAITING_FOR_A_REQUEST = "Waiting for a request ...";

	private static final String CONTENT_LENGTH = "content-length";

	private static final String AGENT = "agent";

	private static final String HOST = "host";

	private static final String STATUS = "status";

	private static final String BODY = "body";

	ServerSocket theServerSocket = null;

	private String request;
	private String response;
	private String encoding;
	private long maxNumber;

	private Node currentAction;

	private TaskProcessor tp;
	final boolean theExceptioIgnored;

	public ServerAction(TaskProcessor tp, Node aCurrentAction, int port, String request, String response, String encoding, long maxNumber) throws IOException {

		this.tp = tp;
		this.request = request;
		this.response = response;
		this.encoding = encoding;
		this.maxNumber = maxNumber;
		this.currentAction = aCurrentAction;

		theExceptioIgnored = AEUtils.isExceptionIgnore(tp, aCurrentAction);

		theServerSocket = tp.getListener().createPort(port, aCurrentAction.getAttribute("description"));
		theServerSocket.setSoTimeout(100);
	}

	public void perform() throws Exception {
		try {
			Map<String, Object> requestMap = new HashMap<String, Object>();
			for (int i = 0; (maxNumber == 0 || i < maxNumber) && tp.isStoppedTest() == false; i++) {
				try {
					if (tp.isStoppedTest()) {
						break;
					}

					tp.startCommandInformation(currentAction);
					try {
						tp.getListener().setProgress(WAITING_FOR_A_REQUEST, 1, 1, false);
						Socket socket = theServerSocket.accept();

						final InputStream theInputStream = socket.getInputStream();
						BufferedReader inputStream = new BufferedReader(new InputStreamReader(theInputStream));
						String readLine = inputStream.readLine();

						if (StringUtils.isEmpty(readLine)) {
							socket.close();
							continue;
						}

						requestMap.put("head", readLine);
						String method = StringUtils.substringBefore(readLine, " ");
						readLine = StringUtils.substringBetween(readLine, " ", " ");
						String uri = readLine;
						if (StringUtils.isEmpty(readLine)) {
							socket.close();
							continue;
						}

						List<NameValuePair> parse = new ArrayList<NameValuePair>();

						try {
							parse = URLEncodedUtils.parse(new URI(readLine), "UTF-8");
						} catch (Exception e) {
							socket.close();
							continue;
						}

						Properties query = new Properties();
						for (NameValuePair nameValuePair : parse) {
							String name = nameValuePair.getName();
							if (StringUtils.isNotBlank(name)) {
								Object property = query.get(name);
								List<String> values = null;
								String newValue = StringUtils.defaultIfEmpty(nameValuePair.getValue(), StringUtils.EMPTY);
								if (property == null) {
									query.put(name, newValue);
								} else {
									if (property instanceof String) {
										String value = (String) property;
										values = new ArrayList<String>();
										values.add(value);

									} else if (property instanceof List) {
										values = (List<String>) property;

									}
									values.add(newValue);
									query.put(name, values);
								}
							}
						}

						Properties header = new Properties();
						do {
							readLine = inputStream.readLine();
							String key = StringUtils.substringBefore(readLine, ":");
							String value = StringUtils.substringAfter(readLine, ": ");
							header.setProperty(key.toLowerCase(), value);

						} while (readLine.length() != 0);

						String contentLengthStr = header.getProperty(CONTENT_LENGTH);
						int contentLength = Integer.parseInt(StringUtils.defaultIfBlank(contentLengthStr, "-1").trim());

						ByteArrayOutputStream bodyStream = new ByteArrayOutputStream();
						if (contentLength > -1) {
							for (int j = 0; j < contentLength; j++) {
								bodyStream.write(inputStream.read());
							}
						} else if (StringUtils.equalsIgnoreCase(header.getProperty("transfer-encoding"), "chunked")) {
							int data = -1;
							int[] pdata = new int[4];
							while ((data = inputStream.read()) > 0) {
								pdata[0] = pdata[1];
								pdata[1] = pdata[2];
								pdata[2] = pdata[3];
								pdata[3] = data;

								if (pdata[0] == 13 && pdata[1] == 10 && pdata[2] == 13 && pdata[3] == 10) {
									bodyStream = escapeChunkLenght(bodyStream);
									break;
								}

								bodyStream.write(data);
							}
						} else {
							while (inputStream.ready()) {
								readLine = inputStream.readLine();
								if (readLine.length() > 0) {
									bodyStream.write(readLine.getBytes());
								} else {
									break;
								}
							}
						}

						String byteArray = null;
						if (StringUtils.indexOf(header.getProperty("Content-Type"), "text/xml") >= 0) {
							String xml = new String(bodyStream.toByteArray());
							byteArray = "<" + StringUtils.substringBeforeLast(StringUtils.substringAfter(xml, "<"), ">") + ">";
						} else {
							byteArray = new String(bodyStream.toByteArray());
						}

						requestMap.put("method", method);
						requestMap.put("params", query);
						requestMap.put("header", header);
						requestMap.put(BODY, byteArray);
						requestMap.put("query", uri);

						tp.setVariableValue(request, requestMap);
						tp.taskNode(currentAction);

						final OutputStream theOutputStream = socket.getOutputStream();
						Object responseObject = tp.getVariableValue(response);
						ByteArrayOutputStream output = new ByteArrayOutputStream();
						if (responseObject instanceof Map) {
							Map<String, Object> responseMap = new HashMap<String, Object>((Map<String, ?>) responseObject);
							responseObject = responseMap.get(BODY);
							responseMap.remove(BODY);

							output.write(("HTTP/1.1 " + StringUtils.defaultIfEmpty((String) responseMap.get(STATUS), "200 OK") + '\n').getBytes());
							responseMap.remove(STATUS);

							String ip = (String) responseMap.get(HOST);
							if (ip == null) {
								ip = socket.getLocalAddress().getHostName();
							}
							output.write(("Host: " + ip).getBytes());
							responseMap.remove(HOST);

							output.write(("User-Agent: " + StringUtils.defaultIfEmpty((String) responseMap.get(AGENT), "Anteater") + '\n').getBytes());
							responseMap.remove(AGENT);

							Set<Entry<String, Object>> entrySet = responseMap.entrySet();
							for (Entry<String, Object> entry : entrySet) {
								output.write((entry.getKey() + ": " + entry.getValue() + '\n').getBytes());
							}

							if (responseObject instanceof String) {
								responseObject = ((String) responseObject).getBytes(encoding);
							}

							if (!responseMap.containsKey(CONTENT_LENGTH)) {
								long length = ((byte[]) responseObject).length;
								output.write((CONTENT_LENGTH + ": " + length + '\n').getBytes());
							}

							output.write('\n');
						}

						if (responseObject instanceof String) {
							responseObject = ((String) responseObject).getBytes(encoding);
						}

						if (responseObject != null) {
							output.write((byte[]) responseObject);
						}
						theOutputStream.write(output.toByteArray());

						IOUtils.closeQuietly(theOutputStream);
						IOUtils.closeQuietly(theInputStream);

					} catch (final SocketTimeoutException e) {
						continue;
					} catch (final SocketException e) {
						continue;
					}

				} catch (final Exception e) {
					if (theExceptioIgnored == false) {
						throw e;
					}
				}
				tp.getListener().setProgress("", 1, 1, false);

			}
		} finally {
			theServerSocket.close();
		}
	}

	public static ByteArrayOutputStream escapeChunkLenght(ByteArrayOutputStream bodyStream) throws IOException {
		String text = bodyStream.toString();
		String[] lines = StringUtils.split(text, "\r\n");

		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		boolean skip_tl = false;
		for (String line : lines) {
			try {
				Integer.parseInt(line, 16);
				skip_tl = false;

			} catch (NumberFormatException e) {
				if (skip_tl) {
					byteArrayOutputStream.write(new byte[]{'\r', '\n'});
				} else {
					skip_tl = true;
				}
				byteArrayOutputStream.write(line.getBytes());
			}
		}
		return byteArrayOutputStream;
	}

}
