package com.nave.anteater.util.sql;

import javax.naming.NamingException;

import java.io.IOException;
import java.io.Reader;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Properties;

public class PLQuery extends BaseConnectionProvider {

	protected Statement fStatement = null;
	protected String fQueryLine;
	public static final String VARIABLE_OUT = "${VARIABLE_OUT}";

	public PLQuery(String connectionName) throws SQLException, NamingException {
		super(connectionName);
		setAutoCommit(false);
	}

	protected void execute(String aQuery) throws SQLException {
		super.startPoint();

		try {
			fStatement = connection().createStatement();
			fStatement.execute(aQuery);
		} finally {
			try {
				fStatement.close();
			} catch (Exception e) {
			}
			super.finishPoint();
		}
	}

	public void executeProcedure(String fFunctionName, Properties aParameters) throws SQLException {
		String theParametersLine = new String();
		if (aParameters != null)
			theParametersLine = getParametersLine(aParameters);
		fQueryLine = "begin " + fFunctionName + "(" + theParametersLine + "); end;";
		execute(fQueryLine);
	}

	private String getParametersLine(Properties aProperties) {
		StringBuffer theBuffer = new StringBuffer();
		int i = 0;

		Enumeration enumeration = aProperties.keys();
		while (enumeration.hasMoreElements()) {
			String theKey = (String) enumeration.nextElement();
			if (i++ > 0)
				theBuffer.append(',');
			theBuffer.append("");
			theBuffer.append(theKey);
			theBuffer.append("=>");
			theBuffer.append(aProperties.getProperty(theKey));
		}

		return theBuffer.toString();
	}

	public String getQueryLine() {
		return fQueryLine;
	}

	public ArrayList executeBlock(String aRunCode, ArrayList aVariables, int aOutputType) throws SQLException {

		ArrayList theArrayList = new ArrayList();
		aRunCode = aRunCode.replace('\r', ' ');

		ArrayList theOutVarId = new ArrayList();

		CallableStatement theCallableStatement = null;
		try {
			theCallableStatement = connection().prepareCall(aRunCode);
			for (int i = 0; i < aVariables.size(); i++) {
				Object theValue = aVariables.get(i);

				if (VARIABLE_OUT.equals(theValue) == false) {
					if (theValue == null) {
						theCallableStatement.setNull(i + 1, Types.VARCHAR);
					} else {
						if (theValue instanceof String) {
							theCallableStatement.setString(i + 1, (String) theValue);
						} else if (theValue instanceof byte[]) {
							theCallableStatement.setBytes(i + 1, (byte[]) theValue);
						}
					}
				} else {
					theCallableStatement.registerOutParameter(i + 1, aOutputType);
					theOutVarId.add(new Integer(i + 1));
				}
			}

			theCallableStatement.execute();

			for (int j = 0; j < theOutVarId.size(); j++) {
				int theIndex = ((Integer) theOutVarId.get(j)).intValue();

				if (aOutputType == Types.VARCHAR) {
					theArrayList.add(theCallableStatement.getString(theIndex));
				}

				if (aOutputType == Types.CLOB) {
					Clob theClob = theCallableStatement.getClob(theIndex);
					Reader theReader = theClob.getCharacterStream();
					StringBuffer theBuffer = new StringBuffer();

					int theChar = 0;
					try {
						while ((theChar = theReader.read()) >= 0) {
							theBuffer.append((char) theChar);
						}
					} catch (IOException e) {
						theBuffer.append(e.getMessage());
					}

					theArrayList.add(theBuffer.toString());
				}
			}

		} finally {
			if (theCallableStatement != null)
				theCallableStatement.close();
		}

		return theArrayList;
	}
}
