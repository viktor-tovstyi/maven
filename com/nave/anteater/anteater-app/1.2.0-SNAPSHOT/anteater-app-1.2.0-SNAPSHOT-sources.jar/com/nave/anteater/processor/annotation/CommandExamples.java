package com.nave.anteater.processor.annotation;

import java.lang.annotation.*;

@Retention(RetentionPolicy.RUNTIME)
public @interface CommandExamples {
	String[] value();
}
