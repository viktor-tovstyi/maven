package com.nave.anteater;

import org.apache.log4j.Logger;

public class TaskThread extends Thread {
	private static Logger log = Logger.getLogger(TaskThread.class);

	private TestRunner place;
	private String testFile;

	public TaskThread(TestRunner place, String testFile) {
		this.place = place;
		this.testFile = testFile;
	}

	public void run() {
		try {
			place.makeRecipe(testFile);
		} catch (Throwable e) {
			log.error("Task faled.", e);
		}
	}
}
