package com.nave.anteater;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.math.BigInteger;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import javax.swing.UIManager;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.map.LinkedMap;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.nave.anteater.processor.TaskProcessor;
import com.nave.anteater.util.AEUtils;
import com.nave.anteater.util.http.SoapWrapper;
import com.nave.anteater.util.sql.LocalDataSource;
import com.nave.anteater.util.xml.easyparser.EasyParser;
import com.nave.anteater.util.xml.easyparser.Node;

public class AEWorkspace implements AEManager {

	public static final String TESTDIR_VAR_NAME = "TESTDIR";

	private static Logger log = Logger.getLogger("Workspace");

	private static String fUser = System.getProperty("user.name");

	private static Map<String, SoapWrapper> fSoapWrapers = new HashMap<String, SoapWrapper>();

	private static Properties fUserPreferences;

	private static final int TEST_DIR_SIZE = 2024;

	private Node allConfigNode;

	private File[] fTestDirs;

	private Map<String, Object> fSystemVariables = new HashMap<String, Object>();

	private Node fConfigNode;

	private Properties fTestsDescList = new Properties();

	private List<String> fPriorityFolders = new ArrayList<String>();

	private List<String> soapNames = new ArrayList<String>();

	protected boolean defaultMode;

	private String fConfigurationName;

	private Set<TestRunner> runners = new HashSet<TestRunner>();

	private File baseDir;

	private static AEWorkspace instance;

	private Set<Class<?>> operationsClasses;

	private Map<String, OperationHolder> opsMethods = new HashMap<String, OperationHolder>();

	private String startDir = System.getProperty("user.dir");

	public AEWorkspace() {
		super();
		instance = this;
	}

	public String loadConfiguration(String confName, boolean refreshTaskPath) {
		getHomeConfigurationsDir().mkdirs();
		File homeConfiguration = new File(getHomeConfigurationsDir(), ConfigConstants.TESTCONFIG_XML);
		System.out.println("User home test configuration file: " + homeConfiguration.getAbsolutePath()
				+ (homeConfiguration.exists() ? " - found" : " - not found"));
		Node configNodes;
		try {
			configNodes = getConfiguration();
			return selectConfigurations(confName, configNodes, refreshTaskPath);

		} catch (TaskCancelingException e) {
			throw e;

		} catch (Exception e) {
			log.error("Configuration exception", e);
			throw new ConfigurationException("Configuration loading failed.", e);
		}

	}

	protected Node getConfiguration() throws IOException, ParseException {
		File theTestFile = getConfigurationFile();

		if (theTestFile == null || !theTestFile.exists()) {
			throw new ConfigurationException("Environments file (" + ConfigConstants.TESTCONFIG_XML
					+ ") must be defined in " + getHomeWorkingDir() + " or " + getStartDir() + ".");
		}
		this.baseDir = theTestFile.getParentFile();
		System.out.println("Active test configuration file: " + theTestFile.getAbsolutePath());

		return new EasyParser().getObject(theTestFile);
	}

	protected File getConfigurationFile() {
		File theTestFile;

		String theConfigurationFile = System.getProperty(ConfigConstants.TESTCONFIG_SYS_PRPERTY_NAME);
		if (theConfigurationFile == null) {
			theTestFile = new File(ConfigConstants.TESTCONFIG_XML);
			if (!theTestFile.exists()) {
				theTestFile = new File(getHomeWorkingDir(), ConfigConstants.TESTCONFIG_XML);
				if (!theTestFile.exists()) {
					theTestFile = new File(getStartDir(), ConfigConstants.TESTCONFIG_XML);
				}
			}
		} else {
			theTestFile = new File(theConfigurationFile);
		}
		return theTestFile;
	}

	protected File getHomeWorkingDir() {
		return new File(System.getProperty("user.home"), "anteater");
	}

	private void configuration() {
		if (fConfigNode != null) {

			Node[] theLogNodes = fConfigNode.getNodes("Logger");
			if (!ArrayUtils.isEmpty(theLogNodes)) {
				Node theLogNode = theLogNodes[0];
				runCommandLogger(theLogNode);
			}

			Node[] connections = fConfigNode.getNodes("Jdbc");
			for (Node connection : connections) {
				createDBConnection(connection, new HashMap<String, Object>());
			}
		}

		final String username = (String) fSystemVariables.get("HTTP_USERNAME");
		final String password = (String) fSystemVariables.get("HTTP_PASSWORD");
		if (username != null && password != null) {
			Authenticator.setDefault(new Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(username, password.toCharArray());
				}
			});
		}
	}

	public void createDBConnection(Node theDS, Map<String, Object> variables) {
		final String connection = theDS.getAttribute("name");
		Properties theProperties = new Properties();

		LinkedMap theDbProperties = theDS.getAttributes();
		@SuppressWarnings("unchecked")
		Set<String> keys = theDbProperties.keySet();
		for (String theKey : keys) {
			String property = (String) theDbProperties.get(theKey);

			Map<String, Object> vars = new HashMap<String, Object>();
			vars.putAll(variables);
			vars.putAll(fSystemVariables);

			String theValue = new TemplateProcessor(vars, fConfigNode, getStartDir()).replaceProperties(property);
			theProperties.setProperty(theKey, theValue);
		}

		LocalDataSource.setConnectionProperties(connection, theProperties);

	}

	public void runCommandLogger(Node aCurrentVar) {

		Properties theLogProperties = new Properties();
		if (aCurrentVar != null) {
			theLogProperties = MapUtils.toProperties(aCurrentVar.getAttributes());
		}
		Node[] theLoggerNodes = fConfigNode.getNodes("Logger");
		Node node = theLoggerNodes[0];
		boolean onsoleOn = false;
		if (theLoggerNodes != null && theLoggerNodes.length > 0) {
			node = theLoggerNodes[0];
			theLogProperties.putAll(node.getAttributes());
		}

		TemplateProcessor templateProcessor = new TemplateProcessor(fSystemVariables, fConfigNode, getStartDir());

		if (theLogProperties.getProperty("rootLogger") != null) {
			String rootLogger = templateProcessor.replaceProperties(theLogProperties.getProperty("rootLogger"));

			onsoleOn = rootLogger.indexOf("CONSOLE") >= 0;

			theLogProperties.setProperty("log4j.rootLogger", rootLogger);
			theLogProperties.remove("rootLogger");
		}
		if (theLogProperties.getProperty("File") != null) {
			String lofFileName = templateProcessor.replaceProperties(theLogProperties.getProperty("File"));
			File file = new File(lofFileName);
			if (file != null && file.getParentFile() != null && file.getParentFile().exists() == false)
				file.getParentFile().mkdirs();
			theLogProperties.setProperty("log4j.appender.LOGFILE.File", lofFileName);
		}
		if (theLogProperties.getProperty("Threshold") != null) {
			theLogProperties.setProperty("log4j.appender.LOGFILE.Threshold",
					templateProcessor.replaceProperties(theLogProperties.getProperty("Threshold")));
			if (onsoleOn)
				theLogProperties.setProperty("log4j.appender.CONSOLE.Threshold",
						templateProcessor.replaceProperties(theLogProperties.getProperty("Threshold")));
			theLogProperties.remove("Threshold");
		}
		if (theLogProperties.getProperty("ConversionPattern") != null) {
			theLogProperties.setProperty("log4j.appender.LOGFILE.layout.ConversionPattern",
					templateProcessor.replaceProperties(theLogProperties.getProperty("ConversionPattern")));
			if (onsoleOn)
				theLogProperties.setProperty("log4j.appender.CONSOLE.layout.ConversionPattern",
						templateProcessor.replaceProperties(theLogProperties.getProperty("ConversionPattern")));
			theLogProperties.remove("ConversionPattern");
		} else {
			theLogProperties.setProperty("log4j.appender.LOGFILE.layout.ConversionPattern",
					"%d{dd.MM.yyyy HH:mm:ss} %-5p %m %n");
			if (onsoleOn)
				theLogProperties.setProperty("log4j.appender.CONSOLE.layout.ConversionPattern",
						"%d{dd.MM.yyyy HH:mm:ss} %-5p %m %n");
		}
		theLogProperties.setProperty("log4j.appender.logfile.DatePattern", "'.'yyyy-MM-dd");
		theLogProperties.setProperty("log4j.appender.LOGFILE", "org.apache.log4j.DailyRollingFileAppender");
		if (onsoleOn)
			theLogProperties.setProperty("log4j.appender.CONSOLE", "org.apache.log4j.ConsoleAppender");
		theLogProperties.setProperty("log4j.appender.LOGFILE.layout", "org.apache.log4j.PatternLayout");
		if (onsoleOn)
			theLogProperties.setProperty("log4j.appender.CONSOLE.layout", "org.apache.log4j.PatternLayout");

		theLogProperties.setProperty("log4j.logger.org.springframework", "ERROR");
		MapUtils.debugPrint(System.out, "Logger properties", theLogProperties);
		PropertyConfigurator.configure(theLogProperties);
	}

	public void runSetupNodes() throws Exception {
		if (!Boolean.valueOf(System.getProperty("skip.startup"))) {
			Node[] theNodes = fConfigNode.getNodes(TaskProcessor.STARTUP);
			TemplateProcessor tp = new TemplateProcessor(fSystemVariables, fConfigNode, getStartDir());
			if (theNodes != null) {
				for (Node node : theNodes) {
					final String theAttribut = tp.replaceProperties(node.getAttribute("task"));
					boolean async = false;
					String asyncValue = tp.replaceProperties(node.getAttribute("async"));
					if (asyncValue != null) {
						async = Boolean.valueOf(asyncValue);
					}
					if (theAttribut != null) {
						runTask(theAttribut, async);
					} else {
						TestRunner taskEditor = createTestRunner(null);
						taskEditor.runTest(new Node[] { node });
					}
				}
			}
		}
		log.debug("Application started.");
	}

	protected SoapWrapper createSoapWrapper(Node aInitNode) throws AEException {
		try {
			String theName = aInitNode.getAttribute("name");
			aInitNode.getAttribute("host");
			String theClassName = aInitNode.getAttribute("class");

			log.info("Start initializing soap object. Name: '" + theName + "' Class: '" + theClassName + "'");
			Class<?> theClass = getClass().forName(theClassName);
			SoapWrapper theInstance = (SoapWrapper) theClass.newInstance();

			theInstance.init(MapUtils.toProperties(aInitNode.getAttributes()), log);

			fSoapWrapers.put(theName, theInstance);
			log.info("Soap object initialized.");
			return theInstance;
		} catch (Exception e) {
			throw new AEException(e, null);
		}
	}

	private void loadCustomProperties() {
		if (fUserPreferences == null) {
			fUserPreferences = new Properties();

			// loading users preferences
			try {
				FileInputStream fileInputStream = new FileInputStream(getPreferencesFile());
				fUserPreferences.load(fileInputStream);
				fileInputStream.close();

			} catch (IOException e) {
				System.out.println("User preferences configuration file is not found: " + getPreferencesFile());

			}
		}
	}

	protected File getPreferencesFile() {
		return new File(getHomeWorkingDir(), fUser + ".properties");
	}

	public String taskFileNameConflict(String aKey, String aCurrentFile, String aNewFile) {
		StringBuffer theStringBuffer = new StringBuffer();

		theStringBuffer.append("<html><body>");
		theStringBuffer.append("Duplication file for task with name: '" + aKey + "'<br>");
		theStringBuffer.append("Registration file: '" + aCurrentFile + "'<br>");
		theStringBuffer.append("Conflict file: '" + aNewFile + "'<br>");
		theStringBuffer.append("<br>");
		theStringBuffer.append("Please select priority folder:<br>");
		theStringBuffer.append("</body></html>");

		String theFirstFile = new File(aNewFile).getParent();
		String theSecondFile = new File(aCurrentFile).getParent();

		StringBuffer theMessageBuffer = new StringBuffer();
		theMessageBuffer.append("Duplication file for task with name: '" + aKey + "' ");

		String thePriorityFolder = null;
		if (fPriorityFolders.contains(theFirstFile)) {
			thePriorityFolder = theFirstFile;
			theMessageBuffer.append("presetting selection file: " + aNewFile);
		} else if (fPriorityFolders.contains(theSecondFile)) {
			thePriorityFolder = theSecondFile;
			theMessageBuffer.append("presetting selection file: " + aCurrentFile);
		} else {
			thePriorityFolder = choicePriorityRecipeFolder(theStringBuffer.toString(),
					new String[] { aCurrentFile, aNewFile });
			theMessageBuffer.append("manual selection priority folder: " + thePriorityFolder);
		}

		fPriorityFolders.add(new File(thePriorityFolder).getParent());

		if (thePriorityFolder == null) {
			StringBuffer fBuffer = new StringBuffer();
			fBuffer.append("Duplication file for task with name: '" + aKey + "': ");
			fBuffer.append("Registration file: '" + aCurrentFile + "', ");
			fBuffer.append("Conflict file: '" + aNewFile + "'");
			// log.warn(fBuffer.toString());
			throw new ConfigurationException(fBuffer.toString());
		}

		if (theSecondFile != null && theSecondFile.equals(thePriorityFolder))
			aNewFile = aCurrentFile;

		log.warn(theMessageBuffer.toString());
		return aNewFile;
	}

	protected String choicePriorityRecipeFolder(String text, String[] possibleValues) {
		return possibleValues[0];
	}

	public File[] getTestDirs() {
		return fTestDirs;
	}

	private Properties loadCashedTaskList(File theConfFile) throws IOException {

		Properties theTestsDescList = null;

		if (theConfFile.exists()) {
			FileInputStream theFile = new FileInputStream(theConfFile);
			theTestsDescList = new Properties();
			theTestsDescList.load(theFile);

			theFile.close();
		}

		return theTestsDescList;
	}

	protected String getCustomConfPropFileName(String configurationName) {
		return getHomeConfigurationsDir() + "/" + fUser + "." + configurationName + ".properties";
	}

	protected File getHomeConfigurationsDir() {
		File file = new File(getHomeWorkingDir(), "configuration");
		return file;
	}

	private static String getDigest(String s) {
		try {
			MessageDigest theDigest = MessageDigest.getInstance("MD5");
			ByteArrayInputStream theStream = new ByteArrayInputStream(s.getBytes());
			DigestInputStream theDigestInputStream = new DigestInputStream(theStream, theDigest);
			try {
				while (theDigestInputStream.read(new byte[TEST_DIR_SIZE], 0, TEST_DIR_SIZE) > 0)
					;
			} catch (IOException e) {
				log.error("Configuration loading failed.", e);
			}
			MessageDigest theMessageDigest = theDigestInputStream.getMessageDigest();
			return new BigInteger(theMessageDigest.digest()).abs().toString(32).toUpperCase();

		} catch (NoSuchAlgorithmException e) {
			throw new IllegalArgumentException(e);
		}
	}

	public File getTaskListCashFile() {
		String string = (String) fSystemVariables.get(TESTDIR_VAR_NAME);
		String digest_path = getDigest(string + getStartDir());
		File theConfFile = new File(getHomeConfigurationsDir(), digest_path + ".tasks");
		return theConfFile;
	}

	protected String[] testDirPreparing(String theTestDir) {
		StringTokenizer theTestDirTokenizer = new StringTokenizer(theTestDir, ";");
		String[] theTestDirs = new String[theTestDirTokenizer.countTokens()];
		int i = 0;
		while (theTestDirTokenizer.hasMoreTokens()) {
			theTestDirs[i] = theTestDirTokenizer.nextToken();
			i++;
		}
		return theTestDirs;
	}

	public void refreshTaskPath() throws IOException {
		File theConfFile = getTaskListCashFile();
		if (theConfFile.exists()) {
			theConfFile.delete();
		}

		loadTaskPath();
	}

	public void loadTaskPath() throws IOException {

		File theConfFile = getTaskListCashFile();
		Properties theTestList = loadCashedTaskList(theConfFile);

		if (theTestList != null) {
			Collection<Object> values = theTestList.values();
			for (Object recipeFilePath : values) {
				if (!new File((String) recipeFilePath).exists()) {
					theTestList = null;
					break;
				}
			}
		}

		String theTestDir = (String) fSystemVariables.get(TESTDIR_VAR_NAME);
		String[] theTestDirs = testDirPreparing(theTestDir);
		List<File> testDirsList = new ArrayList<File>();

		for (int i = 0; i < theTestDirs.length; i++) {
			testDirsList.add(getFile(baseDir, theTestDirs[i]));
		}

		for (int i = 0; i < theTestDirs.length; i++) {
			testDirsList.add(getFile(getStartDir(), theTestDirs[i]));
		}

		fTestDirs = new File[testDirsList.size()];
		for (int i = 0; i < testDirsList.size(); i++) {
			fTestDirs[i] = testDirsList.get(i);
		}

		if (theTestList == null) {
			fTestsDescList.clear();

			for (File file : fTestDirs) {
				scanRecipeSource(file);
			}

			if (theConfFile.getParentFile().exists() == false) {
				theConfFile.getParentFile().mkdirs();
			}

			FileOutputStream fileOutputStream = new FileOutputStream(theConfFile);
			fTestsDescList.store(fileOutputStream, theTestDir);
			fileOutputStream.close();

		} else {
			fTestsDescList = theTestList;
		}

	}

	public void scanRecipeSource(File aDir) throws IOException {
		Properties aTestsDescList = new Properties();
		scanRecipeDir(aDir, aTestsDescList);
		fTestsDescList.putAll(aTestsDescList);
	}

	private void scanTasksJar(File dir, Properties testsDescList) throws IOException {

		JarFile jarFile = new JarFile(dir);

		Enumeration<?> jents = jarFile.entries();
		while (jents.hasMoreElements()) {
			JarEntry entry = (JarEntry) jents.nextElement();
			if (entry.isDirectory() == false) {
				regTestURL(new URL("jar:file:" + dir.getAbsolutePath() + "!/" + entry.getName()), testsDescList);
			}
		}
	}

	private Properties scanTasksDir(File aDir, Properties aTestsDescList) throws IOException {
		File[] theFiles = aDir.listFiles();

		if (theFiles == null) {
			return aTestsDescList;
		}

		for (int i = 0; i < theFiles.length; i++) {

			File file = theFiles[i];

			if (file.isDirectory()) {
				scanRecipeDir(file, aTestsDescList);

			} else {
				regTestFile(file, aTestsDescList);
			}

			progressValue(i, theFiles.length, true);
		}
		progressValue(0, 0, true);

		return aTestsDescList;
	}

	private void scanRecipeDir(File aDir, Properties aTestsDescList) throws IOException {
		if (aDir.isDirectory()) {
			scanTasksDir(aDir, aTestsDescList);

		} else if (aDir.isFile()) {
			scanTasksJar(aDir, aTestsDescList);
		} else {
			// throw new FileNotFoundException(aDir.getAbsolutePath());
		}
	}

	public void progressValue(int i, int length, boolean success) {

	}

	private void regTestFile(File file, Properties aTestsDescList) {
		String name = file.getName();
		progressText(file.getName());

		if (name.toLowerCase().endsWith(".recipe")) {

			Node theNode = null;
			try {
				theNode = new EasyParser().getObject(file);
			} catch (Exception e) {
				theNode = null;
			}

			if (theNode == null || "Recipe".equals(theNode.getTag()) == false) {
				return;
			}

			String theKey = theNode.getAttribute("name");
			if (theKey == null || theKey.trim().length() == 0) {
				theKey = theNode.getAttribute("description");
			}
			if (theKey == null || theKey.trim().length() == 0) {
				theKey = file.getPath();
			}
			String theCurrentFile = aTestsDescList.getProperty(theKey);
			String predefinedFile = fTestsDescList.getProperty(theKey);
			if (predefinedFile == null) {
				if (theCurrentFile != null && theCurrentFile.equals(file.getAbsolutePath()) == false) {
					String conflictFile = file.getAbsolutePath();
					theCurrentFile = taskFileNameConflict(theKey, theCurrentFile, conflictFile);
				} else {
					theCurrentFile = file.getAbsolutePath();
				}
			} else {
				theCurrentFile = predefinedFile;
			}
			aTestsDescList.setProperty(theKey, theCurrentFile);
		}
		progressText("");
	}

	public void progressText(String name) {

	}

	private void regTestURL(URL url, Properties aTestsDescList) {
		String name = url.toString();
		progressText(url.toString());

		if (name.toLowerCase().endsWith(".recipe")) {

			Node theNode = null;
			try {
				theNode = new EasyParser().getObject(url.openStream());

				if (!"Recipe".equals(theNode.getTag())) {
					return;
				}

				String theKey = theNode.getAttribute("name");
				if (theKey.trim().length() == 0) {
					theKey = theNode.getAttribute("description");
				}
				if (theKey.trim().length() == 0) {
					theKey = url.toString();
				}

				String theCurrentFile = aTestsDescList.getProperty(theKey);
				if (theCurrentFile != null && theCurrentFile.equals(url.toString()) == false) {
					theCurrentFile = taskFileNameConflict(theKey, theCurrentFile, url.toString());
				} else {
					theCurrentFile = url.toString();
				}
				aTestsDescList.setProperty(theKey, theCurrentFile);

			} catch (Exception e) {

			}

		}
		progressText("");
	}

	public File getFile(File aParentDir, String aThePathAttribut) {
		File theFile = null;
		if (aThePathAttribut != null) {
			if (aThePathAttribut.startsWith("jar:") || aThePathAttribut.startsWith("file:")
					|| '/' == aThePathAttribut.charAt(0) || '\\' == aThePathAttribut.charAt(0)
					|| aThePathAttribut.indexOf(":\\") > 0 || '/' == aThePathAttribut.charAt(0)) {
				theFile = new File(aThePathAttribut);
			} else {
				theFile = new File(aParentDir, aThePathAttribut);
			}
		}
		return theFile;
	}

	public String inputValue(String aDesc, String aName, String aValue, Logger log, String type) {
		return aValue;
	}

	public void inputDataTable(TemplateProcessor unit, Node aTableNode, Map<String, Object> aVariables,
			TaskProcessor taskProcessor) throws IOException {
		Node[] theVariablesNodes = aTableNode.getNodes("var");
		String theLine = null;

		String theFileAttribut = aTableNode.getAttribute("file");
		if (unit != null)
			theFileAttribut = unit.replaceProperties(aTableNode.getAttribute("file"));

		if (theFileAttribut != null) {
			File file = unit.getFile(theFileAttribut);
			if (file.exists()) {
				BufferedReader theFileReader = new BufferedReader(new FileReader(file));
				while ((theLine = theFileReader.readLine()) != null) {
					theLine = theLine.trim();
					if (theLine.length() == 0) {
						continue;
					}
					if (theLine.charAt(0) == '#') {
						continue;
					}
					int thePbrk = theLine.indexOf('=');

					String theName = StringUtils.upperCase(theLine.substring(0, thePbrk));
					String theValue = theLine.substring(thePbrk + 1);

					Node theNode = new Node("var");
					theNode.setAttribute("name", theName);
					theNode.setAttribute("value", theValue);

					for (Node node : theVariablesNodes) {
						if (node.getAttribute("name").equalsIgnoreCase(theName)) {
							node.setAttribute("value", theValue);
						}
					}

				}
				theFileReader.close();
			}
		}

	}

	protected void loadConfProperties(Properties theConfProp) {

		fSystemVariables.put("ENV", System.getenv());
		fSystemVariables.put("SYSTEM", System.getProperties());
		Node[] theVarConfs = fConfigNode.getNodes("Var");
		for (int i = 0; i < theVarConfs.length; i++) {
			Node theVarNode = theVarConfs[i];
			String theName = StringUtils.upperCase(theVarNode.getAttribute("name"));

			String attribute = theVarNode.getAttribute("init");
			String type = theVarNode.getAttribute("type");

			Object theValue;
			String typeValue = StringUtils.defaultIfBlank(type, "string");
			switch (typeValue) {
			case "array":
				Node[] nodes = theVarNode.getNodes("item");
				theValue = new ArrayList<String>();
				for (Node node : nodes) {
					String text = node.getInnerText();
					((List) theValue).add(text);
				}
				break;
			case "map":
				nodes = theVarNode.getNodes("item");
				theValue = new LinkedHashMap<String, String>();
				for (Node node : nodes) {
					((Map) theValue).put(node.getAttribute("key"), node.getInnerText());
				}
				break;

			default:
				theValue = theVarNode.getAttribute("value");
				break;
			}

			if ("mandatory".equals(attribute) && theConfProp.getProperty(theName) == null) {
				attribute = "console";
			}

			if ("console".equals(attribute)) {
				theValue = inputValue("Please input configuration parametr: ", theName, ObjectUtils.toString(theValue),
						log, type);

				switch (StringUtils.defaultIfBlank(type, "string")) {
				case "array":
					break;
				case "map":
					theValue = AEUtils.convertStringToMap((String) theValue);
					break;

				default:
					break;
				}
			}

			if (theValue != null)
				fSystemVariables.put(StringUtils.upperCase(theName), theValue);
			else
				fSystemVariables.remove(theName);

			String savedValue = (String) theConfProp.get(theName);
			Object value = null;
			if (savedValue != null) {
				switch (StringUtils.defaultIfBlank(type, "string")) {
				case "array":
					List<String> list = (List<String>) theValue;
					list.remove(savedValue);

					value = new ArrayList();
					((List) value).add(savedValue);
					((List) value).addAll(list);
					break;
				case "map":
					value = AEUtils.convertStringToMap(savedValue);
					break;

				default:
					value = savedValue;
					break;
				}

				fSystemVariables.put(StringUtils.upperCase(theName), value);
			}

		}

	}

	public String selectConfigurations(String confName, Node configNodes, boolean refreshTaskPath)
			throws IOException, AEException {

		allConfigNode = configNodes;

		String configurationName = System.getProperty(ConfigConstants.CONFIG_NAME_SYS_PRPERTY_NAME);
		if (confName != null) {
			configurationName = confName;
		}

		fConfigNode = getCurrentConfig(allConfigNode, configurationName);

		if (fConfigNode == null) {
			System.out.println("Configuration '" + configurationName + "' not found in testconfig.xml file.");
			return configurationName;

		} else {
			if (configurationName == null) {
				configurationName = fConfigNode.getAttribute("name");
				if (configurationName == null)
					configurationName = fConfigNode.getAttribute("description");
			}

			fSystemVariables.clear();
			fSystemVariables.put("USER_NAME", fUser);

			Properties theConfProp = new Properties();
			File theConfFile = new File(getCustomConfPropFileName(configurationName));
			if (theConfFile.exists()) {
				FileInputStream theFile = new FileInputStream(theConfFile);
				theConfProp.load(theFile);
				theFile.close();
			}

			loadConfProperties(theConfProp);

			Node[] theTableVarConfs = fConfigNode.getNodes("Table");
			TaskProcessor unit = new TaskProcessor(this, log, getStartDir());
			for (int i = 0; i < theTableVarConfs.length; i++) {
				inputDataTable(unit, theTableVarConfs[i], fSystemVariables, unit);
			}

			fSystemVariables.put("WORKINGDIR", getStartDir().getAbsolutePath());

			fSystemVariables.put("HOME_WORKINGDIR", getHomeWorkingDir().getAbsolutePath());
			fSystemVariables.put("START_TIME", Long.toString(System.currentTimeMillis()));

			Node[] includeNodes = fConfigNode.getNodes("Include");

			String testDirs = (String) fSystemVariables.get(TESTDIR_VAR_NAME);
			StringBuffer paths = new StringBuffer(StringUtils.defaultIfEmpty(testDirs, StringUtils.EMPTY));

			for (Node node : includeNodes) {
				paths.append(";");
				paths.append(node.getAttribute("path"));
			}
			fSystemVariables.put(TESTDIR_VAR_NAME, paths.toString());

			if (refreshTaskPath) {
				refreshTaskPath();
			} else {
				loadTaskPath();
			}

			Node[] theLocations = fConfigNode.getNodes("Locale");
			if (theLocations != null && theLocations.length > 0) {
				Node theLocation = theLocations[0];
				String theISO3Language = theLocation.getAttribute("ISO3Language");
				String theDisplayName = theLocation.getAttribute("DisplayName");
				Locale[] availableLocales = Locale.getAvailableLocales();

				boolean theFound = false;
				for (int l = 0; l < availableLocales.length; l++) {
					if (availableLocales[l].getISO3Language().equals(theISO3Language)) {
						Locale.setDefault(availableLocales[l]);
						System.out.println("Set location ISO3Language: " + theISO3Language);
						theFound = true;
						break;
					}
					if (availableLocales[l].getDisplayName().equals(theDisplayName)) {
						Locale.setDefault(availableLocales[l]);
						System.out.println("Set location DisplayName: " + theDisplayName);
						theFound = true;
						break;
					}
				}

				if (theFound == false) {
					for (int j = 0; j < availableLocales.length; j++) {
						System.out.println(j + ". " + availableLocales[j].getDisplayName());
					}
				}
			}

			Node[] theSoapNodes = fConfigNode.getNodes("Soap");
			soapNames.clear();
			for (int i = 0; i < theSoapNodes.length; i++) {
				soapNames.add(theSoapNodes[i].getAttribute("name"));

				if (theSoapNodes[i].getAttribute("class") != null) {
					SoapWrapper theInstance = getSoapWrapper(theSoapNodes[i].getAttribute("name"));
					if (theInstance == null)
						createSoapWrapper(theSoapNodes[i]);
				}
			}

			configuration();

			fConfigurationName = fConfigNode.getAttribute("name");
			return fConfigurationName;
		}

	}

	public SoapWrapper getSoapWrapper(String aClassName) {
		return fSoapWrapers.get(aClassName);
	}

	public void setDefaultUserConfiguration(String propertyName, String value) {

		propertyName = getFullConfPropertyName(propertyName);

		if (value != null) {
			fUserPreferences.setProperty(propertyName, value);
		} else {
			if (fUserPreferences.get(propertyName) != null) {
				fUserPreferences.remove(propertyName);
			}
		}

		if (value != null)
			try {
				FileOutputStream fileInputStream = new FileOutputStream(getPreferencesFile());
				String theComment = "\n#";

				fUserPreferences.store(fileInputStream, theComment);
				fileInputStream.close();

			} catch (IOException e) {
				System.out.println("Write default user setting is failed. Error: " + e.getMessage());
			}
	}

	private String getFullConfPropertyName(String propertyName) {
		if (StringUtils.isNotBlank(getConfigurationName())) {
			propertyName = getConfigurationName() + "@" + propertyName;
		}
		return propertyName;
	}

	public String getDefaultUserConfiguration(String aName, String theDefaultConfiguration) {
		aName = getFullConfPropertyName(aName);

		loadCustomProperties();
		String theProperty = fUserPreferences.getProperty(aName);
		if (theProperty != null)
			theDefaultConfiguration = theProperty;

		return theDefaultConfiguration;
	}

	public Node getCurrentConfig(Node aAllConfig, String aNameConfiguration) {
		Node[] theConfigs = aAllConfig.getNodes("Configuration");

		ArrayList<String> possibleValues = new ArrayList<String>();

		for (int i = 0; i < theConfigs.length; i++) {
			String theName = theConfigs[i].getAttribute("name");
			if (possibleValues.contains(theName))
				throw new IllegalArgumentException("Duplication name configuration: " + theName);
			if (theName.startsWith("#") == false)
				possibleValues.add(theName);
		}

		if (CollectionUtils.isNotEmpty(possibleValues)) {
			String theValue = possibleValues.get(0);
			if (aNameConfiguration != null) {
				theValue = aNameConfiguration;
			}

			if (possibleValues.size() > 1 && aNameConfiguration == null) {
				theValue = selectConfiguration(possibleValues.toArray(new String[possibleValues.size()]));
			}

			Node theConfigNode = prepareConfigurationNode(aAllConfig, theValue);
			return theConfigNode;
		}

		return null;
	}

	private Node prepareConfigurationNode(Node aAllConfig, String aConfigName) {

		Node theConfigNode = aAllConfig.findNode("Configuration", "name", aConfigName);
		Node theBaseNode = null;

		if (theConfigNode != null) {
			String theBaseConfig = theConfigNode.getAttribute("base");

			if (theBaseConfig != null && theConfigNode != null) {
				theBaseNode = prepareConfigurationNode(aAllConfig, theBaseConfig);

				if (theBaseNode != null) {
					theBaseNode.setAttributes(theConfigNode.getAttributes());

					for (Iterator<Node> theIterator = theConfigNode.iterator(); theIterator.hasNext();) {
						Node theNode = theIterator.next();

						String theTagName = theNode.getTag();
						Node[] theNodeArray = theBaseNode.getNodes(theTagName);

						if (theNodeArray.length > 1) {
							String theName = theNode.getAttribute("name");

							Node theBaseTag = theBaseNode.findNode(theTagName, "name", theName);

							if (theBaseTag != null) {
								System.out.println(
										"Change node: " + theTagName + " name=" + theName + " Value: " + theNode);
								int indexOf = theBaseNode.indexOf(theBaseTag);
								Node object = theBaseNode.get(indexOf);
								if (object.getTag() == theTagName)
									theBaseNode.remove(indexOf);
							}
						}
						theBaseNode.add(theNode);
					}

				} else {
					System.out.println("Base configuration is not found. Name: " + aConfigName);
					theBaseNode = theConfigNode;
				}
			} else
				theBaseNode = theConfigNode;

		} else
			theBaseNode = theConfigNode;

		return theBaseNode;
	}

	public File getStartDir() {
		return new File(startDir);
	}

	public String inputSelectChoice(String aNameDialog, String[] aValues, String aDefaultValue,
			TaskProcessor taskProcessor) {
		if (aDefaultValue == null && aValues.length > 0) {
			String value = getDefaultUserConfiguration(".choice." + aNameDialog, aValues[0]);
			if (value != null) {
				aDefaultValue = value;
			}
		}
		return aDefaultValue;
	}

	public String inputFile(String name, File aDefaultFile, Logger log, TaskProcessor taskProcessor) {
		String theResult = getDefaultUserConfiguration(".inputFile",
				aDefaultFile == null ? null : aDefaultFile.getAbsolutePath());
		return theResult;
	}

	public void message(String text) {
		progressText(text);
	}

	protected String selectConfiguration(String[] aPossibleValues) {

		String theDefaultConfiguration = getDefaultUserConfiguration(".defaultConfiguration", null);
		setDefaultUserConfiguration(".defaultConfiguration", theDefaultConfiguration);

		if (aPossibleValues.length > 1) {
			System.out.println("Select configuration:");
			for (int i = 0; i < aPossibleValues.length; i++) {
				System.out.println((i + 1) + " - " + aPossibleValues[i]);
			}
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			System.out.print(">");
			String readLine;
			try {
				readLine = in.readLine();
				int i = Integer.parseInt(readLine) - 1;
				theDefaultConfiguration = aPossibleValues[i];

			} catch (IOException e) {
				log.error("Configuration loading failed.", e);
			}
		}

		return theDefaultConfiguration;
	}

	public String getTestPath(String name) {
		String property = null;
		if (name != null) {
			property = fTestsDescList.getProperty(name);
		}
		if (property == null) {
			StringBuilder report = new StringBuilder();
			Set<Entry<Object, Object>> entrySet = fTestsDescList.entrySet();
			for (Entry<Object, Object> entry : entrySet) {
				report.append("\n\t" + entry.getKey() + " =" + entry.getValue());
			}
			log.info("Recipe not found: " + name + report);
		}
		return property;
	}

	public TestRunner runTask(String name, boolean async) {
		TestRunner runner = null;
		if (name != null) {
			try {
				runner = createTestRunner(name);
				if (async) {
					String testPath = getTestPath(name);
					TaskThread theThread = new TaskThread(runner, testPath);
					theThread.start();

				} else {
					String testPath = getTestPath(name);
					runner.makeRecipe(testPath);
				}

			} catch (Throwable e) {
				log.error("Task failed.", e);
			}
		}

		return runner;
	}

	protected TestRunner createTestRunner(String name) {
		TestRunner runner = new TestRunner(this);
		TaskProcessor processor = new TaskProcessor(this, log, getStartDir());
		processor.setMaxTestListener(runner);
		runner.setProcessor(processor);
		runner.setLog(Logger.getLogger(StringUtils.defaultString(name, TaskProcessor.STARTUP)));
		return runner;
	}

	public void getRemoveTestPath(String name) {
		if (fTestsDescList.get(name) != null)
			fTestsDescList.remove(name);
	}

	public void setTestPath(String name, String path) {
		fTestsDescList.put(name, path);
	}

	public Object[] getSoapNamesList() {
		return soapNames.toArray();
	}

	public Object[] getTestsList() {
		return fTestsDescList.keySet().toArray();
	}

	public String getWorkingDir() {
		return getStartDir().getAbsolutePath();
	}

	public MultiTaskRunDialog tasksChoice(MultiTaskRunDialog dialog, String[] list, boolean exceptionIgnoreFlag,
			Object setup, TaskProcessor taskProcessor) {

		if (setup != null) {
			boolean consoleDefaultInput = isConsoleDefaultInput(dialog.getName());
			if (setup instanceof String[])
				dialog.select((String[]) setup, consoleDefaultInput);
			else if (setup instanceof String) {
				String[] attribute = new String[] { (String) setup };
				dialog.select(attribute, consoleDefaultInput);
			}
		}

		dialog.setExceptionIgnore(exceptionIgnoreFlag);
		dialog.showDialog(dialog.getName(), list);
		return dialog;
	}

	public Map<String, Object> getSystemVariables() {
		return fSystemVariables;
	}

	public void setConsoleDefaultInput(boolean defaultMode) {
		this.defaultMode = defaultMode;
	}

	public boolean isConsoleDefaultInput(String varName) {
		return defaultMode;
	}

	public Node getConfigNode() {
		return fConfigNode;
	}

	public Node getAllConfigNode() {
		return allConfigNode;
	}

	public Properties getTasksMap() {
		return fTestsDescList;
	}

	public List<String> getPriorityFolders() {
		return fPriorityFolders;
	}

	public Properties getTestsDescList() {
		return fTestsDescList;
	}

	public Object[] getPublicTestsList() {
		Enumeration<Object> keys = fTestsDescList.keys();
		List<String> result = new ArrayList<String>();
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			if (!key.startsWith("#")) {
				result.add(key);
			}
		}
		String[] a = result.toArray(new String[result.size()]);
		Arrays.sort(a);
		return a;
	}

	public void startTaskNotify(TestRunner task) {

	}

	public String choiceValue(String s, String name, Object[] aPossibleValues, Logger log) {
		String thePossibleValue = null;
		if (aPossibleValues != null && aPossibleValues.length > 0)
			thePossibleValue = (String) aPossibleValues[0];

		thePossibleValue = getDefaultUserConfiguration(".choiceValue." + name, thePossibleValue);
		return thePossibleValue;
	}

	public static AEWorkspace getInstance() {
		return instance;
	}

	public void resetConfiguration() {
		fConfigNode = null;
	}

	public String getConfigurationName() {
		return this.fConfigurationName;
	}

	public void loadConfiguration(boolean refreshTaskMap) {
		loadConfiguration(null, refreshTaskMap);
	}

	public void addRunner(TestRunner testRunner) {
		runners.add(testRunner);
	}

	public void removeRunner(TestRunner testRunner) {
		runners.remove(testRunner);
	}

	public void stopAllRunners() {
		for (TestRunner runner : runners) {
			runner.stopTest();
		}
	}

	public void setBaseDir(File baseDir) {
		this.baseDir = baseDir;
	}

	public Set<Class<?>> getOperationsClasses() {
		return operationsClasses;
	}

	public void setOperationsClasses(Set<Class> operationsClasses) {
		opsMethods = new HashMap<String, OperationHolder>();
		try {
			Method[] methods = Object.class.getMethods();
			String exclude[] = new String[methods.length];
			for (int i = 0; i < exclude.length; i++) {
				exclude[i] = methods[i].getName();
			}
			Arrays.sort(exclude);

			for (Class<?> operationClass : operationsClasses) {
				methods = operationClass.getMethods();
				for (Method method : methods) {
					if (Arrays.binarySearch(exclude, method.getName()) < 0
							&& method.getModifiers() == Modifier.PUBLIC) {
						String shortClassName = operationClass.getName();
						opsMethods.put(shortClassName + "." + method.getName(),
								new OperationHolder(operationClass, method));
					}
				}
			}
		} catch (Exception e) {
			throw new IllegalArgumentException(e);
		}
	}

	public OperationHolder getOperationsMethod(String name) {
		return opsMethods.get(name);
	}

	public Map<String, OperationHolder> getOperationsMethods() {
		return opsMethods;
	}

	public Set<TestRunner> getRunners() {
		return runners;
	}

	@Override
	public void finished(String aTestFile) {
	}

	public void setStartDir(File startDir) {
		this.startDir = startDir.getAbsolutePath();
	}

	public static Properties getUserPreferences() {
		return fUserPreferences;
	}

}
