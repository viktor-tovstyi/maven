package com.nave.anteater;

import com.nave.anteater.processor.TaskProcessor;

public class AEException extends CommandException {

	private static final long serialVersionUID = 1L;
	private TaskProcessor processor = null;

	public AEException(Throwable e, TaskProcessor processor) {
		super(e, processor);
		this.processor = processor;
	}

	public TaskProcessor getProcessor() {
		return processor;
	}
}