package com.nave.anteater;

import java.io.File;

public class JarClassLoader extends MultiClassLoader {
  private JarResources jarResources;

  public JarClassLoader(File jarName) {
    jarResources = new JarResources(jarName);
  }

  protected byte[] loadClassBytes(String className) {
    className = formatClassName(className);
    byte[] bs = (jarResources.getResource(className));
    return bs;
  }
}