package com.nave.anteater.util.xml.easyparser;

public class EasyUtils 
{
    public static void removeAllAttributes(Node aNode, String aAttrName)
    {
       aNode.getAttributes().remove(aAttrName);
       for(int i=0; i<aNode.size(); i++) removeAllAttributes( aNode.getNode(i), aAttrName);
    }

	public static void removeTagId(Node theNode) {
		EasyUtils.removeAllAttributes(theNode, Node.TAG_ID);
	}
}