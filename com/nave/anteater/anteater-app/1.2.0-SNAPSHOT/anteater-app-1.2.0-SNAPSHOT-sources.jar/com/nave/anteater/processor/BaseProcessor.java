package com.nave.anteater.processor;

public class BaseProcessor extends TaskProcessor {

	public BaseProcessor(TaskProcessor aParent) {
		super(aParent);
	}

}
