package com.nave.anteater.util.xml.easyparser;

import java.util.StringTokenizer;

public class NodeMapper extends Node {

    public NodeMapper(String aBaseTagName) {
        super(aBaseTagName);
    }

    public void setAttribute(String aPath, String aAttributName, String aValue) {

        StringTokenizer theStringTokenizer = new StringTokenizer(aPath, "/");

        Node theCurrentNode = this;
        Node[] theResult = null;

        while (theStringTokenizer.hasMoreTokens()) {
            String theCurrentTagName = theStringTokenizer.nextToken();

            theResult = theCurrentNode.getNodes(theCurrentTagName);

            if (theResult == null || theResult.length == 0 || theResult[0] == null) {
                Node theNewNode = new Node(theCurrentTagName);
                theCurrentNode.addInnerTag(theNewNode);
                theCurrentNode = theNewNode;
            } else {
                theCurrentNode = theResult[0];
            }
        }

        theCurrentNode.setAttribute(aAttributName, aValue);
    }

}
