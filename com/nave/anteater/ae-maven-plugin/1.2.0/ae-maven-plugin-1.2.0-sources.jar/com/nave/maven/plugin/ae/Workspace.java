package com.nave.maven.plugin.ae;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;

import com.nave.anteater.AEWorkspace;
import com.nave.anteater.ConfigConstants;
import com.nave.anteater.util.xml.easyparser.Node;

public class Workspace extends AEWorkspace {

	private File aeDir;
	private Node configNode;

	public Workspace(File aeDir) {
		this.aeDir = aeDir;
	}

	@Override
	public Node getConfigNode() {
		return new Node("Environment");
	}

	@Override
	protected File getConfigurationFile() {
		return new File(aeDir, ConfigConstants.TAKE_IT_EASY_MODE);
	}

	@Override
	protected File getHomeConfigurationsDir() {
		return new File(getHomeWorkingDir(), "configuration");
	}

	@Override
	protected Node getConfiguration() throws IOException, ParseException {
		Node configs = new Node("Environment");
		Node config = new Node("Configuration");
		config.setAttribute("name", "ENV");
		setVar(config, AEWorkspace.TESTDIR_VAR_NAME, aeDir.getAbsolutePath());
		setVar(config, "ENV_CONFIG", System.getenv("ENV_CONFIG"));

		if (configNode != null) {
			for (Node node : configNode) {
				config.add(node);
			}
		}

		configs.add(config);
		return configs;
	}

	private void setVar(Node config, String name, String value) {
		Node varNode = new Node("Var");
		varNode.setAttribute("name", name);
		varNode.setAttribute("value", value);
		config.add(varNode);
	}

	public void setTestconfig(Node testconfigNode) throws ParseException {
		this.configNode = testconfigNode;
	}

}
