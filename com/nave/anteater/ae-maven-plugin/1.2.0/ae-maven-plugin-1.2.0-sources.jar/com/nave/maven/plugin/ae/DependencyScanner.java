package com.nave.maven.plugin.ae;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;

import org.apache.commons.lang.StringUtils;
import org.apache.maven.artifact.Artifact;
import org.apache.maven.plugin.MojoExecutionException;

/**
 * Scans dependencies looking for tests.
 */
public class DependencyScanner {
	private final List<File> dependenciesToScan;

	public DependencyScanner(List<File> dependenciesToScan) {
		this.dependenciesToScan = dependenciesToScan;
	}

	public Set<Class> scan() throws MojoExecutionException {
		Set<Class> classes = new LinkedHashSet<>();
		for (File artifact : dependenciesToScan) {
			try {
				scanArtifact(artifact, classes);
			} catch (Exception e) {
				throw new MojoExecutionException("Could not scan dependency " + artifact.toString(), e);
			}
		}
		return classes;
	}

	@SuppressWarnings("squid:S134")
	private static void scanArtifact(File artifact, Set<Class> classes) throws IOException, ClassNotFoundException {
		if (artifact != null && artifact.isFile()) {
			try(JarFile jar = new JarFile(artifact)) {
				for (Enumeration<JarEntry> entries = jar.entries(); entries.hasMoreElements();) {
					JarEntry entry = entries.nextElement();

					String name = entry.getName();
					if (name.endsWith("Operations.class")) {
						String className = StringUtils.substringBeforeLast(name, ".");
						className = StringUtils.replaceChars(className, '/', '.');
						Class<?> clazz = Class.forName(className);
						classes.add(clazz);
					}
				}
			}
		}
	}

	public static List<File> filter(List<Artifact> artifacts, List<String> groupArtifactIds) {
		List<File> matches = new ArrayList<>();
		if (groupArtifactIds == null || artifacts == null) {
			return matches;
		}
		for (Artifact artifact : artifacts) {
			for (String groups : groupArtifactIds) {
				String[] groupArtifact = groups.split(":");
				if (groupArtifact.length != 2) {
					throw new IllegalArgumentException(
							"dependencyToScan argument should be in format" + " 'groupid:artifactid': " + groups);
				}
				if (artifact.getGroupId().matches(groupArtifact[0])
						&& artifact.getArtifactId().matches(groupArtifact[1])) {
					matches.add(artifact.getFile());
				}
			}
		}
		return matches;
	}
}
