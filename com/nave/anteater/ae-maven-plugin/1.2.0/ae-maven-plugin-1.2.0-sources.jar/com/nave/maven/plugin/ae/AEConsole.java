package com.nave.maven.plugin.ae;

import java.io.File;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.plugins.annotations.ResolutionScope;

import com.nave.anteater.TestRunner;

@Mojo(name = "do", requiresProject = false, requiresDependencyCollection = ResolutionScope.TEST, requiresDependencyResolution = ResolutionScope.TEST)
public class AEConsole extends AEBase {

	@Parameter
	private String[] recipes;

	@Override
	public void execute() throws MojoExecutionException, MojoFailureException {
		List<File> dependenciesToScan = DependencyScanner.filter(plugin.getArtifacts(), operationsDependencies);
		DependencyScanner scanner = new DependencyScanner(dependenciesToScan);
		operations = scanner.scan();

		Workspace workspace = new Workspace(basedir);
		workspace.loadConfiguration(true);
		workspace.setOperationsClasses(operations);

		getLog().info("Giant anteater searches for a meal ...");
		getLog().info("Loading configuration ...");
		workspace.loadConfiguration(true);

		try {
			workspace.runSetupNodes();
		} catch (Exception e) {
			throw new MojoExecutionException("Execution failed.", e);
		}

		if (recipes == null) {
			String sysRecipes = System.getProperty("recipes");
			recipes = StringUtils.split(sysRecipes, ',');
		}

		for (String name : recipes) {
			TestRunner runTask = workspace.runTask(name, false);
			if (runTask.getStatus() == TestRunner.STATUS_FAILED) {
				throw new MojoExecutionException("Status: Failed. See logs for details Reason for failure.");
			}
		}
	}

}
