package com.nave.maven.plugin.ae;

import java.io.File;
import java.util.List;
import java.util.Set;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.descriptor.PluginDescriptor;
import org.apache.maven.plugins.annotations.Parameter;

public abstract class AEBase extends AbstractMojo {

	@Parameter(defaultValue = "src/it/ae")
	protected File basedir;

	@Parameter(defaultValue = "${plugin}", readonly = true)
	protected PluginDescriptor plugin;

	@Parameter
	protected String config;

	@Parameter
	protected List<String> operationsDependencies;

	protected Set<Class> operations;

}
