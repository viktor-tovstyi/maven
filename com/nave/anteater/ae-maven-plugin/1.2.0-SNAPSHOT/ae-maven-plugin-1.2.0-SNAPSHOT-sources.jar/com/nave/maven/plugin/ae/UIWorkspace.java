package com.nave.maven.plugin.ae;

import java.io.File;

import com.nave.anteater.AEFrame;
import com.nave.anteater.ConfigConstants;
import com.nave.anteater.DesktopWorkspace;
import com.nave.anteater.util.xml.easyparser.Node;

public class UIWorkspace extends DesktopWorkspace {

	private File aeDir;

	public UIWorkspace(AEFrame frame, File aeDir) {
		super(frame);
		this.aeDir = aeDir;
	}

	@Override
	public Node getConfigNode() {
		return new Node("TestConfiguration");
	}

	@Override
	protected File getConfigurationFile() {
		return new File(aeDir, ConfigConstants.TESTCONFIG_XML);
	}

}
