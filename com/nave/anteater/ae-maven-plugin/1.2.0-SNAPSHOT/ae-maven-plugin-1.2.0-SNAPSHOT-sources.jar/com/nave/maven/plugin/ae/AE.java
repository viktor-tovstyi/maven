package com.nave.maven.plugin.ae;

import java.io.File;
import java.util.List;

import javax.swing.JFrame;

import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.ResolutionScope;

import com.nave.anteater.AEFrame;
import com.nave.anteater.CommandServer;

@Mojo(name = "run", requiresProject = false, requiresDependencyCollection = ResolutionScope.TEST, requiresDependencyResolution = ResolutionScope.TEST)
public class AE extends AEBase {

	@Override
	public void execute() throws MojoExecutionException, MojoFailureException {

		List<File> dependenciesToScan = DependencyScanner.filter(plugin.getArtifacts(), operationsDependencies);
		DependencyScanner scanner = new DependencyScanner(dependenciesToScan);
		operations = scanner.scan();

		AEFrame frame = new AEFrame();
		frame.getWorkspace().setStartDir(basedir);
		frame.getWorkspace().setOperationsClasses(operations);

		CommandServer.createCommandServer(frame.getWorkspace(), new String[0]);
		try {
			frame.start();

		} catch (Exception e) {
			throw new MojoExecutionException("Anteater failed.", e);
		}
		frame.pack();
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		try {
			for (;;) {
				if (!frame.isVisible()) {
					break;
				}
				Thread.sleep(100);
			}
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}
	}

}
